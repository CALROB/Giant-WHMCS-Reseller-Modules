Giant Reseller WHMCS module 2.3.1 for PHP 8.4

Use the release that matches your WHMCS server's PHP version. Check it in
WHMCS under Utilities > System > PHP Info, or with php -v on the server.

Upload both folders inside "modules" into your WHMCS "modules" folder:
  modules/servers/giantreseller
  modules/addons/giantreseller

The module's PHP is encoded with ionCube, so your server needs the ionCube
Loader for PHP 8.4 (most hosts have it; see https://www.ioncube.com/loaders.php).

You can edit the wording customers see in the lang/ folder and the client-area
templates in the templates/ folder of each module.

Setup guide: Giant-Reseller-Setup-Guide.pdf in this folder. Once installed it is
also in WHMCS under Addons > Giant Reseller > Setup guide.
