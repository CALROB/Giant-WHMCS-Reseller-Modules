{*
  Broadband service page. Built from the client theme's own components
  (Bootstrap 4 in Twenty-One, Bootstrap 3 in Six: both class names are given
  where they differ) and coloured by the theme: the chart uses --primary and
  --secondary. All wording is in lang/english.php.
*}
{assign var=tpl value="`$smarty.current_dir`/../_action.tpl"}
{assign var=page value="clientarea.php?action=productdetails&id=`$serviceid`"}

<style>
.gr-bb .gr-stat { padding-top:6px; padding-bottom:12px; }
/* Badge colours from the theme (Bootstrap 4 variables), with Bootstrap 3 colours where they are missing. */
.gr-bb .badge { display:inline-block; padding:.3em .6em; font-size:75%; font-weight:600; line-height:1; border-radius:.25rem; color:#fff; }
.gr-bb .badge-success { background-color:var(--success, #5cb85c); }
.gr-bb .badge-secondary { background-color:var(--secondary, #777777); }
.gr-bb .badge-warning { background-color:var(--warning, #f0ad4e); color:#212529; }
.gr-bb .badge-danger { background-color:var(--danger, #d9534f); }
.gr-bb .gr-stat-label { font-size:12px; opacity:.7; text-transform:uppercase; letter-spacing:.03em; }
.gr-bb .gr-stat-value { font-size:20px; font-weight:600; line-height:1.3; word-break:break-word; }
.gr-bb .gr-stat-sub { font-size:13px; opacity:.75; }
.gr-bb .gr-key { display:inline-block; width:10px; height:10px; border-radius:2px; margin:0 5px 0 12px; vertical-align:-1px; }
.gr-bb .gr-check-result { font-size:13px; }
.gr-bb .card-header .btn-group, .gr-bb .panel-heading .btn-group { float:right; margin-top:-3px; }
.gr-bb details summary { cursor:pointer; }
.gr-bb .gr-journey li { padding:3px 0; }
</style>

<div class="gr-bb">

{if $gr.restricted}
    <div class="alert alert-warning">{$lang.bb_restricted|escape}</div>
{/if}

{* ---------------------------------------------------------------- status *}
<div class="card panel panel-default mb-3">
    <div class="card-body panel-body">
        <div class="row">
            <div class="col-sm-6 col-md-3 gr-stat">
                <div class="gr-stat-label">{$lang.bb_connection|escape}</div>
                <div class="gr-stat-value">
                    {if $gr.online === null}{$lang.bb_unknown|escape}
                    {elseif $gr.online}<span class="badge badge-success">{$lang.bb_online|escape}</span>
                    {else}<span class="badge badge-secondary">{$lang.bb_offline|escape}</span>{/if}
                </div>
                {if $gr.online && $gr.online_for}<div class="gr-stat-sub">{$lang.bb_online_for|escape} {$gr.online_for|escape}</div>{/if}
            </div>
            <div class="col-sm-6 col-md-3 gr-stat">
                <div class="gr-stat-label">{$lang.bb_ip|escape}</div>
                <div class="gr-stat-value">{if $gr.ip}{$gr.ip|escape}{else}&mdash;{/if}</div>
                {if $gr.static_ip}<div class="gr-stat-sub">{$gr.static_ip|escape} ({$lang.bb_static|escape})</div>{/if}
            </div>
            <div class="col-sm-6 col-md-3 gr-stat">
                <div class="gr-stat-label">{$lang.bb_plan|escape}</div>
                <div class="gr-stat-value">{if $gr.plan}{$gr.plan|escape}{else}&mdash;{/if}</div>
            </div>
            <div class="col-sm-6 col-md-3 gr-stat">
                <div class="gr-stat-label">{$lang.bb_uptime|escape}</div>
                <div class="gr-stat-value">{if $gr.uptime && $gr.uptime.pct !== null}{$gr.uptime.pct|escape}%{else}&mdash;{/if}</div>
                {if $gr.uptime && $gr.uptime.drops !== null}<div class="gr-stat-sub">{$gr.uptime.drops|escape} {$lang.bb_drops|escape}</div>{/if}
            </div>
        </div>
        {if $gr.can_reconnect || $gr.can_line_test}
            <div>
                {if $gr.can_reconnect}
                    {include file=$tpl action='bb_reconnect'}
                        <button type="submit" class="btn btn-default btn-outline-secondary btn-sm" onclick="return confirm('{$lang.bb_reconnect_confirm|escape:'javascript'}')">{$lang.bb_reconnect|escape}</button>
                    </form>
                {/if}
                {if $gr.can_line_test}
                    {include file=$tpl action='bb_line_test'}
                        <button type="submit" class="btn btn-default btn-outline-secondary btn-sm">{$lang.bb_line_test|escape}</button>
                    </form>
                {/if}
            </div>
        {/if}
    </div>
</div>

{* --------------------------------------------------- installation progress *}
{if $gr.progress}
<div class="card panel panel-default mb-3">
    <div class="card-header panel-heading"><strong>{$lang.bb_progress|escape}</strong></div>
    <div class="card-body panel-body">
        {if $gr.progress.tracked && $gr.progress.journey}
            <ul class="list-unstyled gr-journey" style="margin:0">
                {foreach $gr.progress.journey as $step}
                    <li>
                        {if $step.state eq 'done'}<span class="text-success">&#10004;</span>
                        {elseif $step.state eq 'current'}<span class="text-primary">&#9679;</span>
                        {elseif $step.state eq 'bad'}<span class="text-danger">&#10006;</span>
                        {else}<span class="text-muted">&#9675;</span>{/if}
                        {$step.label|escape}{if $step.date} <span class="text-muted">({$step.date|escape})</span>{/if}
                    </li>
                {/foreach}
            </ul>
            {if $gr.progress.took}<p style="margin:8px 0 0">{$lang.bb_took|escape}: {$gr.progress.took|escape}</p>{/if}
        {else}
            <p class="text-muted" style="margin:0">{$lang.bb_not_tracked|escape}</p>
        {/if}
    </div>
</div>
{/if}

{* ------------------------------------------------------------------ usage *}
<div class="card panel panel-default mb-3">
    <div class="card-header panel-heading">
        <strong>{$lang.bb_usage|escape}</strong>
        <div class="btn-group btn-group-sm">
            {foreach $gr.ranges as $r}
                {assign var=rangeKey value="bb_range_`$r`"}
                <a href="{$page}&amp;usage={$r}" class="btn btn-sm {if $gr.range eq $r}btn-primary{else}btn-default btn-outline-secondary{/if}">{$lang.$rangeKey|escape}</a>
            {/foreach}
        </div>
    </div>
    <div class="card-body panel-body">
        {if $gr.chart}
            <div class="small" style="margin-bottom:6px">
                <span class="gr-key" style="background:var(--primary, #337ab7);margin-left:0"></span>{$lang.bb_download|escape}
                <span class="gr-key" style="background:var(--secondary, #777777)"></span>{$lang.bb_upload|escape}
                <span class="text-muted">(GB)</span>
            </div>
            {$gr.chart}
            <div class="row" style="margin-top:10px">
                <div class="col-sm-6"><strong>{$lang.bb_total|escape}:</strong> {$gr.usage.total_down|escape} GB {$lang.bb_download|lower|escape}, {$gr.usage.total_up|escape} GB {$lang.bb_upload|lower|escape}</div>
                <div class="col-sm-6"><strong>{$lang.bb_daily_average|escape}:</strong> {$gr.usage.average_down|escape} GB {$lang.bb_download|lower|escape}, {$gr.usage.average_up|escape} GB {$lang.bb_upload|lower|escape}</div>
            </div>
            <details style="margin-top:8px">
                <summary class="small">{$lang.bb_show_table|escape}</summary>
                <div class="table-responsive">
                <table class="table table-sm table-condensed table-striped" style="margin-top:6px">
                    <thead><tr><th>{$lang.bb_day|escape}</th><th class="text-right">{$lang.bb_download|escape} (GB)</th><th class="text-right">{$lang.bb_upload|escape} (GB)</th></tr></thead>
                    <tbody>
                    {foreach $gr.usage.days as $d}
                        <tr><td>{$d.date|escape}</td><td class="text-right">{$d.download|escape}</td><td class="text-right">{$d.upload|escape}</td></tr>
                    {/foreach}
                    </tbody>
                </table>
                </div>
            </details>
        {else}
            <p class="text-muted" style="margin:0">{$lang.bb_no_usage|escape}</p>
        {/if}
    </div>
</div>

{* --------------------------------------------------------------- sessions *}
<div class="card panel panel-default mb-3">
    <div class="card-header panel-heading"><strong>{$lang.bb_sessions|escape}</strong></div>
    <div class="card-body panel-body" style="padding-bottom:4px">
        {if $gr.sessions}
        <div class="table-responsive">
        <table class="table table-sm table-condensed table-striped" style="margin:0">
            <thead><tr>
                <th>{$lang.bb_started|escape}</th><th>{$lang.bb_ended|escape}</th><th>{$lang.bb_duration|escape}</th>
                <th class="text-right">{$lang.bb_download|escape}</th><th class="text-right">{$lang.bb_upload|escape}</th><th>{$lang.bb_reason|escape}</th>
            </tr></thead>
            <tbody>
            {foreach $gr.sessions as $s}
                <tr>
                    <td>{$s.start|escape}</td>
                    <td>{if $s.live}<span class="badge badge-success">{$lang.bb_connected_now|escape}</span>{else}{$s.stop|escape}{/if}</td>
                    <td>{$s.duration|escape}</td>
                    <td class="text-right">{$s.downloaded|escape}</td>
                    <td class="text-right">{$s.uploaded|escape}</td>
                    <td>{if $s.reason}{assign var=reasonKey value=$s.reason}{$lang.$reasonKey|escape}{/if}</td>
                </tr>
            {/foreach}
            </tbody>
        </table>
        </div>
        {else}
            <p class="text-muted">{$lang.bb_no_sessions|escape}</p>
        {/if}
    </div>
</div>

{* ----------------------------------------------------------------- router *}
{if $gr.router}
<div class="card panel panel-default mb-3">
    <div class="card-header panel-heading"><strong>{$lang.bb_router|escape}</strong></div>
    <div class="card-body panel-body">
        <div class="row">
            <div class="col-sm-6 gr-stat"><div class="gr-stat-label">{$lang.bb_router_model|escape}</div><div>{$gr.router.model|escape}</div></div>
            <div class="col-sm-6 gr-stat"><div class="gr-stat-label">{$lang.bb_router_uptime|escape}</div><div>{$gr.router.uptime|escape}</div></div>
        </div>

        {if $gr.router.radios}
            <h5 style="margin-top:6px">{$lang.bb_wifi|escape}</h5>
            <ul class="list-unstyled">
                {foreach $gr.router.radios as $radio}
                    <li style="padding:4px 0">
                        <strong>{$radio.ssid|escape}</strong> <span class="text-muted">({$radio.band|escape})</span>
                        {if $gr.can_wifi}
                            <a href="#" class="small" style="margin-left:6px" onclick="var f=document.getElementById('gr-wifi-{$radio.instance|escape:'url'}');f.style.display=f.style.display==='none'?'block':'none';return false;">{$lang.bb_wifi_change|escape}</a>
                            <div id="gr-wifi-{$radio.instance|escape}" style="display:none;margin:8px 0 4px">
                                {include file=$tpl action='bb_wifi'}
                                    <input type="hidden" name="instance" value="{$radio.instance|escape}">
                                    <div class="form-group">
                                        <label class="small">{$lang.bb_wifi_name|escape}</label>
                                        <input type="text" name="ssid" class="form-control form-control-sm input-sm" maxlength="32" value="{$radio.ssid|escape}">
                                    </div>
                                    <div class="form-group">
                                        <label class="small">{$lang.bb_wifi_password|escape}</label>
                                        <input type="password" name="password" class="form-control form-control-sm input-sm" minlength="8" maxlength="63" autocomplete="new-password">
                                        <small class="form-text text-muted help-block">{$lang.bb_wifi_password_hint|escape}</small>
                                    </div>
                                    <p class="small text-muted">{$lang.bb_wifi_note|escape}</p>
                                    <button type="submit" class="btn btn-primary btn-sm">{$lang.bb_wifi_save|escape}</button>
                                </form>
                            </div>
                        {/if}
                    </li>
                {/foreach}
            </ul>
        {/if}

        <h5>{$lang.bb_devices|escape}</h5>
        {if $gr.router.devices}
        <div class="table-responsive">
        <table class="table table-sm table-condensed" style="margin:0">
            <thead><tr><th>{$lang.bb_device|escape}</th><th>{$lang.bb_ip|escape}</th><th>{$lang.bb_via|escape}</th><th>{$lang.bb_active|escape}</th></tr></thead>
            <tbody>
            {foreach $gr.router.devices as $dev}
                <tr{if !$dev.active} class="text-muted"{/if}>
                    <td>{$dev.name|escape}</td><td>{$dev.ip|escape}</td><td>{$dev.connection|escape}</td>
                    <td>{if $dev.active}<span class="badge badge-success">&#10004;</span>{else}&mdash;{/if}</td>
                </tr>
            {/foreach}
            </tbody>
        </table>
        </div>
        {else}
            <p class="text-muted" style="margin:0">{$lang.bb_no_devices|escape}</p>
        {/if}
    </div>
</div>
{/if}

{* ------------------------------------------------------------ line checks *}
{if $gr.can_diagnose}
<div class="card panel panel-default mb-3">
    <div class="card-header panel-heading"><strong>{$lang.bb_checks|escape}</strong></div>
    <div class="card-body panel-body">
        <p class="text-muted">{$lang.bb_checks_intro|escape}</p>
        <ul class="list-group" id="gr-checks"
            data-url="{$page}&amp;modop=custom&amp;a=clientaction"
            data-token="{$token|escape}"
            data-running="{$lang.bb_check_running|escape}"
            data-run="{$lang.bb_check_run|escape}"
            data-good="{$lang.bb_check_good|escape}" data-warn="{$lang.bb_check_warn|escape}"
            data-bad="{$lang.bb_check_bad|escape}" data-neutral="{$lang.bb_check_neutral|escape}"
            data-failed="{$lang.action_failed|escape}">
            {foreach $gr.checks.readings as $r}
                <li class="list-group-item">
                    <button type="button" class="btn btn-default btn-outline-secondary btn-sm gr-check" style="float:right"
                        data-section="{$r.section|escape}" data-key="{$r.key|escape}">{$lang.bb_check_run|escape}</button>
                    <strong>{$r.label|escape}</strong>
                    <div class="gr-check-result"></div>
                </li>
            {/foreach}
        </ul>
    </div>
</div>
{literal}
<script>
(function () {
  var list = document.getElementById('gr-checks');
  if (!list || !window.fetch) { return; }
  var d = list.dataset;
  var badge = { good: 'success', warn: 'warning', bad: 'danger', neutral: 'secondary' };
  function esc(s) { var e = document.createElement('div'); e.textContent = s == null ? '' : String(s); return e.innerHTML; }
  list.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('.gr-check') : null;
    if (!btn || btn.disabled) { return; }
    var out = btn.parentNode.querySelector('.gr-check-result');
    var body = new FormData();
    body.append('token', d.token); body.append('ajax', '1'); body.append('giant_action', 'bb_diagnostics');
    body.append('section', btn.dataset.section); body.append('key', btn.dataset.key);
    btn.disabled = true; btn.textContent = d.running; out.innerHTML = '';
    fetch(d.url.replace(/&amp;/g, '&'), { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (!res.ok || !res.data) { out.innerHTML = '<span class="text-danger">' + esc(res.message || d.failed) + '</span>'; return; }
        var k = badge[res.data.state] || 'secondary';
        out.innerHTML = '<span class="badge badge-' + k + '">' + esc(d[res.data.state] || d.neutral) + '</span> '
          + esc(res.data.summary) + (res.data.problem ? '<br><span class="text-danger">' + esc(res.data.problem) + '</span>' : '');
      })
      .catch(function () { out.innerHTML = '<span class="text-danger">' + esc(d.failed) + '</span>'; })
      .then(function () { btn.disabled = false; btn.textContent = d.run; });
  });
})();
</script>
{/literal}
{/if}

{* --------------------------------------------------------- content filter *}
{if $gr.filter}
<div class="card panel panel-default mb-3">
    <div class="card-header panel-heading"><strong>{$lang.bb_filter|escape}</strong></div>
    <div class="card-body panel-body">
        <p>{$lang.bb_filter_current|escape}: <strong>{$gr.filter.label|escape}</strong></p>
        {if $gr.can_filter}
            {include file=$tpl action='bb_content_filter'}
                <div class="form-inline">
                    <select name="tier" class="form-control form-control-sm input-sm" style="width:auto;display:inline-block">
                        {foreach $gr.filter.tiers as $t}
                            <option value="{$t.key|escape}"{if $t.key eq $gr.filter.tier} selected{/if}>{$t.label|escape}</option>
                        {/foreach}
                    </select>
                    <button type="submit" class="btn btn-primary btn-sm">{$lang.bb_filter_change|escape}</button>
                </div>
            </form>
            <p class="small text-muted" style="margin:8px 0 0">{$lang.bb_filter_note|escape}</p>
        {/if}
    </div>
</div>
{/if}

<p class="text-muted small">{$lang.refresh_note|escape}</p>
</div>
