<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtppdxrfHMIoS4aAdh8jMPrsp8ilmtfoBEHFH9oB6woeSxdoNwtGIhYHeaAVA32XG39JmSDE
kN4OK9ZnSoZp73NUwk+VZ+6VNnHcEDE7CJD9NvGE+/8xXDB8oUtTa4i2vZLFvzg2qMV/QBPiXzuk
O9VGm0Z5oG2+7g/AoSAQA3sUmowwq483B4u52D7zOfoH0K11XCbZXGz6uHmJCV9jGNa+FsO5Evjv
PCjV1UjmHInnCNMquJwnacpJ9G6LhOuZ0vPv95R8kPm5K5kddTXMm1rZ3xAfEr6dy6VjWmtI3Qei
pf80d7n4BNMWln6X1n5z5U8qGTXsuXo0nYKTQffOShCYR3id9kPxVHSBOWKrH5hjfSPaBPs3vWBq
iVMoMheqYXWwb8FRTFQ6E9ZhGePql/V6jlmWv59ohjLpajFrsRaYvdhYPq9WpWhsCwiKU/+RydML
JyLWNuTxp9bz5QKACrQLNtsr8rd7clB55kiWEgex6qonhIcMEh57HBEgz8kcDAT+waMCc+qXD9Nk
S0DQTTcGiW8ksFXiH+JAMpFeXUsRm4dNYtBMuynMEWdsGYckEE1WOQ+WQY/iQRLKRRNg9WpSleBZ
CYkOJSUk6LRnv5QSd2Q5d+L7do594CmTgaRjxUWVvbvS07taiHR4m78NYGvNFSgM+qes9+M1Bky1
yxgMahCmX5goYxdHlpYA1cOMMKTnPuLyHzeQRLqwg3MTaKz9wo+ApsresSor+SK0VS5pjzgB7i9f
WsTe+/bKNCyv2sXMdpinV/1RWMKm/sUAJT1ULDctuj+I9OWwWCc/AhVL+mOGXHu9RN+lrhUm+pT8
hfELCUvnIujRcXLyuMC4sQi/isvB61a7pYxsvbKSgWc1yjda7Ej6OxLckTpMqkzqCYO73BRlyYEX
4ma0518qmY8AozvIH8qa38+AWdxtdKWcDD90RpJKpGXR/hP80DpZv8WVdqHPovexC8BvXPVY2cT1
DBKvnldjVybqQ18j6YLixu5FgYv+LeO40aQqSWnhPG6hE7JqIuxdroHm7msFd/s+NPUQQA13tlKv
9b6Ts9YIK/TuK+algVla2/0rrIoTiYiCcWhLE3yh2beIV0Sa28X99+v3r8JlFpvIqQRQdY5u2GnY
PsiKCOfym9WbRHi0Dx9fZMEAqfwt42AtP8R+pqc2RaSMVUuLJxcYmq0ATG==