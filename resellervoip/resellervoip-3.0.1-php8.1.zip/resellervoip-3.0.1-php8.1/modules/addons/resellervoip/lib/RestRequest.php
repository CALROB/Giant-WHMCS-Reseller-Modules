<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw45RBVSqrIvdR/vb0C1Ofov21V8reO/QRgy0PoQGp66X9wXdz6PbauS3d2SM+uA0CMCYTZY
GuW4OQFcMwA3hEm0VCaqCO0T1EsC1/ORNbaDzulXDSpv7Y2Nq25YAltsPHCaJHoF4oNl2cDHOjqQ
CbzwXB60c87ZOx1JZ77oI1gYyuJj2/22RqHJDIAM2xMLyDJFP2lbh1tWE9oKQRGptl134oHMj4m4
VwDHl8sfw0B9eN354dxflaaIsU29YXLPGFTni8ZM90LGMwUTs5R07MCFigaxKQTPPtjiLZMMQp2A
vwgSV3Wj1FzU4K50fp2IxKsxoqsUShmQ6P3o5VHmo7jltFB4UrJa1uUwKnIzIQpbSOCoxhCDKYcW
B7nkXCYVME6FzPGAfsFu5DJXUQPC2qsTJSNvQDinth3nxoaZQQUEbtmnlvd3nROvtV4QlX1klKG/
1LKNpRAW5kacwG0GEzmK2elX/nfI0qwiSFtS90YSCSx5orSc0DYKGStEyPRDByZoKW606xDLmj1M
UMX4VU5QMbrPVwTlFychlmY5R67vOkMuq7YLSRAQp1FX+eSSf12h5gEt/8hUlSnQqP6dOQvXlnh5
SUn0p1Jc+uBhq5Y+6zL3l1oGQUOUoDkeLTNmdwKWTIjoXBuN/vX6cgAyqzlQS6hStozq/jAMUlZm
Pb0rJWRN6tVqYngVY7IWwU5mbkmuuRagPaA7kHdMIgfGs35XwcgmNmAWf44mYnH9lT83JlSDxwHL
WVPsnYG/e4GYL23cM6jx2EUCJyaCoPCQg8t3Lkpl6lb0rMguSco1qE6u5KXeG+Tp5v4mJNEMD8Jm
RK2n4uiHFwwx6Wg/u2DoyRbPxhzRBMg736r0puFFXS9oEAoW4+dFCNDFwv+FzpXlmqT59aaueSMv
YbzsBtcL4rTBR310/DtuvLT+ZUpofiAg8ZCDYOHj+0SJzlDHogr/DmQpq6+0gR7gfDZyVS9nMruO
odDe5TRg218F6zoVcxS2s2QBIixsTMPQajL+MQZVQ61zpMmKo/1RLgJsxbkFkt5OWdU84G4CzbMu
8L83aiIeqSROpgtuxD6EIsgkg7b+9H8zCT4n4RrSO1qEimjiHtJo75h/BWcdW/aHs6y+EAlAaWPp
lanhdk1VBymA/65Brda6IVfE0EvG5RwfsL3B8QFn2WiVvmAmgbNgucDDwyzHp8PSn+zgRDK9f95Q
5Qe=