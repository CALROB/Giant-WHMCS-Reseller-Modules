<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsanJbp86xEJaOVRVrlLc9fdpwRwOKJmlVfivaTQm34dnuFiouSaGF2Qe4b/eY9pv0DbxFBe
YUVh3z+A6592arkRg2ZJLpV/1qXIlqj2FmHZh0Qibp7h3klxHsHRN2TxpnuY+1PqDfuC/MTSAT+D
cs852metmm6QU0m872/QjwcsPDbtVRPNeqyCA8YG9KjE5f3+wAd+dMV/KdiNz/KiNA+w7y9Q48Rv
NY2mDoDW4BdwCcBMduE4RAd2CBZcn3v+q2P4MrAhgz85K5kddTXMm1rZ3xAfEr6dd6WL6gDk3CF5
mq0iR7z4BHZ/y7HY9RpUtmSrjEAgEznu6hmJI0924PW5rFv7LbOY4kKDKMbEAKmGK9OYLp9UpV5T
+mH6XWvuRBU0DfpT3GrCProF5WW9KTCGM5cj7nR/jxS6gME9dfktiF9vkNn6hqfXqk83J64YsWeH
aW82yp7dDoAo/Tl/wOEhulMXu9mmLUzJW85oA+8rxRD4c4I0+hVCW+TkptYesDHxBi86XAdJOvqL
A5eSSHhyKht2+7s1VmoVSbaW2CANC5DZ4Dn8tUfT3JkKjS1Fdi1yC7OZYFO6LCB6fDXduWMKQ2Ps
n+S4Wt3kDTjbQ4wqAJzLOm7BnU0WBX4m0ajROK2g7XPO0/5DUHNBE9NeXXi5GK1HANnqcX2SStix
Z9oPamZf66K+NCEQTNv9r+HUSR6IzQcJvKzAIF4ivUma8HQwzh9S+F2DwuhgfexkrxYYzXrCQCCw
qRp6X4Fzgp/CqicDhMVO5a8KjZJdVcVet0SVUNiHJYkG4CfjjXpt0ePuhmLbn0T3mkgb7rlUC7SO
oku+47qd81L4+xzlV42Q9+iIV34PTMwMyWim0lajXPcFF/B8njyO+roTojQZm3TIeP8m6egEvzHI
BGR0VrKkcUbe5mnOmV7ABqdZeXwObpPa0lxhKHSnbyrLaeGJBsUATc9Z8/1+sWrK+9pWpJqWYKVK
4973yh/POWidE+ry/p7wDPXjf8ViJ1s/adABQdQNpCLt4kUSOFSP2SvZmxSKubWJUHO+eUmumM2h
Q+EZhruc23H3XzDRJTo4xEAGVAQxy8hDrEQfrXR6MfBKNbu/3UDdR3H4VkwfhEba4CcyFhu84pMr
TeWHYgHx1n7ytQXwJIpPYzffFp23kM+XjRZVJmEFX3EgA4L+ygN6hoTPJzTjylapkUngwP7bpNt/
Jf1oShRldx9+l5XotHav45nU6182pyy3bQSIDrl4Z+hHRfsV0Oav1ICpYFl7des3aukzIcoC89Km
Vj53o+iNEgkS17Fj8Y1HiCownYv00UOEd9ffSxFWuvZMRcu7ZkVfycanbi3d4JTc8u++s/So8Cxd
cv2/gcTNGUdsxn121M+Vw9nv5OTz/gJoM/CenXgAObGUPuc+1K+6ie1jWRgsq9XwC6AliqHuaKvZ
tIHbstl+JGOw9VkxoL5OXPw1144Cy2+YT2rHdPqOp8wOVdGRiWUAXvbr12sBzEl83FqS7/j5qmF+
/KwyXGr3VKYsL4wBzBneQNjrH1SVpB48ANqiE4nniOAp/dwFjQu1l3Iczo/kyowIz51FfPKnsPNM
RydkRAr8B59Ex8j1WT8e+Sjqgyapxlqa27haAHRSLScj4HT1pTyCa9ZdynLK5/gGg3ctSMOuWX8M
7oZPEYDEnuWbrjha1Hl7vg/4LVzRM8nv5IhqkUD3deH4bcuBtRbo9PzoWnHAmxhLiBgAztfaLzfU
///Kb3Uc3+lAmO/KbnpjGxjJK6lG5YhgDPVy4b8wy6GDGqV0PH0U5gB6sQWnclH6Vr0GqDCSIqM/
x/z1tuS6J91SmbtRIkfzh/3ADhnvC33fSXZ70Ym4XGewIRsHxyDn3RBBOB59Lw6mGlaDkwHx1sAy
MGSnXXcQctfEdizbpASCjFTsisREBy8pfequxhzEZG/+AVFkDVhYXNARIH/ie1K7bWLTbzucFw+H
tGyAYFPL+74AV/SFxM3YVRi5Yq3QS4iGVxVmhKM7amsC0XQmUOZBqixx2tAI+Dju5YMZEncrQfAC
EFCEkBiwOTaGaUQi4pAOHNEyFVTPiMZAEVBv92z3iinO76X/aPHbp0LSCyeWo3q2CSVpEotfQ7sv
5Kl7biCGnSUXvrDkM3sGBazCVEkuQhNu37eLF+N63NpHatoBtSX9xOb/DDDxPEBKj/Re0fGNHM5Z
q1x37LemlnJtQEbQ0ATtcuOekkMI5MlyIAoNt/AL/yjLgglLUpj6jt8rvshtgGhJksEnkaiPZbBW
k6KHie0MMAeRpk/WZR5NnfrkRYGQD+xmiiDWULCOffaTX4UcxEv9KW==