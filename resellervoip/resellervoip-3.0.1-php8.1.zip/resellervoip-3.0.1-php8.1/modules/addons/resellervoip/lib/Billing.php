<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoN1ClYGAOV/TsbqfzjjlnxCdEPx2ZswWvky1jwpqeJVAaoea/40WHj295JgPuy7iSAlk1o/
GSO8wHUMEHYvBlKQHAtbGK741lP/bBnTYHMxi2npgYtdZYtxqGbNvrd/RnVyIRxJKRbSrmgxEoG4
XHwltuIfmmNx+h0WdPa9aKCW4IXA2ngbep4SqUmJLthJT6T7cv158K5DzyDxSzBXTF6dmQwpOggZ
5OehSPOI50RBLze9nHHbB0fa6geECBF/mWV1D8jT/0LGMwUTs5R07MCFigaxKQTuPWXbemEfHzAd
TFsS/48jScVigRCM0NPUOujbjhT0956UE3rbLHXeJQ0T+VbcBRTB9oywfWFjjbMgt32Tty8nX40f
z9oWyYWw0r5bXgaGjuXxCKRsLak1CcAvS0fuEJSG6CFj0Ac0YioCMagGuw0Va6MveTpz3txEadaz
UtOauYfAzhs75TV0coJCXY8sBFPPXqrIZxH5Y/6i0tg2qKACA3KBD9725p2D9AuDmRvK8QffJZfv
4M8akG/LzExGaez7PdlS5c1+TUjvPAmfIDe3NuznTYm6XuBS5tww/P50WqLRtMEwspeJKEaI0C2r
LCPHZWXf5S5Pq9rV0HjSxvnlh6Zo+GNsuv2DoUUQn4U3OsROdFwc/Fej/pFZQeiDU+VUNBsfRCRh
hoIWz5R5rcbmXjMNvXvwb4JOPNwIVgGX99Nxe94dyxKF9vmnxrXaaTrrnZf2G3sUGmKQZdL6gXpo
fQzt5FGk1Xghi3WJ1S3bYTknMjKth6fZDaKWv2fWV7dB3fO94844LB/RYxNLG7G6M7Z1Txbf7Rr8
y4RxwklyLoU/8y/59RkQ1AcIBLnsRAacmcC+mTv2xZLmXEZQ8c64jkd77o3QBBkz+MR/5yN3o2FE
dZOG5533bRJ8RFZwZXHJ/SO3Ik4r5Vm+YN/piLd/cD7XFsPDAHRRvLjqK3V6dcStNOFt7aWE516y
Yyup/dqGymemDcERB2V/Or3M6+TPKljMJKCfCqzIQccGC4LFXficcbz4fORimjBjhmhTn5zBKg7E
Jqp5HHkY6dsy5s4muBAvolD4T3zrmjzdLKT8lHpzEA1XTR0qwiBr1vzFZ2q+NHeE/gPw/Za0KxLT
7kvx/NFobAjnrOz3wSPVkH45+p2TirGOiDuDqH8iDqgWM002geiJVg/HJW4s4HEUuRcUwMlZI/p+
SLVQNsp97eZ7gR7RzF5cSHYf6rkOu4GA6c/dOqJRnGRnxa00YT8cI/2kK7hGUD1pQDtKyaBjrttD
VekTGnyR8sOTEb4rl8FCxlGEYhBZWlwHbwCK9Aki5eqPMVQgehZR4AdpEEZt8sBsco5XheUiCrfF
LJr52TQSLBO6bfE9jCTr323AyB/TQyFA9Hr9mwuEm3XXQjgkksbzgxfbE4Maiu0Oum8xCOmo1Qok
rNbzgCOg494aDQfKnIohbUpNI5J+OFMrhB5F3CYEdmjfN9U2fLn32H1oH6w0iyY4730D0Y2LBnrb
lWXdbe9JxNVNktp/E1shwhvt+CSDZFhT39lNYBh3PrOtlrETfMK9SzuQOOqQqYm/brjZzMjKxP5x
aAmVBJSueekODGqtlfRp1M48V9JWC+FiImrO77vc1UFVFZWXyDQ/66nA96NRqIT7c7fy5iO8y/Hx
9EwbkFE+7yVWVhbxXy8KfQaa0h09XFrHxYB63cvpZIPRDrS+VEcvoADuQHfMoMLpNBT/BVlAbHab
qQfAI219fLdkeww6EXoBl+u+9drrdr73KWfjUHEt45A0CsxOkk6uBaXCjnCA8lDj7ozXVZQ/ubSd
Z72p6fuM0x+C9jpyUnPHZiumBFsHXnY9ZN996Whph6HOkvGreGT63VCbu/w5SZVNdhOoYPQ/+x+M
9OUlAgOuFvMk3Pf/S1yYzbGLwfYf/TUx0YK7gGU//8kcSXQbIdRCvmnx42G3d7Bwge9kmTqpUo4K
ZMrI7dOCsa+FNXmo8+LWwUaEoJ24Zn8Qf9FtcyMbRJKIKfsHEJ0DN4X1dfdsobwsKirQfs0ZHY4v
Ck+nalP6D3qUz6kwiSJ8+qgRRgc+OzpzxDun+xPdJGs0W2iMic9hUCClXdqww+xSwE6LLp5fWU4I
qhuJc14P