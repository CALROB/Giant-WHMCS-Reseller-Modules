<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnzXX5YCoNoVJTGHUpH1L/m5hY62FQmsh86y1dNXzHIsLlmdURqcmwKk4B29uHPg09LjCHsf
DKB1eKgvHJ89ChOl11y9xfK10SDpooVJVXUAuJ1O166EBBck9AF1NGsVOt5STexsNgwMyo9fzYFV
auqHt+c9vpeivhUerhTZj0KS092K6SgX2Pvjbztd1cZ6o/OANYy+RE8TmiwDf9SqTfUrJ05IcUQ+
V9Aj7yOBKpJCmNWLO4sc16qqeTi6xWJqGCw1UvOAYBGw6CMmaO1nAOn3sOv2UR3DOu/z3rzI5iBN
bXRC/LjDKF/eU5Le6LP1wzCbLCt6ZxI71DLh9ISJ+N+ZkdPXcypEy1JPUW1IUmfIfkT9aIJ7SMKv
HMlKeeQ6xyw8QLB3UKLLvqWuViKP4TB8Jdkq3dZbnP4pVDorTbhghlBGFlNjSpEmTJaVWihs9S+P
UpV/az6ls8gMFzEUtsJo0dvZqNVyJ5OSYxEcpf3w9FH1Fl0Nd0TihZwy2NdsOpwiel9VOEdC9xTq
A/gvIjdhZIHLcSEmjbzem0aJvdQ+/mL8SEbF/bHKWXAJt/bVXFYAUdYz1QcZ0J2QX4OGLA/ZHKVj
rSdz4/YBvkIfx/yrNhNfK5DI9Xqzg0DOJhaXlPuUfjc/boOV/pNSrXQPLKJSHOm/iKbnrvLpvf+/
mmFZwBinCQpW2nm8KiF8iVHZZO8K+m43VE//OFuKK9FtqEVza6GfYK0KdjRd6p3/BnIwbnoEi/Bv
ovawSqVQY4W9JrcKrqlr0ZGwBTzv+g2FyIBeMCY2HoOoPF+MMQ3IWSXgFITDGfyTDDTpApCzqD2s
T7xP6J5ooPIhUwO4wBUe6r/YJ2Qkkx6iAJQs/s5FJtbf9onG2DkFJ4ftiVWA9jNbPhLzkfXgHKFB
jtXxSAqRf3Akqjj7aExoT0espCaS999JHCdzXq+x+UOqTAoHBe9KySWFtq7ASAgNyskX7Hh1dORq
zGbMU921sMZ/4iOxC/STCjF9X5Ihex1XFb8N4JDwYaq/TyTZvOAzSJJ1rR1/8E7P2GRDGWvfgw2y
ENGCk0WcSeqKs+pPuZ9niGb2SmYGjCXmko2NxgW8X85UcZsX7EEVFVWI3lX6yicmAuCatPfq1Y0n
O+lTtml+HXNRa5iO8VqsfHXbMR7rvfHQ1mrVriNflLYm0bDiMowwEfPwgdMuqqxze0bF6R8q6mE+
UH+pbn2ytaF12GwCVtilk1qpYTT0Eh5mGmfQP6uQ6VJWNu1mBnvMrS/pliQolORl2PycP1J0s/6q
Dhtsjrjaw8nIVdVIpfG3QKB/+5h6IWQ5onV8MOdNrbUE+7VdCioXTb5F249/gdE1N1FMwGbeSoiv
IqzkLV3jBojLY7+BzWbs7wvhSYzyP/AULR5uIj+1j2pQWwYyyNf6DxHlKbm4hGGKJmtGhAdY4t3C
XyvJmo6Az4/om59EsVxHu1NkbzzxX27Nwf4oeIprQd9D0N1wpQtqvPqkUmtM9yDXUJJ8fQKcCkAR
t1WPIucAw+RUgMGEhKzk4jIrxQ0PoIQFFj+3ns5T4jbNpbdWxbiTy6ktuIBGZjp28vsH31ZQXq+p
46awaPzafmwb9KD+kHUIUnioRI/VEe2TbFxqy+0t6JaKBGUrGQ3i2nQDMVP2iLljH5u7coHSQXbi
42I1K6gEvf6/5ROYR9UR1ExtYVphU454d3JlnRwxOBHVd7khNb1smQxlFw0PT/AZUvCK4TB3/ei0
91pjoylLIc0fIuRcHV6rVE6oPfSpGwsh5ygbfKZp8+Uz4i6fvkpvtTcpETPdnB7zX8/W8h1EbDu9
clV9YvEANu9HU98Hwio3TWmZxXXY8Tsl9JjHVPHoPdtFjRykAh1L55RgOwORa481+WMjiAqdXNep
iP7G3jOpqY62K+dGt5KNE6/VyxPBkDDPJG7NLpJ8Dp8e4eBekYVTjX6WARtKowBe8s380oHy46ux
PXQL6iMION3qwXfSbJzOrmuCE8S3j9IotSy8r/p3SAhhEUYRj8xosipAkZ108raI1ObSS0vaBa+y
2KQhz7EHgwrIkQ+S2WZqI7IPM8Kg0IEz7fJ24WqdJ4hpyEuGO8pUIeP7GdH05Dytu0w4Ux9kgxuY
