<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrWQKbg9uQQTKAp7UK5CV/kW9ZzLOR/WokcTOydYDqfPxeExsbLsxlDggsylk3NzbcmONtLY
7TJmal1tefp+qcVSezfJGTqJ/YZ7DV5+Qxu0L7F1tYGBgY0ebAlSK3jfMXdtbVpWIKZWXgwICW5J
j6JUS0J47J7KxFZo938+Fu4qTGrNNy596gGtlG7z72ZsO05j/NpaiXF7eG5CsSHFdxU+K97Dz5Tu
8zawcbejft8mU9+3Hejpoh4UkYVxrLKb+wAR0IEH4CsqEXZ5i960SIcCGzcEGdcm9stWIdU9tId0
25S49FfRJGGW1+uErKQyjw2/pUeUnigbzNy/N+C4wBWdIKjCEZM2JEw40f02JTqu+c4z1MUbm4nK
yCWNJI6aDSdJ9l5oMRN1LlBGBQNZRg9ZJE0MkGNj+JJkJh0JoRRSv4eRVa3gRpOvcSZz9c1/TOs3
vrVXwveCX+uTLmIJ/k+Em1dpp0b4mdmOCHpCvAWDh1oylLkmk1NDDUsxYuyhzAaLarmNBvypu4YX
pBDorWZtvknAOqTQNW6O7x5PeVMC/+Ril+sSuTe05vGYsKRemslinUQR00aBp+/o8ktu70zmiJbI
TJyLUBAdfRXCn7fOUk0ZassCsyFPs3isqAel+ypNdzhs1ROnm98kVNh/sPkbvV79PPUmMUWTQ45W
QLwvmvGOHVDKRy1ojmAshrktFPtjacHp4sQsKEaNenC40aShEtopJoqbxjGaX1P0mecpdHwRPTUe
iYohPxI6Zrt2U/Dgd4II/WrHwyg5XgqhdEORXzWlZUJnTubegTjiftDGvq+St61uoSmrJXKrhsld
KFsHxoh1t0BwbeHQCgYA1loFZNbGhajMMBasAkVIQp4z+kmofqQHVm93qFtmKjR+zqBVv5s++tAY
nKXcZuYMeC4u+MRL+ERoR3dG1DCzK0iZlHREgvTMcD7vdGaE8CNXjHPat/ckKJROiafapWe25K04
R1QjV49Tbv2BAqJ9EMnwpXtsAOp19KbYvSmMpfSI3GxaPDdl4lMFNZRCAkoNI3EhmkGprcyCWCOT
IXssG6IdRXBRGAuKnCMNMC3xTL2oX09Mbsvvx89w7b9whVJcaPkD08NZhLJ4pdHdggUNnt00gb53
ICYwcSoahJEP81OfJzf0KjPQkGhT7CAh+LtY2rAptp0o3TKfZ+0QV/XpXc3iSr+xQWNCXu+M9oeM
PHZNxt0T13PQtxDAC3/0O+OwH9L0HOg5U57p3gAjAOW+x21OsMBE5PkJZeVlnWrbahrtQTBJuA7k
CdpOjNzsVC8Ts/WQqvNSU5Fz6/y00ibDpzBB19wo9vUTK4o7ow0Nf0egAEds3RqGa4UNWpF+qc7y
327CvCVvFeI6rxXYzeloIrrdybvYK46LDxRsTNCShxM7edYhlVDl4zS76w3TMemmdttbrBuM3vrC
BVe3uzmAIGrkMY0L7AULmiGXcRwGETrUV4uFWMu56Q8S1tk+Ady451Od/kC+fbxaA+ALYlZ5sbZa
41NoPQ38RlKgTIs5lLJoZ2kMmbxwOeHEo0FQm3fXSVFVnzFXGQ6nU/T4jLrYwXyTk+JNkrrjowsk
VkCewHgu47sQHzJcmtBl4dg+JmAeaq9K6B2T1wkKvDgs5hCqtOxYKfynlZM3CTDfwwD4LQcee91K
PGTxuqRei9Yy522nZXEhZmBze4AYtgS9//ewFsiH6JPrE12YJ9frUrc3YS1gQY9K6CauqJkj8LgE
t7Id9bnkWn6sdIiMh9bkh4xhIVlVM1osSFFTywhg5G7oxeed54pVZlzAoco24kEKDwNouPvEjWMW
bUmkBSca4267bKjI64WZ4IxOXoVxm0uHqHDrjr4+hZV5bS8jsRHL7y5xw+ttCu4PCHkpMvU+OLAC
NSA0i0bViycaDH3gaMHBArCvc1niPpNnnGLYyoiTvnhywdQVwh8pY5ltzlgWSTuOd996Vf0/MRyp
NSPMqapSmiLhxKmuDck1/DdWOL+A4M+z0//g8vyl6MmjinBhqhjGuUdClxgs/xOHC+oBrW8GWvfc
H0edYBP/tipQuffVQ8BqQkwW715ODOwBlcdYaekbQ8TEikOBOkPNMeP/3CrDnhx+Pm3ltMrQBHD2
fzTG4OgXg/NlbxOhJ4ecC4/swtiNRTpR1vHDzljIzvRj/BPHyMHwfB4zxIk+tBiDP0JEwLM2hk6o
5WlBXsvC3LOTlZhgOMc2tN7G3w2rmmQKH5LBlWk8fvPq75oFCbW/9hwZ7XBXcb4h126uq1ewRZkk
DZ2nq99ef3tKxum6OY/cY0l1Cfa83BFjT5UlaqyWd2B0+5DrZ+Zn2Y6SgylkfLWBSG0AFzPW7DEE
g3UDZUCL5TFsTg+Q8vIX/gRiC8M5W8vXHzpdOJK1L7SqsbZMB08rCHb1KKjQZQ+zXMoSLU67Pj5c
2/gMj/rVNg9iQrAsc1kvDBM+dTzoYx4cFO7o2KGfsv2Cpq7r09XrpIT/ymYO/r1W1mqeP8+cXMPd
b9NsvSNZve2cl+7XVMIOJ/lTC4zRaGogC4GODsfcqMFii/TA4Z3rqAUMMCIz