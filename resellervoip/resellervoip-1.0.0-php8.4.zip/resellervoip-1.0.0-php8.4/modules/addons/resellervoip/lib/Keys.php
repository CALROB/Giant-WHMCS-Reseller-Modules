<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPon1HCaNgxpkwlVHwW5FB38pLnTHcSIioTaDRBOJAPhNHNQmrjVztlzwHXfxzuUBRuAvE1wJ
4X0l7X0vV+sbHjpK7UD/K7HZusC4i7mdrJAWFJLbgmhoCpSZiOOBuxw2G+MwTdXsXi+wb9VwRczi
0bYj0rPpRqykOWpRaKUQuLrRi12b3zveuX5K4Y8r5+qH5EDLuw/TcZG7Znv0vuH3Xf7bu6YVCxfo
NpBJTXuL0PXGg/ovj6xHbFVBuGcY4pItQ2qqdT7CKU1xj3eOnR2HW74fZ4FPZa9vi1Te81sFhV5q
tg8fqFHyO4rZ2wpM64bvmoDracSZW+Lxy/WgTQ62y/Yb4Pp5Ut9jQsFsq877f04zifvf9sdT9A0x
QzZylucShRjs/qJNtnLq6N6jLwDN6v9WVJ1p1HC/p8GUgog5yeXxW5zHSQMwuk7/QJkSlaEBZdfu
42er8JwpjOwXehoRe3B/TwmVKSrKT1wJGJ40oYazjGSp01SElAIK7IsAVh4EgfvmM1W4rGxA9sKL
7ODt2S1z91QBGe9vP+xHSEDC4zn+3c1AZ0AyvWLoIp8rrEagsvm0doyn6vI0oh3dWMtixUK2ASZz
ul7NVD+0P2xGmTXRC2Ez1J5uSKI/jUjK3l4rkmdYjE3OSWlJxCP+3YZ/v5Kg2G+BKPaPkuG5wvvp
hmyJkXiogFhHtwfUxZ7d3MJsWXojr8I4uDowRMgY+nN56R+mpRLKdIP/b7C2zHn4zQZS3cm5/fxQ
1l7XnqC07Lpq22Xu5+4Tsnzj3PQt5zDMOdJsFVRMR9oLvex+0jNyGAXgq5QFXnzNhw25NHQigXUf
CRKct5gg59DU8GE3GU9Uy+WF0Q25xJ09WZJp4ca0K0216OvoFliRGKZ4z1AlXT2UaPahi6F1/WiV
6WtVQvSXaSEusMaOaMzF1zCU/L+stpE1RoO8nyCgwryNw1utRMlnGBgjcqLlXqX4cWGil8v90m1l
3cf7doeuNy3fQKXN6sehR0oHOQplu4jKCWuxH36DWXobXjoE7dHQzXUfOl4N6bWc0gzX5NCkJgI1
tUjhpmNZ9eFhKh6wifWaLeH6RiFtkWGHxL8U7BmqGLOxdca6iQYFmNkNcKL1QA+VjXMgCUCINzq4
P3R/PMDhcrTOWJ8nxxtvFZMbZlL4f1N5uOlqRsOjbzu66Ty4hgjOdlpnWboYqdRek8UQk1hJyZqf
xOZkjYZ0HB62n5ngYbWcbNWWsV+BpIrlp720LMTdM9aZgyNaI9BCWP3T1jPg3ItvcZL1g9HIAAr3
aYU1dyyCNv+Fo1u+qh5wato6yOuAcaTbDfY8119oSHlUQJWzc6Kk6zk/1rXuJDiK6KXM+WxxbCNk
egOnZMm7W7rjpCSA01fzSywK9KpbaLSD8uNU/TQvDf8O9kWr/Qocz4ssIy+l1MPkHw9jXhqGEqDr
6vYtvuC4aZWtqvAptwEZ4WJr45Yb/VbPJEIIPCehIUuG4qsV72kwFKWVecMDuAPZ/BNWP7b5D+47
kZ0Y4a708OU+2BeVLA3ExY9tDC+zVQm3albDJVvJMCPZsbcGprr5jMa2ha5DQUB32u1yYJ4Kf5zQ
uR9yQDDkpV9sNowJJEqaVNteKWQjZZLj1cAVccgxv45ZUe8WpEYj7Q3F0uceLPsh7klTTD1X5A+X
aLXSGlGsy6PK9Zyu+4eInmpdqINN2tlYqhxyktdLLFrv/o2uJd3hY0IJ5wjUKWoMU/KUH+8bnMrC
uFdQjZUoWq0dQCfFyhSFhrSMaixgHZaIKoY6hWwD7hOvCJcaya+7/UVwEj627Vwbbs0juFh8abUM
pe/8+ABIwmjHtPiedYNGORIKel15/TZK5GBw8F+pHmUSW0+VA8NaXLXvv67JQtTMiLThtRAwldhk
I4L3uR07pfkoD4fuFlfpx5r/lvuOb9rRiI1JwJFACyEWmqLcjUTnX+zIUrIIAnVU6SuMw7EUHRLz
Rlt6sBkAeVygZ54h+uXTeJMZO0XJYfloTXWgl3adu18aCHv1cwttmk5ZRRAwNyrQ40YMcbu3MZeE
LbR36kOVaWa1jtsO84Iunq+051s1WOV5hzzrxtAAbCHVuvQEsbO4WP7uATYaSKDuvmcYTQmYTQwb
IwPRBwf7DOyXkVx1hSiiQyVziyy7FMVbujbbOW8Yb9Q/RcGFpvXYX9ubHSTxSa72hGsU6wu+caYl
3Bvf9BTOkYVawybdbWZ17rC+youfGHeKCP/X7UxoGMTssS5HDsXBDGyS3K1zc7XCKN6Vu0J/5vpp
pTMtuUZIJcfPSnp8BDpN0WdW3Xp5hyxNrK8=