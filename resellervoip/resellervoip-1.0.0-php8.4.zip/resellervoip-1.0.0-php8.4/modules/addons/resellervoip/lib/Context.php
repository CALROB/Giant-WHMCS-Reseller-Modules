<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/1EUzdlhbyVylJk+brGqm3DjrO7AxnjEj2VYKdUg1H+KREIepha6TiL41/VQ2g1jOpWt8aO
p4kxfPl4klgMmUkzLeS5UjVAThFSpbnXyg1ApDRTQPTw/Pr57u1QoWa5J2+XyiZUlF/mtCDwBx/u
Z87/BJZg9VNDhMZHAALcqRpSfxb2q6Sgw37cxeafztzZfuq30/SopjpQG8m+MBn7y+cC30vWiGad
j1bRDmr6KjWUoCseVi6nmAgiXHpDlr59qT4iNb+cKFsqEXZ5i960SIcCGzcEGdcmWtNeo2It53Gr
HoQwRFfVJGZ/C/cQqQMrazqr9p9qQVRw1ypFrcvzHALXI6g1PHgfWWWeroYJYJRm+DqX9BlZosP0
RYdXCyhPutSdcNcLcKX0xdl8+fTtMkrkpJkJ9pcvCq7P0WamkzONID7ulsdzEWMf5aGbvVfQ70je
EqPttVmJQTZaczcLJYU0gNegnvtLGmYpxSlaiyhv4/6QcMYoKbxpToVIw860hs+N7KkE6wr3ROyc
cjArmMue7Eh+pu0CHH37eNVJ9n3m/EumqvLlTWOQ2k2/zOFIFeHE/+syt19V4If8sqNfdYLopVcO
mYhFsnA48O/KcrkYvEBHK4GNzWcYMvGj/TwWAOUZziVF5l2h2BIXMNDlo9G1P/PmK6XOpezjOUpO
AxEdfIEKMLKcsSxrO4FiLyNBhZ9yYkjbX/9BFWZQMpzw8VQrX4s6k98V1x//AIOUcSIVBWrZYEjv
KjA6OLRKp4uRUmfkLR3Yrp5zPhk08y69mqjYmp4EejpyvT+gqrSWBUIRzzG4+5B6A6BHBrZEl2Yl
v4AxaqHYvuwwwh7g1s0OyVZP8I8HwHv7GIQPjb9XfUXFuqm+i2JwExBgP0vrDzI8ZaOqhdDyDcGr
g9HhITe2/6wwR2bTy7wa/xv/YuZ28LOtgQ4hWbPXq+RsuxGWGD9hlW1I8pD8muPaNHNhDgRa/GXs
+qMt4HkvPmQ32y3MGbuuaeP+0voBhHNIXyDucQFb+E2+Fg+UpmfFCj/rENjNoVt1f2Z+wypFQwNQ
tpGt708YRodm+Dl5r2RtorswrdEK3ScR+UZMMFQ9Prb5ULjtDdchfUx0LDciyL1/L58bEue70sXf
7Hdr966Oyup5MKz3xI7gTEMoOgL5ssDTREbESNjPOdg/nOk1+1HUpld8Z1bheASGg/5RApu=