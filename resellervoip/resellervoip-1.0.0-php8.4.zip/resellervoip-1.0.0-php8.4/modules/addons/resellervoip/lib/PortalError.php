<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpKxvQ/U0Tw0eurmZ3x/TqaQ92QRYP8K7RAy91kwTVSluBArfKAqSWpS9GKuMk9PMHh4m1YZ
KDco9yoOCdqAM3znTNcTB0Jd1U9Pa4Qp3uteKCLf7vQlVZNJ/LasHfX2G8oGI1b3kjaFcbbOYxau
pJ6780ygdz9FTWHXohCoh1l2FaPVzwSohehoG6wQSanw0Y78xniBkOZeB1WCcNkVPJl9eQ9HWHmZ
QBnVcFFRGWt2AjgvY+1iHIRfeABTIOUYkf0oj6qj/xGw6CMmaO1nAOn3sOv2UR0wPDvIbZQcuLTA
vryS/5HDEAoIGVfGt0cUgYjjpgaWyXqEGoFFG6V5YISnQeYq6gGFUb2TveMohbnqoLDelyh8fMUk
ezTa9sSrwZKDAQ4vj0r0bMUXqEXZ6Z0ldiPifYXQH6IUSdieaQsfx/beWjaPO8PghuwW6hnuMveP
QRfqiphrEGZIn46r98ZitOetKR+Wxx5mhk9OdYtBqMDYPhXk3PCamR9VPXutPf9ZedXJOohCQQS6
89T9pr+8fnMxcEPaE0ei54gPX3xr6oXERHommOq0JroS+rNrrc4DwrXYE1xxozTfBUG0KQ220RH/
IyM3CM1cPBfKwQmfX8CO6J1Syz9e+JqwqFX2M3NdBFtuAKUG4CV7aR9MwhXYkydN5sfHj8Z3WAOa
eol9DNWzs5cm+yEyGUDODWjc2rmt9im7+WlJyftxhSfL5C7OTu2oOJT7orOdwKdWe+EoD01jYlVg
NXuOFHnhV+0kj1ErTOEKzuZlo4IuMfDHhsYkoWyafKrBJGxslIQYgAz0nrelYUpKQ4E3ozboRmw6
vXNfEDeUZJ3pDkpg/oYJbjj2qwyBBqyDhbwOSQh1L04OPBeawKRw+qZLY/4a+lwzgDsDuHkjcrfg
e+NycUMLBI++HbJgPTwDBspYG1Tw8SWOInsDMwJ3E2Ttc0VOvwGxp5Dut7ZgGzaowfPvI1JCjYmN
49smbMTDnq8DfxVb5CNA6oielwEi4L3+VFqPU9h40oIWlcOVbiyqHy09Z4yHaatmPtuS9R00sCXz
L8it2cQlOXJ5vOnjYhM9P5JJssp/jm0iXqy9kqlwzsfYjraLEqIxlOTFjLx664jqPDO7YZ/YTxmu
/tCbObEIsTsBdd0ImZVl/H47OO92OaoUYq0vgjbM9UaHtktuQzpJMYgKvC63lRA7TB6AMLmBEZrH
BWF3WNiDepYS/7ah6fK38iJBoR55TTPBRoh29A6/+e2VZtIoVz+btlKlGFK/QrJSL0DmANbbWfd9
KZGNj6oJSKUuBgQeUYfVqnX8od9FNZ1riocqCEu4AFO1BzWDusbD15mAJ9vkFxSneueSCb3BaaeQ
0jKHC//9iIoWkmQyj4LJh25R9rg9KJVRnQ7Jg5+iO0bRWiJ5fSJwIbthaId2+osEQqcplLaKG3Um
lyTMVj6hIcOSHMI/sTECyrVQ30F56ZiDTUiM29Qz0Q2srY8bydGUYjftF+T7/vE13B81CuGEfxl6
scARhxyddinQhZFGo+f6Z6fW6ouZVOwlDhiVs2sdGflUvR71JTYfo2w3/T4FKeQjhJCOofNeOprF
laLeT+VdL24DzDyUrhovAKIS5O6HKmIqxYYsyoX6MQQBkSf2eVbvEcVw0v3ZPHP4gtp8FvyuA1Xu
VnS5dfQ2gzCw7hIMO8sLaCIetxXVjpl2SRpvpzoJ/Az5/zZTA2Rmi1q1sXTUqnAJCt0N9jL/UqSi
jystMApxT0n/C2bUj87pIYHwPOscseFOKuHyzTOt1w9Q21ZhnSfA8dpwLYOgAKSxKNtx4rbVaIHP
wGvR5udW9qwbyL9DDe4DzvBp9yUyeVprSnDsrkiGJ4ZCCyFbBKR5t5UlguYedz6YJw/eoS3sk+y3
TJ9pkAnscVLCr8tClk1g8sZl4Wf3ix3S+pjv7y1kbhUUD2rK/2tFrZclJrwJb3yjhgjvMfltxWYr
YFsAx5yevCPOxEcWuqF5hXVkFjvucDmAjKYzyNPzOajyMrIbZgsF+LlVWMcO4lZnfZgcdJyZ4ily
eHbdoMhgHJNhAO3Jnqn7yN3bxAx+FkRDKinae213XnWhmW4whyBm9DC0feLjZ33E/+6Hb93SYIWF
5nwU0qZ+mMaTn+YTKZqasmo+Wtp4w5kwggWKE5DaFvg/axNKfZFz91Srgmwg8urdQccH3l6uspiA
liBoRlVeZ8/293kp/eeal77ypedENZPS+/51r+uKBvn0QzID/VspaysYBGL0GhhJwlUWGJEtawFC
dF8mTiBGqGuZfBf+RIwrkCYyHXnHJTr4zBzU/lNWsPrBsHDyC04FJh5QBfUDRdChvmmXvuveoMiT
NwyCDieZrLn8wnfIgom7O6a=