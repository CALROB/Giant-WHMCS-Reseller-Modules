<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnHczivQjihX9znZxN8gI0VbVCtLrwG/cBoyO+W2x1VpzdJOLI9/C2wd1qBA3yKrxmNgLNtj
huDl1TkcUe4RWfdWdCeaEmqBILtnepKn749PbQy33cHy6KaVLh5aIz5m4dMKRRhMejRIGqUhIl1E
xC0FpIQA79BtKnLGnSkKuXkoztGoSUyJJ8TLgRaQd8v0et3GA4+DXW6U0cRREDZWW5AQOBykDeNf
+JtMFxCgx49HuxAZIGtgYUp6ZHrrsWn8RV20rPQtQhGw6CMmaO1nAOn3sOv2UR1/QfIqYeZ52FhU
UYO4ULnD9l/+upUP0hXHy49DUaNoiWObPawpBmi+LCYjmrc/9Flx6kNRGgwqa/rUtt9lFL+lpyK1
jhbQ7ylKYyzpb4zDKxDmieYndu7tMXu31FeWKpKH2Fv32f81DtPqtqBNlsApVZPrDOHxPHnph4HR
OVW1ybRgjf+bK6TIy4PiiwKXS5kIor5GUE+4wkrXplr4bGYvVY7pePo+5zmcFkOmwwHbaAUW+jRo
easD3CJwQjsdQmurULtclcvf8V2gaN5OhG+0jrVEIwyw2/jBbNGJEq+YTLN+C+jpvj7Ap2ZMEncu
2MFrJappaLgk7HGq6hJqQOyYOy0QGKA2iVMsYuTTV04YlgKUDB9JXEPm5CwMYAjUz0yR/b93TKiH
ndkXgOhczX8jo0C9vuY3zrHD8vsSFqMdSooiX2C2TQcU2Nfk3+VqJz1F9qwCbGOCcy6sz92U/PnN
pwvgkqaZuqh+hPlaDJReCukUwfgzyfIpMxEeGaIKjMQxO0s8JaKVHVLEbZDIdYb1ZdRFOscY3BKY
aYveA8rf0u6z8j057GmIKPZ/l2NJl/W3PAg4BM9vt0oQYpKhv2GHQ1Io0eGNWUKuO98JR5XOOMVl
K7YzqEGVdSvX/FHpX7Q/S5t7fqAKiPKbFYzFSwQMa9Jzv03WpfDFGwH8k+BxwvE2vk7KwOglw5Wr
40L3Of6ofVCjQUEcqVhHgHcXP1bvE2YpSncWcL0Duhp5/mexW28LyULpJ4CAyYd2C3UMuCSMjSrJ
b/HSuXS2gXwCsuWiuzEyjYl2WIebmcJZzJZ9dIt8NJgQ5DFOYDm11pIg8U4XINl1qrXbxBxGVwGv
HFaOARlzvJBN9e3/D8lTHAfwHEunxVJ7OTK5ujf/80Qs0tDZcZZaDxZkTCjv1QwUeD0BlvyFWlS7
Jb2cLK72g12rHbU02W==