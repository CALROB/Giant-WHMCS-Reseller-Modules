<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPued96q23Pr2tv6nJgULnkSmwL55VrARuCjZo+s1LPQwxmMjJUrQ6xOUbi90r8pMdBghIPjb
N5UmNI19+tFw0YYDNblkf1btvMNQD2daoQgwagT6/vru/zkGNAbhyTe5Q/CgC0hLgSGadBA5hdWa
SVujM0+sKfevJUS3fYsdg5ZnnfjwrGj9GEyDB0cO3YlnHxHXSo2fu6r6KE4TfNYRuCy3uj3GuYS3
S9HakzpS8SpAfdn4OHGUARezrtWW9+Om9VUGAUfyEzEqEXZ5i960SIcCGzcEGdcmecpsX96kzQOI
EaqLT7XUJHnzLA/OGVpm7w6lxvlJ6UmJ1uXXdPkw/PB06Y5dDqXs6F9KOc1ieKoUes54R/9RAxws
LCGRq2GP2IBUQwPvakZJX5i6OUCUomaUMfZpSL2WiFXZABvJkwPuKLqKEt1+KD1TXFJv6HIU+1OZ
sMGNst7y9Lg5h1ILsYdiEWRFvZwS7s21FufnK9nX8UKb7ZSLDUNxTCmzLz1ucbzu4mRHRtDd46qr
CTnncAA31JPIsWD4IFedgZPQQx+XZV/FWb3c5LmErmdvMxFbtoeFWo2sKJaq84AHnpP0XMiWB50B
iMFFed/M3kkuOaVXz+qe6CWImPyPt2xzRGnB67GnL6CPqLF0QMPDNKY8tJQWxW4q3Rb4Cl9jINdR
GDt98tEsqEDtmk8NgKEyAqF/c8l1+IiNzVmu6UYcP7QRc6RFFU0Dff9+H+9wvGjPJSKiX60igboT
dcWAo/5blszK4eCkFuW922iKI0Z4WNtEtqmTfzP0YeC7cj7+fdTUbDgYysDc9kZGkiqfegn1oHt+
WWOwY9LAGKYXSqlt6IhxoXXSyHpJbTRlwtxteV+7+J03a3S9GuM92O4m79AKAJrw5e3iQvR//TZ9
gec2Dc/6zi+qft9lrqlGYXf4FKXZHGQvHoMv9YsfW1TNWj6qBA1sMn6HWwXGkqwQZz/20eA47Xwb
RKn0+0H5ATqYxW28AUCrRhUrV8sJ4ObePHnr65A7yxOu0KphPJ3n39Niq/Gv3uD6+4teVgd+O7oN
uVXcnEoqa0nLkPgv4ZQ/rjP4P0CxB5eIbspzz38LixBPwczUQJJafaS5z4brvLAjjt+i4KaNNycr
DES6juS5u86nJ3TZY05WcM7q7hcbwHhE6hiBr6ro25hN9E4Gbw2WDXPLGaXVYxWswT08QIpGTpio
ucx+3UE2uXVoYP+AxsbC+gOQCizjUe7QGR5F/4CTgpkXAMr1zsRT0BVscI6nxsGrZxmF2nZVQzV6
FLP7gQTopHccxJL07AlJcsqU7e0bPhm6oci2C0bakYwj4kn1NYQ95FQ/+asBAO/KL1rIWhozMqjM
/LSGWh7Xj5qVf0M0Et9estx43QfULYfzASCdnwR+tWwv5uH0kmSXpP9eLkIPjw478lpB8g8PpAX5
EMYUqgamdhnq2u8AENDbgmV5bKCA49PzSylcQRMBybeo992qzP0KFMqnmj44j/GI0qNnK9wHRUwl
C0Q4lPXAxE0TogeZ8z+NyO9FLbwRhQsgrgsQkb9rhzXaEoCCySnzStNfHr++bdPgFIqDulAc0Q3a
CFTDnPbQV8SAglF+OyOcCw7VphiOVM06UUgfHK4PTJ0ancKPrKYePyKYjBHPHCjKa7lWaMPx0qg8
rmZutkPfoMMyjfEzqVjb5XBe78z6nrW8DWppcwinRfwWTF/WlkzZt2Ugcorhfkv7dWgHYwitRU6g
t32o2Vgc1Lr1fZlgvuzyRYccPpWrdkunyLpH27e3O3KTcWrmsVQWpr8zWOGC71xWGj5eJgyYJoMJ
EW3cO39h6mUKyi20FjPJSQDzQ8Li8VumV5/oZiweHy10mkoTB/jCQvrLgdw1Di8SfGMbfjntlGwL
Iv41Niz9N2/Ia18FkE2HbtNDaW+ndAwUvtb7fDF+1OisNt0MQ5htaSTyez7TDPspvIQHoEfup2Yk
oHdrEp60LuRslwBpRlPxiPzDNzUEVqx0BG54KtSYuzSBut7WtHh4l8O7csDIgtSA6jh2MS939OWc
m7PSVLX2/+eJ4vQCb42mYkuKk2s0U5miA4rC5gl3MDhCo9hK1WnqRE9A48AN5QohousAxHVNLr0T
WOisRi8WwPkSRAd2LJQNnH762lGPZ0wYUKrB1cKJaPJTgi9Ogv6R8sQT7lJTaelexl1nCS3n1oAU
WlM6MzgQrpeFVNveWsaQTtL5oeYWQiRQ2XWsr4iIAvTwiiQhB+yZDYV50mS0Mc+ZKcw7GJP9am7Z
/KQflGfpaLkEVP9/6Fe1QUlADV0wUTKnGvc7MrImiA2ByFXX/U79zv8rOly2I8/D/PITCQcA6lmg
sXTwJGIdovw47WUq+ACvEIfT5CEFPBc2DIkBfsH94lX0Qb07rLibOBstGf2UUY2BqnqMR9rBXXiY
bXL5RfsS9Y2rqaLatCNa1fQKvsVK2Bvu3UmW