<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu+pF/G0c8JxsGQgrwJgYt3URqiuiVrmjk2LxMq/c79kbAOH6MqMzV/ckvYZAKhaf4u8f+fZ
ze4dKAsY0ac3yWzQJ+b5vsNq2YVd/UaCjwiOMyyDCz1G+m0R0n+QqqCh9vpAFVWqkgTXW+DRsFxF
wCaA1EoD/si6BJ0NEvQCLpTAQtQ5XKxRbfR2j2vGQADeeSKJGbATbTaQuB1dA8HjbIcQFij00SDD
tY9NeCwIUd7438aLkfE2f3J4IgkDZwOPJKdTmMOLVM/3p5Jx6tA7HWrxXweW6htb4s1hXZk5G2I5
MG/HBbNtAoqUsw2BeUw8UJ8YhRMKqx12ktBCpGXIXPwJat9vv9+egHsmtBlXwAefW4XVr45lmRqs
Vo51G6StY+JpKh9Gvi/O8EA/7PViBvVmBqy5cAXG56j6uoxyUeE1aQqSVMO+tf4QXLjYp7mi8hYT
hpNjEh8oQxjp9jeUkWmZGIHBuaFmvAzV3W3JuAAWNv7S7FLuAz2yOpfY/KoLhUNt/7p9IogF1nSZ
KQkSm9FREL/Hxou7UMa0VVHCgQjOvzs+A8LMk1W9dBYjNktZ6gd6Z+C7H2l+JlQBodkJ3vxgTw4B
3vxXUIDPihvkjYL4R0zF9VkeLgM8fG8QmNw5mojGGShni8I3oHWb41x/dPcVZqZDPUdQmAXuRdeQ
yy40nxLldU3pHllcQMy0taRjqpPF7WVugT8Cch+M7Ckhh/ZIz+KgoGORWyMP8w99iLLsMKkSNWZt
eHWz4VvsR0Q0ttaX0axpV1kttB71MxEaf5FnDdPtWBWgtHzxPGRpYqQXqF5qClgO4ylqdUPEQlmX
ldtQb9X80jvLklbPMXMTvU1BA02FDAjqOuAuRFP6UIFkrqt9dZqpPy5C2+VaGnI56y/9Ygco6CLa
ICVKvtWS06O6jMX4AvXw6N8M6iEDKjvOdQJ3B8O0EYkcl1UOTsDYwxhgNB7fhOzd1GM6pfPGBl3h
x2OUqsAsuz3g/67wJF/adrVZ3KbjRNIroHE1bXNm7OM9cKsI4jKBGMMOkDH87mfSACs3g+2kitN9
QEuI/thR48p5E2jkUn6hczqGc5d3ecy+OLXu2ly50bht+8HcbsEZDaPIHpxHNBtI0tnLJU6aS/TQ
42d8i+q8zLM9eEfTQuOnALsWaBRcBIeDMo5DWyzoQNstC/kF+IXdt1YrBrmhBSzoilteAxwX5OCn
EfcwqgU3qyddKwv2NmBejhibHKDzDqm9rL65VkbSE5FSrPuA7C/KYWvznuS4Kn0Hg6izL0M2ZNRH
IiK+28l6hg3W6rNPwWlWAkUN9StGtGczcz/S2hES0CXsT1/dJVN+jgGfCUAxaaLqEDVkT+T/jsi8
p1q+k1qmSFOF/RE5alNtl6NIGk8OChOlwo580ZwLe98AOY+9yrMPykGT2ZZSLTFNTYFMkFV85hRs
KYhhawSRENXbVMWKS4bost0JDhln2oJTjCpd425G/gikH1ZtG88thqhDTvEXxZ2Y2MDc7/TEFgCf
4R2gLBClIJql68YwafD6YwMmJ8kNmoDI4NBibgrYy8CnWq5rN6iAiT7weidBsnmSg5C2ZO/HhabT
gh8KM9X1ww9Hqbr8hvZLTh+/8cnVbSO1CoQ7U7UdqaGlkcTrHYxLhyJLTpaJM030scE66kKLJhuZ
yUE+4i7BUN6kBh/DSfuVLTSOYId/xk9etaQ3SMQoJh8bQcbyxAMMjnnotPoJ/Xxe8qtrnT4FFHUV
78r98bh8BWh9PHuEupHfiUJnjhB5f6JRmrMnT/NzuAEoxMkRHz/XZBFzNevMEFkT1Hlru9ODSa1C
o0P2+0EoM6m6ojw0N/Dj6chAHjVhpnw4a7w5Nq50PJ95+3zHchUFtuWo2KbB12//Xm2F1Oa2b4ax
MAGkvdPnXH1MD67Z8t6RUscVaS8202s5gsJRZimjNAcIp+KQR+vdEMCYYVT1pwm3bNxs/LAeq1jM
2mxIfaPCBpYQw+vLkePispE9f1AC8lDaFkiGkt+f9n2EDPxhzM52pg1vvSPJ0d//4ZUr/DtFZ3M7
WeTa8LPNf/+dy3DBMnlqCKC6Uy0toJHtMID89F55NsiNfa/+3JOM/E195I9Y6kIbiWYYmQa=