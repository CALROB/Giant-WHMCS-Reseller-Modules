<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmn2Rs64gbDNLVVwGaYE5F0V+a/Kip1R9x2yOpf18vMSlaIcAY1eybyCWec6no1ZHc6CyXaa
xe7qr4VmYLJikKXyZx+T3OuBN4YJP3Kcrjhty2vvli4qO6AycxWIQ4m3pnOMPmYYolHRLBoFQYT3
RYw9aytYgHypcyeoc45QbHEqfKNgzQYqtFxMOwGaTzgz0vMN7Y8x7zrg4e01gGsQ0O4ScGL9oMe2
iIocs38FefAj9s+qAmBvGfwTDMCv/VeMYIvd6Xx2v/4cQ+RGEgT6opsk2gUktOjWPR6CZfzHIYTP
631q3vfj4X3F2xQ3+VOR/J2WDnzpC/Zxab0Oxln8EWu1gBXi6FSxjvl649tHO92lu7HRZsOaFZXb
Y1H5BA9bMVws2NVC/vqE9OgqTI/VAq9fkkvqGCyuoYk4E5GpMcib0/4ape+X9nQnmPwcdQ7kB/cq
FpQZ4OtuP5w1cUNSiAc0iciRv7GldLjEgUYzVkQn85MUX4UbAVtnQobAu4aUCqIub+Wxs7/q++JL
dhM7E6S5mxEkCE6yFSW57G4SY4FogwlJBGlYzBNZMwOZ62xvhh7jfRytLglSNgCvz0VP9IoEpvvG
qSkF8a11QpZ4vdfXJxXQ6AOtGKTuIq5FvVF68W3TwGtCG6mJtS0s/+u9t6cec6DJz8B9fF5k7xHN
TpPWbtXaU4SxwXjwxclZJzBGH+Qvu9TLqhvCNtQF3Nn69L5Jt97Haz75kEvLId6HxqyVf/3/a/G/
L9mKvEvESQGKqE63WFItY8DaqeOkLIpKe/NPE1rvyau5JPajnw9dl1JqafPkAj8sYhbRVGFyoMhH
XM6ATI6Js00YkaFBMFBBiwKAzT2OSAHc7jPvHjEpVSdarK/POnGFv6f1YaE5L/zb+tta3fs4IZYI
9WAIUU59fxEAwLGFGI9VpSUc+HilNIAnKhk6/zWSNbBQ6AHr/0OG1fjf8ado1PHqNYNNHCCYoCck
cQPI5hmwPZ5rzcN/67pKNUozmD/2Gw1kTdQNm8WSmGWRx9ofcUvWyrLp9wi1jDti8xlxHG/eTlUD
hCHbnrJa56S/UjZFEYF5sPPoZILHJt78GpgG3My08Fxp+vBj4DclVwkkSwxAkvbQHP1qCL4OVXLB
CF4zNcoNErF7t/Jc+28xOybnT/mVf18Amab/gHIrbAOJyEuMZnrMVMEn1yF+NaEu24ysJZ1UKBRi
fn+HIek8veLnlW39elUeu22jEjSne3wiNvArfUecV77XW8xhMs83CFN24jn7TDhuyg4+a3LAvURs
FgwjOGYjg6Y19tM/graqsy0oCWtPG6lyZbn6UruAI0uNz5xnl/emJGRzBaudKHQD1tJT66ULhOlU
RR4VSgnveLMM9xMPtCr0RZYPKE4jFM+OkznIb7rkOQ6eAVHpuoEz1/ML3NSbO7V2mxH+CUXAWnGW
t5iUAsOHj88+oiwQA20cU+1OraWLacqvHEAenkU6B4AXyFQy71c9IsNJeiLX2AO/7uWLo+9Z3VGk
yi3AkEdaILqQHYiLm8V/gk1w8ExPAKTa3KSfTkPWVCVBwgFP5NvPX9MXwhCXo8zFhf5mFUjCDUZG
skVGVTSIBaDI78TiPZLFz4IQv8Ni61bDxNOWgUjnQ9hSgpWQXc+TnDjSViUKMtyOQCThGY4asgGl
qKPj7pFrn99dU5pWROsfdp100J1v/t/S8TM41eC0d1CjUnqO2uuNB/RMDzt2Fs9rzQfWX/EROCyN
AXIrHFwJZ7548WzFOoeKSZqBzKJ9685OmbHCKnvgYDY6nfQsBT3jkMmGrMT4dJK8QzNI8czt0x0S
ZXLd6PhwT1ku5JkqKke605oeZSHptTLJA8+zgwZxerjeVhDl/6anTfbR7Wu9L3zPi1seONY4du84
lqcKffgRdtbTZ5uLrlfanAYvhmVXDV/0eBrn3Xkt1u5jqd+7M4m40rsxDbu+Zr/H/Xu9NWCqSWAQ
9+uiW+Ulir1ly7/5o+wXUjzt69pkHv5oFtD8PK6euhqgv/TTR5x1LNlpyuSgNQPY0YurFePL7WRO
l9DLyKP7KKnLZ+Dc7ZW1WF/K0IuKdUp5P2/ntYBXgUQbe5l1kjZAn6P40P8mmB+kfA1u80==