<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyN330065VKtstcP8zpnJ9Ak3eFCQ/Vz69+yjxrW77TCp3DqgHA4EvdfDjPFToRkw7+7mMm9
HgFTGT8jJkTPsdV1hlRJgvzX6vB/O3YQFXT3Q8Dw7lSQsAD6hgmZjiSzYWmzKOG3OQ3pUU/5540v
DrIPWm+4tq6NIg78jHSq29umEuHE8mzadva2tLeW1dhpFzHdsewZfo9ZWb0cpXb59u6wz6st72/o
rrD8GNgMrsl661gIZNN7lZWbtIeRCAKjNszuZYvi+ynK+njoXqODUuUg81gzvHETP2YQMeHXw/qk
73RbToajMl+h0rgv1W3DebAzkAavJQ/mmrVTTyc21XBsu1NltlTkTx/nwIZyGIfYXNbJgYGus1om
yGb7Cv+ummsj3PSaKLHhrfutSpLgqfUCKe0cn3Nh62mlMSA1lODEh3JXamKabexBMRa32VruAFvU
TwBjV17hvnNvsBHhPdNuob2ucIKrdY3sdHVbaO8YZzT9Fx7qxpauR/m2anIqu+SUWWjVHAkiSf9M
Alf+zA4awxU37tpmG0lYElZzh9ebnz26Mrrp1y7Vu16ThrpwwNr4Bfk23D5k5B36Pgsfu0f6kHMA
NrFhN18UVlbjl4d86Zq4yw7EHUMqDRhhWMpbiipqKA2gwZqO/uTkoTw52zJHzLa+QsKS3dag9aw2
96IEPAmKH50xUKmc/qlp+zX4ePgtnxN1rM0gZ3FCvewi0GQFAlPYxqX23jb4H0Bwrx3TZPgNV+8t
/3w7o8tzEuefnCTagjle183Rd7LTO8UcLWu390XXHndG8d541+jVO40Jn1e5lYb+WEtKhVqOHFSg
37e+J021Fj1fxWkDpL8RMNi6PP4dzYt5TWvvYTxUkA5WOgadkqKHssDFCjMkbRAVMEFM4qPmDKns
hinOe4GgQfU4GEYWMmoyhfTg244x1cJHQcPhEztbTHuwstvcNQFBGrtkfcwADGAULAHOsZsbKLZM
HUMC56vv/5vz8p1qN32LTP0vCK2RcMueQv82XfUFwStbI4rtNKzX3KikSkNIVUEIg6kKZ+8L/FBl
xHIO5IHDm5A1wL+m2CIC15LnYwIt5ZGv2IcLXwSItEYtnPNpcp/6vMzD4Ybnv5hJEhdSqPF7pzbC
tIWa3oGDFOVN6M8o3qYWWzQLlS2v+Zlm8W==