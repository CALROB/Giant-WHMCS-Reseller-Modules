<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnsTpe1pUpEt3YTRezdQhfU+iLREXXWMFiGw0ZdesH3PfrZC0Jt57XBM996AX7TXJViKm9oy
hL0x7hBROA5nJWaBxbWHlfacAL3HdJthDsXSrPsfnTekvhdjssDnDFtPUmas6BFSI8w/9oNOkZKS
JRR/ySzkv0uHc/p/TTMI75aAhDFy+RPIkJP592Y1GfG4gT+5ulIJwOGq2fFWRklwsXtsaePeJ17Z
R704TNR+TRBDTV9ShOYs0hvKHjKu8EepG0bg8URW4c0/yIPhvj0wfqRBFQuAfwxTYvDj5gse8mQu
UUrnWVIAbsroc+LKEzmG4lhnTWeEsMBC8DXrn4cr6cSBK7hFKcbGMjxbYR5WewMnovfxbY2iUOnV
6wx6aebNqJvmjgAizPX6R06EUem8Gm7H1Wf7QvL5L2itc5bjgV9wxNengqSFzg+R2fhhQln7CpGj
++pvdYPLjeBu8fbJVOyBmV87n0JaB5jcYIrhAfli9pY0dGgkv1Zb6S12lnZTEbMnsSJBalLrOm6Y
ktwib9O4NRoOZSx92NQ7Y8JNGh5ns7mUb4OpWWb0FyLQQLD/4ci5352YtY/cCCEa7yq7qNsvAahl
bHOZREDbZ5wzWLvQHMVZkHSTrNbpU9m9pq9wcZwYrb15ol7Nht+M6sIUf6EE2kwTMBrUEV8MWHNJ
V6O5e1U1MM9ufc9NvvOsTSu1mHEW4UOme4xcBEEtWS4kaoLKquwwEi5abn608noS2i9U2GDZputb
ZygiK9Xkxhf4BzcqDTAK1+lmDCty9KBMfKlXdBWO9LyI/cfwx27+tn6ylw2DJ+cMZ4eck697PchX
hJQAQQzeSMfe1BYpm5ndvaoaiHhL7Tc9uDdQkZM4yt193+mTB7+Vsz0TxClchlMnx34l4ijkWMxV
Kk8vazHR3IeJ2qxFBx0eOI2R2xDct5VZhcT6AO+9OjpJRa7sFcqLnXLJiFWl8fg3k90XDXQbqJcz
zq3nqo4XQxEZAZ2A5USfiI3hVGLzTHjK1PsINdP389hh/4i5hbTgY4Us0MHbrJ3nT+I9QdkcQ8h9
OrG+hkYnCgFBORQnm6ELt1YP5CxIcTQ8nloyrLgaEiA6jDxHQqDJ+IJMC7fgqXpgDZiDiBUt1Mwg
Gj7LFXMFYuqJRMiGSMQUVyN+daxAPJaYEtZnwCDw3s/5iQ51aHm=