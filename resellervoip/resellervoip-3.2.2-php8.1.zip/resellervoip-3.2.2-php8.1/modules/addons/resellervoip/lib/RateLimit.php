<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwgInsXvVl+FJm0aKaiNG32cLLaFIKOoJBoy7/pMGGtiwoiYZSe/WpEAMQM12qLPwkx1OCJ+
JRyqwx5Jxzvd/jBDRs6k1wJ0MEeF+ckEuQkV8dHZlDzDlSNzLMb1+yKmt/yHkMm2N629Ktrcc0fi
I/QVB5BME25cnPLm9E5LvnTfzI/mqE+6uEfBRGdftlOcksGUEpF2TXQkvLdTw5ASDG3ULqnB7xe8
tRg4N+az/nlaLj/cY0kJooeM6/j232i2G55tUDEtIF4cQ+RGEgT6opsk2gUktOjAR09Ivd7dM8nM
3G7q2fvjISnNFImd4FSvroEHU63w3gI9qjbZkErHm44ddMd3OJfv0mIzZne27sebKKTxvXBm/fRR
iRNyunmq8bROP2n3AL357KNTX+gboMTAiGBJR6GSrs9lsz49NIm9vPpAo+TM1ufA6utc5CDHQzIJ
cPh88W1yi5r02sNd5EE/mVul1/W1lrbiTeOuz7YbQ9iGciy78N26BO8nSWEdasjebFXl5zS+0FT8
3hVsXTVbo7mmXI4dk3wwo899sMX5uxmziYcAloJlWqDvT1KIUtFBShg9cZWowM9BurIkhXuXf5+b
9Rarnef1SgEJnlYW+c2KyBQVpwmtDLw0+Crm7ernet23czmI/G59hMWVymQJXfDvqWC5EfzqeDNd
/ffDwYubvru56PaVuJHtQd9qyul2S6bKg5amqv13yT7SQjVFSRsz3qZT5v/DC6+OHQT3FRrw23Zk
KDzUFlETDor8QD/lHI0UCXN8RZtvthMQKEwDzBNE0os5SdCkxpi6N7NWZtn2thuny1My8xwqlWNb
r0T3mxVTQZcj2bIdUT0Wjsvoh++Taly7G/xukzhwv03XQ8gcZwLGaJtEYSvGKNeIop9ivI5bQJrT
unOs38/isuX0Libqujve0pIvPSoFZLETMZ1bllAeaT1os1F4/Ef29Tuc7eoRiG84qiF3VEmkOpWa
NC00HiIm4Fttp+3Ss2AH6yGZ58uxfnmYM7n57vzK+fsdKliUi3i9gzs5CBMug4/CvsSIchSIXici
mHM85lt7RqmiW7AvDkB2ga8iIhDPoBtvCS6ECFFuRX+qBehz9sUIpfF4MyyCpME7wQtLy5V43waq
NVMgfpeMuXcATJltEPoXQveSIhF+oGxtwcxrS9i04Rw1Wxd62lHkIPHBlJIs5u8KFMtuXjvPhmod
Q0QKsx0uUWuMLYeaUY+JJqnGkHajq8aZ1wbEtJbxFlIFSG273L6JZd0n0w5IAcFhSsUvPzGXeKlD
nV83HYQEaRMvw748NxJDFQy+avIbj/cJYxyfQ6126AIX9GRyynVOJSJlo7rL2ly600mvLUd+N60i
Vm6zA2hsbsGYtENnW8KpyAU553sO4B3rd8NEnO2BWDJBRRQDzOv15OAjU8KlzRih7T22BixVbG9i
RgtTw/l9IE3zso3Gzdz0nhf5zJjGOCV7bYoqPbj/8i3h6t4SdgqHvXNTL5wXsbEAdZNOKCjE63CC
BVPu0b7Xj0ZiEo5vO0tECt7QsdY4lyWVj36ZXzD3MBXJXGnsInXhcJXIm+KM8bMfv4cW8Sy+4r1u
Iw/5t+E1PCLbbyCeWaYgvq8QvC3m+o26EjCp1zshHhaWYcdy88D8gXADnJ0hwrfo5JT6Knyl1FTS
igB8j0f8IEbbgor3qCcvLsm7EqX/DCkZjjpR5wLpUwqRfeFaLUEDJkHQ/fLjsHLuNRIH3rSXGJHZ
TWIrCi2hNeU99+S08a4TYR8GR8sZV07qd5u4IqBa6vwx8I5SDlBRlVD2NDyhU/gBGnzI9egFAOqc
LJx9xxv7eub1EiRx4t3txMIov6E75ElnkE4MvH30GLbgzlUGjPBxiGVFrNc5MOHL7tOv2qmY11U6
LhHrDqRg4SwlupU6Z2XSVeAU2jX59VBoO+IYuxygV6Wbwmyul5Z5TgIT8Lxs1RNGQugX1+qPeEZd
eRrRlOInEVg1vnhp7fWtfAAsW5jqAVX7wVOUqJXo48d97Wdn7rwg4gNgXAcDZ9c9iMExa/WiPEuX
rntj+nZmqc+po0MKzj91MVB2tOv5RiP7D2B+2619pG1gTBQPVQTeJXP+pIn/p3UeAb1Q0r7QTssg
X9trIPYuJcv+5gjIe1JvKKiBav85JdHipHoNQCtTWJkN9PLx6j++9lNZelsu7gGO8s1Ys6qRKWZn
DBqU/luOy25voohagdd8DaYaLDAfiYFvoU/bkkn4rkywU1n9Ke5deAVkIdRRYTfBtLIWu5XlEH47
0RBc3tavdcLuFHh+ZksCDMUFKtLyfxDEFt6s4cDm5k78rdrurkM8Bj9cqNzIZTAp+i43Oc7UAFFs
xALvNXe3l3OkX2ad43lzmRMbfhM44IjrQImQKKrX6H3l+HpAfJ45ZSrQY+VoigoCTbVgmIGvZvQw
hHPre0==