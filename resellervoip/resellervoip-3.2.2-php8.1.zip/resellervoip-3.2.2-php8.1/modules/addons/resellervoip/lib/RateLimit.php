<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+hMtbE6FIDaMs1BS328+a8gHxkUINWRv+nuOH/Nqn7fINHGGhT3X+20FOSXWTdevnVRPOwC
B13NADhbLwdL/Utvc3xsAVHNflLdHpZCwbaM8K0SKn9HuDJrQJDWFs7ox9SY2jAr4oxCK9u4eUVW
mwNJuxpjYCxvzgInXGZ4VSv6VGY5laJK+c5+bsjt+C+3mCmxiaFUO/K3zBAlA9SttHzpInlPdTSj
Qdn6d4We7+iWMcFuBf+vxLIYRl3fdKoDiEMdUkxMzdlCLFiRSeT63Nk7gY0QlUKJh78tp+Q36Ow6
YQ6JbValBLujG6MczBHKZRUqi4s9q44BzfWtdQkSGeMGJIj5EtINfluEov8/5YnamAemf3vldeqm
qPhoV2562kbwn0Tbr5bkQC2RcZX/VaaxfYxpIYHMOnHS9K3w09B4XTksk1p9+dkPbTquD0LBlgRh
dtz1TuTHchWVtfuTrt0I/zntM5FXU1yFq3Dg3qQVdnJenHKrZGw8/fMVBocL9IiUtfl61uBvAwH5
vDF022hrHdY/AtqCW2g3wWLT4tmnTzoaayIyxrXRyVoDvqYDxsBesC+3wN7lG9hGdek+PecPr4Zs
vT1L6Re1fIud9qbafazEljRco9l6QXbvbTZNuLTQXKrd9NRpRPtwTFLxGXXRD08ZkultEY6yJUaO
Un5H7ToB9GrNobFs2zxeQKApZkIgflzMb1OdFcnSeMavnctZxkbETCT4BD3b5uSP9xFORZJxTXJJ
fTYUNR40BWkrZaRH45vfcZJuKZcc/7yKVtqMMtZ7m4nu6Og40hqJEAhUax/V2AihKPCdDlrkzlOe
Qv42smKjokEQ9f4IxDplQaagQhjd4gJNs1kpgoQ+r3g7z89jYmoTXyPpv0fvhHkW0jTvtJiRxvCP
Dg2JloWi00Snp1Q+LsUBWGGtLIOSm+wCNqijdMF3YVScY8/y547t0ImI2xCriSkrz729wn1M1j4e
yPGUI0auZKehsmI7mj8ay1tAgLLKkExxdme+y6sD0VzjCIn2h1APbUCCKkVot5Kats9z6VWzUoSm
NdnxH/Cnd4KQSKV7m/5uwPtTKVi9R5eMWJ/gty04KbCSjhLRdtw0X8g6ef1/YPqkEYM5meAS32W7
pkSJp9Gg9JJFY7hhisleucW6o43lFk7W/8x3jCSxHQa4Tq9kEZOH5uCke6OOUrK/KsqMREBYfuNn
JUOMBtTA7U+Tu+ypNV8Yjf//WiFL3LuXqkIJ0WA+ahyceLoyYjlZi3GCqYkN8Vlb25ZSOno8xpao
7mPurKqlBrRM/j/KYD4UxkCWU38UivaaXapqpuH+KGwzO1vVmPPHGCCWDH5c55PdgTvrXS+wEAfs
5x3B/FwWQhJzf77ILunCw8+ShtiuT8XjxIL2TPoi+G/GyLW0BvjfBNxBzJQNYU9aaNMSeiTz2lUw
sZX+cQji9kX3R7h94E1Pd5KNBriiCUZBrYeVYAGvGAFb1cuXQvQvIfU2XsyQ0SLjX7IXYaJFkV3U
jzhOZ9pPfN3yqfq6z1R+jtA0PAK3bhBMswKG/oQUbsr3KfdU9EHH6ovmOQqZ/RJW+P3fVr3jneSV
DudwnLepIfZP4HkuXhOojvavq7F6rIamdZ1voEsEKuNDd1Lius4jjf2470KFnVYw0jRl6BtRVI3V
w+BPqCVx1Eq93EVZz52yufkByhCURpwFJkQwcl++GIXd9sFKcbhtuY28r0LXQ/gpzAHB1A8z7u9D
NUtNLUX4kGXaaLeS0SlJPtGwC9izwGYe8UOIy8/R9S0SycUjcNyziiQV+iF4WA+CEEqLSW/ZSx7a
3WoXDDNMJ1IZqqPWfHxbNWIssBxoIgf1Rob4pQtrJOGNInUwBNXjN/94SwMjvmONzgppuK/fDkrp
ssTsob0gBirKeL7QnIRM3FIY+vUxVDm9Oy7zqLnQtZlZupO9INStrY48u+Aao0bUdQWzy+N7afUz
7x9CEBRSO50uKE4gr7nAwXTw9q6jrqra/IrEeTdRQXu077ti9aR6rSiM4IPAC1lFnRK8xzqb/xzT
E5qnC0ntzrZcrFgdgkuZhkb/+37UR2IrwAMNHiz3xiWbzgZro7wosLJqy4QMrLukL4A8KwizRKec
9ut+YDKtsMGfHC21bBmjWx4UuprtHqF59hzFnqlZl0CzaVz1SyPnJ6xyhW5DDtKqNTmC6Py73FQ7
JWEVEWAmZRulDhigI/RgVZyxTzZpLB2IrjNMEW5clY6UZOiu/VlVVipaZyUSG/5ybD8rQdMTgOoz
5kKmJEgCI1g/FpLa3sYIX67YbsJN39LAQwZ4czH8LEJRuRSlgpWU44bhIAbnhfM+6EkJfCQ3RE2I
wxnE+yLuYN3C3r7XPmjBeup9NvmrQZDT2GyOb1LSQjFbtgYcZAuOZr/gtx3Q9H0RX0hhjSmSylS=