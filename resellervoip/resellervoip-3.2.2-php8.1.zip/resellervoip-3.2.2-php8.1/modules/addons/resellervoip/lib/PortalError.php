<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwag/nU3X/73j5gSQg3s7PO7BmuTXatt7gQy10cB/D6KBK5xvhfnzggQya9fFLFpvRsSkiMF
4VyM68DQCmLUOHTfg5aRMTGnIdm+9s0qSuTstWSoRx0mE6BBhCFySLVob9GgR7s1Vorv//+ilWl4
lNiRsn9PJL3a+apuLNGNocR296id+ZxQH9CKSs78LOgL0SCgOXO/oPVXMit3QANN/Ef9H0kFZyD/
1r4TZ5jt5qXxD2cMdivddwb0dBiH+kndeRb5j3lTVCnK+njoXqODUuUg81gzvHFFPqoxjCuEncwh
vcRL+oqjNUKHpI37AlfuiFGPfgWFjreJvzLHCvGFOJeGfzi2Un0MhKtHhJGqqeGxs2HFOzGieKgt
0C9gVcPc+iN2h4SiXjNW7DhBuSGrvCJa0NkuTN8Xp6FwrsBiupQb6EihdZSTgXCbKh7gDSc6pauY
yxhZoWfoaTp/JQI3rR5M/xnlTMV3Aei9E8JZ5dR0M2U2BNS+crjuXYktvZzFsru18GrLUAMcpZRF
jYUBe1F7w0DKyyUW06eXLaEfOCw/kH6y2ozmbjDMmQP8IPG/7RrzOmRDoOLjnCTpM8/pLP7A4NtT
GAWSfEPVTxqGdTrp6JFpEjvHOFMkr9X9HFnzhiRqIAdoEHghomek/mq36Fuw6+kB3fBfJQ0/qOqN
oP0NGRwxwQ0ra+5r5ht6f516ZhF1X0arUaVm9GyX5LZ/+vElvS6JPf9djGkd1vedi2CIcsTWup4L
/kOBa+zOplfwvJMOK1mOe/2WRpvcTAHjehI8NUcLYAiFLDhU5TUC9SJN6vOnEvcq/s1+0biltTN+
z0dQJMjKQJjeGurXxtZOE2s8hAb38ep/50F/80F7g0vnCpqYBpHnPLbwQcirQ+4cz1H0dVZG8GSK
eySUHD3QzlSzlRZqGa7IZI9gNAMMWkOUXLJGQ76oc3E0Ojdu3JTB0pla0O18bDMz0moRVOWB4BDK
rouiMbCDmgFKSmSfGCe0y0fnMAAC16SD0FYACib4+N+TAVlbe/UEb8vCStx/M0k3gAJ949Q7+INL
6uhvMmqL+we9SqQszb+Tvn56fJB5cKio4VDjmYnO3MvLrQlKuWQEmE7W6X+UlYL+oPlRhZAM4XYO
5c/oFMhMhvHSkcDvyCWS8PF1Q43T2zeRZLjW37go4uX/TPSR35ctCeA1fE7Jp+E5derBhQF74nXZ
73c1v5B25EeaJ0nue6XhAB6PeLNaXeeeo8e1Mz54ZnAYB7e/UCJ2TNbfmDWw6bGu363J9DXMfIpq
ln8H0JrWumv+zY2hw3uPhJy5n56hnZBsb9Gb7j+eaF1BzllwOSINwejVQF+EI8G99a+uuiag1Aim
DKkqnrCG4DTPp6ZHT+yjbuUbIOd+BZirCkA02UpWCC0FrG/Szt/TUi9nOqYbi0sIuSJ4ymTF0dPZ
GBCnN++Eioy8SxPcsNcgTvLKOC0EnG3OsUgedrpHdsvpns6W3Ii4p8ldqAW5GzVq3VEsnH5VtPWK
Z98ruuZIlG13FuDAJy2pkGjn8JZkyvfHFe1KQ3qrNbzaukJCejiF8OqEMH6+VIucqZgoq5ewrrxu
GcyU661+N/Yp4PbR5u1ugkhOAXRkU1eS67UtXpzsHQX37zbVpgZ36Syaf2LTW6wkrgjtkVK7Abl5
pV6BubgvZRxjINX8BjiuEZkQH/CvkJsjxImmiIkVLhS/VwZtRMJb+CdjJhNitIGtIoyGUxUBwacl
DKLnETNjLNxNqBkiPO0Awd2OPrSqMTTNWbGqzznTXhmS7B9P8/25l8C2okSt5QHejB6+yyBjlFn2
z1nnQwSge6Cf4vi2LCKKe9VcGO+RATxxrpy143Yp2QzBOVWAUwrMfsz141vh96r8pVF3sU79trLd
H8ZCElEvaVsWMFEvaFvwH0903zA63Ah1vnPJDMRcM12IfB53o3TNDcXFOpQniIjn3IpgxJ2P08sM
WPui6GMrxjpN7+65vygNJhhhqgVRM/GY/9nT8jMbtYtufTc8BLNMZ516jH0WNu5PnnWYTV4SBDTm
K0nM0avCYlQb67fxlVQevgkohKnyKOH2CEmkHvYY82kQJ1nE7XVkv7Kejvee33bhhtMq+kJOcYcu
5jB5VLHWJpySrA52xLZPzLT2WCbzBJKQI9FWLGQCiriWFyMjtBrodWrD1T8une+KUYKi3lEiVqKb
HVqXpDH0AHoeJ9qb55K9KnCuK115CmU9k83lwSVxsocM89xR4JkbidK4Yx8OMNU640z1jJkEUHyp
3dRT/eDrpF3sWHmeh03EtlVK84ID8NGrpAm4YmebzA1A4ScOmSRHr/KDfQBbJm8=