<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxfpSB/xnKYnXidbd9TwnaVdNOZnQyD9vwoyswLWifmSBN8NqGUos5WaUXPHjIVhMLV38Khu
/zC47kPyLGMze1a8J+OWSUSsAY40VU6q66clrmNMS4MbNipE3k7a1ceSTwsURfKjVNpW9OPtsveq
HYx9og3lM9O+L48aGWTWiClH0B6FIF1hr3IQDl8mga8+DMchVfBHZ2k3Mw+bkaF2xI+n6bA+2uWE
ni1shgrNVKtExm58cw2XK8DkdVOaagq5Lypc3lkdQynK+njoXqODUuUg81gzvHD3QiIW0dZLOW9S
S+bzTZ0jU/+Wy5kMVClNvMynycSSKrJ65+JeEtDT8pkUXQnR28rGOwDxf7yYq3lCRLaBSsOonvsv
C/Nao3uCGrvxbd1leTtte4+XOuvud+esPVMFmp61NKzwem6NucBFeXNU1t77dJxy9m20mTGeM9nF
mZ/+znNIOVZ0JNRDdk0pInFUVn56m56gTlgtsDz5ZCyW1117i90qq792Ai/RIXn0zKtMzVoNb0ns
2B8WaiyzuAemwblgH4Sf+zMEulNyzNpo+mOgCiBJUEyf10iCmMORQ6fCkOFsvDl+WPO6mNHSj0vF
hDEBUHBUqcA+r5ModeyNbR2sX8RKmD052rbxLNJYLqwDP9DamGbhBOCYGkGJV5A5diKsAv/zVm8q
wHmVCLkInEV0Uk0bdjeALms1IDEa7IBpyZHa1FX6YNK3y2Q+3DGNIfcSTzJV4OXIzZ62ffuR7yf4
7sSqX6w7i+YGJh05fyrdcFD5GEjEtE4EDUtJ+FKSire2/O/c61+Deuo1ZXRn2G6K7LP1TsXH4QIT
ZbfKpmZFyr9rLZBkJy06elAdQ34v6Eo1Xvt7uG/3mfyeC0HEXaPmp8sNyvGDSO+pD7PcF+vzfwJ0
TNE4eIGENHJPIkt7KOemeQNfc7M49KSkWvhupwtR+duYkHalsPDMNIWd7edMFrfGDOPoTebPYMmj
tS4YVr2jzLNGFn/vVMEPQM4zavIjIFC1IiyU1QzxUz+weLSD5wdI4AOD6xr3kgtcd2A+kZq601Bp
GjMrWUs3PDgA+7EAjvYcy3sAgO8Ca5LX2Z58AyUafhAL92HkvMpCbuHopwQmPfc7jI4/8BQ+Vpgw
154Sn8N5moN7QliNh2Luz0UUq05sGSt22Qos2QlpsFPojvcTDkEP1ckvXojcvyB6gnjVHknqi1fH
SqO=