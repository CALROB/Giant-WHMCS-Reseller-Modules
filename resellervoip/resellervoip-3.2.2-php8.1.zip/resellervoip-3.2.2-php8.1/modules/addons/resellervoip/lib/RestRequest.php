<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoDOTCHUl4pi8+BXv+q45WURPQPZdOWO3VIBR+sx8J9mKfd/g96ggpUSJdzqsh2fWVDoh8MT
oH+3d/LJHeq99Inr9xKm09V2LoxwqwBa0e74o5GhEFB20u8alb91YdfiW6lGfFauivxoIy/Cn+Yv
7vM2SrsurVjRnkME5+VY4E2ysoMccUBwsszC7HWr++V3T6ZnmR5hS3MPIPKRLf6RDnxBf0BYEieS
zMaptTb2/zHZfY/skk3EFXkawgXYCjfPkJyrZwOJ9qrvyIPhvj0wfqRBFQuAfwxTYsLoOGjHq2yf
BbhrByIDdcrM/v/Z1nHmm1lgzh3F8g7AUMSJY0cfSbYEA5gGIyc7A7g1fFO+Dv3o0ycE8meRPD0K
IDRHQzRW4GGXHccdXALvCxhREm8ecp3XK1AlDrBNBIlYYVbGAusXJ+EjV2bS5UT4VXwSh+AC6HiS
eCYY9lDgKImj/KKvj77lFNeLwt0t3ARK8hJ4/1WXM6+HWXJjSvrQtECHkaiWripIsCBBgIn+3K3t
hDfK92cZn7svzW4Ny8PasFzjf8shxnDedYyPrPEu4XguyJ69HSB80PBi78fzR6Rtd7eZQabk1Ey6
zbj37JWnx/gHw39lgAMlDeNymwJ5WuetXh5tGUzcdWKuAfGV66p/O2s5IXydK871nAwTmPooe75J
nPL/nuWDup+v2FsRfj1aTopaoOa7WCuz4RbnYJ8lhBSa6szi2u36SVF6Uvq/jvodk5LPIgeWiJNk
4nFIwrmTbGDOuYpay9vY7l3pTJrUtwCSNurhBXj8NbAdwwNUK/YVr2wcd0WqTjQnTNQ750hPC7NC
R1nWyWD5/IFPwD7E5uwPrkJq+2oZ2i6kZjYPQUyn9SQV+TNceaptgYSXXWySuuL+PhOFLwBNOtpY
YE02lcK7MSyFSS1pv5UteFOrxXfVnYKW/KwC40qpFIKb4OMU0SbsuwKhK5ML1fvhNj42vXq2DnHh
6uJIhG7Basm36vbzxHvYx7CYed9dxu0AvWM3ChcyUVkMYAFKfXLaSXM3DwGTeXyXFtFS3KFvQNBl
UvSIDbAN52QYZ+yi2Bmvbkb1BcXzPxoEvMcQSGEQy6A5TogLQ4ggEgrGE2djqKBGyVSVi8h8ppzc
6iEd1G5nJYXGQlI9kjgp9WDoZOPSbH8CSR8NSQy10ndOAuyFPspuMNcVzIs/HHi5xu2ba47+7W==