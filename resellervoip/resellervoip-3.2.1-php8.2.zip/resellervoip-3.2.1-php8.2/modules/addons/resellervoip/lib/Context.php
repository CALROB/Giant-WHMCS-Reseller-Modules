<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp3pRuHNHLIiAadwful9tok5/CmVxuQ3l+P31anW5SPBZKjh8Vt4nSvag8l85mjs3h8GMx8j
mfdfKy2jeVDCpa4LCGfwGXWr2sB4vVut/GNbTvUIrW8+sor6Xh0mW8LuO8dyCuMSN/qrswrzmsn9
0KnbWuERbUnEoeadXPwHTldFofNVeFtyt0hwzInQxDBl2F6kzAtB0mBhuTK0r6XpMjVqZWv4jKLH
7o6Kt9/BgxE6BE+hnZahFu95rdxD9EX+lEJARINUTDCBJeHzivIrR7RfzYyYACb6Gd6krcWObK10
7dQJwVGxBMx/ninqYBfTYXo0drkDVxrDqXwMiirQGFBwCfYeBgF16gDj4mdD4soAYjyRHejYjdew
Td9uYjgyqWStFoVBVG+FzlvDX9LpEszG6tBhOnYXinj58aqgOSsUchjO9aO6Rj//j5ny4lGRPiit
6tBQL4KM5euFC7IC6kdL8oE50/xkw15CyUg1bWVOuYI3+AESxUievWrbyzNZeGf/ziq1QAUOBigJ
3TQmMW8PN3I8Mh8gEvz+IvUfTg3QVARuZwTMjaysddbQKwWl+2gcvZ/GcdjaRxjRBwYj3yQrwTKH
CKeH4IhK36xoINtdJrERGfBkIwn17Yaprsb72eSz8ttbk5EiRV++Qi6k3IEz0VXV9S77xDIR4exH
OXxzIHhSdUBFmjvwMfNF5RtcNBC/mylzcIPJylVdBp1O1LqiMVn85re7wRU5PBF2A4sijP/Z4PYt
oLAlEZ6jgEyQTJMIUaLKxaUI5gQ7MbnlbQ4LpS9bfjcSowRgxn9rRzXUPPtMZwgj42T1IP9O5vJv
9FcIIoNLVnTBgI0IwkI3m77v76arJ1W2/iJpI6BUIRCfZDvyXjdTLRijNbCn1Pw3vlZgjXivsmXh
3D68SaBcXsvwONOMrEWGC+EcfQGrgTVcJDCkPQpYchVTW34HbAer+jeKC27EbimlEOzHye0bJuZn
C6cvVEN5x5iAPIHtlkarH5ZSz+pI5n/FKwBMBWLhNFW3HTIL0jWEdrKANC3+z4DOnaQzH4/sEf3L
zKMopCGmcD81srXFHSgiAS+NCL2i0OX69Qe7L0NZqfIlm68XtPO3LQ6GJhkCDeimSuFRrgHXYXXl
5qmjdCKlBGSb8fzJiXxY9qMWN3T8rdANj1q+Zpi=