<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmkbBapyZvDZ/HExRy75iG8FVoINvnARHVYXUMcInqHAXyM6tafBA2RJUedylaQGvEff8GnO
kU1ENKnSIoqH613TmIQzlBLs0XViA5VHb0Jzk9ZZv8YLYZGYvvCnPc76JqFdEXA4efsN0nrgwbGe
m4bIM6ahgPpzJZFwd6qC1Xj14DNifZ/BO0nHWBvd4EeO3G4CVxnKx+FWRK1bBMG9fSdCUaQ9WmlL
YXeTpQiaLNbLIhqbRmrFwDWxN+k76e7ZLwCP9fnnXbyBJeHzivIrR7RfzYyYACb6ccCpsAYwfbOZ
RKI0GV4xBH5F0rWDxAHzhvBk1bSZEGlzPQItZl8GemicCm+uifx9+c9o42dOX5LQEntV70w7sOZq
Fc4G3l9mEcYpJNS0OG4MESnAYqY9jHnN5So25M29iv7QHN06YyRr7BqMMlIS3Y3DI7XpynuFqH8+
9OdjxefUpuchYSfDt/DxPP/w0I/HnBdL2OUdH8hNPxu7/+C/Ba+FsWahbUTMuuGEK7xOn+61nW+r
LZBmS7kRYMhh/9BfkmnebYop2nucbC2fAdNOPwbQMhPBXLfWFgUuS50nWrOzIMtLJin/Z9n/b1SX
yT7DMQmsM8ddvzUkC+9Jl5QSP+m7s+OhS8kD31Jf0ftctrQTgVTsQdoj6/yml28nFX6lZKK2zVEM
Z7TW5iK42lyG+Gtczfv9ECmG5hsx2Fyht5s4XseAmfFkV3UmfKwq3ndel3WSmYOp5E5enyCAJjgp
m4SXQ9ua/eDAdCccOoc4pEyQlFMzL0dKI0wdk776sbQe2No/sKTNZOMXf99RLC6neTtn7qVAdqhS
vyY3/GllYQ3VNdeqNFmC9ZtwuaMnPJBRjUUmINoY/MjT6B2BUDAEMJ4NOarRz3wimySsPqSbiJFB
m9vjkUr+uknx+C7CYS49NoNspjW44V58GWm8B+47hxDwn/29ZtCFH/YzQ0cbQrfsL57cx7/yxCfD
+avfWZLIoaLk4OjCUY0f/ra0uOe7TUCDnRsEQLYCMRP9XoXClYysrepIOzYuPXjyb+Fe+XMjC4xj
DZSOBhUZrmIyziK4UC/5H9dX5JK6suqRLzN7rsvEp1pi5Xvw8dP06ZJU0C2rSxZu6TRCd7GIWhl6
naKckpE0cRX75xxOGve3AtG4Hd3C/erOo5MBN4eY858pKbXUCfqlsVp5x4qtQkOjDvKDG0ENS1ON
Yc4VwjYS+ffTYmNH0DVdYdFeBJTP5ltK/GQ630bLknL/07rP7UuV2+JCvZde8M+pta+DoN1zixHY
9Fmx1ATxztZqJeZFlng+CxUUBcC6SPvoYKWCjD7bL9kFe1ToLZ5laolZoN9nBt8era/UrseRuatw
I5i1ABFQt+qwaY4xbgIngNKgy5XPzHC6SClA/FFkZQyxNU1KplFvH+WsMMI/QLaLdw/lw12vvwmB
fXz0LlAk6PiFOXCl1nnMY6IBfsOiDhtbG7RM7bScMJtQONPVDTrjRJ1rAnJIUoQDOIU51cKYGCA9
c12jrV2Vvzc6dmMmcNrAWHoWDfgBb9imdJz/o+LT2lkIRdSmfKzus0j8QlPU2I80xM1xVanyFSF5
y/np2lGGIylTyLV50hqNDI7nGmGWqWdSvL+5FGe2aXE5ZQxqURlmNYSolJqkvfAzMV/PrVyKd66h
qArTKjo4ocmx62mIvf5ZDPg3AA6YEIsbfjkrZpkl0Q/5TomQ0F1NiubehKh4KqVMnYeUiyTlvOxE
KnwKSOUJ5PT/D9bHNNyofQnD/TkL6DmiqeJpxTSbzplzIBaSmPXklKrCfbLHVU9WlhaJhD4jMHxS
VuwSgbQm1+4S9PVbWpzM8wMlIzVqxDQIVthFsMTXCjJSZ1AqR64hGY1HPVpVhROWKzvV0CyZTJIp
H2A/B6kxpMgaf8W40Lr5A9P+AclN8yJobQctQI2hZ3WZMe35S/w60/xMNdaYPnM72+EIf2+XhSEx
ErNJsEBivHREp5xf2b4TBC49iRm4EZxpGLDo1PXV3xNf7MsHI/VhgUeHd/59EN8VeH17rUGLT6Ij
BpKG7egCBIertKaYxyhOZJRz/3ItKGCZWdowhOG+pbd3rJNN8Aj4bInv483Tai5BIOWnV75dK4bt
zCwM6qrSJC8TFZBLh178jB7ZyreeoJlWGpeoJmLXfe135N6Eix2iiz6Qq6xEVW7ML+1EdeQb4PVX
a+Qam3LimEUOQfFQPIARlhcddzahnRfgkRMP2mV4HRC6fAhi5CC2pgjWa4DubVkRiTAfgLVsAyT7
w9jHWhfj5zSONpDmHP0jnZGBK6OR2fdo9cwAu/gTZb7sXCMonBcJwKyL