<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwnbN5p6iwIJcz/9Vs3oWAovEAMSqqCJrPoyORYw5wCwXQBOsHRtGMrH+3CTb0ElspPIPHTQ
JEQzeTsB5f717CPVMsHKwwT5JGQBqc1F4idQ44A9XdepPmdJqat5VFBINGef/zIqR7ODk+vcXJwW
unV+LWylPddnzuMSm8wlKYS4SK9PRHrZ2XuSEqpj6smuJNNVc0TqbRrUDQByn27TBcZ/ikGGm8Wq
Jc7hrgDvDs9ScjxnEN+qfC0KDcvYQjVpQAFYp73dpmjEX7spbBLiTkdsBo8eoKRaQmI9yN2Yh3+6
5Dv1yKCjAFhkya0GzC5fY/pq3JN3YyG6jQg66xjajoVr1mc31mJ9PLE5C0YPmtVty74f5BOtEktv
h1N2Fl0rneFXG6rDxRHQ2VplbvUecyg3CmUKchzeUElD6rGClqjTlegiZt3WtAQSHz2RqvJZBR9m
CLrAY9VYRYNtRpJ4lDlozgweDtrIm+6zSogxXsk0YRdIykjdOluvz5YcwSEoQ+MKYcWLJh6JPldE
Kn1J7XVOHOxUBCZjxy3bKU7V0ZzNrFgzLE5Hb15HMRr84Hhfha4+z/COq4p+nY/5lbEQjZQr3nlX
w12ViXbTU53uzefkj2Gc76QeYndKBFMzb9EuovGPY9Dt19EJqG0SrNj5RTgyY/fRlo/yHOGiKKt7
S7v07tUbPNmJEdVAwBha6criGPM1QA7pBWC+G8mS4VAMaVdP5Z9KgcCwfjYnik9C/T5Y4c+sRqMk
24+l9zxi9MYAO646CqRT4S207dFYfUy0CGqTVH0mKGcqcn8nl+XCg5uTMRm0J99KSBjtvrq4j7Eu
5sCHoRH8DuIDSVitCOzufkhaKEncSeOUaOCKelpHVzBBWzt1WgBIi4GboW3zyW6hwifSIhMptWiv
tZNQH6JEih67MMJ3jZ9DWs+wv9ZepskbGPm2FWHeq5CWdj1A8ySJz87mGIMtrzOJnUWXIp5w6c0u
CYsXz0cS5saCDb7q3UYXYkPW0Nw05WwNgVvegSWT83UP3yjLA4m3EPJWau3au088Ufuoo0SCvs8E
rNQW8tawgWpQ+nw3QWGmHcVdxObCzdR/nhx6QbIREQOZA7zs+3jZsxCOgkrL6mq0pCVIk8DIJHCn
B4VY5FUzPqp4vyqJb0NdNuPdIV/g/6jhVWrfn6MsSEUbwkhyUULmscVM6IvXX6ppI70pZLdLCH8j
LNTzegfVL/Qr