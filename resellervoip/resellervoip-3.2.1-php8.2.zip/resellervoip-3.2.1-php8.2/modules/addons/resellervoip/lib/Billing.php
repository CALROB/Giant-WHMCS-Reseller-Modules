<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuz9nx4vbZk6mFnIacrRz1B7Mk/y8oUnbOgy5dtnlIF3rkeRpRI6iCRN4PnvsL+m95qRL/TY
Lf9qfB4MSB6GPdXVIXkquUC4U1Rx54eM74+8C4mwjQupTJcrkPjJ75TtLTnEQm47Bsz+Amg6J45d
zf+j2rKndOd6P+rmPBZffbJbfSybOdvDaelNUr2hvvBcpbEdpu9xgHrHXC6AG/donz1kjltCnX0d
M1fxH08LQ3w6A/hP36vsO7nUk8jWQJZysSNUE3BNSmjEX7spbBLiTkdsBo8eoKO+Qe7NaHR4jrvD
dKmnTK8j71fezApPmzZMaNQl9QIUOaLvo+w7YCnZjq3xU9pq1EHcxg1uuyagDykgiQAWrq2gmNdt
tCVcLhzjiHncBH6+IuI/4X1+Aw4w+W7BS03lQq3hnOXbarZ3/qEepF3r5oz5+FEcYoqfAmpXphY3
DXJeHJrQs6e1M/TEanmr3A2aeXsCSbYEA0JzYoeSM9FtvTGQ6gWUFIPDHKLAUrT/lHUEANhryGQh
PWy+KUMbAeSKvAk4Erqh2pf882lR/HRNVxx2+CVcMhBJDuMoU73HyjUcN7xuXlMK/6HORj3ChJ0b
swEvENA3A+fP7bLVtSfqIQH9T5njfHQhHd/yO0CbbvgWDFVF4dO/mXd6/gdxNHHEMyLmRX1bm6UD
2Cr9Md+OwyYsNqL0FsWvOpLLc7Vnn6XwXkTi37UlDsR9LEi3RNGU6oeiVR4vIkSDKN1T9xBDi/HI
ybI5U/+7fiiznTkdiks1iZaXSi9NvUd3tJq2lVEWShkNsanYz7SeRvYKhPvU5/yjHAYLwCOoBlHR
SV2fQmJ9AAFBRjBu9xQnx2PY3liWpalFGBnjQWCmpB/8LYtG/aUhTSvbSibN3IgU8GyDzeWkFNOg
yzEA1xwkdy0dE+JwBJx4KqkSe+ZAaRq+7+alRtaP3/2clKDJ3UrvN5MTma6AMNOCbDwWnwk+Mvvf
9qGgj0J5Ktff8bwAEG76HCEmyJUr9DD3ogbSJsxGrir/baw80hh/oj/rueZ5rOv/YANP5Lf6J04s
kHkfcyxKIXfPKVuBjmoK/tx81igkAoCWHz625B1rMiTqEaxhO5lS7b94W6LKYJJgKL6fBbLcgUHM
xtx+CgBldr3bwOwYa6uOVFJWmVi0TXU4nBNVGHAOPZWtnhfAbrVqq2ozGKUZJk0/zAnOUE2xTx+D
KR/nlCIN54ybZ+zdodt3KGXI6YOaR/88nmaQ5yxiD5xiGIkHZkeATV+4rbacClZ1UianBZwZZJPM
htekcfY3+X9KTFGvxbmPCesmAl5UCG/I6CwPIHqKnZLNf9VH5AiFXtOLEArNvxKF72fp/pGgD7X2
9HX6hy5oICtvY6Tt67MU0V9p3Z+rVuyEmkbeHFbQFlwQcyET6ApGUWXXKDxf/W6bgzBpjODZL3EH
Vd0dcC4vh6zp6evmFxRIPm3uwxJJl1HqxgRCuMr1GKlG9uSHIKx0Aqjr7hgbvWnS9Ldg4DGDtG6A
VNXJ+jaiITUeGQLqloHOlvzEWlI8bkTvK3Exn+T+xBHiHSEAlUAxOsvol5f4fA/oreIrqwaW+S1J
swKbanV3us6owFngRQpE+6KYt+Yj5Oxxs6FyRUVj12A4hVGDKsmugDNz0JyTN3V5QWS8d/I8vYxZ
GpN5/YBfQfU9hegsWb4cu37YuNF1VI3/sY2ul1Z9UrtydX3Kwkb0E0TJoqrfp30Wkbff2Y4SoZT9
PSbE0h/eKWCufAV60z2CRq8mETJc/BUTK6oVzXbVKEPSDvcGCqcZ0brydzqqCKUaNx80P4eftvlz
cdnpO3O+RA4qqh4dRrXUqVSf0e+rHssill4wmGIJ2yp120X8w0dMOz/TZyacb+9yqs5ZD3lt4CAc
axlQhBUtUB8pC251dKECP3Xn3EvPjZ9QAsDw5FP4efScXPX8IwQoGoOHG4bGaDNncRZuKyPTm1go
nrCkVmzVQUfj5aHS9W1JfCLoJByVx6xVJq9rwdcyZ0YknpaXNZy73e5OGU0pXXI1QhUW83rHYHgS
W7hoBUF/RhOO+mRPOwRODZx7BssTUBnP/xQmurvHycwViFpx4aHBShz9q8y1iqUtdMLKsKuYn09h
f6gfrfi=