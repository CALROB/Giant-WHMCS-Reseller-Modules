<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtpgoL+mJJAGIL1SVF/PxxmRWTaUuiJl9yMIcrvq4WdaPsNw4TJbCNaxgiQMr7q5NVaJUbb6
MdZPj0UnwvGkSc0302pYTzR/lb78NKXDf+xt2xZmJtQlcd57n9s+BwtKUd9okRNPwLN7Us/mtWq6
8rONhhQnyFhlrumdDAqjdKgBZR12flMFsMyK5BKxtnzniiBk2qoQ5Cs8eecpaxt4NXnPvMlQz1fd
f5xKsR66AO/Pnei3vB1rsawFqIXmGgcPOi+/gWsqZUz4DhDqUvK8qxwitCynUD0xW7FGP7u4YdGK
arDESm7Uh6n5fTI3mgeME+rztOUjld5m6bbzyTdTZq8mQYxdwRIMVl93fHI0eDJV4hhk3GNG5xoT
kb2OzVaMsmDbqSGdbyQcJmaAhYRlZ6bO2w+3LhH2rPGrHKqXcBPoEnrB5fmWRuTR1jldKen9KZwo
MMdEgCSk1o6AHG3miocjG1Za89Y3MhF+fgB6pc3z6L03d5CEXMksnwsfacaKSJkGvyp+G17GJTOI
eoipOzgXylsgmyLBrhmhVzFAwnQCs/SOyuJdzA2wa/G8jvJcibOrxDFxpGsOkCsB+dQ5MBSQ5V+R
GCFk2Wcec5qJzXakhEoTwP7DbffJmDWWGuKdcfw17S13J4DxeJ3Nz1CVSFexGMjlKBI+Y1+dJ0Q3
+Yg7QYYHpE3YPdgaou+VpTdmmxtvVpYYEfMZyDZXj2qcHKNaf4Fv33R9M5MJK5UCotLDWPTKnJMX
/lSLQUPq0R6d2zRaHyK7eH99ZzYgwADQyiTtJJMofcJMFSCLOgS2re5ST8m6ACI3C35kj4Zt3aCe
eFuYWDVNKzA2TVu9n8M+r3QWXSb3O3WpRoYkJ7pBSypMiWc2h51r8FnZJZ9Tvl+zAgZTPNT7YBtG
H5KGhFK9MAMM/QhqWl1jqZtjow3rhmZDoPw13ShRHy0CrFHKwru0/Nh08zgcalMksuSctt7st+jp
zrfeQl8I6fpU8bCRCvHY1WPgZQgQT5PVc2L9VIDXMVdTZsY+X9ZPhgqguJft4XIz1ze0EipviaTA
k8CaFuhsXB4tf9TRQsl4LLzjNFi6/VbBib3Rli9iqNYLvGiMPjvJTcESma1ECTbnfhguO5KNFZCJ
BmccIQfoisUAnwP+C+pITSDkru17yjQTfP+AEkDg9RZrivO1IApXGin+rkEOncFXujj1zKL11Xpx
/LWuo/v+lx1boLq=