<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnPZO3sno5WpIDNr7gVBJG0IttSzj+j0regyB4BfGP7apr0pr0f8nPvxfCiD06hY4Q7cdz5J
tW6LPruhevoE/MK5KWOuo+XyqRdLeJh3ijK0iFpUcqCk0nBlRHj+Z27mQrTkoTxOujIqCn/DghQ0
46A8SOgtPy5FMtBbZw0S06D/UYRHBwkuWhM+LW4LcadNipJhkcbaSIOSIbdPmHmvb9MOe1CcOpca
BuiHxXwQzqmgit6Za6SbAuZsxlcP755rGtJyEg4aWKGsitHxbGZJlgpSpp5uq3jVQU+8su8KFZoX
oBTp0TkiBoZGR/9qEhKCEEg+J4m9MIsqeGkFQ7ORPGwSaQPExv4r80uLnb/Vvd5CZmTAj+OzQibc
50KrwwtIUEigAEnHCS21OCmEUdLEu4zGac+0cwta2VPES63gFo3NpcofyhUEiuj/nEeSw/mWpiZg
qxsd8aMnPFTjETPfso15l7lhHrXmU1/mvUumKBzxyemU+p/eM9tNYguaFgk511FehTwZbgrq74CG
13byW7bD64YgkmH96CW/zdmQiEFj+AMJXpT7mNkIMafcyEvY0j2ItzCFDdlZuKqRVKzMUvWuKHs+
GmV5nwi4CefTP1wFB6lTSM3Acg2J76sKjLWDv23pfA0qgWHVY/mSjQmQD81K7siTXYXG0KEpGgBJ
5gMPuGbOzX4vM5Mz0snUAzRtDP/ZjoxvIVPxInCO2MRdfUhnAKcQvZRAH0713AsC45U+0/ObBTOb
uIhFvDQPNT9+1AQ0FOYo7vnle/cxXhIXFduEur1JgllMSgm64oNdt1ywZKsZQflwO/Jd5ea7dVXi
AKsuO0NscfMW96pT/dcajSYUsnn9peh0wKTXAU2d6RrL3U8SxNZzpIPr7rO/3z2Nk/yK1e7fHxkI
iaX3WKWKXyYCjH1xn99K4J95kEvQDD1mDQOMftLSaZV4YKLSN/dEz7RFJ9QfLwTCoFO/iQme/tTt
ol4iJvF9LlaPAFIwAFQ8srvLXyli1L2Vr6aH6dttEnL6OqM1sn/bnLWAazGAU5C7n2tf24BBIFnY
UCzpMTNR+YUP6UW0ZNnmYrn3np1l4jE3bU+MylIbOwFLkzKYK9hqWOgWVHLCFPxAJ3SPW3RxPP5d
Ih15K6fg5oDyeWvpVq1n3U76giRiOiv53f9jXo2o++ufuR99NFK04vz93a12pXuuZAGXSNvny6u+
5XtXhMVV1KjcLiPh06BnRZirSzK73oOAiMQbPMkY9smjzHRbhg+OCZyRujhvTCaQ1JQ2SGUJqk4v
HHBA7OjrEsaCjDPqTv+FzjdXFtbbR0it12Wac26ru8CCa4/n2yGfpQEPSdfd4qfiyZXHSrz61z70
+7hbbY1vsIl7o4Vsbf5eb/ifsi47+8782U1rxWKIEymJkY0N7uaTuxDZdFzd8ibW2UlbWJhY580Y
SfSmGPjVgzlHfQkIiukEZLXBXVRu3VsPcFVkr8+nTO/E69DN79+T/Fgm5qlvOopOvKU0GU6r0fRZ
+Zwm/OJOWZjR/CLlWYWxzWSqEVpDTYnUts76oIkJy9ksFixrRveYKgRJgyrvuZOKTTMPYcAXjXVZ
d74BDhnpAhGY6YIOKOP/yHVaWzvOypAfieI1cCxMwtXzRBNGfmERBled5s1uN+IqKLrznKN0VpF6
1OAwnjTdgVGw3RhP37xCTykYSvBis8Aae9O5WBFrFvrbrCuo8m8iSABqEOBUUeCxuWiOnH6TI4XP
18QCczO+7TK4WwM6rIyFrnpGJM1cXwttLKfJ/diKy4wuJ0IWwo8oZrkmN6gpSsshzF2l6Mi30WAm
3sT+UscGiFyfIdt1zqZ2L/2Cy1NftRBtHxjFA9kbrjqz/f/c9GTGYsSiXQuAVb4/+H7tkEuKMmB6
d94kWeHr6jMrPdvMdab2bt9g03sXtfrzyGFddCnXAJu+Idt+Cwa6mLLytDUZQIjUsvfSPuwdhQ5n
B4zK9uu8dJ+dzYbISbV6vUeEb7rMxmUjcryX5VOWpolcpeElxybHm322VAd7zB29VKnBWhINkx0w
V581cf8fD/sApdW+KDQAxZa7MTeelzs09tjspNo+4SoKX3gF4YXPJLkTAkxldkClDhKTJz4C2pur
PC1/nnH0vyeg0is/l0ZR5euIxlR6ko98V/JxzwstVOFuWvCiCN2CAfVihfdZpBAFCZvT1GvUVQno
D/zvR1u7YcNu26pKO5tvfqgk/t9y71AvMXXXmNna6EW1Y3O5B1ozEuDfa6xdhEwkYpvKS5GwDIU5
OV/I7e/p8dzWrWA8ooiBN0kJ3AqKb3sajnmUZd/3bEHhmShejdrTakBp2Tvc6ZFa4MY11vG5zd+R
oP16xWMxUxDDZXt9aUmTOFS5wDDu+xNk4m608AxBvtKBB27h7YaIksxM4SysfzYSzz3VN1IxT6pG
CxpqMjoySh6B8HYpU1bR30==