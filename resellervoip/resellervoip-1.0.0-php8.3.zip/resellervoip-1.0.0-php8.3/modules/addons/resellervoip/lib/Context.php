<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuieRCpE35NaavBvxoEWxortEvZxsyKFkAoyfCH5iwHFCDDPAinFyoV0Ywqr9pcOMzCnDRnN
KguSK0tMiS6+/ArfEBXSWZu/PC1HfZJuFU8ChquAZtXZj6n1rIHKzaTnC81YQoxGhXNQ17cT/NZ5
HHWWnL1qmvJQ0d6WVg/txSYIFvdNI0+whlP0koW4uWqCy1W4P1EPWANe1UiehKrgC4vPkIh64P0a
TikRf5rc0mdbY+Vej5XDvSA9151xV9XSceMAIUUxKKGsitHxbGZJlgpSpp5uq3ibQWac0dyVIX3C
robpWU2iETe0XrQfabSIJ54TuyWV6cAjUxHrnzLWwV8LKh/V41sHOnqsJ+tDdbx0v0xXwvsW+qL7
hXAfhTq8PzbWW4LnAwKK3F7Vj7YPPbTwCbXOn41n+sf8wUqBRovchzfuATn9L5KhZmxeirkS6CAL
+tn9BlSvb8j4chc+iPHTc+u/NG4Op1Rd5+7wc5djuFv8nkzyAPltdszBa7wBkHIHBQ6M8zBHgzQi
hd4uhHsR0mLSmwxYBqbl/M/BhT/mMAVBUYfaG4+hLXWBxOLvfyWd9XeItxf5bj3U+XmzsINDo9ck
FIGC///FxsT3heRgvp1qdwRfxgjFx5522G8s6IOhinTrkuFuJKjbjwvI1DepGF1Ms++EkfQ6bLNf
0/tXQDeWzbAvpG/pZ2ja0FkSDJh274pTYJaVQsCzo64oV2heHIQyQsVkX2ZVXun7tLxLX585lu+S
//9v+fvsg+jfzH7iKHvnVSCf7/6BAh62E0jcYT7cFwzim2gHsmNekIlqbb2T5xv3qjSArwlUyb6I
AG1BuzpTzhhiGGYyHbbE+3KO5zYNkTrLaYQ/jm39rM1QOqtHEoDqsEH4QdKgS3iUqoQpn8KwAKTD
oY5eaf2RZnXxx8ynLaQQy6/1rvJxpkFGS0laGhQjc8vOy/X1CIGh0GvXWIixKq0umhMd50seuset
47ClVqkxonx2bgjxQnPzeRmCdua28MXU1PIpI04R2A3MBiFfb1JL1/fPozPfYaa+pCuuyhR76tLv
SAoHeRixzedBsDKt2Dsvfp4BQ5/DrJXfFlYjTiwWxVae3G875tvpAm86csADPyCdysGiJUlb1vlG
XzdVG10xi6BUQHHiA3/Mtma7orQBxzzyYDYiGaHOVW==