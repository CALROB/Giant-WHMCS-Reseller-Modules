<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs3GbY/cE6i0+sO334+rdZGJZIsL2GZ0V9QyN5yw8bHAbhjbYOBnpyt0OoFtqwBovyZ9WiSp
ptYp8loxjuYn6B78J9zuYtABfzT+6ROcBun6bQwBAlyNmaOELmz9Kn0nrU6ui1rrbG0uMrmFb8Wn
i0eAloGgpm016ymwrm/NsvYlXoBfrOg2Uy7srvboz8NPMA0MsoSF9x2knQ57AevxDrDJNZdBxq9M
COjicU64jcLlbh33S4Pb71jMlrZAnscra7j4X+Dx04GsitHxbGZJlgpSpp5uq3iDQDvhzyRyGxAs
B3Hp0U6i4F+6hSc/ZDeY7LrgLKgRdC5EggkZh/kG3hQcSj0bx99tqGhsh3fWzYCkSFpdm8fLx9bh
6bMmrLXxdIH2r2/hugpXwmNRTmzqMA3RBVnQcOe4zx5LEkMGPRVA1HnA7VP9YWvWsrU+w64IfkEE
iutkG0ufsgrCS/b/QysnCrvPFWEYROP1OntV+YFQqERQPdXBR0apE+FGGQS1ZbUcHHO7RTCX2LFp
fR6PMNSZdo6KKFZULG3BSwdiawyvcA6QiYD2UxOGMIyRsXHVSgp92/DiUNNqSlhBIByIBULiOn8h
dhlXFjb73dy0O1W5EcAyoROl3NCNpwCORSOP9gDVzSaxPyD/12Z6zo+VxbG3xzNXbFuSfl2BK0+j
HiGSQwYkj0gsvjGzVpsrD2keKNEtjh1nmjCL6bLis9n09vaqDZ5yBh+xqSbCVUJZVSlkmDJqXk56
/3hrr4nt3jWcmxQXEoWG1cL0Rj29D0+j72KqLxSw37pVDRbyabr8K13epko5m0BZU+IcM9Z+Mdor
69Eo0S4x6bGznlB4s7uGSlV5SJunqk2v3m28G/QrUYhPbLPQqiX6RQazgyMmfAcS1K8xfaZMF/kN
sFOLpmP4VPZZ9x2gg9jlDaQgBotCms0vJlRlGEqNiC3VHa2D0t+MMfmHSWcLmE+J4rUVPg5U0IQU
KN89dqVNMm29kxNKadiA2CgS3MGT/k7HCmQyr24HSaAJ8trg/MwFmNQLuUjtPngTQK/9HabuxVJO
LZYWm739EEi0AtqXdt4RrKaqYEQWbVZWgQVTuki01CJ6pP3QE91c39JIKhr0vybMRIIsM1jqviAj
wk9n113nzRtoMb/sQ3Q/WMJ0HUvZWvKpxe9zU9s59XvDTPU9fmDQwPxX0/MYv+Y7bDjpSEeiyv8F
hqEXDs26/3q1WvtUV6pznrVVSVvajUuL2ZVb2+l1b5tJBrxMGcVmn5RGL2YiYZ7tD8nV5QXnHB7b
0BzPNHw7yq0eg8yuL+yOQ5WrNwLewHV0WtXWcmTw2gfybqc+Ie2jVMXWnJRp/qIJPzAVnA5UEPD9
M89L4cg2qfvvD/7JdpGdEu3pglpCoXqSt57O+Cwf0LMqbjrJdFMNVZxys2DbLsk/BbDS5nnxxpZ6
dP7Rczt9XOIPr6985FgEk+t1Os+kgQtXVX25XPtGAETZ+y9t49Zzrgjj8Vgy3Xn/AYv+iqs6aC39
AOSIiFkb/ULgYxUS/bCkYTbGfMGFPxZX+5CxWauWVbfsOBQUBD2iZRAIB7KcoGG1htCk6WT7y3B+
asFrllFUigVU15XSIf573fHJb8kVQ1Gsg6RqCgWTPL28816tmOMhOZZ5FHhnP5yOnGaxAhIalIzI
QrSs1TOeXbIQbvEzlJ5XQZkunxWbgRZm3JWE6uboS6EaohrgJonfK8KpWI2b0Qdr7hIjAy1Xjkg1
DTghVw5E9ugHM9HyzPIQm5HTWNCZY2SEKiDGVb613Us8VmYgnQT+DFMacVXNoXpvHT4q47kHIR+m
PchFW4Nh5jjZwl9D6trqLIoJSFrn/5g7fXz2L/3A8svmrcwp6QWjXGHHrnTyOt6yT/tCVIMrQlbE
xQgIfq+bzoBEPX+MFkKwJYhK4LbWmfHE2KZkYpX13zumjbtZEXbEW1iPMMomaZ5y7ypwyXE7y/sQ
71IBaBh6wo7C3glS9SE27jM6qcT6EtDEzuan0W3O3RIHFfLqd61ry/e9vGIZSMhXYPplg7mZBiaR
UaXwV2PuoLI+ZS8h7TqfEGsiARhxB4a8Nsfot/kjFOjbo/fUw7GnaFPxh8cQ7Zg+1ezLhamI7pW7
u5KxsdLbiB6QQN2Y9T5zzHex/iM/eu7wvmue00Tamh01ukDwxTfgCXhRhQVvlMJlpITqz07bKgXu
0lT8UA/PrpJPId922rVYBy1F4b/uDYXn2sMu06QV8Q828/gYSVaqnkOYEVR5JWme1mz9283z9taj
c61eqi/1uqe+oPxSyMMihXmT2Nf4Xk/U98OniNqaBEzz3bQ94c8Q1y/WWByUlCZaQc6YiYxuE5md
qGwNL7Ueb3gXwly8hOS=