<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrGQXcnFutf34gyJJmClZfWJzEtRAdbnYyG4YzdrzeUtkS9znfOgoQqRAUrB4Q7zsjoZDirf
L6uLSK0FBuEW+Y+TfvDhgHdi6/fogPv7iq8UeaD7eyvCNTZ1gmn/EvT3fqZMCbJxBmS+CLSt5Pg3
YLVgJ6D9J1SKkfpKcB2NOMTlhTgKxNu4Z92Uju5PXwhSGvtAnRGb7Ohv3i7fizcmDafyMJAwlsNn
R+hUxfKGLT/KegOV/tqGBQCvanPP/i/jSqGBAh831rf4DhDqUvK8qxwitCynUD0xxsh8hGX3HxR3
ftTWSm7Th7F/yXx/5fVCy89MZNR4N3djTU6HWcsT/9mVB3EIdfCuAbhbC9hs2elKI131sAKf4Lmx
G75Fy/qM1WD/2YMZdKzEmDbwUVkuBUvy8O1PjQolinMVAcaVmiPdtHe/vw4MTbGKwOcp5wmXO6u+
MpheUKNhlGgi7xuKyUXEnjaMCLH6CbaKGGjPgdkhQQShu6s+ERxLBLxK3Opu+hqNVaXIDyb7ZLaT
Crgd3CQrQRkQ75n3NVsblQW2NvBe3EuxOFWM+uCF4+gbBBjdIRF6bJ+GovYPeDnwnEJ8TwVZcK5f
eLss68rlPxcPKCh/X85ROGHGDWYppmofhHaU5UfKrNGqnG9Q9V/RS3Bp203fZ0MJX/KemaC0SUyQ
1xwlcGcEpbuNARiiEaVZYDdFWAJnmm++dXN0x3rl/8/DqzbX0RT9EHwe9lHaEuq4P1+DeXdY7Lju
LWMskq/54jvvoG6N5IgRdpBK9PcT1bxKUR9hJd8syzoLnn5xXPP6lw67CBtk8+LfvDKrZNrhL8Kc
NwQ7KPWNA5D+PpNvGi/BURqEqyuBPoxPUZW+cWbpV3QF4LZs4HCUUQPnCUKuqySOqyMJaySIVIJe
cIsIaiYyMJFuD+HMMZPhrY63Eh87aFMN54dQsvCBFJJ61MmU2Ii1LV6MinPLicy5OlFFcZF1PdqZ
QnzbYW735T876f/fNORwcUactViBuRiUGlnKH3Yi5/g0I6KBXubHv0Qe9DKcCkp1XCFkSoYta6Ha
G/JGYNXK3/5waNftVFE1ubTjUzab1qCiH1yL9ET/bSuUhU9x3vdTqz9z0Hjxi753T4db01PUUWD5
W4jPrebiS7OPuXUrZzaq4e4teGVzu1WgtD9oXZak/2J8G9sEsQBFCxUCiZPQcMoGhCoszFGxRwKr
itT5Hnitl6q/NTCxk3MnwNy1y4ln2juvp3q54UfSRDIqua+hX43LqavZuUnF4EL3H0TdR1cl/WBv
tTKdma2ehXJKJOWBVh+E3gcqU4DGXE6rexISsg3LvqmbWRsHtCe0XpV/6Uuli28ChL2OdKGZOZcP
LAubDkQ7LAex9R9ajXfteaQNnZh2UftUlglPySiG8Ksc4W3b0IT8rKU+HI9/WWXpSpXE3XBKzIBW
KB73GsKJvqFbFzfxLAg1/+stzpC+yjL4heK2MPtzUvEUjesTNwiqxuDA4d7jx5DZcIASoGjLDAaW
67yT7DmmiTg20tcAo99zGbB6gUtoR/ilYLcfrY6NXfTTWxOnNzHHCQLxc3EpsYpBQkKr3g9Dhlnv
PSAvfY49Rym/soVXIyFoKwnGzVkAP/i2ZAjE5w3IbHB5XLnY4HCvw/klU1z3FfFxwtz9ngodXZv6
W3vGQqvEta1eOcOROYWbhjcWh+lpCcdPAj141klNRPRCP2/uBlXTTOtt8OEnXlzvwkHKYUvQWZLr
IBJRqEyvYXvXI75huRkDG6QxwKIK85A+t1h9QiBE1qmE5No0QQkaG4TToxjDdqtCRbismoxsZnYN
R3wCrA4WHb+f4lQJinzW9vM6UGWDV29up6sDdvaeN8IgAh3poIw1uGEcfXYp3n8dHZwe6TyoY/ld
fQUf9fVUwBO/1y1GI/tCRAZsaibAPaNs3BKicMe+yMW9G0UhnM9rg4FVR9uUTJPXwbEU8se7zzqh
/Itvt1PNHfDgX+QKa2vUKmTFSImiMG3C4foERAc2gads28UKSrZzv1SjB5MGlYlnPf821kRRVWmu
+88YPX+PCltHIifKRHqGZHKmvR+1sk+0foEaYGoB4yU4f2t5XXLl6F6T51d/8a+hz7XP0qVH+SwO
jy8DBYg6kQkFbx+z