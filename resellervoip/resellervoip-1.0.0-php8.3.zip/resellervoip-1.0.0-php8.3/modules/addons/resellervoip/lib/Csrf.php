<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtEyxiMRXzFgPWfxvakI33wrkS3/HMP+//mMyP3aAZqKEfN3cussESi/ORW4meXGB+mTYjfw
Lnv09JSzB4Xwotk7mM2FTdeJMbx7pcn36LVq3fTII2KTDe+gE3BkVMcXjdXVEc9j8ceNw9yJK4Pv
OEJBHW9V9dxZqy/DAZu4XfWZCswjcDCJOyOtZcyBfdxOD9CpaLpUeGIR95z3UOcMVlJCYa3cDN05
ZElyIAsuAetzSC38H/6imtQ9EqduCS/2UNVZmvwDpTzGCqGsitHxbGZJlgpSpp5uq3lNQfEvFSt6
cdX03EHpWToiEfEUYUXCSeMkJWXICTg0ZFK1TyjTmkA4sgMOhTVzvIRsUvVgocJpRxXolClgjHuV
VjHMty/hqh9Ki3j57E0hOai+5JENRRyovjxmyJz+qDzGCYIIbanS80hAMYsVZwwDsa97Q3VRI1H+
8Xmeted2mkaroSWchNAEm2G/o70RtyNb4BdQRS5Y3SZfO+b5EBQ4SKZuyfUQ6mnhaSfSWLaxiW6q
4cqiSr74O2njEvigqjhrERRCLwgVxhz6r/axzoJ/9R3OnzQGXQEy5+AbOtQfjxUQ42fzg/B8hBjK
3AIBzvzGo9Ukz/AIMFEUl/O/OO93E/UCEfJ+yrf72gEPfcH7LnGkIo0xuxm2S2dUfh/JibOpfkJ5
bYQAbzQwsAbdDMGKPB+SS9BxuHDPPAI5pFUsbBwDxGoe/zYu58odLQ/bgM9u9f8CDwRyRSFEOMvN
qUT0vgvDqa0D6WR2lchLzAE416Q9XYiIDDer0idaDPo3rpXHyzfMwoUVWAfEpV44LOtpaITWImdd
7a0g7Uy4suhy+jh12dhXtpjlsewy+t50s61lKQNrCtPS4zNW3labBnEUPV383YLQJNxtS5cy+iop
7l1c3DZNPCcE81G9i1oT3GjGzUdHuG2Q0Vzq2O9VBvz4mouFXovrkvFDcyqf6zzQ7oNYjjROVMSF
WR/GVk/EFLj4kZOTlTpWrW7/EEx0FsmiXbOR+fZ4dOyXOBl9ikAmRC5k+qzyDF6nqPm/x4xHATAH
j9VbGkhsvSSJUKA8ejbuqal+w7S1Cujb36CrHKYDv8c8SL/OcrwiCi9FwnqmkBbWvez9f/dOUQ+i
xd3I21+MLwZ7hPErt/UUT0PVoGRZeBmuMKQsUHm/lbY634H0VZ1OrLSVHh/cVOLY7yNnkZf+4wLc
8r0Rp/69Vi2JyMU2vs7TNCKvrSJlXXxeLQEQfJx7ovDk//Mziwn7J0YzTlohrHLPEXhCjW7P5ece
+hcp3PIAAJDJem8Ttd6iU+Tp7CwJ72xOGrGUHlMMQtn+qjWgnX82oFV1kQIeDo8XgjPgSDg8bQXa
WjrsQ1Ud8iOruvlv5Bv9HiwDXCrUL/DobsuIt8xjLtb2Hfi6zSvU5QpdcpQtOPvrKY34EkYIUTHI
tjiOaASoW86G8kjU5Eg34ClTkqZeYB02B4LEYnqSIwabpkL6/yhbTyU3RhPbL77rH9MnQUkfc7EN
1xjhoY/CFlmvrr7jnFgw9vOHPZaYcu5DE00kZ7KCulyHxp+TlpfM5d16l1CWUtUsilA4FUVCLR5I
aci5fOG1C2TdgN0pBMht1TRMyobBDzUshKnSPfxbrxXX36Yy4E6XIAY2MCF+mj3KzuTqb/JnTQNe
EXmWwslTwU562E6TmvDMSUFjnRuBf8/oSnu+lBgaBhvjmCGZLV7XpvRpMaFcCCOzLrIQKGCKgV2o
4Z3A8yh45kp7VG+qGEjgotRPjAm5Ktiq/tpyP9KNYcOJd3qsJjhwbqGM+FbqSnqSuGZDZeySJQCt
bBJPAoPb5DHsgchWjj+a4hsURXM4OpCXZX0Wo1GSoKwnEoDnSrLp/DzMbKysaDzyqY7o++9TinxX
TYUM/knh5ng4FTmSDNe1Yx5dMaOk8wET004Ik13w/LZSjUFXAswtj6HWxXBy+yhDKo5b9XYhO/Rs
EBEyg/AYd2rrFhYHy5nV/XYCP/YKjCsVxyH7D7LuK8YXFOPi4ujKh3zdk91sbZas7pVBUqd/R4AD
QeqH2Yjk2Bn5VAPv44+4rOCeJeD03P2GMJzyjvt6kwqE2keSJBEMjwxWOuame3R7/krWmUQ3XLX+
CnggM7UAeevUVPgs4HdXn0AbpNAES9pg7dggfmIONHU2IJOBkAi8hAo0XymJV6LcSr5+iHKAm7Ja
BSW+FNPLpN61HZamWd0rbO3EwnZgv7MSod5XpYFhLNvd1rLO8/FImOS6ZIcWtDM782ffKB7d3mbp
/YBHZPmp/diq/uElV2DNeS5KKg7vkDC255E8CKi9N39R2+kHZbmDetK1EjRRyapJMEqNPvy0dGzR
Co9MuSGmYv6rOsENvuFGOsWJ9+St4ntT8tL7znLrWTkH8uSDx9096hUyB5zNCRl8WJPTbc7tvZOJ
gFZGwaGQmsK6sadW5iwnnErbD+nYz4cz8qs9fqHgPP59gGdMb2sM75EFTlIopSwrIL0qvE3ppa1R
34ICLAOJy1aXihZKZEjk4jnzYslgcHnCFJk495QcFrMglW==