<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmvtVgsztKA3lC7hZkKO4x0ILTM9wTP1xe+y1pD3bFTqwZyzTtAJ83qxf2nuaBVhPxgNmtC2
0iDUz6/+rq5aPwPidXihGSXlT2WrJgDeHruXaxAvQhAzj8IeWENSPa+hiqJIYafehWpZdy8HYu1g
u7rUThFoZGRbhGA24pSgh8QN8+CMifNEFwyeYhnfK+2qxMtIb/w3nOg3tPPslYZUWwA/UtI4gWlb
UvjI952vlvqJkrOquep4JOzlopw3opJ8Nh2H8G7h7HzHJVhk47SLNJA2l9NY0g4nRVub/KW/6+Jy
vbxj2cPD1WKlFRt1B8PN5afpPz/EiH6Dj1Sre5pP4PrIYK2zav16iGMiRKWah5ji8LUp6y/Aj6L1
8HRlRVJrMJ8tprvwMEwH51p5PnQcDNs/l4bBBHrbUMOjp9Q81wxY6Its5X5MDXjMV5V70cpw1fdZ
vcE/3YciGcKz5Jv/tYsZpGSo3BTX19lQWLzyLB3Tr6rYG/49STqiZ49DBvvd23dG4XHtEiE/Xc1d
lLm+wv43VaI5ktL+humNGUipuwk90iOSMM75KLbAXKn9AvEM+6TenPQaVFIPUtXyJyTFqjakLRDr
NorA5GzmrwkvsffR2iEYOtu/6MQDKms9l0ylSk5X9hcPe6mo8aVtYCekPwFvsIwEVv/K8Enj8zFs
O73hS+b5aGiiBWl92OF5Uo6YjdJE1waay0QoHiSYp0rw1eBQpDAXBTTsFRN/Q3t93lNYFUGUol8a
1X0AyLA4O/CV4j970kaJtQp/GBbk2cxiiYH2VQsiaCQEv7mV5bRIzMLrsMWpoTSLQ85RG0LhVZUu
t/2hrF2t2kO+vPoDAtU9tRRqfiptnUMWkdcaOrePorIAOwholztQ81Xv/Z//Tjkle+ycNLyGUOa1
SSP3DkOmPYdOKpTbeREWQj+MGR85zD88kglaAOwPUCb9BjaGhVlIXDJVtzNPCoylfKVjXy5+lrPQ
iJ9yUV5BhqIQlDm4srab6kcgntN/Y+c+WOtAgyJgokMsxyy5D7OOXTJx5rLLalgEod01riOpEpdm
6jtkeAZSw3XYcBYwZkRUKEECUdumZ+0SKGAykOJZm5SI2a1bgMcecbsV3HXaAyuckLCelLLxn0cn
FkCe85S/76FuegGGGMmPFQ3q7UZItqYNKzAFXaAVal+WtHcxtNsYPs6KZydWtjeLxi0k1Fc35uK0
Z91ZSIYw+lNsAUekPYyxBWwudJyhHLQStIbmoU/yRU+/JE577seAWQ8eZcKZi9NHjxCi/wSWGu6e
p2dlB++qvJZdjEPLCwCim0h8nwFuKFZaVcdVR6cPh+8r7FcrlnuBqVxjgVNadH/BQqsu76YPd0f5
1/+P4a8AvtoZqY1ZE+SnlUsg/tCwtg3wt/KSqnnduveqR7q3c+3zL5h+oWWO0f76wVM9vc6EdW/j
J5v6fjy1aOj0RRfoVuk0Jx4dmXj34Zv8JcOQev89qAbscjlr2sXFkxZqrqaqtsGlKurVYlNGdBWV
1yJHgbmqT6IXq5LFE9vbUf56Qsz9LquoPzTo/QuSkQuShqK9mI/MAWpGyrOkYs+has2dsXOdSzNw
uwYAB00hG4dWpwNUw5DnA6A2WzIhDBSGz8Slb5N/eu+CyzwhpXjgS8SoFVxv51R0sZaq4DlNT3G2
Lc/nc7B1m8XBIl0cONtmh4RVeGvG39XN/pbFpMHmEJ9NZkMSwly+WGYQFOEfsuoKIIpt5XTqreOW
YCgLCqICMRhbm1BkoZrhPv/MKZVtPk3ciRPKRZ62jYFQ+mHWRu9zYKCw87XACyhbzWOqalwqUwVZ
Zl48Pmz7d+6+fk0UEdW8O0+zCV4VA2Hhx7T0bEy3Y8A/ZU2ydpqQl2rrlUlSg+4eRHa1DWf45yUn
3Xrv/qNEOOeSwyumdDtNhFViAjyGmZ7cbgnFpqhKxwzOa4YHXflNVoiXImoMCr3ma3Mq86TzKlFj
HKRDM3Vm1pqPu3UUuDM6xRV4DPO2G6ralPvcGYKEMODKphqsSLAXmRpzMsROaTmQY24VwLlc9mSc
jjiW66m/r+f0YJNlCZqv0xBBcEVIV+hCHi7FT030yEkyXvMoeWjmD6+iT8uFUlMu0K5VDxAi+GNw
X+JDtd9d/xbKKARnkoB4f4ucUn9FACYUJMsIwgbPObZV+ZrQ985kAmjLN8PSW19nPaEJbI9bXUYg
2CGhmwJ5uNQbtmxZq/C15KM67iraTYOw7PScD5sTLHGvvi5NB3Om6Lg5nR0zJaZ4NkVI7Erbgu9a
IHKjM4aOthTs+2nf5zhA7AeQg3JYMT8gGURJqq2w2cN4x1VuGJ7Ln1DyuojTyhTzmo3SQVKgLpwR
oNWOP5K4DOUs/6oCpUfr/+orHhDNA85D496y41ERZj1sRDuhibNVFwbm34RiG5A1hOCLc3y=