<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs5UAe/FkgwWakY/hFniuFfIohfQ7i9xgyPlU+zyX1/TeMf5CkmzBXm5qEoJeEQAacDQV1QU
VrfiUfnMR2xPSxYCt7FTMTEahLBtXhoVYvxQ8d1ndjDwoA/Rz9LBsItGMERP7bD9CQMUv0AkXVMF
XTrWj1qz5cfOjlJZgRtyto1ItS1BuJDgFzcadqnqUsA2HWpPTP5jaJ4F+iRFCfdqo93JuvdyhZME
gGhOQWLiPfh1xSchXRRF2/oWouk9f1hbUm6osn3uIUuVKKtwxX1t5LqoWhoLuWAXSNR/xPNMkeOM
JJJ2PGXUJGZ/B4+3Sm+2ponX1uAMEDNynqGV2bfeY8oJrh1eCntSgVfCNWXW0HsnRyBn81lD5WYO
KNzzQuMX5nCSQ7c/KJzomiB/6E0JmvtQ3q0N6g40yYxu+D+rOJFjTSuM74379Oj3Uj2zMOhi/tlK
x9SP+IZsLoMwkeTRbhZDdsgiNyY4wkXuiJ6+8xkqUOybyaQ/Pp+0gr/PthPGn8YwdNVP5OMdokzs
xQyGs7Pc/0jAn/kLUfF4yDSIP6XmadDNm41VD1GkAOD4MYD1wo929Y0FdsrfBqd7Lx7LgXR3tUIL
k8xT42Uv3j2WrreWAXCGLk5vHTV3KD6sQLaqte4xifqp3tFj04PDRKzUkf5exKkRlZ3z65lBKeaK
2dGL6Iukzq0N1+fcn8gnZ0rse+9WKmblt4kWt/uhs6MpXY6WoKlHP2WgLYhK7jXmjxqdW8qRkAJ2
/AGf4YjOtrOSg8TgSQCpkWsq//DJWO9sWpGXuBlDC1+sVMETJzq0cwXWsVIOUfMKeMwjpjQk2Unh
VPCC/ATRkCi6cCIfaKinLv3mJdMqonY7twRHKSgEQKcxQCWkPUBDgJrsNFrQqMHoPZEIeWdYTRmt
e6r6Ige/1FBy2wqXalinJrwG0Q7AxPmK6X5wwjr4H31SqOFcXmycfHapSmDIkqRm0Xir+5w7RG/u
xGRzG95+OjzSSwuM/vfBcxaXjT6BaGOjhaGcAytOlEd7HSogHgMjdF6EUzW9Njyj5afp9etAFyaW
Cyy7ysY3JIdYGX4dT7GYYcKBxKRkCRTCq2+QIALViMEx3nS71uU5Dyh+NRnn3Bu/+v7cVaH8WsCH
i/6KYOkndFj+7XL88sNXeCtUsrxhezqYGHSSe8FYl+V4Tp0h0RaNQTZHcFNMMtNrBqCY7sNNXTJl
+xbu1r5t2IwoEhPDym3/5/3TdQg6ZHRQOPW4yZ8bfjZja6YFEBhgj4lZgcEk/8QGCXVBdfNUq79Y
qmSrpO90723FscTE8B2fyyiDCa7kpbO9Dmf86NtLUiryDHlrdIvov2/AUbCQtW1yx7FVZl+nyPEB
9VdfgCpnrLwspLIN5izJ2JGV415Un+9ddL9gejEz7d9iPzOqWfGe0cFXotSxMsd9GIYmgEH24+VR
MWUQMB8GzALUU5dMnZxljH4I8VnEE4vkH+6cWmO40g7yK2+N+f8+2cHyG6js1JaOKpEPlE2emmYq
R+tpnKFWTSaX+9f3zwOOpo2bX887xKXvRl52/tlVrgar0B3nJht06Hfa95bJV0nfIfNxzR/Gp3ko
FizU3CW407dL/wlQsnFybe+SDJHGCfPcX97nQV2Gxfh6tbulqkjdhd9eFwjAXhJbyGQWPEPEEplq
aQPiVU4q24pd8VIlt7qL6YIkhM+Axws09x8zJo9ikjgNLI3OX5IR3lV8mhbMJYIPEDvGcDIQT0gZ
yIKoqx8QcsXivPto5GgFFniEjUL1COfw5JMzWz/4XktnutyRrf2+vNQVqILTdbIBW/WzYMNqKyjz
avd21RzUdbSZC1wP+zSgipbk0cEDko1loBrcExmjE5w1KIAN7AdnVDO/9sE8BH6YEJMkg2WHK3Gj
gN5lS/r0VGsx82cwbjdSuDj9+/MZ81a4bTwyTTSSQbRPXCY/31fcSXUaYXq9+LBVM8hLBJQqzIVr
ORtRTMzceIN1rI0hvl8xv38MHEUyE4whLrnUw2lLinWcPyPLGOiHv2eJa/QuSbXWJjTUJLxnQwoX
y1kkh7B7hBWfTDdJiUNzfzNfSj+rjGSTZ/smQVBLgx+y6gAOZQp8oEdlaX7RXs1yuO/CSw+BNTyn
9Zs14bGjVftXR2eENQyEdWnjYGZ5baOsxs0WTweLpiAjPvQFIKIopSiDrlHDc55RZOfwNxIIJjwK
5ilIU2t8NTgzdN+7FxzGDFP++9FX/b5tpTXbB4XkMOd6sK+XCh/YWtKZGXOTzFYA7yTK2/H6Kdrj
Wo2NtdVRKevs98juCapCyU2fHCb3i+UuENHcdTauU1Ue4RcFll7oQbkHiMNvbUm=