<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu2guCJSWjdhdH1rvvC2Ce/eVV1qPgJGXEHLrWqtRGHF+W9ysl+XdgBLhh7cPNoCDBWD3qRV
4K1l2g7mvGOtmP8hRVvAWUYIB36BdXG+jcL/pERVmkJf6GBHPKJwqavm3W33UT1YVRPhvP5dq0eD
CO1czVpi/+xvDfa5GuVo11ihWnDjdsPGbzJhdLG7kE3Go38zBIJHXjKHPFo8Un+63WhEbKNK70lA
P7Zgb7TAuStaOwn1zTLIwQs9DVoJ9rBsZmw58skfuCeVKKtwxX1t5LqoWhoLuWAXP6y/vQNYopTo
VXMIPGXcJGJ/1YBt6NZ92DP2tEoVg23tnhU0NC8BS1jEwAjiRuRgQiMQFSmxuXz6XGf0XAIjI4vG
Cscvz4nfASVF8KXaE/WfQAG23FLI85dbzPWnHSpUvMA7NKvTgwcI/vUO7k9POxsv28rkllZo3OOn
qGJ70vRrmChgkGC8BEcMSR396iJ18vBmyhnwluQdAES1sJk5kO3DWyVmDj7+QuSf05cj7I+HFJKD
FTjTpfU4lvMuJYdI1AwH0h48oOAn7AmH0upBsDAh45Wl0sTRxX1wA7xR7y/ZnQC39s8NbeENYcG2
GT2TGa6u0SNeyJyHENY7ebcbRsjaNM+2e/LOMpBmA41GDcc49lz8duPby19P5v+rx/NtAiQgDOBX
kKzzhIOr8wX8rSAnuKhv6c77KxjaBf2fQCqIxZTJfVjE0yoHBOvhYHe1UdLcrUgInkYxq/AwZ5/R
hj48OPYXFa5kL7YeM9MkPOWA5rxkXRLS0OHLDzZ+Dg5H+QBvFy4KsgiaqbcriucjID3UoKYlxSTu
P4F2lomN/xapBBpqsMqV/gQ+iLLqcVN1Idh0bvgAV7uZqzEl/9pBVJcNA5QYWR0p/oQ9wW87eAMp
2ZIWkZZIHquuNwVlD76fvYZyRkWo/X2X4P7ucS7vdbhZhqW5Tw1utml96e0Wutg0uNxaw0KSkJDR
Xs8PfQsOfL4XQ7+4PHQVmcupGsfbTFymcx+yftMj15CqqUq2a8OIHCahSIpTiLqLTRJHZg7AdYyr
1UKcdZ7yyDB6E2yMidgACKbbbRtaaeBuCcNwYX3vGtf5G2XhjNS355ni7TRovGxs0IZcbwM6iads
WKai4tFl721R6BrDK3MWqPoMHFMNQpMZ1qE9W0==