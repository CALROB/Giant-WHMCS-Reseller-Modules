<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuOlsbMW2J+QkPLFThkGC0lUAw69s9g3l8Iy6I0SekcccyIk9BqZXVPmJBng4ep2kKP/WflH
tF0s3Pa2rtxDUSUxDvfqgGCFOrVpfbhj4clWCiySmdtPpPn0gJQnMlmwcaVwgRAoUmd9mEUZd1qE
N3tc6IUXYBRjwwoYTqPJmsrwfOtsqapxaG+K0U1Al6PpbKHCHoGDsAWVgeF9++NkrR5O7SBvxdPY
Gsm44Yt2j1FdL8Srn3BHExZCu88D5KJcT250lX6OknzHJVhk47SLNJA2l9NY0g7gR7zDLsmu54xc
tJtj2brDCGjc2+/lz/akylmF4f7i8FFxMbw6wCAQ+DKaY3YHk2DM8xe/iKQM+xQz5eHgM0uEOnjy
4PLdR+egww1AysIOGB3oifm01UdIxvnN5AfBJLcZbRwrbGU/e2o8bg47x0KNIStN/NtSU5ZCytgA
YHPyKUCieXppZdKRuD1+DH3r+nkDrx+UVEhVWVhjOmPjsDdi1iTD6GiB0jcHspX1HsAyGLSVNGqI
XvYs57sAKEWSpSzws6V3gR7e/VfOoUZxytgJCoaFw/CW3qINnNHwNkXvfuyoywDWVoHMa2xudDkc
SwW/m7Ow8BU7rzQT4RqZy5hsouyi0ooK7O8dpmVRlK5sZftKVrHy/pRQaixPWfBEoW69WlQdC6Mz
pDn48YllDY2X9klRuzczxLQ5KSVPhWp2eYm/T8ncQoYDJOJ0YRQbKj9/fhGTrsRs2ExBn1QYFUdX
4OTx/IwN3WF6+6pobBTQiFL0QsBr/ZJD9vC139OZ18L7bfhxUstVodi2nhlCe3JSniv6aqvcdylf
KuEZe/XYjwEQ8LJJ9zMA9J6j8Vxmv1j051Z3MORfVkhaBjc3LZLbXL9F+dQ84P9yIsY9eps4yYtk
DuoS4ciBrlnr3z/K1/YUTHc8P0mw7BOuzCPEbsjjlzv2VlYeBDlyr0Rp9dkleUoYxYYzkxUcrZbQ
YUIkxQHUGc1ptYqFYTKVJ+vJN0Mr3be4cYFGZV8xY57bJes6yAA5kDeqDB2uTdYwYKM7EUWclyPP
H+5/Ch0GWiAm1F0zklH96J/ba8hFaDoH39wc+smrypVTtyDYaOOLz1igdxJjlQUV2SCg/T5TDEpp
bv1plPpdw9Yfq5fisozca6k7b3MsET20lglI8++1xRk48OaOlgdaT9DY/iOqHfH3N5iQ3wwZ4cGd
IW==