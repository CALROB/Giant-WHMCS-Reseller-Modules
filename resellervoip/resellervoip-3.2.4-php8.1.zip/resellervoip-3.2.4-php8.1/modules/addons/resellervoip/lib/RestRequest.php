<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpqXAuX/zw+l0fk+gt9YMtLiMx6fwk79GFfnYCZZRel5bP2kYOu43GjMcna/V4kliPVLUbh2
I427XpyBdsQXSY12JEa5jcVtcCrFMXHSAKK88hvMyy5p2/I5CQFukekkAWwe7ZjdgBX395cBrN7r
U4VPvPOHadBlc1fa4e6nnvdkREnnDHvs2Y11IkNJ9QpsGoqs8Kg+jIG0gtDuuSyke9TBRIzhbAp6
fo/1Bw5urZlFdN2d91fbzx5SMKPur0OOrj59vz+dhC4Juulv1axBA91i0M3wTknetWXgSe/Ip/mn
JM1vqJ/xWMr5/xlq8Y9KE9QDCfcyFKPaLw2oRCGeRt5GXUzdMd1rLZ/LFkPHoEqjd4U4bvUraIQy
x17FQEXkE80+4FS+TiwXJUdtZxp+Foq/hknw2KXbjZQ1PZbm1DZ2TfypaJI7vYebzAG4Fl7WaEcI
hKErnaVlUzrZXHa11MT1t4j+u5g+blLUvebBqFZo4J448+EhuedrabSskBIPq6BOJmVhm1p/UPPO
4IU8yLyrOH3EAfAGkC9d8h+P5mFSTP+ABtktlC6E4b6xohqWuXQeDv3oFWhZZgVkFqGE6tVc9iVm
EWZP8iOVJrD0YklBh0o8+xuOAFEjz2LlyebWnRGu+A1HuHsslJF/QLc98Slo/HMQX2XzjyrBGpE7
4mSXVat2ehR/0jh1YSW4rNRz5kGtfHtTAXRHwwX++NWbTug1uAnhCr6jUc7l/++uZuz7ZJX6Oq5k
a+y/nyfeMBWp0fI7Iw/EQ6CQ/0iawjq0KFGu6zhlSzrYe7Haow4699xDooWeMqX6X6fV7dhct9OT
Tz2nKurPMeDDBN4En6NP2XgFretK2uV9+Sify0eOpeHZ7uQO/pVAuErQb+QkIwp3sWp3Kn5mtXkz
5A78GdB9miOodAP8KWaov0sbwTQTuIWRLVbN7KTPfCwMO0xV3jc1xxrGAUainHYGECMq8RcO6UCI
IumCMo3ABqwx6481qyMjfDzDRCKO/cFRe6Yb913Xp4U0ozk1tailPMpY2T+u4OKCua0b3xz44YGF
ynpYER1GZp613EAjkCuk/a94/UcODKDMCaNbYOY9VZCk1Qn3ujJoOGEz/1285ybVEdrRQudCRxi9
81BL3gYtXPV2wYBI6bwcUShhtQypRifYOfANS8rPaWFId7sfSqaz8hsMMrMin/FPdkSYA+IZ7r4D
om==