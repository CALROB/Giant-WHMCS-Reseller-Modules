<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu/Hd6V89sL8aMi9HFYnCCTz/DO13VX/NDTHM6kS1HOxMEd30cAFWKAe14EVTC8zAhDYcGA8
/wgLJPuseflb+JyXXGHLVpGknYr0GsR+Nrf/YKMwP32LrChSzKmSAkTsMeM3rsQrdDHzkDOPZMfY
zyPINBnAXniALM5Vo1ZuieHg/w59SdAnehK8ME8OPfnp7nufbYZ+CsBrD5T1T1m9fILSfuDzqUdR
yI18RUBqfCUZ3+FJfflaIO8wdxkmfD7JJ+gqH9QQPilZY/a6Jiiea6m1OFfsx6ZU2Mm3v/YCJWmn
D0WZb/U1RJZ/5UkI4g3XEtVa3+tmovdEs/Rx8qHpAmuq+Wg0orgeQ/M2KE66qv+oJ+6KHHTsVqNY
LAoVmqGb4CWo4TCika0RYC7BvsZY+ZORN5uBw8Fr/HGptDbFCEx+pixHKg5ty5hY3DjeyJUGRYPu
7U4Ef6pJ/l5tUJLFDpH4+i0/ExWV8xH5tO5qTqOP2YLBp26GaA3hbKbgCwJxW22awe3uop+ObjSG
cx1id1ibxv29JUwQcpO7YMZcoa0ryo/Wg3AQ+K+D5BB2AnVMh//f2OfwjkRKbrJ+P89meCHYSKuN
SLkrAzZxZxDsuwmPihGbAiS7tR6ifnuS92y8Z7Zc9C7Ll02uHly0EXKdsU+AC7J/kqCgznae1gjh
5veswINQwe0GhbfMCDMMNJXgNlLH8Xq5lb0OdqMUz8y8HDnDuSXM/TaLUg/upWuvzarfMKs5WnFP
U5rwWzj9V6iI6JMhCOg0hz2P0VoWYBfrUlEn0BZYYCkII/fe64ZGaKkIUlE2qSn6X86WL5YOnKXQ
PsBbyytoS1XSNerNpfqAeMWSI2+YUOB7VGsKiEaUp4te70tYyD88opv4i8536o+45rRMayB3hMI+
kHHJA186A+OL8TXYW+lKk/zW4nCN8GUwO4Ux9So/cnc99yDBztg9OtHeuYVxGgs2OqL7bO2veu9H
jGtX7ewHXEu4V2xLQEvog3gp6su34IoYBwMg2DvA1fv+hGCm5eu9IJMiJeVh3WZELaYxl/I4kEVw
GW29Xc9ADsPLv7ZOEbJni7LGVGE0SefmWs+WSDZprgeLMUsS685wRXa/RRjtOyA4zzIGt0wDW4Ib
XOsdVI76fvuGm+BcOWEFcvgK0aYzkZqvQG==