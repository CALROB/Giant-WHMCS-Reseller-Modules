<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmOm+lr61D/o6ufltbQmE6lc2+KP8oPlhxIyeo87OnElv2TrQrm4qZZlZFScbF8JteyXs77I
/HuZPCgZhZlBKJ6d9PwZk8zoqj6+X74n/BqlfmM3cR6XQ9wwOb594ei3WB61oWfCD6DfbC8NpD1/
jmZvdaYEx9Tzlk08sumDG7pDhcwpMn0mXhqG2r+BGUpi0M/agwsIzwn260wK841I4X0TuE24n7nc
A5clPxFT9ELEsvbd6KTJCjfR/Kx1WOe/qOw7i7JaqP8Xly9F3SOlxBYoEiquHYI2QS8sl16/iyq8
nY85+ZqjN/+J3l5Eok1n3hVeNklORbqxPa3Oeoa4LkillbF8I4juhVy+8lcTD9rVF+/9CxeBMIR/
lXkZAXEi56kl8Os2AI83uMp99Qkb9ogT/sXNapxPoiG+NHjRoGyjaMRPONz3+rhflGeN3StYRwxF
Kd1714qFzys2So4iZCgujL4dezqJIJG4ismb1zPhHuWO9VpX1CY7H4CHmVHFsVtoXbOmkB0uiDth
KvqXASSasSXWlZVUpu0mfv/FEcOxuBsOz69DV4gOOIr/zRKPuNVLL1hOsc8HSXqUvzvPoW7TcWIL
WtDkpYXmPtS+zJR2/WNLSDEaxOKGUi3qMNV8OP+nk4qWOhft/Jk4675jvJY3BPVVIwetqJq0LRxE
a6Vbvm9mSjhOGr69zThvA5dfAWtLLdTB2diLTbYP3WBTNkGaPNqhpwdcNNrfQy3KITTDCbVzwUbo
rIgyVEhKU4UCxVyeMW8vkbcBuv9mYqRMl5ghCo1XdkAsILPk6wUoCVgmRAgCXKcRQDrBnq0RKj84
VRU+rligvM+RfISA1u2EayNXvAIS/lEAjBiIAUqnjkcvsIww9EUynjvIEYV/NsiQnDrK3MWSZ7gp
t0SIAS7orzaS4pe6vc/RyhwkdIzzVlKYPr+GvZUPtPG5qkvaxNFiWrJKoI28VjQmHr/X7R5rfMyb
2juI356Nb1a1CdLz+FRH+iBqOms71ydqCq2Z2W6gsyC5RhDLtN5dvqz5ugC5cU9BN0Husd5TllUw
ufWWgTYohvCtu6c+KsJWgIhbqC6YMCxovo9CZCMhwgLBrzyJWXt88gjIe1dkejtVKAjdWZbgT/Xr
vyC0iCk2iFk/sAi8IMkwXWv3xhA5NDsW84ooGm==