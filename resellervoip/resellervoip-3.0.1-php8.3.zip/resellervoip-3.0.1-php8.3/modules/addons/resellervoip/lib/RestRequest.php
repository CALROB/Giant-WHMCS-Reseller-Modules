<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwp+bwR3Nco9daG2XVYmlen00HWm4cujtzCSplRpBY/FE5xM88ZYTDJGLZOpOm8b+2pDog+9
fesVTtC9dz/nzFxuBxjePOKAgFUovN/LnG0YHtjrCXbovvLWbogyWcyCvzz0EZ2JxGWNkiNvOP3h
A08tVgFlrc17XjhSYhZbLbKdN9GUyzAc0Q2pOUJE0JiLgvtGm4e5cHfZoogbWlzO4+zYcx2EBujz
fKi3wWqobEJOjybpmTTzCbdVYG7NJk6z/0hpk8OCMfYI8R/2Jmt6B+ouiZhDE4OaU6wdonX76KZu
rAmXdNWwBL1PyFWfygQ7g9lYgCRoVA6caqpFMiIaSCXgeYpSnG6hTpzdITa/oVjAvCoNHCO7Iu+b
bN6J92veKxTeTaMrN6D43AEBqAzP9Ib2ey4Yn1nwv7n4ApvME+e7eqgG8K4xqi5h4jWUSk234q5W
9GaAAvRYiLVNOCcE0DyvpftQzfDTndzq68q0IzryDcx5mfo5G/wU/cNla1I9EOSr0JkLe0yRxNjp
V6A4bsWnuN4WvZiEcLV+u+/stZVx1jJiZsnrJFyGauLrCbwgxvNsshmkxN6y7ttlhuKktZqdkrLt
r/6LpZHlpobRyX4/flNKmxv6+5oDx7Y0ncrkcxKeYqLwJpHvx9pjKDKArDgb/65DXmTQxzRYTBNs
WorSIYjSEPzsL7Ld8V+2Egm0GbdgULcfIvXxTe+c7RAWDF3fI7UYg6REc6iiwZgOEAkt4lV0yM58
vmLSfdmj9ioQIyIUB2zS2VNfekwdp2Uos0GRBzauYp7uPsu0sS88UtyMw5u0mW03lyjL03WGyW/a
44kaHEpMzyPV5g4rAuqWC6v/MQ+UyFdXvVyW3NuLTxfhyZq4TFOTIWVfCR2Z7h/n48BIZG+AP3WD
qC/ihNS83lT7q3wVqy+tBuH/WGQSVfi3x13L4g4s9URyvTGvOOEElFF6PMS0techqRyQCASM0zRM
SYy/Di5xbjBw2g7rOf0d80Y+QjDGTpGVMswNU0jr+v9cgezGBm7VTC27ciq5XJkxwMnnbMw2rKf4
ckpNRA7fh04w9LV1kqcK4TYZkPGhtTwU5eB0ji0pvIrur5YAY89jW1WeEEBdvlsevsaqq84/t4Pr
br1vCOAxr/S5RMJAP77M2KN25NnzZ5j3LpuuFbpkTnpJiTTeYmSz2O2znTuCzmIIj/xDViDbU4fX
FjXYKK8+Oh35LnH4