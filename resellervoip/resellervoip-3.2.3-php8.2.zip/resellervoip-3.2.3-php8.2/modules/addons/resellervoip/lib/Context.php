<?php //0032b
// Giant Reseller Phone System addon 3.2.3 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrZs4LYpGUgVJao4UmL7ZJ9WUJJfWDzMqRAyVNzR+mm5MMZb4CLryp+iB3cOMaF4KA4Ijs2+
QpYuEix4t8uZOsaFTjg++mOd0jDbMu5+gSseKNZqikEg4N9Mt+2wMAX3ujh56xWRItXPOAK12RhZ
pLMKFezuP1+df/X6G2HXmA9aTYlRPy4akFOFDKeKJ23j36YZl2zX0zI5VgvILx9s6gH58uOGPCKP
pfbSM+/UTklIpU1cqtq+TokjfMWxpL577fR8j1XPTUrXYMJ7gmHP0bvJrrft6QSlPtoi1uPJhedw
fbSxVE7CTl/PEhr0mA/UBGX2j05qgJVfcNXZdLGDQ05tUgY6ytBGlTf8QGmuX0/oFoEAddYO4o0W
hmcWjAMNbYJzNGoaezH/R94SVUC9UDNIIu5Sb17DgGI2aZAd1rAmB7sUHIgQdPMP42xQzhAiyFNu
Go03fBXf4SiozCZzzyA3PQ+C+bY5soWd7dVXgvCQ4BOzgsobx537k2SJD7aAihpjvYgkPan6r5cu
9aZyGFwI6LinJUDMRX6fp0uu2q4S3JfJr6tDrvGDQms0NcYy/Meqf3BoikLSzRcrsqxckfcUVmZk
flmONWR0c0luV+1ZnMPMD3YzxK46WTn/rOYHOQplRFUAID0KtZFEMNcpjyvUFiLek1JO9Qol+ZdD
La1pHSZO+EsftWD3czAX+v9WiB88PxoST7tusTc430vx51PbjHQxYC6aqOeEtSHjFhh0G84oE0K6
ZSixoiGphFJBlB/stkU4p6kLDFIKZtl3SiMtQ9ERh6upJjPKr2OXWjvs6ZHzKkK0Nyj06kc3Bpc5
DZF1pjXDrdW7euELGVtWcUCXVm561wnlv8b/CSuwteTflun2H2+drT22wBOT+jHMn+1BfhbzBeDE
dkQhj8vqKVP1Y8kbsuytBvMof3NkjqFL1Q465b5cQ9INPX85vT5BhKQ/Fyu5592iZlGMGJU6yYiD
Pb4NLHZVM6x8s0TenNLfV6+c2mjXQL2A9FwcK92bpVnROPwRw+dwmg/VIgzDPX8KfvRi/sA4gTZ/
dPyHSNNpX3dSnhr97Sk6W4NOuaDWJ+ioGgMYNThss/PT3p447507brvvuTTO5SKlaWn9iNuAZrBK
d9TX4FWJbGOn4lADSXw7UCKedAWaHvywcoGnuwTGHr+S