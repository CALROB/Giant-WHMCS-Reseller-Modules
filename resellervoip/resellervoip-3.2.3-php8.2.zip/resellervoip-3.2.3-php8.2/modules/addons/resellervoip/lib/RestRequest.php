<?php //0032b
// Giant Reseller Phone System addon 3.2.3 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/LlxAKwoTIAnzLvXZlYnrGmG58mQz2Wbhwym40MQHSaprjcYgPXMl0+PRsxyV27mtdX/7Rt
xDmaYn2eBhPAyhLRieQKMV6ZR4aRAHlsqi9XDDHkhFiUo+xQg3QGhzKCduQz82utOYC8uO9nE/Wu
I37AWsH8TDofMts/VzAivB0I4AnLguOzgdHA95/DgZheNgm/zdGhTYEjKGjVT9zHtwqYmWpduPg6
b4IGPKOGomoxLmKfhsJ9VfGFB6EgQHviqF4g41Ai7+rXYMJ7gmHP0bvJrrft6QSAQrwQVvdB+4VU
vNkJ+EFCNI0W63KEWrkHrPZV54IuR5M73+bNENb98uOGffeNQUZmr9tT0Tuioy9U89kNligxLHTn
HBNz/3CtVM2/bPAy9bUU9rV/f9fhTs6m6x5XyRei84fDoo4UiW4LnkK/phQcpPpzCPBf4e8Dil0N
xSYxgX1eRIJTr06ZZRt5vaNcrjO2PtWaZGSurakQVFn0R448G3gOgDmWQkxJfKK1Hd/1zllM14zI
hdBxO14TIfFlwNbi1vnnVtm49umZDuDRfRiGuv1ZRzmBcjJhCOE8bleEC4Rvk9bXA7apuY6eWIFm
s7MnMon3WLgenw/DvzR/vhmu1D/x5gKgkGJwiWslHI2cCIgZ6xCre/IY/nfYwuVlAeQm8UlClc63
si+lCSIk0RwIXwFTyL6hm/gQxJw8PCWRW+bbELR+fG1uaFwAi+LJKrWnZKlx3fFgL/UEGQ7PHfeE
0xCjlU9wdwL3nTTDeL3siAj5fcfK3nvSHi7IMVYjxdKAeACzcAcKS8m+sysDxFicXciJxOGh1joZ
QEWqammSIlbX6ObejhqneCPaTOPL8Yv/RX6cOpzvWYELr493IjrQN2NssvjQ9aGCXX0Wo5LyqwuA
0+f6RU8cDec30yqXjD+uKnnS5Bzo4lGH5saWiCQCalXJt73bZuP5Vv2ZJJ0Rn898AWPLuyVeI8cA
87yEhIoPrOGlLnkyNW93lhUVEKS1h2OEIPHBiRjlwazmRz5Hbd661pg8mlLI5Cb6lED8GTaoSNCQ
5ch6PLXu8yDZBmEIahYyJs6O2t9RgGAFNoEw0AwVNTIjBP34d7biPi5GVHCdrNiPhm8NXckcd1Ng
R81FycY6L7u3L9Tr1tcjzQRJXk6Y5qA66qHFiKbs+UN4X+cAbB3lStiqoOhk3kax9fTByktsmyHd
55GS93WJRw+HJbs4