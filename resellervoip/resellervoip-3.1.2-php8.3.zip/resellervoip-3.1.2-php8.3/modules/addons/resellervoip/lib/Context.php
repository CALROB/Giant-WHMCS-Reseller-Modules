<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr/mvkwsHzl1IqfppKYT/ho1g8PS+zSGRkIrogM7sViECmn2c5FSKiv+2EzjytSxEUP/ZXEf
01R7nPLsVqKRcsLmFXOUr6HcQaPzNfpvRJWq9aW/mvNwj9rHH1Z7FMfWH6zWW3NgOucST5MvmjBO
SmG4YLNU1uDXkFLpiutqJaThVHGUhr53b9tlO8LhU9+TurLSBgAp7aJ8DyxS7P/8pPRxwSkT4/Sj
iclI/8bDVaZbOyxilN0JCIeUuCHLa9FgeV2zSD22n8p3R6VROhC+Muu6DNQGuT59XMz+nU9aswID
YILTFsxYp0T4CxJJ+e7CBpavFiIm6U8iVj+HELlLN6hZY0764dP1wDjvRplOBrevlR45k8dZM8JZ
t6+wjFGzAdA8bVIpcKMS+7J+iRc7+K6w5bwscLuf1XFWv5yjmQHRl1tI5cBeupri3sw+if3u2aLv
6JNq8PDnuQaGsQluYFVUm2NsS3ky78ur0+cms/CTOY3efz5xrV6oPq9/pHVkAmKr7T9YxQLfT6AV
OzJImQfW+KsWleDC3mE9MClUqyporVD0cCbX/+62rvpk2xjKreH2++8MDmQndG/aT5QbhMG0c/NY
xyaf7WbPsmm8BMhnJ8VcGs6UJ+n4IuiLJcz/p8IbNY4qY5i7FQ4f7Fy3p0f/HBV38dtz4JivS4mB
WpIt/yIOWJ9SWAaGu99Ojgd3LyN36OYCDaShU3t46X8+xPmea9uBSqmTmWB9qeRvInIfDZE+n7DK
eMaRT8A7NiQOFTbBkIWpTcVbA5WGxfjPkcmRMTuTGGrU/exMAG0YkaDYhR0OtA2RV7qxreGBzqHe
Q5cugKvcyg8vKazR+n1XMZKbwxwXcz+4V0bt/530TVDzg1J0fgKcNMOEpGOOSrY8rdFgd7eEBTv5
9Dzr4DuA3jVPt5gk/Fa04HcmYBDC3qgGQPg6lz6UyVViQCnZKJJxbFCbWIhNCW7/IpL7eanCMlT1
MiIu77Xl0Ak2Pz41PiirZJLtLKn+TRmqTcFo+tyIdC3iG7aSlkU+Ujpsh4Aw8v99cd2dd8ICibR+
wsKCqJ12fsP4GfdbR21Vd78NV6cPNomMfwoYxNji9BsEWszpwOGl+z4vrOqgfdWNCty6p7YcV1iB
oe7GFH36jSHETnTB/1hyKWBmB338dIbX1SFTBk/He1P2VOu=