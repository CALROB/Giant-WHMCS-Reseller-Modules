<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzD25UeUgktDu/Y0oKt1yoZqS6mu6/pseTr67Zb8xW6ti04gDTbcDAtAZXFGPHvIFxYSNBvM
+Mh7ltVxAKGTJ9HxYf4/jkgz68LQnrXWmZeBfXmddrTMIVehDkfUFt0vwyDkRTodlvdnJS9cPK9E
KtB6kTV9NntKBBfo+pJgr8PqgcGW/f7E3+lapgPA5gKZ5tKfTvpn+UadYPsRtOUVL9v96fH4T7Px
m0KoZswwrJCNXWdtnSDt4tex89m1+lTLYGc8dFLWh06CmsndssApFbkz1ZLsaE7HIPfjNHgf/qPH
hh8eIwTlxCm2rtWg20pp7n+65eheXsOvKV+g+qnpGzuuVb1OEgaQuP93KwjnONCmZ/nvkQqGKvyd
Dtgpa0YFyjeUEMqoBO7bHbTmLPkW1PAL1/EmQNOC5ebogMso3KTEEVbxiFSz7xGfVYSLIKc/IYpC
y5cLLdnOSj/Y5dDauZTm8BYMrfft5zx5G0HkUPBzI1IRXEq1BVVflG0kcNBpMHmAI9ix1fhyWqiI
oJZLPqbA5lOrOt82S/5gaGZcNsd9/xnhuzsmLb3oPUeEER1bgGkIKFWlJs1CfThirTcEK5mWWi41
9tGzBHdHAvbjYLGkvYRwYmEHBX1SmR9R5cT3g/Kx6eNKgmgXb01U3ZGj29Y+8UHg7LmuBsb0lKZG
0xWNMsDETE/i70cNEMQ54RJQaQQEFs6W+4eu+H2Sb4LlOMaqkLmRftb2kRJWNVoeSQd13TjEBWdD
rkoXWojOWqZLzdBUjthvbaf8l2Ma9LpE3GLqDeZ16NIzG/aclQrjW16JrT9CTCKqobbaG6HjHt9R
fx3Ua2GfBlmfjlqUmx2Qhq2F0pjlMufr1FMKn5WaDgnGLSY8y14Yz3ZX35Hv26qMVEQ0z60503wC
QfFlz3H5BCVLWX5jOvNediY8GHgNjsp/x9nw0tCtSOEJOf+GQXA3EGrXMF1Ssw9B1Lr6ndXR9Kzk
J3cayW/AuF8pDYhS55Qksjf5SWyIdC95d2LBXhFjY3eit9MI/sim5mFO5mTfM2uk/zfrte8/CdlS
iux3n4rMQS5oQCLxBipuW4EeZd6zNFWrTKtIIkoiYsO3A3tl1ZxHI4Rruc79HVhpf0J17XF1hbzs
t24eyIIjTlF2ioRp8XuuGdg3vaOjsW8U4KSbgKvgYd0e9lsjVQb06FbBCq5+UD5aeU906BI9Z5eb
0ZyJmfMQe6iShQq+tlS=