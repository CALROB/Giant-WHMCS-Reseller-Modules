# Changelog: Phone System addon (resellervoip)

Each release's notes. `tools/build-release.php` reads the section for the version it builds and puts its bullet points in `dist/resellervoip/latest.json`, which installed copies show in their "new version" notice. Keep each bullet short and written for resellers.

## 1.0.0

- First release of the Phone System addon, the successor to the Giant API UK VoIP Reseller Provisioning & Addon Module from the WHMCS Marketplace: the whole phone-system portal, call billing at your prices, checkout with number choice and 999 address, number ports, 999 records and the phone estate, all through the Giant Reseller API with your branding
- Needs the Giant Reseller module 2.3.0 or later; one zip per PHP version (7.4 to 8.4), encoded with ionCube 15
- Guide chapter in Addons > Giant Reseller > Setup guide, and the parity checklist and sandbox run sheet in the module's tests folder
- Known limits in this release: CRM sign-in integrations, estate exports and the optimisation wizard, AI and storage metered re-billing, and extension QR login codes are not available through the API yet and are shown as such

## 0.3.0

- Checkout: customers pick their phone numbers (area codes, number types, memorable numbers with your margin on the setup fee) and fill in a structured 999 address on the product's configuration page; the numbers and address go to Giant with the order
- Custom fields for the chosen numbers and the 999 address are created on every VoIP product automatically
- Inclusive-minutes panel at checkout, scaling with the seats or numbers the customer picks
- Account pages under Services: Port a number (every port across their services, with the same forms as the service page), 999 records (with Refresh and a per-number view) and the phone estate (spend, forecast, health, drill-down), each built from the API for the customer's services only
- Daily port check: a port's progress is emailed to the customer, and a completed port adds its numbers to the service's billed Phone Numbers quantity
- Weekly 999 sweep through the API
- Email templates created if missing, editable in Setup > Email Templates: app login and welcome (sent by you, with your app name and links), port submitted, port update, new billing digest and high usage alert for admins

## 0.2.0

- Call billing: every night the addon collects each service's calls and SMS from the Giant Reseller API, prices them at your rates (uplift, exempt prefixes, SMS price, minimum charge, rounding) and keeps them as one open window per service
- Inclusive minutes per product (Addons > Phone System > Inclusive minutes): prefix groups with minutes per extension, number or service, used up per second before a call is charged, and disclosed on the invoice line
- Awaiting approval page: approve each window (with an amount override and reason) onto an open invoice or a new one, decline it, recompute it at today's rates, or collect a service's calls now; stuck windows are flagged at 35 and 90 days
- Auto-approve: with the setting on, a service's open window is added to the customer's invoice as WHMCS creates it
- Charges page (what was decided, with invoice links), Reconcile page (your collected cost beside Giant's closed periods), Leaks page (seats and numbers you bill against what Giant bills you and what is live), Cron log with a Run-now button
- Customers see this period's spend and calls, their inclusive-minutes position and their billing history on the service page; call logs show your price, never Giant's cost
- Alerts: a day's spend far above a service's recent average, and a daily digest of windows awaiting approval, to the notify email (or WHMCS admins)

## 0.1.0

- First build: the phone-system portal on every VoIP service's page (extensions, numbers, call flows, voicemail, recordings, the app, AI agents and the rest), run entirely through the Giant Reseller API with your branding
