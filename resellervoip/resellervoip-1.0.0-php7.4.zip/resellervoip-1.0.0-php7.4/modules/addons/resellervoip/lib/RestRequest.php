<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrDKMM7Sew5MdU/CGi7KOOHa8QOZqfasEgEyuyQeI2EDfPhB24ESgqgsKnCQQw41bJeh6mOq
OVWZZULroOuGY2zGkvjbaCsMhM5UKZak1dYcOujCx2iPyYwbSnX4cv0x1QuuBXOId82tsbgr5zn7
J6KngjFeWXBP5DTTi3xriIoUnlNkNhgK8x3svNukTCZXR1XZECDjKwWOCSIgVAk6pI0q9adhGPeS
3+YS16tEXKzg7i4r6VKErsXQ10sOyA7U2Jr7RUpcQvyv4Yox4iPVYl+anw5WCvNRP4z3d1DJSXYM
IX+e/p6jNHvzxuQTnv1iybeWaO4UkIGEW+yFXlKer41WcYZUVkcT6HZWzZY4eY+d/ZT5K1x+MAMo
73g3+BI9iKArlK2qPie98ydBR5Vo2LZHNd/w/olM5dsxYURFm+NfY1kd6qeT8HrttC65eWgNY6h3
YZRZIBhH8HRXSWinNa0dwRU8nGs+ZsT42kpJs750O/J9XbV28aMg4YypduMF7GL4sEAGVBVXjQqR
JJLfZAhw5vDBE8QycZgRNSRAcD7wuw21yu6okXdkg6CGw4+12zO26EVmcZcFTRJ7y0uEyd1bMxBd
DyubLlj6k1HlUgVm7f0WyfKAu4MlI3tJ/anG5Q7Y31P2esYhg+Kc/pRDQo1TuzrokYjOYCFZdAAF
dhxjtUyB5RAXN7BUwPsE0zyLyLtTr5Vq71JhZxyitIYoC7IB032eqr35end+guZTEycx9X2WH0MN
KWwKVuNaaxylVAl8UbRJkUNsyO7zvbVt4psx+pGto21Te4c8UuJ4FHJCsPAt//TP+mQcggiaHsYN
sQ0S+DxCR8JtJAkqutz3adZzHVHyG0RxE1zSJENrQHxB73A3wm3R5PeB87jJqdAAuORnWMpa7Mdg
oN4rmTDcsB2VJJFWvyF/bwtSSXX1i2IYSbSzd4uNrCXE+EpKfEYWsOqKBhEWLR9ejQVY3CitGj4h
/HatctBrUdOMYcNAD9Fzf1P+DBLkYTMBLbYlqwXUOd0Mq8og93rkAjYtRVvWZqDKxLI5+VqdtZFB
dWZZTzcNmzVIlH6gN7eKArzzsB/FfEXnH+IACsVySeuf1dmdxOdlE3BTqLbcsw7TeXky+gUGXtM8
5h+JCuLlDBsmIw+vj1nmKWlHqDA0U/pJgf32o2vaydAlkE/uvlKxMzQg9pzYRYyOvIS/Wprz1X7o
yd2fhaEo1HGNe2oISpUYS0MA2LvKGj3PtgoTokNbbLNaP46pLJ1Mot5fMg1vUl55