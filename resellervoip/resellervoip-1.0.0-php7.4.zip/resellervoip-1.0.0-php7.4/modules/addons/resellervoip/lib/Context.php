<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxiXgpbkz2y+Sve+6k4isRYMbQl0MxuiOgQy2QJFfITsMYkxXSzRwmzpGUF+rLzWuqJCgXAp
dPWxNPB4JULYgTTbul9TUpvePvV/6+diPUn84sGv8K3Az/5mdPiH7/0c5FPkrLZPMbxSij2/n3w0
1gGC4I/ZEdFm9wRrjjDSeyNEhp8adfvsxl7pliIiRPUvZSt2PhoxMXb2XzU834O/w3rAx/JMeZet
Weknz+aPvQtDJaFJ2uOiWR4qiToO4axGPbJTjanZ6fyv4Yox4iPVYl+anw5WCvLYSTMir3xLZy29
Bi7er2wj2iEVPIsqy+8/dFaHY3v204LiaHUBE8rYkuhSoZAHuM4HPJigg3DQXwWBZJWn1jnMz9d2
OInGPHyaiyDn6622OVRKJ7d/8m8Ogp6f5cOec32tzB+GKE6fs9NxjAGYfYWIbxGNhUy24XlCN5l0
Q2x+R13Si2u8Oh00nc3TldCQ1hbTzapQ+myni/pSC6QgUfl1p1kPkrBRY29/x6qBbgWT1IDp83ZK
eIoLYwirqRZgeL7/3NJKAtx1NjbQ4kti294A2mYjY7kALKmbgrCOLIy6SNwUaLGbTA8S9v9kZdew
u5owh2v8jXPc0gdEGT2TDuoL2HLjZ0xLkxl1UdCsyl6nRSP934IDWTTFEwz/mKCryHtUxNsqDgXI
nHJOnf0upM4GImTAWnqPh3MVyCVrO+ojHYKQ7hCWb8BsGrSpjsjbuRqxBgcHZ/a/7Bnn75Uk8zsx
J+L8Ma0GhWy/qNivDZcBEU23qDkVgHQcl2YE9gc8UBueUJIQg7ReElmvShulp9SRMqHyvscrJdG6
qk/MsxzYEUD5jEbtX82tNRTWuGc/KgC8xuuX6UVU9qhRBXv4DK8dmz9zf1i+Eyaxqhwa89PwTCTz
qJE1KgyDkW+9lcoebqky08/FxMweMSRBsYGN3X/sHQkgJS5r7b77Qh97mOEnKnlcWHvvmb+2Deva
LTik7QHfpR3FqPPfzkQlKi6wdXYyJJjdjUdt8pLNT14bimLAdou64OxA8rKhC6nh1dG5L5pQiXIp
UZ+vITDEDotmCPoPeOgtpyDIK03zTmV8Ojq9L3/rSQuJ2+GonTgG2Gw/Z76w/NcufXfe/ysdHFGU
GjSllXzHbbNXnUzPuowwcslXkhevqLy0Ki5XP5aF6e+/RS4zeJWINVgUx+QdZPgo8suF/GqhiAiM
Lu6LFYkBT+xjaJXc2HivD6tfbXRkj5Y4TdfS0nvtSwRyXBS2EwsOsYu79bjaRGHyqxoVMQmh