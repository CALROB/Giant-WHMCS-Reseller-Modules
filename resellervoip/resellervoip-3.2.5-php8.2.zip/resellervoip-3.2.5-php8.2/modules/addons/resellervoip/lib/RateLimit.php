<?php //0032b
// Giant Reseller Phone System addon 3.2.5 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwKvtKr10oPY68z8RbZi+0M2s97lrt6sU/LGYGPDYdDMcaoV/S1YZrLlLyhLAljIuYU3Tv8q
DMI2mHAbxMerRkTeexR+Um4OOEdQiASj+cDxSinw5lThdmUKwum522AY6L6eMGt+MD90SHc7Q/5H
gRkUpZeM6hil7sM0IY7jvmMUy8dCRKwmke7pBN3+JQ8zzE5c1E8mIR9NUdaqTKc4YWDaZ7k/zN16
49AG1U3UTn69/6SS+PR5uMW5NPvZ4HF1u775WAXwONkgMk96naBg47B5fpJUk5bmnseDoqLFvAlY
WmKREdmb3LF/1tIGlqtH59heiEK6WpjRDp7KIG/PtFThS9JBE4dTwUtnSAcc8XAZqj/TNhqh7cnF
hD6V/Zd5xzKObIQqsMBO6a/4Sxh8P8+uIJVblw8Or6lxxGZzvbhW198NEqTitfdDwVNh3nJIxlIt
JN+fJuIPKEc5hJ0srdsbq9USW9FG0FgOhjKmEtw8EjZRs7zVJkIUYTwrV7uIVTZ+h+5g1KxwAM2r
6y0oc6yeMUZVXiRo8ly144KCXY4E/DvlsI1/L+dy6dgLkTn8PVE5sfEDHSUL5cVHx6Q2StaLMdeq
srYMfRjGV0isPlt0PHRpxjOUvqRVOZ5ZLRdkyO+MSp5Op0RrKV+nsUoOquHkvM8KZ+C5kRkV78ls
9ZLbW1u5/ZRg9AfWp5rdldSmWIrBBVuCpPDPy4DYRDYezmjSHbuhetViGncqU8fIy+6FlaX6K0MQ
I1lEbBaJ9kP3rvOHy+3SxlX904f/fFSLQCaEZHHwizNOkl3qe3kXuA7C5NYLKPZQZEsALzrbikQh
bjAYfh7FU/PT6mIY0I/LJ9CWf24cf2n2ORcO2ogcL3QWLVot+p+MTtaxEPRTw6PMaXnIgQPCjoaT
AGerzEm1mQrTonTh2otOiRt02f5kQ6g/BVNSzl54yJ47fAB/5BvYhWAS9qc9teR1E8qzdyQ/GR7e
C1HCvuHmv3iu/qpxUo5MLjHIxC8QgNxec917Sa8RIOnOq1HshaCRm7+8iaWiQSziGFIVWnWn81n7
X8O+Lbl8HxZlmQuzwBOYJOtqzLImhghIeK6i7niUeuSoIKCKI5VjN4u+/5h7ERiOOZXoKlASyrjj
UTITKnNt5mb6aB776mddtIH199YxCJgjtUqLtt7TLIc/FLq7rJRjL0vblksP3AaIm3TD5TzbopIm
mnvOrkIxhDJ4OYZtFKCbQ2euvpYLso4VpKZ1RwhVe24tq976qt9OPYcD0fNFE6JJ2S10ph5PKHIM
iR4vu4DkufvfQ3LQrwTsT6iPXLX16urpIwSRi83niI6XhwvIUczSqzNSLq6cxfrDjQreEr/WxenL
181yV+QVM6MXhIm721TuCHgbcpTNAXVQ/fW8cb0mQeTm5YePliTUwp2V2heE57hkhBuwp5anXtvj
YqLURf0avM9tJdj/9R3XNX+FMJDCQBBFlDYer/3BBxyLRu3aV/+lkgoHW6UQk/b6L1tmM07oM02g
ODxcC7hzSJtvHcYyHpD3AbLlbOFd0/OsLMO5+UCa06o8ADUaEqPrOfFbPrKCDPn4H0AMVrWNnuDq
MHQUtR3StzRoa4sT/qlSRXS5Q5q6XM6InvcjeaepvHIWT6bENS3i3S1VDFdfe1xnIww2iZ+K4UTI
rukybu7HebaayxLThDx/IFzfPsQbI1EiLHQ2ofOrINSM4XHx/adT6ixGDf6qX3Az0AaqBKUtxP1u
8SaT1hlyh3HkmhNcsqvKPSgU8CSNFuTItpZPao2LtS5Ci6QKpcQiIDkCcU8pIF2W/1oYnMZpKCqD
xK8uIPEcCYwyNIxztL1Y2UgjoH2FeZiIz7Ms721GuhlxCzlyvBVtE52O6mohvoUkpuSAX85iSqVu
YxcxDYsNZ/i8YB75tFgpnlrqXXE9DucVZcWpANPSr4mixlOoja++JFasT6FPnPwZhhDas0/5wQPC
/rgkuMiYUktPnx6WNg50Hl2k8hqHLCmXc9cuCrAMfYOtD3JpVIZ8/LEUs8Gf6YwgbUQdBVr4q6Ys
1yd4aOeAGCwdSGhr0CqMYRWFvFW8h956cgt/GIz0LwsYvYTe0vB1y9qV+1kvNT1OYpBPPtqSOuIi
3HdvJVd2e9Lt4vB+mzSabmYjrNxm/VL5vJKBI+Xy8NE1t/nWcQPrWxVi9Hsog7az1JdbEvpip5j3
KRDlEHSpTtgOpx2JYDEbMMM3OW41XSPP/cG5qInhZCL33JqmcdF7onLSitX4WrG4YRowBLOg/XvO
/J++XXu0gUJ71/64eE+EEs7o2KoYeWBKs7dApdbtPOQ8bzOQv1g+JFsZ7AzoiV2s7V+iVfS4kZCP
zm3AL1nJV7Ec5WVQsjX1cHsug78Ian0rIsydiWnl+ddhxvBXMN92e2uSvl8=