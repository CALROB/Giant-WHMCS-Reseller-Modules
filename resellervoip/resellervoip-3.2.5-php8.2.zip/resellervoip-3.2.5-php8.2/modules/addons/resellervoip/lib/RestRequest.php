<?php //0032b
// Giant Reseller Phone System addon 3.2.5 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnSmujbN1DSUAeft+Zahha0pSk+OJDH70eMyPS8HbfcPpGhtlaQ1nkrafQnP3JBEHOSXdBc3
xfkegtj+gJGYtXLBlT/B3JSz3DO57r6TQaMZ0eMCHtOXuM9srkhVpcijYTDMrg5HHeh83MBq9PQ9
qZXGmTv7TCl+/LqKdcPiI2r6Ji3oUW85zEHEHGaewApkgEmNWQR+nWm7BWMPk9cp6u6rDZfUYtTy
YXKn2ZKRY+odj7fKFtV75ub8hE5MZ84CzYgSez6d8QfQuaR6GkeGSiMdDDwuMN3BPxncGSLICpsu
v5fg0YKD1FpTdnTJLzxJVgHvSKl+EtENcuQimkziKlI87mPC7QSF2DuAXEtVz4oP5nZma/eLZMvk
LXC7Png4HHPjWBGn8wPjRpCNWe0jSvQu1XZyz2jaik4kb9xsBzrOiVIO5/jlNoLK589IcmPJbaqk
rKQE4lg941snN3PyOxn+4jUirZW5F/aX57nqlpgmHU9V4imoyGjQxV5WiSkUP5vErtZdTxDMwL7O
gZf6s59F+Y7L9pgDWCNMQ5q8G+pT+sVcEjTlImDHGnFZcIoRXz/PluG/kVSMK33AutyUKIgromtp
wlb8SkWZXHwRBbyZBlZeEl1FR+LnlK1CCX36k9hI1+w4Wrm2FHnQSdCH/AOX+piUmxh6RaoEVhRX
Ei3nGUD0dqi7OP2SZZiCd1SU/OsA4l+wkDpTQoNrrhXbkSOoIfNIfUCkwPSCGQY/VF9v+8Bw3Ej1
Iw3ni1K7tTMvWKfukqWJMDZ6xySZKr2n00NXJgJdGLfv5LfkAj8xJvfq1OnSklABEJ+ELa/XNBKD
GUjUniWfWoUYIsVGranuIeppvlCG2vcWKKj+mTO4vurE3QWcAhekn/VkL6GxAzrYBNtjS1brr/4f
RumDfPwbGkh58v1ESJ0bfKxJlW9AiKy6FI5KvZWSnWfHz38m9ORFt8xxdjSuZhe70Cr1kS+FINl2
QCZK8Y4zXTsNZmiXO6eRUBPwQK+DRhjpv3D4RYYRVstXIk1/XjwLIVlMYifpUtJUqtg3fxl/lzFJ
ZRgaLTdp9IwdBVwQJXzmlIM1zG/PTqGRBuS16pyACXp+Z4qcImeB8xdFUVE1Bcu5u8YCS1Bi7tfS
OAyOEp2WMMNmG8fDhdHhl6JkigSP0nhjqiC64JSaTVjI5WDAHUOCIg8h3wYF9scZXXnJFM2q+xCM
Hc2P