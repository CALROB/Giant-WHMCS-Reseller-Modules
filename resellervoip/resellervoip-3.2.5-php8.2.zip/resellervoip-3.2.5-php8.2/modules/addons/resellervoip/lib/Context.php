<?php //0032b
// Giant Reseller Phone System addon 3.2.5 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPphxGC4jNRdsB47LuiamXLXxGU045fqM+/CcvWcgAo3NM12E1607pkfBHNESZHwmg23W+z11
rXWUydh/AHYG52t70zvXIBqxJn3g2xC+QKaKX2U2UYntiadUzCFhGTWtid0f6S9npod6/b9m+gMz
pwlvIke32YtDseb5pCEezd3UP5dP0MgjL5eMrko1UDe43ZS3ndZchqb7GAUPFmvfOQfJzQ7ZZltI
z87Vy0qszedd5lNqnEQKvfuoejIpl0oFos8/BMrB5wxsG23sgbhYHiP2wX1onQSqthXPS2vmuc+h
FYKljEDx96g28WrT+aDRI0rek66eyCGHl9uEs7K4AypV/lSkHM99hZshtkAPCCRS5Z/k2yTL3PZl
hYePbIrY60Lr8Gq1aCicVKmitr8U07P4nRyLMsdUtmwrI98vH0FxQuFp8tKzt247afiKktRgCkwK
GRZn53ascgkoYgjrvFPQieEsV4YMmtqwteS4LoV7KpEzmVmCDBRGN+aZOciqyYAC1ee5IJEKFpkt
JhVcZI7ZOFzzmHnFzIGjpWCr8BmloEWrtLBTsL8/fCTLv5tNiO0ZMP8aA4B5Dd19kxpySHmghRSZ
dMKQoj07l1N+bY/DY3X2p5A1+Pgkvt6mUvfzud0fbFrKH7gTIN44HYNpDZl/y1vC8ohnSxuGPOY7
ff7SbOPnKk15bjfPCISbphPtBCyMpEAe6+fGwRENRehEPw+lBSa9C6BzW6Gqv4MLH1kkhlWI0LrP
r2UgHUquHVTNqBt9efhcsf1/ABj8AAmiHaGz0TvwMJfgB6SLR1Z9ofRSLXN7c+zpnK+n+LHHbtBP
LxEuwnmwlW5jK9+B6rcmTbZu/t0HbW1UCkm/eR3VYA4MJ1cDP9Yf3YL554tGiIYsIonIasSgFU47
0rfpnzIMjb931ZzBEdiSA82n645rZ2HatFlzbF4IYtlBMmq5KDINyL+pWsuidHn4X13Jr63c6a0S
nWfNXS4YqfFwQA3kTak7FttAvyKGAmha63avjSRR49XSB2XJrK3PTnbS9YWGBIolPy2D5WPM0GSG
MiTdP1tDaix72Eyt+2r4LBuV/m/p0se9wY/HW0vb8wSvAI87fZ8huPyS/ApZSst4fVPLJhkA9ks2
WL6RAxgWGfr+Fc9i75eBHliTYzba0q7SBN/ErwZABVc/