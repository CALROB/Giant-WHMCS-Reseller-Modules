<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/j2A4irgf1inFYzQ9Pv+Ap54Dddc/yoJhkyFj6D1sQGkv4RjSzGxpQysCUJ1njQ5zCdYnwM
qyK//OF58ofJ7HF6HM54Mpk25MC1L+BQ0bT0VwP35k7FZosi2RWNbpHLoxFcxnX5uH1uofTr0Aul
Y+bphSYns327ZdwAIcoYxZesUpCnKWrdzaJsjv2f0bxREMPihL9y+aF0ZZR1GFMenb3HFnpmEfU2
ZM7zgcU7GeVZaQ2YqGyhXqXzLOBjQbEK2bbAHN7qRQVgO9GZeB7964dzA0ubc9DcQSF65gKF2OYk
ApXlTqWjKO66TnY5xPgBGRouTOnVt3ZUx06Ag9vP/LqN8XHPLv51C+26CClsdiRiBpl6swOG1wst
VhYtERoNO2RnaY249cWTokuH4oh7ixRLq0QXP0j0N7Iya6LQxBzhhOvlY1WNBIQ+9qWAcOTYqE5H
bQgatE4er1+co815SZIbNTGCH/jkcdMHGZrzMEUvuH9GjHujKMdfITgVeW3ELfLr/WaoX5aUfjd3
oix6OPITLcb5H/sl4jw6laDgPZ5B4sG2GJK5V9ilxRzJmlODNVfIwhJ+6c2rX0cJE+mRwLDiyZj0
VAEHUDGDI8uOGa3FwcoMTaskCD/vKjCmSIAWcgbBPcPI2Rfm9o8Ng/6jRLbfbrww4GIT4NYi2FSh
UYKko6DIUhPTmkXrQA2E+0IZFVUCsngqP3QtXjJxedkRL0y0eLGsSCDpFJg+XmEqk00x7K20MrxC
W1K3btvSpymxd0rEPUf9plfyJ2fi8KUPhR3vUTCGfqVsR1eBwOViS3kBGreDEw/V9kklPeHRowvV
TyXZRD9IxtvxcmBPwmozRF6r12pnaUK/bu4FYtEXbP0ecCSGKC2fOfTlE5Cx5EGOfYW7uOJBN6Fv
dCiZIy291AVZG/g+csVeifNNgdkcE9h5m18mmI3riKpTcziEHzZmd4bS8WfD3dtltFjM3l1tkbOh
ZWNU+oR2iKVRgrJu94IO0AKNqBceN8XzzO2HXmp0AdTAENZ8jJ/hvnR+UgOKJ5XMKDY4rwnH1ykW
iWPKdZr7rcDZ99FZDIZfe7710F4k8THM2fG4QRBb0bACCaIakH6f9mc8ngaHtdYnpqx00CSqHOny
IQprCeX3xXWcLEfKFXzD0yzxRrh+wgFuAinT5YQNUtBMkRz3zPvAOA4oFRklbqC9nrqqTTUnlKVt
x0==