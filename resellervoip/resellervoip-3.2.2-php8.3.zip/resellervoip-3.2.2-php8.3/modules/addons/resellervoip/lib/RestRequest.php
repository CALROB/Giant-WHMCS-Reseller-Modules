<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnuuR4jT75Lj78BvQ33hJynKSokjHQrigOYy1dSXoudv8fPcIvCX16hhdyGDOPXKticouNRF
Kxm6uljTk5WuDPbCWOAWhsmJNLboFiEJ05C53Ie5gP2dVNpwsujJVVORjW9Qnzoj8C4GIVy1G/zt
QgLBcp9mERLT4Ts+rDOqPrw7nPRz/lHbAFBH1n1K2xggQF/fiQHlGsiWNb17TP52k8KZpVCdqRbB
X6v5cs2v52Psn8HvL5fKFiFLKMpGZXAfC6hbHiEDd9xW298NwdM3eXZAQPnOnckRPmcITjNXcJE5
Id++Y++iDV+1LupbK1n3b37CceV9Gk9QflIHogKGkL2HMkB4tkvJhqaeQhdLLm6gMJBPBhnmN/O/
NsCH4g7GN85AKWC8vO1eaHN/9dddONrfgm049gCgczjMYZ9WBngw+BZD6KET/OkM3tArC40hQURm
n8XsH/A9S4t/BQcPZsedQd+tjTNpi2P9tFNMMlZlfYIeZm6SvrlJNzxQ5KYYAXHkJF6KlrmN6jyB
fw48y2jtCuTxtoDTaL6Q95zMPNE+dsZIlCaRz44dzOWz/sBY+Rf1SoEPTuA3qASI5YVx15JFUify
XkUhBgXg07gD0mUwsWo3wGYzGC4Q7ypIvllIWAY9i6+X8sKf7h2DgXk/PSfYT16RmgTVD3Pi/7IU
g3D/XjIT3QKVzOd83+37fPO5Vwg4RUjqh9TrtlG/HUzgJoHu3dWe5vH1QXP/WaKuW+W1r5dfaPt7
sDDBjBQZvE9LthgbxQNnMOP67SFbINpDG/IsvEQMEZypRf2vuRbfSKmCx2tz3A8/CbRBSzuUhdZ/
+yzwW96y+pk0KoOiE3LXQdm+pJ698MkVEzPADuPDbT92I72Q9DhsCH6d1t8UBqpH+8AXe9IytMVP
xWBNJwCbl94PA6bPM1PthHfWodfc9wz/qzRRNPO5C6vL6B8doWDl6B/k4UuqjTxKyAYPYLPXBwN/
UAJDGsTA4zqFOpMMrj14jj2VlEckbXJJ6q/Es0HKgKzCdMuRlwZ1ZMU92GtOGjzRHMLO5jOLTtit
YLcoDEYNM7/t7RC6EFEAiWCuDnQjb8ORTfe+9S2Oe6LkEP1VQ7RCFrgKjUcko1dKDjiCz2qLEHBW
QPDuGzrTfrLvLqqdHXE3HJE6jDeOnsjs1UiUDsIO2HMZ3bJZa3TUSRXbDJdYlZvmjPv829i=