<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm/OYif3/vuFxHvY7+dO8dDG70QefkJ2yPEyZt0t7MKFC1GJveWRJQHyG9EQ9CYTKzzftFoO
NRDVsKz0vkypxWgqPWq7wfxOTgn95K311k8qKtu4zJKstizPm7C2izVL71LlgWAe6K2ayvsKkx6L
me4vl3tq16GzIX1UTavGCm6KPHPa2VKWEpb7wPEU8gNNYGi+rn8RtQbY3KQdVfm3HOqXfinLEN+b
9jHexxGq697+5pqdcR+NY5iDrlSxRUNF6U629EM+hgVgO9GZeB7964dzA0ubc9EtPAniQyQxdnjm
h9Z/TpujNKWxzGybRY+QoI5guA4FwO6KeX3kXT/CObYiDROI6T2EvvUi7ak0I1xXLxsMyMb8EgVd
RqfX+M114RTr2cQiGDyOqWN+RBCEwv2TCsCkxDX9dS6PZdXoQ2YA2NGu3cKdY1O851dOJEL7EYeT
XxhUAubx4hXzBCQPCDUJguEBT8UuMzfZ1NxhlHZFur7qVVKScaJpu9XKhtEALn3NiRZ83IZXVk7U
DEdcg56P4+Z0w1NPodlqtz74vr3QBKk1EKiAgR+bOFP0OXoACx/VyUB3+TdsCM+YhT4CckK/6QVt
6cpyZCHWruriG9AC35it4u+GwzLBjsBpnF99a7C+qlUfX2WNfOMPdGKqcIrcWlUYWDAUgT140EMs
gfx/GeZJ3yFmsefT8p4A3hofrN2bBH8F0W5FYhRBsiQ6O5oYimamHOvh6IiM3BbPkSTW3psg7beU
88dtx1XQgj0ahkrGhij5Y8tFyb9fCgdGjZ58efzCzBurO442GM/SUWX31VWmf8v4QRo+Tj4bsMeZ
RHgq+XI41ScdUG5wHD2XBbqge5bs3E26YvGEB56yLIeBg0Vzw7E3T+pC+DCQVe2v7q0hSX9RyBgv
M4R/g3Gqc0J0882uCtVqkrldw/wnjP1jCzqq2QYRR8GZl0u8IEhvESnBmQg5xpa5J/r3rpgCnJyJ
/2XNhehWsSeloieeSuQt0LQIULmAioP5b+gBlX8qZvmG27A9ExySBri5J04mm7klZLIzyrL7uul3
7c7CnPJAdFeAMf5TH/QJN0MnLyLDm6EUTtJhsegcBR+bIdE09NxSLFKcSwvN1a33M13HpnXSdbY3
BZsI2L8RyImOLKqMG1n19X1cZ9jcaDFRywgXR8obyZ54qycY3K8Jim==