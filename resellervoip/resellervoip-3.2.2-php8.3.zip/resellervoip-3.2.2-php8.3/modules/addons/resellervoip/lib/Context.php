<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/SQJExiyhJ1xQ3PpQs3p1Hbx6VuzZGb6+MHcVASrt/jr594dDukSNfRyP9H9fiLv72SM6OT
8Q1V1FCgpJFkoqsQPwDj1vsM3f752UsONUgLkWaDq+aPH4bUqnMN+LQELCfaSQYBSb/CNT5pdKTP
UWpehbB6VUf6GOy/4jeu6M3ChH+MtYnczUBPmouhy+nVOMxRsGNCU0sGT1wBRsXZ1R0stKBP1F46
I1vDk8CgbsOkkAGt5Ydo3bw420G1IxFiALDdErjzqCsUu0YI5+frWw8OoccSMCPh7Mkjq3H8daXY
TqGh9etbh3d/xphM385iJi2kGdaYNMZrEfz0uielncq9xQFGzEk2FPAqViVI5Z0wSFYxwOGfOkoI
0/jvXkBto89/goVxol48uxjPMXS3KxC1nhyBsQqbFm9S0zjRfItAwQ+YO03WUqjfupBSiO+1CEp6
mrSfOZ3hW5IbiPmfXztmYsHInZ6uV0WZdprBTDgk9g0acU9D1nnt+LSvi9hAWTNwfwdaZtspwwU4
LRcXkMR1VYDYPkhXtSKC5uDH8OyM+/vhcCIB3bodaasL4g6hRfX8nHCkIpZoIr9TBD24TyKflDHa
u/me7vY/e3gOpx/cYKxt8hbPv5ZsTKyxNphJEBAPGxgjqb+E5J6ZoW9yi/GXfovr8SETKljKcIZt
OWqvkQIxzxdU1ztajHANfWEjwVX15Jwb+/4pfd/pbKWtpUH8aGEIh1Wb4kww4apj5zpt5Fn+rS3e
cuQZXMEGqBBQI2QrA3bsCpueQLAia2C6L9yoc3KeSDoROS8ajs+1w2/cTEvglBTvxSs3tN0hRc6r
RYI0pS+faOE+8uNKhj+jULj80zoukMKkM9AMl1miQlnlaVjLoPnWdaXsoLmcSxMZqCKGS0DjqctO
9qqwIQB1DR+yFLXq8XaGbZ8mijYj788BhQ2w7quQAhKFbZ92mq4hLDWfblJ4ymuf/WimTU13d/D5
Td6N1oQzsbBdKs5GVOC1fv93Cx8OoH+cjgigMi+lbMphe0osM/aYN+bVJrHIJ2g18Z4CGyrOOfq7
WEzLyVtbgRMUInMvv/ca1kEUuKLf0gdohxZz6VJiWY0NBDvPZIuOXw5lz9jId/f7Md/tMnmeDTjn
Jr/21ZJxlWxuzh96XUSmvDX7+Vg9DLGviHH8/7y=