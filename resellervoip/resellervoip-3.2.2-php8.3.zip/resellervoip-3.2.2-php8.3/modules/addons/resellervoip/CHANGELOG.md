# Changelog: Phone System addon (resellervoip)

Each release's notes. `tools/build-release.php` reads the section for the version it builds and puts its bullet points in `dist/resellervoip/latest.json`, which installed copies show in their "new version" notice. Keep each bullet short and written for resellers.

## 3.2.2

- Checkout: three or more number tiles per row; the number-type and area-code filters are stacked full width with controls of one height; the active filter pill's label is always readable

## 3.2.1

- Fixes the service page's script (broken in 3.2.0 by the tax-wording change) and the port form's remaining "ex. VAT"

## 3.2.0

- Tax wording follows your WHMCS tax settings: gold-number setup fees and port prices say "+VAT" / "ex VAT" only when tax is enabled and the product is taxable, "inc. VAT" when your prices are entered inclusive of tax, and nothing at all when you do not charge tax; the tax's name comes from your first tax rule (VAT, GST, Sales tax…)

## 3.1.7

- Checkout: the number tiles are square-cornered and sit in a grid that fits as many per row as the page width allows (no more four cramped columns); a gold number's setup fee is written inside its tile on its own line; the chosen-number chips match

## 3.1.6

- Checkout: the per-number monthly price chip no longer prints over the number on narrow tiles (it sits after the number and only shows when the grid is wide enough); the active filter pill's label is white on the accent colour

## 3.1.5

- Checkout: a stylesheet comment named the supplier; reworded (the leak test now guards the checkout stylesheet too)

## 3.1.4

- Checkout: the number picker sits in its own card with its own colours on any WHMCS theme (it relied on Giant's theme variables, so dropdowns had no background and the block floated); dark themes keep dark controls

## 3.1.3

- Checkout: numbers are searched for every area code (the ported script only searched areas tagged with a carrier, so geographic areas showed nothing), and the API's national numbers are matched to the chosen area correctly, so the tiles appear
- Checkout: no carrier names in the page's markup

## 3.1.2

- Checkout: the number search reads the endpoint's answer whether or not the browser already parsed it, and when the search is refused or fails it says why in the number panel instead of silently showing nothing

## 3.1.1

- Fixes the daily call collection, Reconcile and Leaks stopping on a wrong class name introduced in 3.1.0

## 3.1.0

- Module log: every API call the addon makes, every portal action with what was posted and what was answered, the checkout's decisions, the cron runs, billing approvals and the emails it sends are written to the WHMCS module log under "resellervoip" while module logging is on; passwords, keys and tokens are blanked
- Checkout: the number picker no longer stops before drawing (it expected a pre-loaded number list); numbers load per area as before
- Needs the Giant Reseller module 2.3.1 or later

## 3.0.3

- Checkout: when the numbers option is marked Hidden in WHMCS (so it is not on the form), the picker posts the chosen quantity itself, so the order carries the right number count

## 3.0.2

- Checkout: when the number picker cannot be shown, a signed-in WHMCS admin sees the reason on the configuration page (customers see only "not available right now"); it is also in the page source and the activity log
- Checkout: an area name with an apostrophe no longer stops the picker's script

## 3.0.1

- Checkout: the numbers and seats options are now found however the product names them ("Telephone Number(s)", "Phone Numbers", "Extensions/Users" and the names in the settings all work), so the number picker and the minutes panel appear on products imported from Giant
- Checkout: the "Telephone Numbers (DIDs)" box imported from Giant's product is hidden, since the picker fills the numbers in
- Checkout: when numbers cannot be offered (no numbers option, or no area codes from the API) the page says so in its source and the activity log, instead of showing nothing
- Billing and Leaks use the same option matching for the billed seats and numbers

## 3.0.0

- First release of the Phone System addon, numbered after the Giant API UK VoIP Reseller Provisioning & Addon Module (2.0.1 on the WHMCS Marketplace) that it replaces: the whole phone-system portal, call billing at your prices, checkout with number choice and 999 address, number ports, 999 records and the phone estate, all through the Giant Reseller API with your branding
- Needs the Giant Reseller module 2.3.0 or later; one zip per PHP version (7.4 to 8.4), encoded with ionCube 15
- Guide chapter in Addons > Giant Reseller > Setup guide, and the parity checklist and sandbox run sheet in the module's tests folder
- Known limits in this release: CRM sign-in integrations, estate exports and the optimisation wizard, AI and storage metered re-billing, and extension QR login codes are not available through the API yet and are shown as such

## 0.3.0

- Checkout: customers pick their phone numbers (area codes, number types, memorable numbers with your margin on the setup fee) and fill in a structured 999 address on the product's configuration page; the numbers and address go to Giant with the order
- Custom fields for the chosen numbers and the 999 address are created on every VoIP product automatically
- Inclusive-minutes panel at checkout, scaling with the seats or numbers the customer picks
- Account pages under Services: Port a number (every port across their services, with the same forms as the service page), 999 records (with Refresh and a per-number view) and the phone estate (spend, forecast, health, drill-down), each built from the API for the customer's services only
- Daily port check: a port's progress is emailed to the customer, and a completed port adds its numbers to the service's billed Phone Numbers quantity
- Weekly 999 sweep through the API
- Email templates created if missing, editable in Setup > Email Templates: app login and welcome (sent by you, with your app name and links), port submitted, port update, new billing digest and high usage alert for admins

## 0.2.0

- Call billing: every night the addon collects each service's calls and SMS from the Giant Reseller API, prices them at your rates (uplift, exempt prefixes, SMS price, minimum charge, rounding) and keeps them as one open window per service
- Inclusive minutes per product (Addons > Phone System > Inclusive minutes): prefix groups with minutes per extension, number or service, used up per second before a call is charged, and disclosed on the invoice line
- Awaiting approval page: approve each window (with an amount override and reason) onto an open invoice or a new one, decline it, recompute it at today's rates, or collect a service's calls now; stuck windows are flagged at 35 and 90 days
- Auto-approve: with the setting on, a service's open window is added to the customer's invoice as WHMCS creates it
- Charges page (what was decided, with invoice links), Reconcile page (your collected cost beside Giant's closed periods), Leaks page (seats and numbers you bill against what Giant bills you and what is live), Cron log with a Run-now button
- Customers see this period's spend and calls, their inclusive-minutes position and their billing history on the service page; call logs show your price, never Giant's cost
- Alerts: a day's spend far above a service's recent average, and a daily digest of windows awaiting approval, to the notify email (or WHMCS admins)

## 0.1.0

- First build: the phone-system portal on every VoIP service's page (extensions, numbers, call flows, voicemail, recordings, the app, AI agents and the rest), run entirely through the Giant Reseller API with your branding
