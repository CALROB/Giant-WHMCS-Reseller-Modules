<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm6rCzFKduZafGEcyAy3tbMvTmGzU4XHue+yukdEGTvqdSUeOS6Axs/VfPSPKRWqzNGU8Twi
/Uuv9OPg3UIkHWq/8MgC2nlJghf95DtbxEOeJ/Mb0mqRTCrWmBjZkySEKBlMacbQH/BYsDcxUVK5
FdE1QhsNDfnWk4yB8qn6Id8V1IblZTM46qsilpLDw+nm6trEx4oLprlhGN4maLbc9MZ4MgRSMLCg
LetPMP1ctfTAKArjHXfdELw1wc/phJIczkH0+QIhhytB9WqnE2qYhKfY+lW8/U4uR2uZUsvH2rpS
3eZdYKHDClyoQvoOrkj0WzHQoiYYkS+U5ZDeRL4NzAu6wA+prl3/ezdhDODjgGYuYJxzPN9A3Rl+
CNdGPiUQSMWI42du+nXJyyTlZWTFOkhYBflxUfaceRmVBLw7kbpC2Nr8QEak+IK33MWDKwT9g+Vm
1zy4GGZ2zGLVWyKWDM4UZU2Qj5duC4Hqce8u6lWkOv9fX4Rj07NEEBca6DuoWp6D9K3GlC26Kphm
CvsJ4HieN5qoRK4iEUGnERMblDx50GVm/7x+LqMRn5dkqgqCYguBjkjFhcCoZM+MhABP+deRDjhx
9yIypy3M8y81d5Xz2WWiSmqC73HILw8QXRMdrcS8zTHotdaQMVN8FKGmA8RgyXl9ECBRbA7r5Wob
X5Y67vKnZSvQb3WtN1ROowzUtEw+E6995igdgIO7MkOBV1svGHhEb5gijUuX3gP53kRv2L3NOdw0
yrVCm7Wd1pIsB4/DccOCfNIcxHbcAuPBlvHFn/YJGnakEgP1bbgcwAvxLLv2hp2P7zV+D5lTz4zi
JwNLYHJ36kWK68As7GNwURb6fo9QyF9eQ+fK2fSTjVi0sq68ba1+c2tZc+ss2R/t9RbTcKombJML
xvRly/UK5T9Kn+t++RgdGpEjFNvGqRDPX6joXkx2yAtRkXqb/Q6WBSmZY5K5dXtbUgZFazpSbXEl
lm8eT5aRuU7690a+NwhNlgjGplIuLoRLK/kt7sqHoootexzLZTVEHqnuNpK4/kO9uH95rUdlRgPH
wYXNd8A83VcqI116IghY6zc9XqUyKHnARPt/CJ/1S6OVnIISSAXimGhTldReWSRX6lNZc4I3r+kZ
EKwJXhBfT66NsV8CMfaHh63mLZ2B8hzHuQ1zxP2ct9euZKNLRildzqKjS33n2wL3C4PiPOwt9oLl
/OTYTvJZT96brs4ET0h5q24wphkkO5tcPXp3rMEiv0sj0AYsuBZtCgIxWS9c6hSsFyqXZTUaE4Nb
EMEM301JQgWJw0nLltHGPSvzjeLWi/gGellbfFqJ9iVpLPUiSVQ7Ycm3nEPTLcxfcCV/lddJ20Vk
5/6npFGOzYhh2zxdsJ+HLIOaQfNMrLjRkU7sXpTo8wIjV3ErVOGGjjYZwDeKh6HavehokwTXMRed
UBaFSwCMTsLk6L6xQ68GXBBjs68zdvkehDuh3vH9CnBNwhzE+JSVnfGEy9Oo6v1RXf6/WJWGa78h
8PMju9TH280Hjg8sbC8XlIA949Lp4gZ1ZK9YNdSAFLtlAZHIiyZzzBAubwNAwckbAzQx1fotSbiF
3C7+xj16SCDZ8zrEM5mvHkVJtJ2PZROd69pk6aUQGwTXYDdJTT1h2GiDxPd6b4XjpGFzTlmw6OS7
ghEJnx7JFu9809vUpInVh2jPd9e12nSfR66wkEqbNQSLWIT8ywQL6MJtIP1GJsXgiTPQozwhXHBL
7gsJl3vTSHHzRZkQCa662qMNTrSMByHTD2oJju+fnPEA/yy8Au612FEAaZd6rsTadUwlqlW6mb6n
Uet9uNIEquqtSthX64Y0cxoT/bjARuUUwzuBgJLYOCcArYiFCFUyt2PSR1DRR0wsDHvKvieH1N4k
vpHEYh3qWSmMehc1dlgcjuhnDIK+jf/PIk51YlkyUW2p6J3jqZSB1yd/xcyrmnIm3qmF6ZDiAVAb
LJqlYNFD4v/yK9xvT2P9jeR/ob9OKPKry/FxWfZvonf3CSqTgao99v0TOOEiO3kM/a9A6Kt/bJ5i
UuKHubXd479GmU4WkoyJV/JimhRBbl8o9rHS6T0Zwh3SiDbHjDtP01puwT8/G5QhHU0PiQKveyeb
Ra2snu7D3KqgXlUZtYHlbEYc5yIv8cSZCkRYWqhQUTkOw4wzGFzDrUjVzjmM8+z/MnjNSI6fN+dC
qoAwWaS8cn5sjaWGlZywrcVG4VNrZc2NerTH8rwr7ug2Py4IXhGPlL9Av3RQ3XJoryI6mhIdGpJj
c553YP5lti+YXhRU3XGbV9Rz7oXtVqDVQq0zvCmk6wG580NdJQoB0p7MNA1vjZxEF/69CBc9rwQi
vcOFUo3WDGzVONeNQkC5XBn2uWY9XBeUN2GujcgKDD9ACn8H5oFExdWvpQg1cLL0CdqnlZLWb0sw
CmcDnYkpNHnpnm==