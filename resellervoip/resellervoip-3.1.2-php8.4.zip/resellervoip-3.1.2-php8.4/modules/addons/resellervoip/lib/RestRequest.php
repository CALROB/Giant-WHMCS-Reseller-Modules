<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxUDP6R0QrrAcJVnHTM9bq5ks/ztlvi4iBQyaUdqaR4oJLCqgXA0nZX115wI1gGhQNwrYa48
vwmeLaLMdc5ad/F6Td2f/dSMY+mHUyMQ2niu55xRNVpnjd4l2AHDpjKrCIh3qbUe9f46oGhPqO+b
4iZQsxlrdz+e6YGJPMgNyzzA7fCYEOOwCRbt2LZd+FPn6qNdmspFYD7slRR17syJ5v3px9f5AcwB
QxieUU2xvV5ItMuHwZPG9wIMwBH14dyweSCLgTPsgitB9WqnE2qYhKfY+lW8/U5PRACmaKaBitNN
BjiNXnVi9nRSwr43HxGlNkYH98kYdwXVBiG2Sm2lXyGxwFLP/8NmzRXi2fBW0IX9luLO574Djro1
/gPNET9WhbnBO3O8CfTTu1PPUmpXRnJcjbmgaf9tncmt0AwFYs2zgtN6xpTd/1XwbsvYMjIXdwYA
VQWY+lcZndk0ZQvjt+fAJcUomfAvGT7mUC0NIvB04JeE5IMgClG4kfo1IbGLhjxGpExHFpLFRDDT
BQ/aDelU/tkY0yI3WguGEaFH6zUMX4Cmkig9U72HXNDmsf0OKPod1wIjEIsQ1qzjYkyAZWpKA05N
h/m1ecpO/ykPBNu/JmG9FN49gE4E53/T+pww7TFrV+viju5ZTXO3OUDR72W7kJ2TNwDuGeTPQiVi
k1ETn55VqeE1Ib8LboXnaVeQlpZrsqcPzNXWu3GuopX71uRmWVmFzTaXPzgJ3CRqEqxG7XFPYBfS
fT3n6DtNB6UyikAjzMn34ZBc2u7jYuc3jKITFVR4FboXxEdas07EG8QmdnuEy6fOB+K/jUitrHFM
UgOpNwrUC75wob4/OjSi0HUqFJaq26766xBwpT4V71qWkaG+NYOdm26o1D3rhhZNL0AIBrcCvNJh
ksAMjAzhtMQMObATEO9ohR9II9nErwBwSxNE4uA+y4ctgaKaLIAQgtwSMsV5TuoI8xfGcgoCJV+n
M6vb7ko3ajs3i2EtFbsD8+nbx2ZlJTbbi2CWcs30tBWw9ognLM0JBOdoh05Rwodv14FBgSjvEfsl
eYGLal75ldmAlj2xGqbrYw+6ONdOFbgwQ+Y53byFFm3e37qRaxBljV5Lw26ovY3Y/fH654FZpMLJ
dwwofYd51hIq3phdVrjE22SVTIunU8HBs4K1rYxA79tgabWK6t2aw4lvdIHB2/wFhug7kxeZSCS/
YrCV1y/8MYvW5T6yQr9jT0==