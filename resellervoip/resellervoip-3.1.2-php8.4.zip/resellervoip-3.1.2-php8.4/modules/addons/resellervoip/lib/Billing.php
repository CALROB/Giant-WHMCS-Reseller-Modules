<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/hrTtEbKan5j43YK3kZ4dxctND6W+caGRsy7LgMeg+n0B9xtgfzJArKiUOlaJcBreinKKcc
5ea1BHX6gBNreOvjnoE22ynqSqxQFwqEwwnvMfJ9VczfwaG2mDkLXZAEQ0GUHjVVa1VSEjmrRvPM
bNOKetGlov5Tvq7U0/nWxYwzXk5qobIeBqjQUVi3IKDRMGnyCA60J4VO1nxcmhd5L3/GLLFObpZ/
KFmfxlTgZvnEOs2MFhFzT/Ie5ejb74VTiVxziNuJ4StB9WqnE2qYhKfY+lW8/U7sQY7rxO03MO+J
eIklXK1D4lyegLjrl9KI97ijV/3HjNvicRLYh2uXe/Mg2gPEGAETU/uzYNlqSElsDj93xPKtV3T5
nzS2wC6hTXi22NgcviRu1bh/7GlNC2L6xmvFrKuCZT3nouDgg5GV01hsS4srbL7j/v0dohkAA3TO
pj2341Dqc8Ef5WujVYSTiy7ojGzB4UGI8PwQc9emH7zdpeUw+F6U4jjsa/FKmswFGT00IGZvA380
xXsy7HTpx8UopccLb5wq/A+FJfAoFXzMnj1cuz4vh+nCreqr3J9PNGxtT3vUP+XdUWpW16SgscOW
ucJfOQI1LhsGhFbW9/m31bz5EvKe9X4RpPsYgyyOAU9X4dD8RBpEMILuKHT8X6ocSdIXb3hIlPqF
GREBuico45u+Vm7L1MHXmYk6ke1G+G4urjsFcgx7CBvx9kVwUDS/6HdGNARCc0sYPwOn4yN0ONU4
oJJPnd3Ma5+VRTUU3q8ijyFkLbTqXjoneenD4zjmIOWaOv89nsF0h2BimKHyjLXKavDY67aGUqQ6
RL7ZGx4weIgsJ6DqCkGaGyfIiRWkAD5rxzl6PUN5DkoglE3LAxPKomFSaByeXzoIwdGAsSn0m8FL
29Nx2Na2JSzoB+P7jIwgtnubrvBcUO3yqxQ1twdah2qL340iqy7R2mCUVHU0NC5I18H5akGxJSgF
glP3D1Ksid1sjr//O6qpqT8zAN1O5yqbsU+jo0Q30lABQqWZc9ccdcCEu8xt7n7FmFbm9gm28O9h
pdv/nw4ldRlXHjlpkyHDVb1DIWA6DRdBVEjYCdeNpglp/TiF8TpXraVVp/08bnxKDELgmEk0O3Va
zNRqIE2wni9uz+0a4iuDOkqggWcfz3IVQ3YJ/KXW5iDk8ENMAODBOLfyJW0cileGfLbNfykweVMa
mBCdPNcE+hYj7nA5vaIa++ZpXepej88SyPYQ1u9w2aai75nHw3gNFaIBO0MaTsAF8QIkC5v8l/fR
OaSTNoJJ/kEcTfxbNlT5T9UAgAQT1Y0kZ15043wtbwzTmFM/YRoXBO8N7ZsNkbagmYrAvEuFZg+L
4A+s1om4VvZhhLo/2VfmSTG/HpvjSkYp54HlL37Xc4Shd+RCgLtUNYZVATtnSzxFuech5dJm8yea
LTJa0LAZmwZi20Qg6skz/DBPu9utp/0K3XDNB3UZzZfxaJa6yEuEBcQvso0QQvaQPeAentXiSakr
ZViZ1MrdyvSJWrzfTfRkQNMVxqEKvcdXoJ3Zh9nlP5HepRwY8ZKI26xIB/C1SxKqtYtjp08I+sKl
1K107DYqwplQ02CDT3BbBwdEyOS8eE1NQAwwk7lFTaMXHSJrLlIMu/RkPfoqaw+DS+m3E6A5GbrM
ly0/5ZG0JZjSfQAsAHhiLNT1/xIA0AlQ7vJjQz1oUX1hIp7uGs+zJZAjePGrsdZcVl+MCIGdpQXS
mrLbJYPkYntDdlSOgOu4ZU3JUX5fxWNdlgQmZil2zmz50F9+tz4AHOSnRkh2eBsxH6iYLeVQV+Qa
SkIuk/bn99kXVihvQOCXGoyH/iFcU66uoCtC8vI7NNKVqfddnx+hQVDf3XTwT1hk9D9qcDD1UZdY
/U+TkoPDNPQJVfSYRcsg/au8CwpfuU0mHUkLX6LWUxmr5fp9sjLY4ebe2ujbjQ+XjqkTEsLSMs6b
vBCTyWGB0nW6y52Jm2X/qCEd/V3kPPmLTjIGl6WsNLbZq9HO/o/K8K+kFcuVvNv1fC9vIbTSjKzv
sQaNGWcQasfWXos+SOrJUGD/dZbZtFBaFYynLXiuX+i5f+YPiaUDK+6h53DgrhXrgSSh0Piwyhwc
XQel+W==