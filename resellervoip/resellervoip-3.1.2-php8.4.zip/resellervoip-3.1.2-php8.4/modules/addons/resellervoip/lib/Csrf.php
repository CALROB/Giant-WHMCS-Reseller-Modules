<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo7bZQSeJtQ8CLCOX5lfNcyCs0Lwxf3MNFAeenNIAnQwdJIruCUQM4TuSaMcN9fERwjBFstr
LqWQwSN5fsKdA+P41rN4904Ki8JhtpwDUbPImeYZwmwnhr+B6qa2OzilXCx58imk2TUDmABPAiq4
dpi5kICapiFYOXziuhA++NGgGbx6Jjk/K2t5LbuNCuj4VPeEwpPDocGB2Fli51NJ+mfxy0cP+1V3
OzL/u9TyGdk9GevL4e+ShWS+Zbmkr5/bazvmcnCGJK3DooODCJWj8grAOlhu2FtXxcKk9VBHicZm
FXPsjmD0JIRcL9+r/ab8ee7tNZqUqCvi/1SO+oLDDxbPvzN3E3C5A4pFyHESCr+lCFwP6K30tYah
5tH0Ou8FMUUhP359/btnpI4rV/hhUPoZ7YmtYvwdtcPIT3XB1jd5d+9rVgekCiPWVUTzrE2w8KQE
WABwFZCGHrLDBJXXf0733BBHCpX7fSeJ4SlM5XH0Vh895/sLt02PlvOMhuSsYZ5Qz68q/qT7cw0A
1qZMNrM6cC6JSJxSITL3+mmTNlD+hg1AjX8J8pNKV8otnOwKtH3w60sGJV2ML7HeUJXAty2jh6Cc
j/Zc1bWpu8xvxlw6X6uOZu9DKjzyhpEo/LHjxL5t28BIvqzL/5qFR5VuLIVo2tEuoIuau6o+0LJ0
pQ6bWnAGj2NQrgLYo5fQogq2Gb00Ad3a9W5PGYzDVRmZ5gkY90fh5ak3a2WgriaLFqFENNsA3Km8
VSS66GDc20q2yYthCEACGZ0JN2dPVzxDnNb0gr3sRU5PXae7TP1j79CGogBkpECikA6+p6zNM1yv
3IpB5k+g/kcxbmy90GIPq5sySWKA9KQVxfriqCZyGE9hwsDiX4emO3QCdRdMKXjmFz6rdgkDUQOS
Wr/ttXKzV4s2/xcuR9BPhZImQNC2ElXkb9reS//2TiIC1U85Efr+B9r62EPSWhYYD5ehMyagV4AX
q87aisJwOqpqsL6kCQfMukeU/uvKa0bd3thZI/kKQt8EjhYIkN4GWiuvARYHsmoYBD5aTe6ZkjiB
RtUSikEyEyXDT3UF4gmL/SXcTpeHvuWgcf3UWpy4ZvhznmYqUQGf/eLXJ2i13owAY29qwE8DiD7E
84q1GcIOyNWohRwOH7kVXgd7XXeEgHm+qKVADiPf+63xgBWxrVbsDGzRUAlyEImmFbYPk9HQ53AQ
r+E4T8h3+GBMGeF5pZ1jrFMTjHgWUiIcryJ6Rn+NAg05XRwBwfwWHQuI23x4tRbp2LLBIBeXv/GR
my8uLWT1pwH6Egug/WB0zEcnwsoWGONz8kG9OrCZmy9myhXD/xTWnvh/xhFiXZR/M0TkeioVkdhq
e2Aw95DZYBzLWclETjUuOE2ZGbJHjPTQ3Okp1XEHpsda1SdRWTQyALWM/QTigNQCB/HvDV43CaUH
i9QA5FRPsx+ZJ41CaDMQ6yixAQ/W5tx1pwWHRy/GTefL+DIYEixMJKyAiD0bsbz/SEDHa+g0Gpk+
qVmIs4Th+Tn1v6SqudnA6MB3JiIiv4Ol+StMsk5eKMU+O4xprokTV6D6bnpy0sRaSGCAn5pJ7erj
Xow5ga6cWV3QimoF2rp8A1SKCYYLogsJbkJDRV577J4ADr5gjp9cevwHoViCdQMSjtny46rL5F+Y
H/togvorKEhVFNxCffCgwzhQNF/RYjQ3rXHW8rE27BRR8nV/jAsqdlM8IBsTrgkxw0lAPeudPr4t
k0P8fkaAalR5AKbdDhFVpYpv5Qyd3gUecs2BdCUmjeD19IPzU7sQLwanBpfhq+oEMFg9mLOepbn4
9hVXhOZUYAzll5B/PM/cxhG5QoybMBlbFwN5iWLYool54eWoRDTJfnoRRE3ijQvxBUNbNA+O4kTP
x0b3D2LggvvvpztYpKJ4pMiaCBVhwMjlVf1X/NQF5txKo5wre9WpgnYW0o2vxplATnnQbJLsh/Ts
UVHWBQ+rolcC7aX3bhBDBee/Xjb9JHwv+03IHTCQEV8gMXPs5xCOjYQaC3VLO75O/uJOJo5hBt9D
cxHhlDwFn4iImg9sIGskWmhEQnq1MgK1MB9ZyObWpW0CNVIxq3RyXv8CTxViJGbvtyR/x1XtcudR
s4XVMiaP13L0EH5ZpqcibTV02FhSvbLlWd47Al3KnDicMdhYALmQg8eYlZl54lbMGCTyUaEK3ofk
CQWApeo0M7uu7AmVNjekuDAgH7BmTwZ+lKt4RJ/fkZXfbIc95Quoh8Be5g2WdjpS9m5BPUnE/LDh
1jMsEjUnxDbneC0TRLujLgsOmKfsSjzChwePC326T2QoBrgu+yN8SDxmJKm0u+z0OHinv+RtVKAz
hc01hzJQlJyDntTXkc4HD9udEovzGXXDvJxZbO+lmkiQasyoUw/mOkK+MW39Qgf9C0mgdRNvEGnC
C6HpcPy76RiIRKpW9i9EtIfUmsaLhZ4mVAvtmZX1R3t1AXKHaseJDjNgwT3H0fQLCZRhTzoPIh7S
D2m22yCtOICb6ELp2YG1mdXhHQEkDVxyD4J5WdVgkp2Y5a1Rgm==