<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy/WJnqmDBHIoLhQFlMAuGwn/he9tPeUA9kynBHQ5mwD1E0jKq55AqBIFGNHDyUYJqD7xqdK
lzSKLmeavV5ByIrCMDfkYnNd/rJBS41zFXdtEJDriRKQ/weKLE75hETTnONaPxvcIq8Sj0UOBVbG
d/y06rauS1oVEufFfMSY/uwTx1Foweomy1NFzih9Ai8a5waPRNtL+INK9QlgDG+ep+kfm+sDZlQ8
kjWw+hHkoo11fddPn7yZmqfwg9IAIoz2VFuOSIKYgitB9WqnE2qYhKfY+lW8/U4RRFIk93wdXrdT
PWb7145DMl+Eir6NShARjZeY++ksL42wasTN4VuTFnCjcCEarNFnG0HxONKFYxZEgGuzENQA7Uvf
zbEJ7An8Oc487eGJxvRvHYGbQorkE4jpCKfWgKzrrpzbxlKRwIHprlnt08NgH2xgH3DLAgV6xd/2
UjNUggamuLDyd4EW9TEOm7wMgXtI9Ud3kocM7zLoAzN7evM9rT5TFI5MYOJqUvEj+j0QpFVcvsaF
epZ/TV8i+3zlkUBp8LueadAOLvm4txb2WN4anshpKrmXqfwWEcpQXmDeCSgKiRJrtD9GTqo75Y0f
ri/7hVVWUa5jn0xR3Ab+FiKp6BPMOGc1qTYKcHY55fmmznv0BUV85AdFc9LuzaEg6IXRIFAeH0w1
4kByZmFks/l+bKDU/VdMGT27noeO9lLV68086z4ki1g4hMP580Dhwp97kTf/VEdGcVQT0SknqMqO
aDLOpHaZeLhJw0ZWDIFjhIR1MV1LQPYde1rd7IZZYsHIqXeN8Y5De1qjYYpFNTNyLoh6ueH8qY7Q
YpNaqG7llEgrOj6c8vwB4NV10640TxKAg1BHzN5J2U3UyByRjJTJjfGX9j4xoAFs2r39IxOwJXpR
Na7Gu+NMTYDzNftmU+dZyF/PZ4l+CNSen+CsJxv6arlMwPFe6ttYtTortU50l5hOydOlMHW3njJn
hlYHE60nVG7QinIISJBjNFZnfXd+ByUJ1EVx68rSeRwIS2YYWWDvHm2cg2P6Wqi2mSk5TuQGDdIs
Oap8MvPhI2AsY1HPwC/kB1rPsUv5mpeig/f2QW9FkepfEoxHE2qYBH6U4JJTtCaLO+G4xOC4Hghr
hgbm9LQD5lICxaOYH6visVjOYhHH8bKa5y/hngyLGU8e+yLmy+mbYh3lJmQh7r68Lm==