<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyBzoEkVHZ7COajTo2m1DoH8JTYe+/lPME5vEEnYOfa/U0lhv2/Zojc48vWCYw6NRCfPHctP
QaPUxfjmww8cv4Vks4rf82NNyjatAf599tyg7rRb9y/T7IjHMe2CmLHSEu3S5Pl+bBo59i8SpjmI
0Rzyy1sSi4dMKpakO7x7qM1+NEHhm6I7cYnlfo5Q0vRnpy9r/D0HN0EzDACdbioF8/C8zjf2lAh5
A4VLm4nZMjB730eILr87ICuEzsS5LFYvzeOv4lYv5er8xEQ6oJs9c9Mb1rcUX5eYnWb4R94LmVvq
gJT+9pZg8HGc7Fy5jXf1Y2S4vp3ET4GoZnJX6TmadHnkqr1PWG/QDYo59q5fnDNHxn92Vso2qL+h
26tPUjtxfq2/E+qboaGgcT15STlgvDcE1EhA1mXhBuDHpb4pyoLjNVaOv47GTkU6xO8H9gKgvIgC
BWc414vUTaWtRxzs0U9oKMtBzklvM4m2K5CO4EFjzhnJlFQRO5fyY3rcjCMc6fuA5ssuxLxnD4NW
5TADRfW+c2kkN9rhddhnlWoAp1hINH8bhyEg1q1WM14ucBn0J8ODqH4lcaREzP5ue/ffACAMsVLW
yX2bvtr9MwmlvHOCO9Pg0Pny5BBZ6+i5D58X5cgOD6nyYQEuiizY9eueN3SwVeVf9GPvMIXdKeqZ
SZveeO55A4xzl8bvqcEcLC6sI0IHWWud14sPHfY7uJFJZp51wyn2jAJDzUlQhH5ojp91BEeMNCWA
Klx5qKA/XzjRNm8qIXfRmURBV3hBx6t08wv1Eektf05vuuEj/bjRUTS3yB6+j/Fkx6i4KdFPOFF2
Vf1uhDqIUafpoNwB/WACPaqQrG2+8LK174TDUaaPylpTt6lhYlcF20DgEsxzrx+GPxHWTJvIs7VB
QR7/AA+1drcCM3aTgphAoInvhFvjnbaLbzBB9jZeUQbHwakFVHewfW+RKyhJAi2SxLj514ytV9K2
ni57aAycTavxPMe8N3claofL24i0h1IzUKOWrNLQR0LyRKkLwlZABLFVXXcNbipqbwyfNzGhWZdm
8DubteJDAFWxt76gBJjwTpibp74uHtHUWsCwh8w4mTpYzktkgzb31qBZxq0v/OgZHwa0SmjcfRUM
/s6iQ75feGSLrI5BPVWBblnbLqdQQuIPeaVtqkpzDZ9tqwQqRfNbP3/abgqhlUI0mYcZe/2nOeEJ
ed1yw37Ne5UssBM0yBWHWdTIiB4VocAjp7mkB0HQJGsUUbFYaZDgoRinueLxdwRTDpq3jsVv68tD
b9tasFkpV+ZqSt9sXr6avzX6N6uAV9u6nhUnyyuFX7o9v6AFhmapzkpuh5bcD0Rx8FyhtQovz0FM
bEYWgoKJYNy+XhFaOKrxXgO2G0boipCP0ETGUqb06baaAjQzK6BmOQ11tKj3Oe0BbNMVWBvyNeCg
n+fcyb+pb6zT+un+5XBL+AiYlLnDROx3M4q8LFdCky/VnyRu9QPHyDxiKethdOXHeMTgdcK884R+
wlLJjKhLE3Hl7gjiCLVzMgeHs0/YC0YxvyX5iRf3MYcPLPo9lyyLx2DNeTgFl1yaVSxVLXXo2MYK
cykIYAA9ANRTIcee7JgBwbIY6xyZ6ROmWft4NursZhIkorxW9Cj2fV7cz/DaYZxat1e3f0GoTa1+
XLfZD13gvE93VNAplCRK3kCfWUax/m/cp+MR6rkgvF3Van4oJGFtBoGWDt0pFsrGWOdOhDQfJZH9
ggC1FWvqsOStMPrJ1Lksxp1fdI72yaTwXk4DiLhK1+zcyXabpC/K0lV8iTV/JID5XaHsDr07Kcsc
XN4ADdly8HlrSHCagN19qPFrtQURvI0F1XKFu1vpZ5iEenlo7rW+1J+xUyhzmAJFPnshvzxGoYG7
6h8N07IKUTqacFj7hPYA4GSSmONeMETEpeEqZjxdUpFOS3XVXgUkNECBCl18N0M4Xnr7ws+0bUIZ
6DMLw9Q0OcNFtUXu4fsS/npkmND4Z3dUKNWaFyAswJgiknGcl5dMkYeNFKotkfVYC4YrSOcmS9JP
kKKvFhM7HutyyX4m5ykT0iVClTNDOJbNJdk8chHBVj5/MwDnY0lNlHKgLO8O35b1hBDh3RnJflOM
Uob4G/ljIvXcUu7WKSLP2uh+5qudifxhjQ+lrP/oNbH5djeUUDTRZwUvAKlFGO51u1BHFJQ33vzz
iV3heqkis4x5H8JdaXDf2B2Km9jmhj3IDntleAenH0AttyNVQvKuzpa5moSRcDSKMREoOiSLKfg4
HBVxiOZvEKbFLxcB/1BxDRvLa5j9xle4AOACk0g1I2QGCoQ9a+DjOvSF7OtEoGrTMH+Di2qlOj1g
xAAW+p8hjpAwuaWiJkB5Z6V9s3ZrBiXM32XtegNOy9oeyWsfgf1KHDtNATnWH+JARjDkChzUVLRS
uHzlDm/hy24Wk5yRQfa=