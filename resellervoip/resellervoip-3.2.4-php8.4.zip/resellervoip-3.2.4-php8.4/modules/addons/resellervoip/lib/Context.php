<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtNBfODaBHwqTN4me5+RreSKan35s1E2tU2qXa+hONCQQa6l6XvTcU00cbklAk5eS09tb0gi
JIjn15opboZYy/+Tr0Pl8js/YMC1J7e24mt/iJJQDDL4iWjn59AT5b9lUhMLrmQQIYtL4HuP7LwT
aoVFDvlnkEbbPBmEVVw7hH2GggAHVD2WLDA4s9DBcqXLiu/5Lj1bLnDvCZlFlgjTjmSdMt3u6zp2
knAjxanDK/I6Ma3by0p8kYVftWBK23XHkPXHEPsYQ+pcXiazYPYLfGTPdeHQ8iO9s6RJUW32Qt4G
RQkN6fyR3HB/KXKHPBDWLNgeX8gPnQu3S3z6Tb/1vetOpIhtwO/ooanzfYghoqE3KfOSfdH1rx9m
sKPkw1unsZG2ptRsej0/bHyEueeUqUOx3ar7yzBVBfXcA6e6+gnrWHbp6X0hQBtf5IR06cGeiRhm
NjymT3wcfTFlfSYXa+BUYl0ldPqRecIYMvF1CwsU3dQV/gN1qB3YLQbwxyp9xwVtk5e4jBQ7ra6b
Ts7aQYKpYlZkL0IqB9Mad9oVqk+B6/n7GvrwTC/WRtrGc1zlYof/Tny4G9bVs2OLgSNWa4vBaDEK
6bUPiwpW1F7SrNgNMYR/W3GZuc5uNKQTGwtUtUcYx7P422Ht9cLdETky9W18BlP80+/yzeqwsQww
SYm7igoUwHVk3TEQ/DT/SyEYeBcOhyyFE5uxLwBwNLTqmyiRMErVgnoyQMLQhs2wxCJ0MPA2s5eq
rdDq6S2h4v/ex7rEysaE1Pb2SwxC0EL1DuQPDpYCisnrKTMTGCxCqvAd5zc1rBHVbh00ZHdT9Mo/
sCI4NAPMmdZ5TYVXv1I+cDsBS69Q6L1Pu1xrnPSZ40bv3OWXC//j07+GO7XMUkNdKlIpb5I36TBT
pjx5tXkRECoXpbJPQTY1muFUfNXnA60wTpCO/MSce/AR3TFWDAaYKugeWCGdae1rd0ZOZRilxN8/
N1FUBt5uawUq5enw6oWWBfruaQT5TH36OQOJb0mf4gBLhe3Wp1Oema/npS38qDPcK54qBnehswPE
sgvRldNiwLSTXewd8frpaMaItxUte+9bclONfNfacBGFBabK/PuPoqYB2mJHZJfI38R5bMW37nmJ
RgJry/68VFh6TDdjRFKxu9ZbWcopzGLiw5i4TZue4XZa1SD+LXV7nkJlLwb/u3wXJwUuP5XSWm==