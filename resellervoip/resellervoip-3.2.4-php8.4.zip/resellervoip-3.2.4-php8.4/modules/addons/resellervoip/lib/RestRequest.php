<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx2+dGZ/PvvcBu8422kz0Qfy9nDrBUhG7V6qoBRPFTJB0myRGJBV+uAQRN8Zhxrura4NbV6P
eLglQ/t/XQMICL/qJuuF7Xlw23/5Y/z9SCW1t5uqtcdhmtWo/ZVulGaBXnZdN9E9AsM9VIXLPIUu
pOd19/uHbZscXIytr42pGQqw4J+7UW0jjkN0zAP8JOwUEP0YmZUzJAIjS2Yx4u+XoWH3z5WJukPl
pc8byRMse/bUO5aTq7AHq3wxHNZiRg9LB880+KgmEkpcXiazYPYLj0TPdeHQ8iO9W6dsJVFrcM2M
isFBUg8M9cbxm7536Wb2jbSX6m0fy1Me0JWU+eQazV4hzX+f5RMzMpFCRw7k/ib9XlvycDYbqeOJ
clVhpaX/mo7baHF4qarthe+RLFTUP8J9ac3Nv7rzsv3SKSBFtW9ONgdVMzqQf9NVK0XYw3+E1hLN
j6Ll4tqruwTiS4rm4YOIK6c0YLv5Wpt4NIstaP9Y8+ufBqdOB+PSyb6dgKY9/MgJTUBiIRTXFrSB
WUBEnw1m3HGodsQxBWvwsAxpEVyGefURCpLhGUw4emhKAiuu4d+CcwOWs9aHh9VXH2HWXofY99qQ
xqFc3rxc0FCcUXoxcLXGIxd9IEDzdRk/0/WMscQo6wAQ4fr3ZL4JQ3/0POKqUoN56Svc6x1diiiF
BFn3z4eYdAwdyXEZSaqJ8Ifjf9Dj1pkvGj744V3L3HtVu8hTk5IO75eJblzrpC28+0o/X2pWz5nd
zeieAWTqZK8zccu66YoYDnRN+0Buj8PMrtKKPGQlo4k0XEos1sFmvsrfTryjED2kI59z+kNi2ayZ
JjERZepGcOh5EhnHUCwWkvevTEj7fU8Uwk6Fm9CxCWFxc00iFsNhDIuf8VYinCHnTwzvqr78UaSc
n2aFAaX2+Lc7qFEN0P9nnFVik+YEE0X92/jdnwm3XxNQxs1uujlaKyEArssiGR6QpGbXboeWe37c
IxR1fGIKk+uOyCeusD1heYOucX3tsCslNBZg/GHT02eiBGBAl/4ryb9vSMs/ccKZNVto1HJViQL1
FbUpYHbL6bjBNwMLOAOgiNhhmD4hTaCwRUfABQfZ8oFiIXX4/S/Aj7YXOwZT2fflqwOm5hQLAY+C
OKxA94dGvgk8ic/VHAQCAqYy65qXP0lCMmouzZfGE/pznYr/oOT9ZFvGpncO5L8gALPRL9ZxWqEE
231eTUBQzArqKb/w