<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+h7WY2SB7SNNN4N0r5MVri+hCxEvNcyRj6JxZtw3fgUnGYONKKdkrq5nMFuR3UZL5Jtjw5R
ZBEe637DqHWR/vLK2IH0E5b+aZ6oowi/QuppPXJw35/r7XRTTAEdIhiQo2GLAG5JnqNMYvwRwxM/
E//6PiEgfCOI3rpbIFiVAvjtMgJwWH9VsBjc7mLNbtM2KaFibRRD9lF5lrjZpq/InC+yWZvHlsXU
/jnefa67jIX2vGBdG9qM51x9RWqfhIghgIvukhDGFaIZjYfA2oj5lxEkwKwSkkkjW6bC77T9O6Oi
PnTVQFpPp7B/xMeuEwhOondM/zUEZrNYibwdoX+sOwIBPAfENH8ohmNS3LezIi6LI565x4TCMOOX
l3OtNgK+6w7ek7FwqTOOlymM9UXJHLhUI44Llua2PD1iRYG9yumaqaGQ/UEs89NjNSFvv7h4r301
3ZU5XPe/1bHfeIAjM1hkWTyr6aNeaDp1kSN2XtSF9Kjr4ad+nyBoP52BY1e2+j3oyRGMZ4iultiw
lMpGyyHUnaL4OhG6LTDun0gdLYB6drmbqpGus5r9vi8nJGavQm9+Ik1TwIDFAxe/lIwhah4u8Aug
H9tmrL5PC7FRD6AimHGrAVaQ2Gkpfb4ahSTD5KJtYhuRVyh9EooxMuxJgCVCOfYRtLS4dJaW2F80
8iHePGG3lA3zfnwUeI7VO8o47WuQcBnMLPjIOjBRJ5zKP/jiuxNp6QMVfLktQmOR5faVvliLlTq5
tZwqpj/pXjFtk8NV/yKIfcOUyv8AU8bXPHXUcbrC6ROQhgreUJQT8h5yhANe6UpocwoGcp2D84TW
0tuvK9mUTQxdT+/HS1Swnu5sw0GXWItwOY3HhlUbwaqCjcDdGXw6v7rby4GVdtSdTYm/CtzCGFdK
+VwNHARzQfsCV7fue7WGfXuP8L94HCIyyJdGmu0Gdl/R0/W8CkSfVAYHkxtjg1TQ6Lf4uQRGGB8n
0wRJYSpQ/SDkYLK8uGKr2hAhrhbieUIphC5HQjFfChR+AjJM3N+SN9TrCPKS6s0GQNZNjZ//XAZR
55Xg5A0PktqwyvjnX20LGE3AN8YbZ8rp0te/mO5JWxRzBfTEHMvwHbzcgs2oR0AJj4kRLQ6pFe61
Jz/5dlYU+CaUhcEmVh9x02sZqjyghFVEcEi3E2Mc29MttPpG7oXG+IPQuGYp1HKVpihCr3aMhFZI
T7jm47X78fR8/w3LO0VKmFgd/IVZkwhFxDyNQISl+CLWJTtPo67p/OhFhWUVwagMUudR4QkzqnlJ
siZnQ81eiRhu28ZCKXqep2GH1M6uo0QF2h8139a4VGi3JsqoP//uPDS/VomWkIoygF3da6VdVK/7
bH0R3BrrNkHqJG0wIbYjvUdEnWICjai3LryGYpe3se+1UhS74TYWeGRA6Jj9Ban1LNyMp/6cHuaf
pyNHWtu0sG4R2OdnyjVvndiVFz7wMHQcOWvgAMGJdSUd30jNTmcihuLfSuQCMyLlX74x95hxofxG
3UhpikEQA+BKdPzRpVYeSnTjB3XXkfc64Il/qs/pr2Rfzi6uCE+ctamDMynx1ahmnbVbG5tlzN+D
6HtcdqDqbeUi39734iyHZpt+oRnCRGwPT2hsmktRDW9S8TwKjhhRFGqpWe+jzjomymh1JMbdkbwq
Q12l9Wm8GsC1ckFvEeSBOH8jHia2JXLePIJZZv/X1o36DhdqxC/QTsAZ942EiXlft2n2C1cIZkR/
hfZTYBw0HaQLNtVShSbrr7W3PFwWOU3JDJRZA8475I4iGK2XWKN8cbhrnBdWtIZVARJrltRC2ecj
yNW0h3iWXSgEmMn3qBdyTRSxIR3Q9WJuj821AG7rTX/tL+ASOlnc2n3gP3j9lBKVKsZe/6roR1gH
WtnMYRecsHj37KWHtpE1KjF9/pA1DY6f3DHOy80xBNsyIoXoXCPAlWeNd2cv4t0dKlFP/DRLbVtj
c1bmSzy8BcWIm+tZUCyu2sH9oWKngW3tX3F9aaL7doKVW3OsIbdRkowy/ZJB0CDkoapR3JOK/++z
k2xRmul1ClxEdHmGxKV+nqYbynYT+9ndwCgFWVMvPEtGx/FgKdJLJTOvfyzS9xA2NARBZDGzuGWI
KYGLy54wK3LY13eCKQkZBPCex5gnX55mcntCsTMsg1h5SZXqGVxqQhUGlvPopBXaY2QqgCf8xkzR
W1xPyWGnipegAZ2luIiEx6U6Y5rL8M97En+YVut1nOuVsIKU7ZyWz6mm4yVYL03pmG2J1oRBSq5A
u4yANUKbJZlqcacCAMJ4ekoLTkyD1XW9XU6OqwKsd6XD8MMhyDwjovRjAKYzmSE0y57AXyEEfxYI
FoEVpCQxC7k6wRwv+v83//in7aqdWzzss6iIPIdUQN7sRnWEUlKwhmoscPMvly0IBC4=