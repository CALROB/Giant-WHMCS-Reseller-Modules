<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyPESSi0hadjsVJaw2LsVYofAQFYw4lM3V841+F0CFc5KVYkUgIfx31VS0bG9C+JRzKfmMG8
utQXqQTpn/3j1ctmq6g/1QzyKMwllsVGgLNmvUlPdjNwBuJQlFnf6rrgPl59Zjy5mnyjAbjS8RXK
RJJ1G02Bi2UaUVcIGJBR3umuwfVOC84PPp8CL/fcal8v/vLUmEhZL+3iboUkzdufBRtF+nqzDwqn
U/mSJme3MY/zo3PoEvPp/VLuTnn/bta8Z8sVVlyDcTeSexOgIWihHR+phkbEdBhhhIvnpY9RIxBo
AHgtccZysimF/y/jvUhKOHt437IDrDvgYkYrUMJrcPAzOt6/TF3JYcfCoNJT2Nl0GWffOl4kson2
XyYxkwnQCTwLpNx61PS0QVKW4LBbNVpQAfRzNRavIiCWq/oje4jpZoTdtZYmdE04BA21xLd6Ds5G
zl+z94urzt4GptNVeN+XODvsaTx9PmkrUrc95lrOumM6vaRj0i0GiTDXJEXx7QPu9tELhNrJ8POk
kmat+NPDaIItOrbetfHVsiG2/fUVg5QwpGzCdAoRoyknOkbkOvm+GTSeBC1Gtq6iKoDOFvk2BAms
Q8mWWOfO/hCtZv3svFh9qRISahjkr+VOX9YpVbPRe0ta+NRVl5h/qPhnDhaqNqHgryxLUmNIKCB1
42G5eG/8/dk2mI99IyfxV++XlfQQWddDxZgkGhjwhATTGSCID9cceJwNRTSDPXfddPpU0MVeQ4u6
T7yCPNtQsIDjv+7xbtm1VD5bX6pZRh9WivLwnzHfVjc4Eo/mE+fcBdHSNxOoR/HM0WE/BQn6MNy6
ITdNco3qvBulXv+BTWuvVeJuhlgNAEmNR0HeIbC5OymIxCwV6060G4HM1bRqnC9ZcVFcKHQ7VcnN
hV45wrrN9Q8lnT6sR/+AsfKq6WPrT5CkaxM2tbmi0wrLrzBrSQe3s8tWSSHcrqAuRW8R/cFg26CZ
7oSSD8ZFq7nY8NoB5rLpcFmCjAwrO/0V8L4Fidf19Xeov5xiVUg15P1i8rSXitU3jWup7zaX9RYZ
qQHTuXWL20VMfikWA8euwSn7gaG7+lAaHKZMySir0PlVtR70lCOHNUqQ5zlVZ5M/VN4CjIAM3dj4
AzApnWo4oqes9x6kqOCeZanDkESMi595FqK=