<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtHIvlLekjhwSUXprWT12bQbXN5/Zosr/OUylSZ3Ax2GR7lg3HjH93928Ox+f/X5RKquB2vc
/dC+SlxXTy2eGeHLiKPqltAnMXOYyGEGjVQV1Ket/9VZuJSqe3SFCqdigWS6PfO4Nu6xEgMO0jX5
d/Nz44x2uMdAwHqREbJ1LeYcUogL1nIUk2L+MVfrRWQgAf2E5yzYMXyxNf2QESkF+v0LV/eEnHGn
c841DM1MNNekJTsFD9CCSxAET9iwfp8klaFSWzK58AEsAaeBAqM/iwxfJfowwwstPOxujXzNZqHQ
rfX8++BCI/z8PKZYx4UUTKzSzRTSHKZCtbFie+8dFcVfn3yBKTWVEedHNAqNQDhJOglj+DBGQT8W
d1Z7Af0SmZA6Qmc+tnBc16VDurcSKIEO9VB3avkN0p8M/qaMuV3YgYdc7+5AFo55xmCSnpU6IAr6
ABZ6qH3KMRc50UB8hCSYvKF1dxPyMomWU9znSglxNRgWi+V7UjWeahpk+8wxQnJfs0ZFo57rdom/
8j1XeNfDC5plgwEn5m63Z5KjUZwW91d1KCM0XChx6CQ0h5TiqMD2CRq7Qixqk0KUMfXoELy+nTQQ
pw0oifmaOHUFOLpCndwgkqVNHshccd7GcJPPmizjV9arOhyO/vX3YoepQcP7QowCGZ+OjqJ3uREe
tHLRvfbV/FhzBVedLB1eOVgQmCVxfKg29N52tUtP91iAxFxIZYwJse1sVcABrbLMn7/2AxswKpGq
7FGAElJc8R9wcz94Dvg+dA/6sDCeZp9cfGzems35J031NSdFUIJyMz7AFXe378NRewIJiByED04v
tAaBjRvYUa0ZUE8S4ByiMMnfmXCivAp+kqucSTq7fSXBYHDJweFKrubqLXI8vsrBTZ+deYlSUKi6
+caBA40mUFMXpnfcT9GQEvgbrDLxvJbMZBf0TezHvgmhR0nezy1tsBO4SxyRqUelvwl03AEUdmDW
TwJFEQsLcnsOIvhsAJBs6Q3wHz2y6fd/8ybLeB+eIQkQIhek4hAW6lAUFOiYZi3CUdypewjuFhI4
pdJVlVdAIlTWN/3obB5dyInOFvSjz50/y23k1XpJ2GhdnUA0plgsxujQyTgqDiTNf8dZUgVW0rVl
BNctFgHeCWZSdqvfQKrxMNcH07NEOx/x2NlninfM4DfPlgAWKMLT2dn/4vcYoxMjYbQtJW==