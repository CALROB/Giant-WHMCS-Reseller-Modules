<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq4tmEP573d9589LnRKf6X45bJZagsU+UzuVZFdiRr3qJvkd/WJJRFAE0i7/R+9ZcxM+l9HE
cEP71Vu3Cf5LiPYPvGp4y/Va9CdKdzhoQo7vbnyCDT73ZUFMm3tJk+4u+DUrngun8EObgv0TJw6u
wczEkZzoPEVRSZacBvVl96DhnzgvoMej+QvuEAmECbMGroH2gkoTvI6jnE6biXMvlazHlSepKNkz
rEeuk3aRrbbEMPMCdi7IS43r5mrJkygxbkeORTJN1rcsexOgIWihHR+phkbEdBhhhPnqnrEuEpGr
p65GzoXwuSmn/tJF/iYjeyxx8hiKyWXUR0WjtkAp9aFx8QSB2raUZA5fa2SD+iQKxaLdiVTChfW5
jzIgkKmfqcw/+qexXbiurSoe2m6za/iCdXbe4oFltEWHFU1BpoxeiANJDqBqs8Tjx1QfXcbHSjCN
JCm7q+xjrVh0BpfEBssw7RGIBh7ncggOnTCwVbKi62HmbHEu1tB3antpX8cxeaE/QrOvirlFU68b
qQgqhcqJQYzda8kGZZi7tyXIYFK6CoS6lLhGfD+FGXq/XACYE1xl9VJ1YB2ux/jfeum9vU0I69Gb
wusD7ZsdqYOzxVZE/cRjRaHjz2WPsADjgQEkBMuFg+t8iFMcon3/XDJwkp2em5/rUHt5Zlnl6aS9
y8enZhPONNCpc0+SA0TPT5tjTjQnu/xFap2ul99MpdXtZWrU+XOUTwA4OYZT43D/3Rl1Vw2ojB7+
AhlroeqWcp/IPyj26BRhJ0GXXdGMK+eKnMawQnohr05jN18DVi0GHdOcDH1S8siJxLakZ36Fqfqi
JGA4U/lp2Afbt9l/xKUWsjuAchUV3nXuZWU1fNDvU8X8ycI/8i8k24uTZZwU5AIdaPR8q4Y2acf0
dZhu+PpZyHuxm43Q6pK0Uc3nUKEEdTokJHnEvTbMQtDMmYAJsginVOc6VMm8YwXmy7pyBZQO9zUu
pk4Qg+E4nrOLQVy7kGEfnv1xfjOA9I2u0aglGeEmYdN49XeRj+Xg3JynDf4R7vov7ivHdtXVWTxj
1wZima/g2ravt+aXi+5cxyCN0SiFMt2dcnVnZPm+1UqM3ktTBk+QdSNJ4b10kYdi6XR/wDBogLBe
60v0o9fBdHgYG1Qz8qDlR+nzXKSvqrVz7xdVGjNNelUZvlgsA9LG3cnYEK0K2LCTdVOoDTyHDGB4
tArzJOnmpQ0e6JXypln8iFdpzhwZBIJdMoXabr2789R9gZbBpdwAmqxaMgmtqYJg3oSwWwy3ciA2
G2Qvkzq6iR6sJIAk1oopXCaNpMYKwjVFEeHBCwPC9wHjU6Mtlemf/yVRGccuM/1ukY5v0VN54ESj
8/fuCx6hZ9MZgM8p0RHucrpCy1l6tF19gZGqC0PmmO9fNava4FpJZoACIf78gpKVbKu7Ao8sXOQT
WmERyHN4OK7iPqy8wRs35/5EPYWlxb8M0gIQmbG7/TZJbNPP3u2vJ+Wk/fpkLBgr+/epeByTjAJe
8sG7T9s3WdBzh98TxWs/NkXmmu5YVN6x46QsHnDgKRv4n/YefSR58UKJWlj0EZYEoq2T4F7bxzr/
+J7Ot84qyYk8XWWRP5pWtvwcPqU99hcZx1PbAz9ORRBdlgb6PXEzgXA/O0KpJnlY4KcoWHcUp1qU
Id2vKn0qAoDsNp4NPt9NVxA281xQudwinLkM9FU5+8X8Vj6HOaPj/1RhiYvYs8qbrXbJLuyfUXkw
GFIiY/9f1FzpkGZRn2PzrmLFShLMmvNCKU3K9jJoqKLFkGy8Y8alc4AIujS7ZR0N7qZwFV5bFuDb
fC0wgQHg17tjRzb0OGabzJ+v/LN4l7yVlGzgs6/A6FTQA8RuMXqNHSx2M+5m7Mf1D7rTY3fPXdco
3XEGY88jz2/k3PfCSZqlBGN/FKatZLqoHqTqaBUA4TSwHdLMBEDp3tRDpHMpCLIsNUL1r0UFPjmY
jPF1rf3NJcXQpeyV37GjO92lagbg7SLptIJCU59Ag0SNEW+73HnB62NIwfbZkE2rewC87ZScjk7i
iBQmH5GDqN/BUVbGDiyjlPtSBEQez12bRNVMnlWSgRMT+qN08tGJvC2f/Khw2a3Tdy/CjXsSEMu=