<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx/65F+tRn7jCt9zWHy1hNf7aXNcCy5JRVMXv1epECZZmy28Ukn8h8WbxZFxo3WjW5F7c2GU
OlxX4+QscDDnrpLTtum/E+ZWv4ytRpT/mVqPtLGgw+H5uq+TfNZgn+sg1o9TOafVgcDIWbBpqodd
8X+Q9IU4fNWwigwyiV7hhwQZ9U/F3JwvOqFmdge8J9eaKXKPhZRvIwcquooSPk/JwDtepH+O/Ysl
UfEBf0BvCwpYVJjMPPutqe2ip6YF6XrS9C/vfEaefy3DzKxpGZRheezkblZpMEHXMNDgkUGpPgNw
+tFwb1PGU36evU43HE3eP58n1EDNeIxSJKp8oelkwfMgAi10P/D2iSWewDoYfSs+npVvbEzyI1ry
RhkS/EmH3OE9qABUapkPX/wFQbMS73ckYg8RGqVjmBnAKVKHUBPM9IztLfbGPkM3Mxo7lDfY+ne4
M01DCz/YwCoUCKdDozhJMsGr/K4Og/ZQMuyjsZt+Wq3LyYBKoezjtxJUaGjppYqmtMuUy6QGtxQf
vfpgW21taVTVLZkrN66/7yX93kXEgxbKE7jX+pH7OAUXGoku2IRTS+qNLtZiZtGCyRavILtXa9WX
lfsBb7Ifc8NPkvdtnfhPfYM1j9Yd+YjYMC4IjxvstIbkedqAqYDKHl/hDgSCAYrxVsW45ZRBlKrS
OctBD+jfJM4FvWlaNjk5mUCGGlYrVZWHwLGdzj3Qw9P8n9qYxUMh7CF4taIwerKX6709NbtOVwCm
0E6P5mYF+wYhNE9JwB6+ZbMmYWV+zOWn5SJifmmO2HdE6jXdP6x6PPn+vQp/1IXPwmvIrgwSGFRz
/lmo3si3l75k4ObuS/+YkmpQwEb/1emx48CRC0EB/TmSNO8MOPdCpGzjH/njwz/Rq3Y4HZRk5WRm
sOx1ipCv/qJbItsBG2dV3tgzcxZ3GFw5KLBck0nNZQ3w6jOMTEzvR9pwxby0gqHzob6vTnMng8ht
2u2vmYiIfMe2vjewpCFXS0W6yls1lv7evz1wueN6dQcd2o49Sx37UYRuI7IrZuQuXK+LTNuXA+vt
WzrKntaBFgoUu8s6xsvFOFkBlR7jCcw7hIxq5LsJDp2hjNUEJ7nOOxuAj2eRNMvHc6ad+Kaprqv3
O/0j9+7WUB3QAu0ZPHNORWyC56sEQRy50kte9v1toC2s38v07xEXiwZmGsCZGEWYmbb6aGJvkryw
EU1Up5MtiQgaaMp4TsoNZzSgMqdJOgODSm6zOR3Cz5wo/azRhr3ozX/3jzjziQzfThdk