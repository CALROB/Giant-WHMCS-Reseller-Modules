<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs3t9txLHfnnf4ooNSiSKGMYXvZieSFNGPMy54aaFWylyrt6IKY7Y5S+lgMkzxxNbzX2Vgri
XE8AM2H7LJAx1J2tL+3ulqQGqPkjaHtT9PcfDO4Q5TWzpQ1LM9qBJg2+PLUhde2Yul+Qn0lxR+zS
0uZWJQB7oBtFEfMAwybz3COXpX5CGtmj1DnFEC3N40LY9XVTV1k+vrsPMgJrLp2OwddPuAiWoINN
eh9SdhN1GbSlVeG4KAK6g7kK8Hso8F36UQYXmmq14RMXzztLDX2mueuRIz4N+grcQzOETSMvNyNg
1ZxR34juIW/2yf6Q+IKSzNup2jsdcvEAZ4ZklC15aOH2j0j+ofnecMzhh+s3Frxywbxw/tZGGl7z
aesLc0qecH9sM5KZuMHX6nCTQAXYv6Jz5pPqGRfXLYxdSKSfwUMjUYpNbOx9Ovx1MglQ4dLJ1uk+
pvHeAG+S8NouwC2mTauF9XkjRoF0rNmKLZQcbfhyZfef3+z+d8KPj9jAJhnDM2DHwcaBZvo2N1YX
WbrtU90WuoScPvjSmgYr4zO6EmpYOjkTYD8l4VguM4JnWMju5ikHSJqasckgDARZvyWcqbZJTyvW
oNfBUJdhe6oXbJ9Z8IXUopa3GoW76s2sYUdk/JI/3EF5IcrxPOWf81k50wYxHxrIeZGr+Xr/QSfz
EbxbdHaM6MbkXhk0YZlZbcIJgsu7YhtdwA/drs5DOifBQYNPoA0+bnRfhjdGRO0JCN5oSu/RAwZQ
akrTHKc0arMcRuirnBGhwij5TWxqPAadsqf/lta23D6pwrbzJe54R5Md1dCEiZ59bzqIZIdcvMZu
YKxCX8KNizKooD3nE/mrOOKrZvTSXVETL0Fm8qC94oqboRYfrIDJAn/zvoC2J5qYZXt8qNXv4Lff
pG2VpG0onD0K1Hh/rDh+oMU+YWV8ZWpyk57VHydZLUYdDuIwAPMbZNFqULJtKSQjmYYcpd5Z/Y3U
V9OFxKK/v/b5EO3O8ZWxGduiOIlr5BfxSHRhemCQKlvj1qbsegLZvcHCqo0STTA3z+b5lTcFnSyR
BzmUQfEpkAcBuRrLE3rdh41ion4Zz2uP8vlPQ8MDCmr8nxURxN7exRDWGzeZ1rM7uqeIX7EhK8hC
mHPyKz5JlTotXXTqJUFO83PqqQaqK6+DovFXnfkFhERBuKWOt4sUsWOW0uo+f3wIt/qjFL8xBkxl
qokkjUpVQXV2bg8XZYK11KhnmzLTlHWgNz5vqWxNnIxvTGfOKrpuFqfDBljvkAz+Y04b0JsfmsXZ
Fm==