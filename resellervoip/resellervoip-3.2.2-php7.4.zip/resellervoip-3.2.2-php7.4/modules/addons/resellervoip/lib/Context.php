<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+JRFj0gCeFdDs2hyoiP8pPnuQ9x089frSjoGj1eGIwrP1jWV1QD7noYmfsR3hzvQbJXQbAB
EVVvzxX0pTcbZwTXM1COCbaLFqsNRxBjfT6kTzcNjH/DnZcyon84TFvCADiBaCbxpJ5m+YFLYyFG
IQNKTXGZNrYVc3SjnMW2tQ4u7XDKbAIkV3escIkQqX8H2q4gvUC+tesZINunIO8XnccxDWX31dsp
Dg6rjVEnsx4k31TXS+nUm7LVauj5LTpt1y0HZm4Ab1qNjQ7ttTKs4B3YZXjBqHVwhITdG0DR5YMF
TeSFSFjkwMyX/rDNpGKVP+vdBiS0m0hDsJlCdnaZiDrbJrE8+r809vRaDVhFVsdyalPmJtiA3QUI
Nff0eWGB8uslmkGJDGZzGhYzfTgT4lMwO+noF/GuITTP+kAjNHx7mskoVMpwfN4A+CwSs6/gQ2NH
7Zg+CNRnTOTgDj8gDJUtQ6kFHAjhqQE2E7kwSPJE86c5gbcbJkMySUjuxhufkKdR5F/t1/eZYeJF
eRHmJoEU7Y4BCmALn5YDoQnCRxXm80cXgGfroJdZ9Fu4/f0W7THjAAcfkuW19Ox3i5tH7i+AycMG
nHnTRbME1X8Vg7IHGAn+5BKChBC0zgx2QHISKnquNQmzb0yGmoBzTcEYbrxMa+9iUrvqZ6BNR4qO
/bpcuysWv1sftg46DSfJJ1umn6uF1qcjBbVo5OnbxwWzqmRCWDBSUjkXNaBkUCzhhXN7dBWT0wyq
FimRGs8n7NhH4TYkN3SxOWjSeItDI+CWwemzSPTjFlS5B/yaGuc0SEZaZNdzjGT8PfmZXlmaXC2b
HCFDYmMY1qVCycAMcYrJM4DPVglIyhcVMFudNuHeI7+oxxpOGIPKMlLbN2Tuis/JlfFHx7fpE6/h
V0q2Xn0WMNUXg2uqvY3T8I0MCR80IuWncgclSuOrZD9zuDT2wuUrCW8k+dJKDz9N8xfHCIsYFljM
ttdoaDrQ9e9u8G7T16e450uQyzpMYBeELh/nsaGI7XaVUdUhoApjeO3RPh9EyAEF0DSq4wgUOJPB
AIP18WeiCeHgCk+QJ0vxSthudHyijVVnj6xa71GG/i2qmX6ol+X+drlg9xX0bgE/i8K4x9lAoxfq
k5vFkeBDXCGfLrpIRfJoxkuwpeKVMJH5YTDPvtC6tKC52iKTHg30cViZEitDNTIca2lYayWG/pFB
3Ew6Bxv1vB638IBT5GquM8rXmKXVh24JyEEiWPnu2WWg/3DgvIwIdAeoNhFN