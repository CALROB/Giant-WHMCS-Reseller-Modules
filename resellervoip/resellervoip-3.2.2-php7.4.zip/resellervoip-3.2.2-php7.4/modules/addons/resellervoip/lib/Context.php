<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqBbsPhBC2BTbbvCkQuoGFO6MUei7qnmCggyXpgjJ0967K/PwW6TqFhBVzIBgK1lKo4udUoV
OKld0bjp8WnZjHgLdnZW6roeq2prIYcTVLQs5F/B5TLRHsCLV50EuZ0HHq+yp8cKD7b2LsBHY3xr
9QVyBBlVzR8lLxSIcO+TtuF93NmIlbC5zTjKJsxwwlCZ3hzkvSMP8kYdXx5vsqLJPN4efXfEl3IQ
UrB+bj3WiRJe0Y4VtVoyNJd7E/0jfRL4CvoEQ4b/2itrJlD2DkkYZswM+FDOv64RQsPcGiPp9+/B
SfaaRUvlQF/0+d8ZNggCd8HvN/+Sj8vGpCRobCC+/XGm/GoYMaWTBjhoJHzA7h7mbaW7FXFTIwjp
j4JcIWHvgh9BhqGMbKV4jqSeZWwDZVe2W4JJzw/Qc2UHybocSx78Mig90GTnLw5tweOMUhPwCCHn
zVHszjOOcVymfSqhYi68L28BNYLgv0e4WKCEXWwg81Tbg/f1Nc8S6fwxwn0b7VZ6kIhqCP516fak
mF8jSOq/mpQe3YNaZzeDPR0hba9TI/AW7jnnVci6kHohOc3y2T5MrtQOtIdam1n3APPD9TxvySVx
0caZvxBjQjKKtPMr2OPuSce7trrMBd7e1oJ5QLqIvQ1M2MqQhUwK3SzVVQnIRxiDY2zyTiVMo+Fl
djO9y/CGjk+BSrkvyy7mzusS4wTggBZyM0MXXi1Q+VD9rKeiP8NzThfEk/0bdQV4PFfuTB/Srub2
o/tg2EewE1LrnOGY4Mk4uYsBbsi0wqmzos9fb8I3Tc8W/XC4y2EZ7+0HZkhj4H9pfmVokdEr3QUm
KpdUXH4RtJOCX66JrYzY703DA8LTnK9kM9o+bLwXx25IFlyPXAb7cbu1KMiUxwYvkdFOys0j5+1A
1f2BkNsvAtvboFWCBwxeEXqJXqykeHVo8K/jYpy/Azc8cGLBrlCZ5/FxJXJ4dDnZ9i8HPuLLFSDO
ik+y11OKS18RoaR4jLnRnvHDN58Bb2FaPstL5ohyVDPZ6nmWOSxi04sD4TxLasGZ91dMuOn5Pnda
zxiJP4jrOCuXQc8IiHy3BYCnRw1Q90J8uEIaAbuo0D6Ukdv7XZt8NGB92cJ+ndat/bBr/xCE0O4t
/68icCUSrAPZ4umfmOAoXqle6GJR1a5Ee1PiFHlQY89ag0Ox1BmqKJfLdoPoaaWQdrQGptn2YSoN
Pg3Xjaqoasc6RSLaa9nYkMmhH0Lgl66rmRBUaeHVHCqix/SE5B8bM0SO