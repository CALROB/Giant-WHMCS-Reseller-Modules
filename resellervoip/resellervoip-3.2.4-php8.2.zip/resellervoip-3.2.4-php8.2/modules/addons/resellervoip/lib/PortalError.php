<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPszIGZNulhOwWUJN5ZqGZx07zdAlB2q5SgQy9hNIqM7LJSuIN+MacxaUvuo24cSp/k2qdglc
PUWnO2PReSfQiFG4Zlw4a+BTsPmundonctEcd7sF24Iv6Ln5Ss49FWGuZ7Qq8wV4W+fo/9LtkWV+
TVmfFsL+AY/GlNxV07O7Bxrz862gr0le83ISGag0SFFz5QAJaY5c+tMS8A8Xn8UlMBYtwHaHXAqY
5/00skd9Lg+JMqotisKKxQckvouAMOf4MIwo2G5bSZjql2hTV5WrYE2rw6jF1NQTQTjZjrT3fzv+
RdDGVX4D61e0H8TCrknEne2huo+gwVbtZ1CS5YQxES/E49WS1+GbjaoRgsOeTKOvkr3KIhMtLrJD
SRK+sflZwKSU5rLnoOBwAvsAZCH+AeGF4zNkgdS2g5Oa4NIqtWdWFKZ6/9KFk/e2YhlY0Pwss0Vo
2W9JCRq7kTLCPd70VHC8m75sUHoQar5wnVT9njKV7w1QWRdzKZu43dxRZGzDZZLI/d8CeHxkWFUv
HeUf4jNie08Z9/Y2mMN52mPvl079VE9pS6QD3ziayIZMscWd1nd4+gvHyYO1hVJQvtsp6RJ5wav1
l0zcWQBsqapP8tLE86M619FmlSXBSGXkyhXyD27HTjSguQ3PmIT9/sBusZsJVTJZgLjDbArgLGtP
ZT8k3xvcGIFubxtCHIUXZx9OQjjw9yToggBHWyRjKKOrcK3I/3Tx1XxeonF3XWjM9oTcTBNHJO6a
uUykp1Tfxt2ZpL2UnqljNLr3b0LpzpkxV88zMtklWyVA18vj21gV45dFtul+32BmqBKMXa69pg+e
7vj9dfkKEsMPK+Iu/cC1JUYGJlfpLKy7wyOMle7x2hAAQ+o6eqmDKjZxD1NQgc52lIZ5dzIc1QXC
ZuLOHhvRldF4zv9FsD6TzuG4xKQEyOGjsCfLlds44DplstwNsskiwDyAjF/C8aKgQZaxBHWa5Sj0
W2nZywezq1D6HbmxX2QGCT+9pTWu2RfYeKL8vdhwIAy+CuF8ojbL32Ga68kqUUezLRqVfButLVme
XR5oiZRWZUfyzuQKXlcSkIWwdBKNXsEBfO2acH9T+nFFOsXCk6X2yWllayk0BVJIGr+nx5Q0zTGc
mffaiipigHCxU8BqFdLab70FU8Z8FuX87zFZQhFKARBeCE1U9NO9pImbYGaLRBf1pcIlpAseNk7K
CZdBrbVoUFMhIJPKTgHU8sNT/A86SxeZ9jzHjC3Zbb2tVO22BcgQS18RWgWki+oxaco+5nDkQjlJ
EKiEeaXjiQXP86BcklzP1XaxhKOT3lh1TqdZxgWCPWCPtEpqaouxkqV7oTYYLcOe5YInHynHKPtV
y3/GhTuksyp0pZr646SO6LEBakiRkpJbbsn4l8jrAGqsx6uZ3/uEgw9oIrT67eB26PuWeWllS5lW
Zmz5hEbKBjnBbxkt/9lf0Yv+jtNTA/fO7V+55zTJPRKFjmQMHpcOkgs5oOzVRyKkep4/aWETMChe
za6GUQdvlkgvWFCDlw4KtZi3BdttqEubTT+kJgMkm8ZEscJACDiv8SIMTxCGxvMDvluHpgRKBOAV
jZlQhujowtJgpjKtLvpTp3OqRqqZQzemfpVj/7kYVg6ocOarpOsSDdkBmDUMCsMaC7aBv1uater1
mEAZ+nXtVIreubj3MsAHpSBJEnKUFN1jRPnz4jXk2pg/mapf4TwKnlaNPJNK/BisJA5Fqr3ZCYvM
vIUzKs0HCnSP8sXqWC5g77dLhPWGl/geyRcUnrt1XR7dSm9tJvVu8Pi/t+cK16TgHEU1vNrkvHs3
tGSm88XGsJJaS77CgJwtpQLTL7TA+ni40n/VDHrYUxREYLeFbQyuXDzXk4g9pBAuh2nhBGn9zFZe
10sQ4OHB/+b6+SppwYUOd/0PWEPoGOo6l1fkV3cHoIpnOu7IeQ2QnXntIrAtTpCAwDf9vVhGcc7W
lYG5LZuNZmwAs03td5OgR4hl+JPi2Q/xprCAVZXsVOvKeRj4/O1CIcZIN0Q1T2/MlKpr65kW+2ts
PQymA7vytXPLVlrmd5eH4HOe3MKSIXe+HFTd5IemY48iE3rqk52pqCr6rgFSLm5NnmiA9O6VmDPr
SbTzrwb/gy+T91giHZ9NWMtkelgUP52YshkSiJlzGwXQ2DY983L0Mk0pOh2tFvR5Y9PlEBo4lfdq
1uAjJSTqXdZD5yf34JGrX45xdA/ddQBWpU4NMLWe1NAVdsqcJ/kMrmJ9L9ky2pUpHpCTAaact5XM
Y9cOSuxR5hC9pySeYXpYVcmgxHLEa9qcDsWQ4ShMFa3SZTh+X/Uqfp7Hjit/jZtuWOS=