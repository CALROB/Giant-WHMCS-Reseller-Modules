<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtzvoDEOtZ3aOSDTyEZbibpCHCQPyoO/PDEddEAYS/lYP0nshgX0Tk8etKZ+nWAkgBvqXLYx
sLkqGfl9VTE+wVO705Ee3lIbr/KM287R54Cj2jprUOw3eEXep1TiUEScVgxgq3LTcBbgcS4luKVb
adjO5jHz9TDQnCCXjr8at2wL2AGWRnFzlmOYzGxms37eeOvEcb/Xhf9/BMaUTlFCi3vOI03rBMB6
JdTFcFwjEGI1EGx4UlDImvEs5LElL17I+co55EDQvrSxTBmgtNnODOZWjUXhJmLsNN6d2aeEktWM
TI6cq88H3JR/oe2ljcjZ++HOvaJv32tTrx0SMNVEA9pf24fXuXiz6rO7ilEJ9jyo4pPDuD3VL4NN
25Kn7vT5wlGs26LD5NFSivEIfFgWI72VDQFwS40/FJKozdh+RBIIOVUmirbTJRwlrmxvKIhklKcb
5snNXoI7pheZShIfKX/nebrDraCUhrGMb5oHlbt2Av5cDN0B2ggNIbLa42VZDAoVRNPMC0wcg82G
35SCkftoneNavZU8fdaWJ9dS88GN+xd74No+4fRt7UMb3Qjp1CJgkWcMLHRsETT37de7vepkn/ad
QGWDPDR1R6k9WES+sZR24w3MQL48vqHBMq2MJgWmVGKxM5Up2/yikhLzN04Sb7m7nbqHP5PedQkl
HLdxta6Zj4imbU4AcI14BLBq8cjKSyrrlYUujqAfe8GAVIe9esFRQvv/NPslgXSdMHpHHBmlbtZ6
uynx/Gr2wwhixi+7jkd35Lub7lmO8wg6iq2KegtlJ25zxi5N3TygLAIXcn3zBA2ix+yxinPpU/E7
8WIxQzWZfXry0641h4Qr6JKFZfz2qgOzu8Z4rmJxkOKTlSoIxoJDvQ2aSxOV1b1IA3vx1I+zkxKd
9Cqo5O7Cm+OZ3eH6CwW4HXfVo5ENb0y4Thba7XYmCT1dwLnh9RssBPstAwD5GKY5G0Ohi2yKQgZy
j6Ira/3a7t9NV4WkEp6r9zHTIn9rY0Nc/3O1eIQkTeZI2di/OMI+PkHG2EogtTIL1di4QjfQZC6A
P4iIo8e1DpfvSmawc7INXwM285X9t7Zotp/D0gStDcgeHZIJejkWVQJZlKf8FoaYeUWXLCC6GfX+
Qs0O4vblP9hthCIyOIp/o8fxsSYo32+FB0==