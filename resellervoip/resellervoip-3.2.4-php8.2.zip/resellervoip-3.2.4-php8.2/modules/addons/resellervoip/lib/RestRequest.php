<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv6k1slMZlnCgnIIIAIRHRiMf/d3V2EFXgAymR9wESXURYBTA8FhaBysah8gy7S2RICodr5n
+5GBd2G0iWPlk47CuxBNSk78hjwS3Qrmu6UdOhRUiMMlrpNv7ybLyALHmIUxQ/hVW6m3rcJ+bMln
CxWaFUlFP8S4u++Zgwdlhph3ZBBfrZxfdxmlXfYHc9f+iaH29vw5oR3K205U7wTqm0r78pL0IucC
FwrLGVJ1ffD0hXVbigOLXKJ27PVQzS7eDhrWs2rsEJjql2hTV5WrYE2rw6jF1NPdS8Qoh5T2BBPQ
J6rG/XCDKmizpt5TvQUJqFZtnfFcDuyCcFHGrudA4ZlttN9/G35Jkw/tUDf4xl7zdQV1L1c2rxHj
UcHUUwCG2HlM+zVAISjjuan6HOJ4m707zWYMCa/VAYLBSWxvqDY025d2QEKCBMV86Se0XrNNlKVn
E0C4w8lZ2inNmnHIcy7kWahyJgqaQUOm40wnP083k+A2r4lH7YHBHjnx5/QdD1VTrr/oN9U7LMFY
ZVMLtL9MgjlZaxKzhuEcwugi6Qifq0/QbuPw1HDi68lZEuP4gzXd+S5GT7vpPh6BnhKgNJB4VXTe
cRuoRViXTyTW+z5SAZDKOZqRh8NdRDgDWjJ2W/eP4X78nyOSDdoSTI0OdUS0qeA+YxfvtO5Gemv+
CIJk3a2m+6uwLp1ep0nilJBJ4kfsXlly28Hc6+/5Grf4btZFaMAJ/VK/7q9ErK4TR3RovNTKS6lE
lWr8L2hw7NXin9T1RasfeiR8ybG4uer0tSnZtyJ9PbI6XyWeK0QFbtyIqsRjam0fz8XoEE3NZLOJ
7pAy4ZIBYcqcldKHYTwezTY2uRAkb5x2qzZqx6IOWWfXW1aWsVbqNXDB7knA+mZK7PHvmQ/vR3Wt
5v3Tnh9zBZvFGcAJUrfdGXQIN6hqnB4+XyKxz2r0r0/A5t/M/MpKI8TY4WUsbkQ7WitqMqIykWCs
470JqqbNgPMzsTHIWnPfzLUO1uBa5n0uEWyIP/fCUWEUQMIBqHN3dH/O3DbAnCkc9ysOCOUkp4I7
IYkjEU0UCfbN4JQRskyatIkdrsVIiZhy7wH8po4Ekdl2a63VNVZX8w0XRGvxrGQdfX5Z3woWBKIi
fsjdAd1QP94nzry/flE8Ecd77c1K/DvvR3zExyPC7Q5xusDJC2HcZSl1J8X8CzYugC//yf350FAv
TL83S0==