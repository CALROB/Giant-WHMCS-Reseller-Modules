<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmKddfKWyMBQEPqBjjcQF/dWix41cTlxJkSWYRInWpgUSfZh77AB7jP2w7zRfb7PAOvZl0Fb
1wlyc2Jh3t4RD8eL59LBYiJaJaNRTzuHmY2GE8mfgcjAvfgsFlKjn//MIMp7HZqOOXV/SBVnLeHv
3Ocyus6LNR0D4e+9HkbguYqlSx7kxB3DV0ed6+PNY66gZs4kbijLhqu4CzwW83Vw9G+4hfPw5F96
a7YeBs0J8ON/Df7H8H95nE/r8aJ79xT/wZIckz+nLeLPJRxp4HXuxiK9U6dwC8qSOiP0SMiobgB4
wewcIywnmNeiBKAU9ltQshd4NY07Hmrvd2FHmP05KjvGwFtzuDPoQIQDaB8bYhWWiGDgXrZ4d61X
4OJfeTk+xzJE8j4ibLg7P6U66RBOpYQ45T8/mhcGeZPDXpySQB1JsxOKSWNrLmYSgE5N8wTDCPtd
UhApYIuZsxWT7ZQ1bZI/S59DziFa/HuZfxcMAtJbyj7cvElQY1LGGDVV7Y1MhmVKYKN1DDjNGy62
CbLWGjNEon4DzcboMumwc2rRHFhpCgTgIZgP0TmKa5WsTwxvUoo47xql46hqrBWb2uztrnxTh/Lt
y6TZKVj+q8MZNSrN8hfMKqUte5P8SG1mRgyl+ERxgt6NZGkSZxa+FXqG2/zows4AzI7fGNPHvODW
qVgGOj0jfMtr1ISihqVaaU+1embB4nBSLa2PYCeXa14Yb2KnYwZ3UcRoyFMTpl9MHcfBRJdjtvUp
hDuM02rsqF7gAsghfYIG6/P1u3Wckj1VgN0N+mHkG3+1zmzr6RnNWV2fUit03n4noc96ZRDKQ4TV
d1Ej+NND4LtfvvC6Uq2wwryOpXDM5bIJ64t07R0NWdYz8gp83jcPhPXt/+YGtt9iAPGVNu7l07Y7
R/PdlKRt1/n4Ehp/Tgm1l98DlrWmDHVPQY6q8E9sU4HN85qYxkbZ/E5p49U6jGtGlmpcxVZJxUpt
LlbREjg8jJaRSxzM3tqGc3erig0zojARAVheGUC6A0XlHWQOpkzdKHek/z7noFjP8O0hKLyHga9u
XKDSJFLzjtcXEKfmE8+vWrq9mdA7cggoQpWmlBMgQH61kIEVjf8oGhgCfWLf1kXWwaOgBGLbHXXR
cDYnFlnamxIe3A9dnPpGdlsRWBDntAzekgA7m4Lt7X4NewvtaqbD5cK/XyAgYOns6x9IZxlekbrD
RI8=