<?php //0032b
// Giant Reseller Phone System addon 3.2.4 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuYbTAp4Sqs4bH/XZ/knkcDHlE/zw5UcGucyPe18vI8Z9vCABFG7VZBucpS5vdv04qrfc7oK
BQ0mjJsx0HGjcbmIrs/j5PEkRYsG2lmCmiUxxMFPatfr7LFUmOhg76GGsdyzPXteH80z1UC+zjoS
84SjliObl5ce2mzbxz3iqW8FqXekKno1knRveYJvmKE3BuxbpP54BBnKVdEjcKn2uYcmsoskRwNP
46EN9+pJQGjF+3T0v9K8GIZBguQqDevhDXVqcS/TvVCH67ZknGbuQVemZHnYna1eQ6loVqRRygQz
EOpPVJ8jIVzmmARfIgW79q9yurXBL5d/gXjbgpf/oz1ZbO+fCOLHi/lEC4mfzTltD2ae3NspktS6
fDu8xhv9iYxqW9N9u3rQuVu3x6LxgICplZbONdGLYNyIlvaneIMCZZjxcrod5rfjcjLQ0GMjI/Yo
2XfCjmmraVkl117erAKSRf+RdtqwkVGD/fLBXyJo9DTIPAj6MBPX4ZkA/sCQ9BZPfkCNYA1VROtj
1aXetlnyaPAcvGmQGSOryzKDw7VFP1dRCBXYfmjQZ7/RLe0ApsE1wZqc+41HFtY3uNZ4iPiFtLmR
ltiXCMEcQ1ls1/jxXKxXhqLOGz3bK+kJdBxuDkePnhGTzWz3/yigNzYBGooTCTpn8tDwtHMZmKM0
dcK4YhdtoBZUnVkOYWIZE8ZGdH5umKmjUo2QpMT+qMNPrRfSRiF3y2XFXwerWFUft4T7DFLlT4rc
Vscj/J91uwglDcol69uO3JFbx0uHoQSNfzC4nRo3yHh6MAolv6IgvAQzjYyBvAnJcaGSfIcG/xis
Lvt+xYMW7q11kix/odsQ8O4UeLmvY2NWSwWVmpfiImd3AtG9Mj5+MnpEAWx+9CAwgAhXZnqcOCpo
CSskDnANoLKKRwyRayORT0qXzz3nv8RoKXYVZplJbnvbNopZFkPBIMVvlWs9lyj7yMDOXjurOPuU
O2R/Bm8iJn8tW+eo5m+R3Y2QTbQcVEIjylIPeLz8UUcic6APYJkfBQLl7Lj3dHmLoBjeCEnTT4kO
DlsTT8JXyf8K9aKu6fdEcE9f4iHrme9u1c3UeP1V4jaqokoYKeEqf18dmFS3TKfpfUC7E2tH6XDp
LZOJE/Vm/MtQm6TQDXG/iErAiIxEgREfkJyDn0==