<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmYhEr+TSu2GN1wkVEwmjFISEw5BmJUHySoijhRovBWGPAlZ3ff4+a9SVEyOwDVJ+bnDdMza
eHDUCPE+t3VXVilvSNASMQaClI4b8Ltm3nxW2F9/2CR+A+VRQfM/D1zDrqpoD3A1NwmE/vHHZqLP
pTFVf6P+x6AUihPD7it8eQsG/E82syCkK1GzRyPLKTrETbRA4kbkbNE4ViA+NI0rxgTWvdfDSMRA
gM7NFbJ+bIBPI8OiiBhpyPbWP1hI5Y5cZ6CJ6lEjBR0FAMnjQtYCmv0ted4WrkKnIs+g8VfEkZIY
0PFpjcib3Np/Flh0rfARre9cd0tb1SBzDCB+NlFgTBJJZAM2w49iG9tjix7lpnkpHpzgwawdOP1x
YU6APX49iWa6GjUwJfSA04iZ2Zr/+BqKxrgOMwpWdaQJw0wR+P+ybHT7yiqk/BNUtrVokTK8jvQ/
+k3lxWXfksqu0wrPsv+TjfgbTtRbs5KspBmerSZmgIMyecAXZcoM3v4+yOPLR4WZ78KtFMi1NeUI
Kegh/ucNcVsJ3ahZE8pj6znu9Wa7HZZXUJZ7Ilc4q3S9Fk9LhLV+m015dsny0RABwoSprSAMtauE
YnKOXP4ube/6IkxlGVtuXIoa0YgfdHPyRrpAIdXOdjv93HSIOsQ5YunhYCE3LjfisHlNgB012rRF
SZBhCMrlsTKTR0nlj3uKJoTmIxhrEQ+iJxGiQTXalTM3olyUxx6AgCctVm7IWbsXYxBz9y1svAvF
oIOP/4S0wLcPCdg5W3dc9E1bd1fzorMBm+w3UGkO2wbJ7B8np3MUhMhaHkvBtol2PeZJOyIbNy21
LsqMG34HFxzkLpjAdR1CtA2QqXw5DjX/J3rWpnlLeU7jNf6E3/PPsfvN5CVCCg4xTpkhy66qr7Bv
UtYEOjZdSShnWGbC7aBoaFLPvQcGtGWJbawYHi+O+16bSlfolJLg5+wsLfv47qKkEGmKOOcY6whA
DF61IddRgJkTeduaWaIZTYetKxMvu6sLfJunUTkWFUggWWPgn80FXkKb6gNBxK4r31R6CKE7kJb7
udn6P+gAdeiUVtkN6pRmOST0JiHdgbEdZ2MxGDB45qyDV5z3qwTE++dr7YBM0zicl9BHtWOmZlck
zCWeCFiKt+pJI47GKsB447i8uiVNSYs7aT9DNdU4+tbyQR6qEhgvy8gdvlNvGpw1d4bfbOp1qH5r
WF9cKroX9FJd9FpL3xjp38tEAdDdhO5PNkuXYqj1e0cvSEMmOgkcXh/RR2HKyIfHUU0gCyEwDXYG
qiDp46QQrQADs5FQgIMiBojRbJ6f0bNfQ2UO3Hl0CPWKikfntwThaECk3tt/vLle7lNbU+AaogwT
imoGpty/8dR1k+WhlIIr87u3sDkDc5fLOQWSmjG+Se7jhGjENJRoOgxf7NxNCM487IjCK3/PTsPQ
tZlH8+SOJck/Zl3MV6LT8NQ3ftKfvmYrvkb1oOGicURCpU80TmVm2+7OPeqSvToKDRZdoWS6tMZ1
K9HscoluZO63nliE8KIpXjM6C+zPHFFUrevRhu5b0kVYG3DZmtVV3UrmkHe8brP0aHUUFnJnQc0p
dNxUKfFFrkAV7S7gHEcoSIduMlTBUDtRRbB5RgrfDG0A2tsXY4YOAia7D3D1Bic/ng1hJ1mlM0w1
I8cWhDLfzPz9BHYPo5Aa4Jv6Hvk9zPeCYKSqCkaBgT8OiZJisitpHmkP8+bXViO9uoeWYvNwe6d6
4C+n5mFWCBj1lzuj5lAX7A/AuWJJPv5/OS1ozv8KaWjNobNbPoVsgZW33PLuH9Qf1SaG4jXPBmj0
VLZ6zJikozmAI0COmuovq/MffICuJPqernWNRz/FHXVrc8II3lsavv/2ji5/w1I+H+ObxUcUqtWE
w34jdGgy7vx/ofGBC/jo6ElBY4SFGiBrffNm8VR5p4PbZjcDuhqDBmGAUh9x9FzTcGkRrEGSj7so
fXJR6cumUu2xObugUWrWVfs9HNdS2pvScAEUv+B0bnTYYhPihJTYxpQHhLyIjLDGEjGDK8R7wC8r
IOXsEy/wmsCkffVYckp1So1TMmVLV5RnEa+VDML6qmilOYGZaK1nUeyqR+/0dWdzBNkxHQhInm==