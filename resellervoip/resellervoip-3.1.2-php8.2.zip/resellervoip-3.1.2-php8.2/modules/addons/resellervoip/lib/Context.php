<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz9QOBauibY/mU3rckYRGuIvbSmFH2S3fyq+n4ie5dPkUPrF12IFvC1Dz2u8hIHDExGn7vJt
eHKTWgXcRbSI7Xs51gYNktOrCt84stGORSjQhs6g53P7uVtnRIx/K4yAWkPltO3gtB9N7UyNph52
ilvD73/6J3gal6LMJFAwm2BwlToLl+O3izlHYjnywv+La4FMfC33/BQTEMivOJc2X+I14l+w/nXP
MBUy1+CM/SVGKCI+UiGqSAaQ4ZCR+/die/0Rc/yMUIYM3obiRMjuZCEGDw9n8DRbCT5jQ5sXel6p
7Xq4sGxn7Wqd5lwJcon9BJQpzEnZyuKoR/N2OtZeFq+7850aSeNZ/qivIb8Ag4PG7IGncc8Gf0Oj
wMDTN1KMY07Oxqr4Nv7laAGcmyWzbvuPLZOQ/pfAZNQR9XMZOHzclf4nEJFpQY5I62nlbmcm2qgG
JAs+gfW79IgT3xh7bLNGqRbJP/OA9msAfrgmxc/jSBDB19PqTfwMyOcTVl4fppUOnvCLeouAy0Ig
KkgMtk/epo61laxrJMnvXMkasosYW6HFPhDUy3Y7VGP/unOztk6lboyQoeFMjS+eBxJUj0xht1J9
oDJQX27sneU0IHUiOVl2CL5vIKJ9IadrXmvztltbLobL9NFzz1G9nfODS48pfUECP3uNHybF8dgd
bZSnous/g81l6QTk7RJLUoUBDv+CvSxkxXnBE997dLO3EK+IhbL3WeKTE7yQ3aGj89zRfigQvbpM
M+eYJqr2jcnpbvMG7NvIiQdc5hBNYKx0J8XszJE1kLxJOXfpt7x0PkTqdP16agrq2+XdkI/Wy4jY
4W3JHno0LAMOKAGBoXGIGXLMjG3f7pat4z9p1AaegaP+zl2107eBbXu8cwq4bLc5AqxFxlWVRD8U
ahcIMed15LylIoPSQf+ekT/5PR78GPKkfRE2hb/QFpJ24WzlCBWosBJ5Qu7Poxb33yMW476h654R
6yIYW/CY13LeEywxkHpeaX0iK8DS4Nn/2WLL+9ZNVSKq8MBJHqR8KzDtjjb8gqKJVccvhbmQKoyG
bVofPOPeustlqNE+WMaO8IJSaTuz9cq2rQKwIj8fprkv+Md+QWIOParlNKt/x9Kiale32InZOtua
JHsizLmYD43zxtg07AW1xDEe1JxNUAtrU06v3wbRsAfHeZuqjr0=