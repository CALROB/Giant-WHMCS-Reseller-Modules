<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvArg2dGWn4EgGyz2WKdlXRr72VEH/0l4D9CjaIkbsv217H11ZT665rgmX86Xeiki0ETY5Dq
ZHJfif5F8lT6I/K+/+i7VCtxdavPf5wHv3+yzb5kxQoLPyDksYH7zofd/28KlUU0NyTGQcKDkv5n
0xw39nsWoimCHU055LTZ557sDpH4h27BLM7PCzO2c3ygD1fekO+IWB8Yx8MnUwzWXTYEGogy2ITa
HbuRTQGP9Hqz7cUZIOxO8Ctm1oA2EF9Epk351YNuXWhk3OiFAMnjQtYCmv0ted4WrkKnt60Q36m0
wM9IatNINkyc3Ht/HEN4nHTyu77gbDw+AE3ZZxwP6/De3tYtZv9Hh/2sJX3lYIs5hmCTBmUyWho7
eLZHQ/evx1WL7QC3vSrtmFLaGXN2ag2iqy32Kgz3ih1Xcv7cBLB1arqz0fgKJi71+3M4x+shHLXo
w2BT1qgRLZ9iBsHwrB7yxu+msZGPASM7/N3ixPp7RpzyLexp6GVYKLFCZCLeV2ElZuUCHolSLLXM
wngLQmjWmSqX3R7gnVzSvrEVxV2jkR1MTci+fnSINsGpd/OcZxS/eVU8ktfICPerbaBR0yyXQvJO
dbHG1gk7v/Opn6gYBE57A6XnZhy82nUC8KSmCuYJsGBOtd9v+pGvG53SnXSIJYyLtbjJYEMACB9q
TPELP7070kpjPcEkzGfLlBjo92VxK8B9OYbD1IITDZ03CAtr1j9R7HBVXdlttB/DXnpIZtDWzVGR
KHPbrkORBO2OQPkilGyHY8Yv9An8ouKxnow5zCvjessI3rTqFVbinciQ9gS3rq6LwXGXIqHd4weG
0cLQM1D9vyq4CJek/qlrH2uQIMK9yXmj6wmUJFVP0WHmO+bjyZ/cAC7godFvEKGZCoKvllIOlM2N
UQzoAMCR04I8Pz000GoJov5XDua4nizbFWrmlRM3f+i10dvUAUU8wk/V4QCb/akK8Pmd8ucKNXBC
edrKNaRSzdh9wofSBtPP2Lz+c0kCBgU4v7NrZ9mkB0w51BUsr51IQKT93zu10KYHj0L7Ook5Y8kO
3QUcWj7YWGmSxDMU788pnNCvsrHIdf2yNBoRp8eaiEG0/3Ha7i+ftds/leSxtnK7Ug3ZXUmLJMaU
gX6+TMDzE7g/PTPsvS1s34OPIvWHLqSH1zLESmuNKesCEauss4Wzx1Pv3ZsHlGOI/Zyc1NMCHodl
gbO+OCi=