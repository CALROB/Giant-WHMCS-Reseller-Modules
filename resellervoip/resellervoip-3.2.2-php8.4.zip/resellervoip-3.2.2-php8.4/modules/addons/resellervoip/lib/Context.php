<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzyhP9OO3LtQuP7njPA9waNuolZzB38kPeMyPpWvA2GZWdvDtNlu4AKFTDHe1tC5y5BsQ+7W
t0mLzACed2PgAwVTolZ5P0qq7D/ox8DaZjRzlMddGnNAJv/kRLIlsVt6JrRSBdDDj7RLjGivJMta
RnLfkDrpulVslB/5GGngwVZNNJfIYfjUH6Yi+jTCTRnkZQWK0Q4cJy9TjBVsoFcvJkRDIJ2MJr0l
MfmZOeZ5reWid1S0VdRepWfC99Imka/zbCVDzh2CVG4p3TuOdoVLzG+4RYs9NupMRtnqAtgi9HYL
AOZU1SsiShqq+Kzyi33/KKxeAT/g3+WECLakBjz62J/LssiW0LL7S5u1xQIJP3yu6f+Phj4iRPWc
/niBEVBfo1baTi/obsDfJojsDpVdftD7wJxawneGSpgs+FVZJ8vQ+QGbIrliIFrSsJPpNSwdh1a8
2hSpD0DC0eOiXQBEsBFtLZfL3nYLYoC6+wXY7i2zyw3YCel2ywAR8QpDYjHWvX19jVoFpZB1n/wq
HDRGVTqI3hxXrUkz8drzPcs4KgYL4BDHKlkIvqK5D6rWSYE5BNOARZ3TUworM4P1yPQlJJ0l7kVu
r4tc/CSVyCj9aAnOYdivP2t2cbfItnuSRkMUH9CfEyUtyZkGt2jsJARgtDnB/uW1kvVUEfFyBz25
TEu0wY5qCZxbrH2A2XIwFZrocm5TD3iC0fEdTlwDMQOFd6Zdnznw6wmrLNtLnC7tAXg+0nO40Cwq
gvel4PN6zjeXnQfD0jq7pRBkg+FkdlrXW3Wg1zVrDpYnV85OY6JklCbzvUyHWsKaOuz5xGCC0/ej
E3gwX4QRgP4W12dX2k2CYc2MwNpO9qE+qsZDoWmusOZofDuPaRxXCh9q7F3/cTpTltD/nI3Dw3ON
mcuHlQKkaFptl7+qblJtSpY4CI8M58fzM0zG6rf5r14ABghQPfnGi3sMEBgmQsUb7zabMRRUy0k5
S/QFYKVzeggv2Qa7uQ7a+cY5fiqB5Vafuttj6/43bkXWckxqL/AVjbMLGMf+FauFWx77pjqBDvhQ
KlF3PkJyl/g2bMrvadVWhPit+4iAyxJdoYuQwOdvUZKLNyESJQNlr2w2il0l0Nju2Cfx1u5C0ojB
AzPHqLz1xWnG2JT3QX/Zy7tWMkx8n5SlZKSrFSMai+B3mU0kKeYSKWky5MWcQEdRdSElVRDSLGG+
