<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPydt7FzCwK7byF1DYTojVf/ry1OqxUTdlBIyAv62XECLVWDBvWJt1fQW/crgrLxm/rP6Q53c
zFGunDCVTGtpj9Kfpj7wgo1lESqDSaYl/NIch8+WkDq/0LyvnWGgOjAg8nbamyivR7r45KvTmI4S
wFmtZ4+UK9/l5Gw1VoIhRzcbwdaUckFNBAULP/d7qWN3JPYfgusaG4LZ5QZL9eOFkJ/Ih1xUG2SY
HvGn3rtd9Zrs4emS8VJ6b7Swv//vFXdRiCMdgvukkmz+jGYF6xaDTPKaJvnFR+bmRIXayQtDgnce
xeUe2cvDOHjStkRS+p5cbeaF2s4EReIB1pC74aWIMre8k+M1cJvVX3g+O+ESfbJNIR/+Ui9KEg4v
LLZnX9IuqUcyLOsmcY3UAMyqXLKuW+5jxIUyX/TTTrAZXX7ynGzxsPs7Qv+ZjbtgORDX6HUPM5uC
GPcpHcc8xF/9dbVrBB4xXGRvG5QUlLmhFq6YROt6OGhocQYfQqQ/dKtjw3zFwSIjTVSv2fLnR6W0
ev9cfcpl8qgtZfp5UrVkbey6n2dWL5dZe7flI+/MR7MxTZLIeMNjMgY1olTzL7Iet+8USyotmoeu
01UB1Nrix5b8rmef5y8ioCiFiy2il8Fw8kHiwT9zpzIeQDt91fKGjoo8Z4zcMV9AdchpOaYhtxHi
bKAt+9pP67mfedeO5yuxWVlRxbMcN7WR85srI6ZwlrKO1i6mvnSeqT0CCpBAD5CnvZy3czEH40Qi
DPe6J1WgGqA9bYA+iH5lv74SEuauXf1nfJNXjk+LJBmqdR97pKkBhgqs7ngi2E+mVWoQYR7cFXsM
o5hR36a9qOw219FyYuySR7ENNgqqY15YVmDbgaHfSDNAeJrLNEk7eACf7wCA6Ybfr2/QvxpoJzXV
yQF3QPSAkNyaZQkKdcL0DGP5Pl6rh0NDQv8p8y5NgP7L7ltRBhnsalA7IqQUFuiiL2J9dGqXP0iK
dPld+v5pP77A6tTm//sPpIs9yZ1vC9ny7PansGL5OWkmZ0XKfbRmCZzZosWO6ygcIwFyFkdPwU2O
zGJ7eQy4hNrIurDJwFglQK++p/7R+ocFAKoq636JobliXt/friw7UXixwRI7y2oBqHO47xHkAod1
qMEJcFQjz47ji+Ly/R0FnCRZ02GnFcgiyJBNH90A3WuwTRNwEecXAruB9NjHTOxo0GcSWxoQAwPw
3ocp250SwW==