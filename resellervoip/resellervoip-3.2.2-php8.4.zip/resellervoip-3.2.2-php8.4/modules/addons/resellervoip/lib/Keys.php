<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt01hY/Rwn80fhSx31OXEs6yKSSE/GUSafoyvSdpSbZ+QcuueWfHxYBH+881MrreX74FScw1
MFQh/HpX67A59PDRO4wa/pSu/DJPdViL6bgZgpSC+7XcfGv3AUp9AHLNO9ZVPnW3orQ1j8FQnP82
pKXlZw294XmcYf+LaRP+kWPe8BdbJVxvWja4t1yjXvaOc6zXfJYQLjDGpES7S2D+DAQiWKUJPcSM
rmBY33rYymyb/4TFRkiHLYvj5SxvjXN1+fpUqfUYum4p3TuOdoVLzG+4RYs9NupLPKcXELXTDey6
iu7k0T2i3FzuS+Xl0cOwrtSBp/Ha9JukscPYPQMk8UQhqVHxSnbUxckP6BMI/TdmQXKeqBrpQvJr
9WfUaSRvgrGTWNVArQAQ3DG3OEfKxjZN3YvBwvFyhVxuVe1DEuoTOJQw539C8qkAOXrWbsziscIn
zdH2fkVZ4IpU0gBbeab7/zC5979dA1tDutowPecfKh/1hHHoC+ib+negmSKUjwSErGtNrgrlWpur
4OUIy3Z7CiLIpDQHWo09GQ8fivf+dj4u3XBSJ1UiAdFXt+kc15nE66i4Xw/g2AaEC4ZF+lJ54McK
veZ75U8dSTd/xIMRzYDh35T54mzUYIZ6ua/lP/jJ9eo6Yn94/s50CfvIu88upsh1qURCT57ntaFo
PyqnFxEZyXpuwUggoaqWtuPX13VmCuMyvpubgf5WwBZRXeaNrMxHZtdTrjcSY6jHhC5O+9kV0n1H
jHFrTIsyYR31uwrP6lwQ4rRdbIjEECMaRFR/iw/IbJjftVAUxB8xTamfJRxR1M2AaiSCGaXo5PjX
aO8no6l95SrhKPx4/BHcySljBtzri8+zlxSYceOPoER+Lfd2Nlifb1KWhdAbOKGbxEwisPhphDkM
r/UOshJIQ+0cUdKo3uO1NNtNiLNaYImT/6ebYhJowCOBATcl09diC1S9i2z6Ek6s8VJPGXONAyJ8
SO2aG6Msx42+SjbUdBYTWH4qOUz3bzXH3ionOs8FfXVJPonvx55J8MXXIufHVCHzOkWYxMjFkvss
shrkx7t2P7E5WAQHXZQodithcTFTmBvpjiSMPS4l8jxcWjsPKcwg0Eedk/0CZfTuiXhvUfE5ds5J
IDEWpzGOx8Bpe1I/0EmpQWVAqJWT/vl38lhwBWWjecHlrflJrIiWeclK0Mz8N9yo1V+q+Wgbbhr7
G6rS/9mwlGzSYq0qsPFifsLdY7+KZMuFKPuCZ829L41nEzWHXEHDztJfR33QFVpn8ZVGu4lvWmz4
jyKuSg695TQ4oGaK1W0JOONzww60s7ybL39cUeMOXs8/Fs3flTKe677qqLr270PIRbMdAZZ4BtIj
0W9cE8wdN01YJ02A04gJqjA6ycC4tcgUbsTXndelFMg+qHau/wTtpVdpUAIacM5UbJyzIaaKIcUT
n2Xo/42r8QjYau3EEOjmAeGuTOYlr+Zl2DkqChqFVUgKYLKRbBDB1fWeD8rbPnfj6Xt2nX1aQYqJ
aSej6YkPJ6Q7vk+oCBeUTWZyWunztkxkhpzwycgOgG2db5VH6vsq1HmgcRwNGLn0xie82wyGZnhB
mgjz47UTeeU/y+ADbs1inIl2eesimQ2yCqbusMD9udexrYTm9CilVE1nvLPizv7MKbns0ag4y79i
cgRJQLV/hgcawFtpzFDC/ydOvYdxJ9H0chEcgDZG8dqGGp2hSK0S0NE5ZiI+eQwGOMyX8DB0Nu46
YXN2UnHEwLli6DgIePbYLgu2FWXZM1M69a9Wg6u1Y3bzIFsu204YKVRjT5xes84PBWhzB3J+dqQE
EZFB+XD36hCFr15fNV6g3yA6sxqM54ZYkbijaTGXh7v2auoAfOuYEn+qDYuDJHjAuaWHgsIzqX+L
QJNbr8CbGD/C6wp+S4PkpeTGsPz/NP4c+rZdoJ17HCrTky8Kvj+ZRMNNlRTCvozORIeY7JeKPHzh
RCrrxMQs5vaCqOFE4uMTZ61f3kVlOFIqZGEiH6SuNwNizBOeY5aEd+ajtoQy7wz6dg5KJOA8QOsd
jUEBCAp1OFj4Zsd8TXtvgd1Qm0XETlbR/a7Iqu8ooTI0ByIYtUZJUE8vdTwp44JswqKWwqxGc+f4
9CQth/8fFopktyHYhv/GmCvUANNRGqisOqsXGT4gfxxKjvdVj7Mn/HnaenX0ykH9tUVuWaGXDLmL
ocGqFUG+G4SSqMfcGKKIe0iqo0FUhsFUUq0mvvAKf8cJtAAF3EGF/qrcSJBx5SN7CyY+Tqb96iTh
rNNUSDox1kuBHG==