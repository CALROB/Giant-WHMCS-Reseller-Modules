<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+cCHztPLRmIe3dI/j1gO4z/11WxcY4laBsyaZ/B+Wn3lGNbx1Sc9s3zAK3EmTMxlxg5PLJs
7aC/0knW+k0o0tT2SS4SkaI1xbx/+o0zkcwlfDNXen0lWDu9s137Fd2mL9FyPE2ZMB5JSpGaJBkt
FyDBfvxGSH4AvCY26oxE8523PPXiCsE+TYvv3NaS69SUG/WxqO8u18Bv48XL4hU+OtEQg/1Teqbb
0UpQ+U0k+Oi/OYYremmKkVBIXcyZP9GvUp/nNSVKUWz+jGYF6xaDTPKaJvnFR+dNPznnsN/Ru+yI
a7aGZ6rDVl+fvZITDegXiS6sTBS++9qK/e0Rhu0lb+Y45hvVilZkOzhVIxaLRCqTo/v3+hec7tn2
R+W7aMjgfTyPbTvoRiGdaMF60R1gqPMeapSUlSnzlIYM61Z1Xqj95jKMrNQu4kNIFy72RZfUoPug
l69kJmhzGkDnSsO3kTsTzxrZnxJ/K3ZVYwrzP6TTKrTrslT3zBlKx+1nHIDBPlP+L900OPmZ3Cxj
QKfQLB19vjpfBCaA8Iv+JfUuwG/ouluBWn2GfdG0DC9h109hai2U7hgfqDzpMzKYZp+HmHNWVdBJ
Dy6OWeSDh96SPdl/Em5SO2Pl0dR/lEtBPQO4wCH0iiZakU1qZiBGJvBbN+wpo2MZ5+rgAW5PY+1c
TyCCJoSgVDZDrWJ8jAhgOtIlOX2qXBhTnbucJgcFz0iqzhYethdXQu/HuJK5RYDhVxR2vAXFuLOA
HEaqdgwkzDsxcYw5Q6JzNMEF3ikeqaF3tyFF+HfVQBl0cXtunqYEKsiM6jo8y5T0091tkmcFxNWT
7ZZJoNQllhMKeKWSg2yUmqKWpuqY3DtRnwhH/H8La7r+gEVxvpF1TuWsErFAb6ZZOQSVKM1sloU2
eaUlokvFYRETQbbT1iSDUUIISCg3yZsXvD1s93sYzdfGcqzZ3IIhDmaCm1kZ3DNntcbFMf/RHmq3
nbxHsn9aLCMoYq7ZR3tgHQZTJHYk+u+4XvROhfDKSozE9L2q2fzDhG84sSW11DjhLpNpCTEMOaBV
9jm+qaccFn6B8ByMLs4zwgN8amZGAFT5yS4zUEAa6je97HfXw7bqVAa7M8LoSGVZ4rXlWRGmQ4ti
Q44FA+SMrIa7bhBiERQnBj95t+BQlzowkhw8RwtKApVw4HftfbotgWHqZMYpBypXNiMY/Q83OorU
+8zJGlCBVYtLBQPqHR6YCqc/BbKdXsly7Aq3pw9q7DNGIWPnuQV3Sb8vkWLU0ucEygBfEaUqGZaV
YiWjDjOo+04js3Zq6yfbGVwKuMYVdSbf596XyNzQ60n2TuLWrq8IYT8nWkeQIYfkUlH2l/rfyWX+
eL/q1vI/QVi47nnWMqXDbkKQrPCl3ZIv6pgF2p5D1UYAwaJKu8ujcwRLV9pxmNQhGMuzOeVxyz0H
2K782ds4XO8r9AS4bcsQPcaPOMC0BQvF8nMbXIPiq47Fq54ggstqASA2ghIkkOm7A2VIFtxrn/Kp
9yDmdas/BYshhSd1Gc6J10D/00+ZI5HhFw00FlgZCEtfXsFd2/ilQ6Koj4a3AA126sgbykKK/0A3
0Tip0lwR4ePkQ2QbMkv5bL6dE135T9fvtWEu1xD8s+WdP/pUurJ++BP4TtK5SFdfqNZTz/Gaf5OY
OfuSjnvsA/+Rx9YkvbH4hlKOom5Te16OcHHwELE2qe9V9oOf6776TxfWrExeXkxxcprpd5JXckKX
wQWFMZ8PfEdn7/ZOJkSbPyl/aGdJnE2fVX0lOGRxGwmeKMzdICuETTIb17gCa4B45tYfqbmAEf6V
9k3BHlRl4moxVcxIqtGL0Ah73RhznoUvyC8APN0DETjmwNzF8N6AG5TSymjETw2ndKxN9B1nAsRv
4UWHVU3e1twDaXsTpN9UX/o+JnOMJSWLQefz5kTsPAnKZR+pKumQl6pmyaXXNZvluw6rLeV7DYeh
dKGVeMbCf3Jaz7deNoMTT5VS8MejHkGBMF71kfVV02o2kRkfrUlWAzMeY5VHFlsn/tYBz452s1Ov
C0IOFYwwCGjlAl2TGV6sxRZnE3BUlTqu4SsmWThS4M+e3JI/DTnWq+EtHMzDw6ZAaId62e5E+u8z
4ceufvQ3j1EiCM0=