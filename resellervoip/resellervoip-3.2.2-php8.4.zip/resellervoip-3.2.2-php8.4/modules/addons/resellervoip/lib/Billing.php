<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyvzFz/xseCGXiYg/FF8/F0rWY4MG5xU3vMy+RpfXrsUD6U3opYqOCCTI/QgEfo55yb27dhf
rMND5R3MVo/cvFqJf092ppXSX/WSOM3bANl9QPTCWY1dKih20uWdzmbxtQ1P3C70igmIfSgxUtIo
CG62CrTuufnPxiEkfvouaX2rJzHDbz5cFgK7K8AYHNipZuLjHgHtmYePald1u7IpQN3rgEa/ekr2
2zno8ccSE8BN9OewvqMzr3xoNG0bDP7O33vgnhcl+04p3TuOdoVLzG+4RYs9Nun6RPc4fdyCZZvY
oQ8EWyoiJpuKUB75CDtbSNunoh1tOkFdrE4TTW0+AgBuMLUo6aDbb7XvpCZKIcuw3KmsjCCR7hJ0
fqNR3cIkWk4bKm2odO+qVreAFZwGHLQ/sVUqBRsjxi5wErbTt9Ny8bGgAj5c/nDzQJxK93yEKtyF
7obBAjsy5v7M8vxmJOUJ1dC1fNfCaABFanNlt55MlXkhmS1el03Qzs19bk/fK3DMXVsVxNzbNlbu
oWXs4hhxhS0l9dZnlCdRHC1HK+V76PEB9Ce7Y1xQBbsRBo88NZdSMj0cxEactd2YuEjq979z/agR
KB1NBaOGHPZYAWPvQ/ZCtiMg3cZfPNlfz4gBqwPitrAFTgPVwW3dZgTD2N7NleUfdylpaerUIf6J
b41cnARYCejvqkZzYR70fa8apPt/um1cpweW3joC3fQiiU8qB392p4OMf4zKxI3C/fYpxRnJn4OH
2ZxZRW7BqN2QBU9oGgT9T3/yzivK0jIxjOEYYfgaJ8LVxlY++wp32YlsEA643U3wMCbLYwivViVO
h8EDX3Hg1WEwT+OmPLuv0XGdfoqkfh/EbvV2PLz2YbT38DxGsGfkrU55r39m92JEpZPxy0EgwiGT
aGra/Gxwq7VRW+OaGb/BBv6KVk+YexS/nPilCdeU405V9J+vHeJ4KMwhRqSESKthdAozSwwVYCKc
B8Hk0jzHbNepO2oyFoexLFTJ4ladCHx/IZV6qpNMtOvzYxdzLGtLa15xOI+jk5eV9EHJBkcHwx3c
HukEmQ4mULVSw2YzpwEcrjEC/BuSs3jFj18snk5Fr55f4jo3i+Mh+Fu4GpH8WI4qB8vFOEq5CLuY
ztNg5wDBUNFtqiFToX8HS0gG3OvunpXpiimshe8QP76wXkh9AvpHppD2l4RfkvsAcxD8byL/0yH+
D1UTs2DD+IgOCK5wo3tSfviwYM4cX1ULVMd4gJDbP/HvtX5arefQXKmw8H+PpZv5SKTN8bCr2Nnp
eoaLkCgAiBNEcSP20ceNlLAd4dwj27RUJu7sAbE3A7xtLAwCWLvn4BB7ZzgAZIAnQe2bBFyjdprf
awUFupHG9YSmYq5Hi8vDD7m5HmlDv0CfKoTU1Hef5QCIQDNDSSOlwLbpGibBc+YFMz2XrfNMiTVo
4yIUZ/VcCDdfh/S2wN78PoNPIeZrvKQFzmHEXG0o0AvSBog6jtDEfuPsO3LMuj7Sl/Hny2rPvj2e
LOOkLfGv04Zd5g/ld0TR7e5eblfJijcNCiLyanLOWh34jbAUKrR74QjtwhEri2cfMEhhJzVp8y/1
jBB6B21X76hQW6gfA0QeoMAoovA4cctRztblwGY+ahl077+TeM5ZheroytPceWrsbxLAzoBMer97
X8BjK/NdT9781wbVWyvBLWp3JSok8O8cVxn8ctOUppB58smOtbXI4CeD2HEku+y6zkpo0rbY9I/X
6jwqfd6zTEX5h2kHXh70d/lTkWCq7RznN3rjGHalbeO/+UZWf9srDqFv8D2jTIMCJ2/vszX71FR1
dxGv3xcVd1WIRcf7CLdX0yn8E0FlYmJkcjM9Am2i6SW0do3xEbM6loP/L6vEuxHJpG0jeFtVh588
CA80IPEs8bG6rrOVHgb3pqPys3ZgHTQw3RD2DpkUDYO8bdpMmcuC/koWZIdK0517iCnhxMixMFBI
KR/ip5dGdnXYnW7J+zr1rTyUx9TC5zHK2UzjKfuP3XrCTkL3ecH45sAezuIv7Z2SqEdd0rSZIrG+
EtrNIIrCCNLnH/gHGQGrkVZjm+YtQc1EZntILFQwHAJuFUVCuWsG5PO3IW/XE8EvN11Y5DixmeFR
O+n0pykw8AXiX0==