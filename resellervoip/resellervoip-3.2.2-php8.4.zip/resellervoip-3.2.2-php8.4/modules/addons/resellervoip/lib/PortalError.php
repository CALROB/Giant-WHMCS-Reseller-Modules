<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsmvXT7q0txcXOyGyYcmrjMgxQitskYoXuYyB9o0B4EKogRslA20njdqHxHm+P9x6KaBbMnu
GdCDvmIQJkiMtAoWuCRxUGnzXwZoqEBuPIjoUrxsy+1oQae3AtTv1e1QVlSxhGA2BwFzdzCmd+O+
z9/4iMVfuNuwBd0d1Bvi2G0qv9ENQOJc6TJ+vcIDme8F23KK0e11w2nn2R57JIYvcpuv1YrR3lt2
N454G9K+tdhxj4QQtXwA1G+cb902Kr1BxXl466dvImz+jGYF6xaDTPKaJvnFR+d0QNgEu72gi76y
N1hWZd9DAVzwttcuIHR3eRHPcnmRTAAzyq8WSRwIgnrB+QglQgOUMc72vVnwayEGWj1IXJPxWeFG
MTRG3klseIvTVdqxEr1doTMwxngVjBdcx9zzlR5+8e0Cpi7Fu4Ut7vNdAnla9oAzEsIHbYHo2wyl
hCH5hCkAsT15zCoUJKbJ9c/7rq/Q3yOUJoObkeeCtDBGgg3EPHyfP/uMYHQKoXh6g6m6i8PRsDUb
5auowLMY/tQioBhqnfvwubc7g7bJOfQKn823rIjXUDigr3czKOZ9JWMto8OYdxAkXAHEXEUTFcxA
Bf/m/HhQmRH8vmK/hBjtR9NVWFljkxfSYm7Pn6AEG7ZltQyV/xg4J8C4JBt8wfhYsT3JElGcfAGR
wrfP5l7v13zMc376bFIPJ0dV2wrbrHm1LqQKeWuZTS8JNOPQ6crmtGz9OfOCal8S2JH7AhMmGztB
slK8uqcBGnil9uz0bfHZU6DsU8B6phSG/1Hos07vcA9VM6o7+FAC/Qpz37Ma3OqHh4uPQ8i65IwE
KD4s9z7OMUxvu80jXaLAa/IIMauVj1alQNJXWExFd8NnpS+++0R/qmd5EY/bgIEE72GIvOT40Elg
YgVvcNovuucaUAOYJkl7075yDoleICp/w90NswWNbgTVMmgWvaVsQIJHAFXRTRSozcF23/MDh1FF
/Tikk+lekW3/mSXVZVRvQ0y1G/QgAlTSqSXM/xk5YU2EUvTlt3W6i7kZwF9OzxIsIN+GyUpCa92r
Fl1pbZJ5X4jvaGHJalTOLvR6caKRTM5WA5IArV43nAmW24VOv0HO6eCXfMwGET4+qTu5cvgwr+Y4
uWWopb4bxfwRyZNA+qSgDPCDeryTiQhuof89JaByJz1a9TaCJd7CwHylAtnSsRktryUUDMAIC0rA
yMP0wTmUqEG3xVcpUD17yy2ULdQ42dMOAPkq7tM16pbRWrwFqXep8tkbfML2wgTQ3Zhdr+8zRXmA
rxOhhqT2SaTwz1HJWmWtshbWN6mxHU2G1rgvPSZqB0j9Br2D3/Y6e2WsIi/rhBKowamAXAb/klQF
jkudz18p8ZH4RxAspLgAxm8Zdcn/Vau2qx/MBD12Li8FsYkPvK2y9j+P+zUYqk0RMAO5RggGBjDt
kkhLvGGhTc61O/qlQB5sijktZcj4obDsQ4lxBD6PD33PmP3l+gR/IlLRvF6Gf+nG03fQvGlzwZsg
EwB1m14SbrGBJzzan/VpgoaaqX0xyEXpjTnzempIlYkuwGZPkj2Zrt4Iz0o9ysmEHPtSntqoVRQ4
9PW/jvOfxoqrrdnZ4bMW+ApY4KNt3Y+SngYMwwMETWdtNNHUAUHV277RyoPRwLQuYDDCZ+OtC5h4
Wuzp5mOuxt7QVfmSJ8Mqpo3Ws1DMnxY7qZ9R+u0GQ95J6vHhrvvsIKIr+OT4j4sPI395mS9X2NV8
2ThRalAoOBK7UAxRm7yJ2qrNCi6spxOnVCjKZJD2tFMSwqPYr9D1Djc/xMYkHgyYz6WIYWLQMv80
JGM6nxGm0DNFVED6wOTbmhX/cceXMGr8I5jXzhJeEaWBES7A/+ZAue5R8FKeoWY6+la6asPiKp4l
szipu8uoPGmiyeTFHgeMDXMwdIY6VrPFifCsSD1EmogJth78c6b5Nzve23HOX3R9Ki9BVtckct6I
dRqJ9C8Ad5tV3obYhX6Uj0SbN1t15ATTXPN+XcJZ+uhXaNVNyJLRgwJEZqdwi1DFPhvip4BWYVOn
m6cTAhumBdzh1pqJYsJWWaC60HNYjZxao6j6sFPmW09h35MesV6PKsbzT+7iK+RB5/QAYs7cga/L
zPjvurC7harKBrgvtPCRPPL43g41uUqnyWCdBHTu+Zj6ID9NO/3gzMCKYRpLUKA0VIrtb7XJPcNq
EHaYDMSno6LxGA5qntVbJ0f6hMDS7uO2jRrvYWcmLfARs7w8wtJ9r1mYeKtQYWQM6B0I90Xsjdx8
4MF7Endyj48kt6uYoPBrN9jZN0Y0pkg3eo0krHGARfVvU+1JFmVNIWZtXf3S5OMFeJM1MRMx2QT2
