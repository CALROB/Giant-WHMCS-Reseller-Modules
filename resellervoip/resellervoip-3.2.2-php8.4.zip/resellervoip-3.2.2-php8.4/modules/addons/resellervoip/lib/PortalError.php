<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn78+8GV4C6hudvjfvn0Wt3efdSpORkYVOQyDB7+Gd4OgQlGjCjmw0ZzAMdGQIHnjqqoBdBF
+KeCCwrmJ8wNHNxc/98o3cPFK4lqbMYkzcPko5XFdyWZBdxMVK4jNEREpipYl+/WG1iRoXZgdMbD
KfvEuPYHvenDGf6TxGecpK3Z4kAVlbQ8IywS7mfNDz92Nl7UlL2R1ckk2HOj01A4uD0l6lYyDYCs
PpYc8F2kKOlujgmqqFq11yF6ygV8xlBmcr7XoOCfBm4p3TuOdoVLzG+4RYs9NumSRAi1G73lAXbz
Hmd+Xj6iEiJZonLYSM+Q/6s4nRxlrKJQKdS0io4LDHT9XKo431UcyWEcFXIWprm+GkahiTXQtEW9
eqkRsv/M6bNiexf+oeHJQfujCBHExdAuG06rNBAkzvGQJOLBIvHebnqxnrDpYsHiyP1MgfHbhpvE
U2zPasek3clkjwi911qVDKi8rOolfTq5zEmD0++CL0q1DbVMGfrr2sjYuYECd2PyZd9vlpBBTN1D
SCa7YXom6w3Bpa5vsZjKKlzWeMmPXn1jEPY+SjroRgAQcaK4EeMirBzWJaPwdMK4cXhwseTjrgQ1
W1Ng2DNJZ8YVzvBbrRm/+/XRvrB6dhFLWRe8yg1rlsjzMFkyexKR/nIaBt6EKL9OdIdhYmeqOJdi
rXHcYTu1eUka55c9GIYKMgyTl43evcWDzAyUULJ4VSU+uTEcITw0SI/R7bJlxounEBs4wa3zgXgR
pb4ZKJvQ9UzaClLxzU8QjVFtMpYst2+NkhBN0bBNgSkKmTeK3qRNB9NZBseO//SXnoflrYObl2BI
9l0CQgn7b4j9DRtmwAQ20u8cW1zOOOJh4OP8Dr378dHwc74H0eE/pqrinwqNvAG8YUFRk67RqYmM
lwknTrC3Jt+oa98Zbb7snF2FCrRSu/EFug/mdv0IX77EC2atVSkBwgbaNhK5kEDQm01eGn8e9LWh
WZGVww4qh0q/eO7NTVv7Lyk/WLx3ZsTQNjGX3YkBCdtUVavDDCFzvF1jqRaZc/u14ssNDNONcCT8
oghpLRPjx9KGGkOD7D8LSm68XFCqGncMs+Ub8Uxw+IGgghNv9xjCW5Vr8ou1ELD2p/cPwauWwC+2
CeGgSYS+BkWEAC0MGUNRDE7rY4NviPITADdR6WAp9lvQnW4rgXB/XYjfX4IuyQu4gTl78yO6U7n9
Kr5TB8sEhbCdrkrQ0yfMIZW95HfC4/NJbhY4tRgTNxjXd9zksBLB3ggLZz8JgcEGJK0mlxjk7GTV
m2bq7yXhIR0gxgpDqhZfdExWkf6Xs2RSnQ3YQcWO/GyPaeFnVXIGQ2//mCRWIYkITlJr1FlnhLUy
OmT6pIcv+yQ1z35tKpw9PQsU8RPDskzaqgxrnDFvqOTZL1c3/xKQDWr9Qgaa/IElc5kI6hSpufjQ
1uVz30fb7zJGjMqG0+as2sQ+ZlHBm6+DxBIICFX3QscC634026AYsCfpM3dOHjcAB2cdzxSxDd7B
o7xGyx9GIo5KRTOY8uO+kza2U0Ay0yPYLmjSI4BzdWhw/jkpFGAOPgaHJiXFtqEm80lNFP8NJP9X
MC7zlsMK+fzRYM1QXsf/HVUwvDdr0eUoXPTBE9uwysIK+l8bquXpDh5Rmp76YfCp/FuzOsykJ8U2
VuY+7GXdzYHcFjx9QF+kHdta/gOMLm/N6lHZRvbBmU/AhlNc838HDVbuCS3lBeATEIQXpx5vx3Pa
YJKFPXdQPcWxmBtWcsj4A+s8aw2r6O23GYID8yY2GOQR99wWjBepf6k0c+PUUWjopYuIXe/J8Oyj
ylKAknbxmtwn8OtX/GDxo6k5faumgVb4aa0lwdpGVkF5lbjOTY0dsg7KHiAEEEXMqcHTNM4bhqDz
+O0Hc5QbTD/WnGci9crkb9zNyFizyZiNnV/3N0hKkxKbHLJbquwBJGRxdSEGYmjX/87nljSg2JXD
nI/8LJR+qfMtcqj3brceALNN02sJQAtSA2rgAlpwjAaP9Af5Big1OPqzuwVUQOeWHu+fuUhZcU+N
AHE+iKSIXBv0G9na91tHdsv7sSqRGZiWBZN8N0tBBd6wW1V9We1NK17cSpGz/IaaNhkKJ7HDWl/+
56kWdRh60QZ8TyCEC4bTtVP1A/i3RlJZgIDFW2ztDaU1bDuZ9B6vo5g7mL8pKmENvORH9Kx+dxH3
s5/yqBU8vVplvobYijMDLJv3VWv1Fph+YUMbmnPD85L5uoDLPT+aAuxkKgstrZEncMmJd5nhyaWM
6POOz9442TBWzpwVNH3gUQNI2yueVWEeJXs7Tg9lIZOeSb0kXbdRDaSeicBpvZq=