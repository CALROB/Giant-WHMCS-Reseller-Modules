<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzkg/Ha5TiPUr1neEiRY8PcZKiuG/IAOHl0NWI4kB7qqQBUEOx+vloJ3fDMuX1sCtSs6fFCQ
aQte+nx53lpMnz9ri7IIlAUqNvIojJD39oAtOta5IwS9Vm3RhrTinHRzS3xIjJybkoNhBLXP3M3n
XLrWgdTqavBxw8Z/2Y0O+QSOk3KIRDtsY9ty0qkKsRMGQYNqn9a/+X0LZ2bknKjrThZM0IUTGObt
gwty88k3KJP2lN6J1zh79NgeyoeFEhkcS4LEEw4gKueFVhK8Znkv3NML94+SJs/fi6cxADDyXXt2
wyV6A0zjJKtdZohHvybitFWsl1drZYQrJcln7xu5r8f0SCN6Vb5nfsn8w0MLmKROogY6Nb8122z+
M0QwJqLXhb5FwrxFAL6/BEJqRE76iaoXNc+kQqsQ0t15OpKwm84exo4/9NBbii/S2brjplZ+hETr
xxlQg5pRcGN00xVBD2i23HYvI5Z8HDQ5RBTCKo4CD2qQAeNlh5gGpdtFKbaq4/mRknTIxFOnXwoY
s7GTgbAMLwEvO8iNPUxOE7TfQNs9d1YqgFjFsxgT5UrGliAnobfiVqXjAdkwub2QQVPL6Wf8ilqm
+JtKO7+t6eia220SZRHH5oMgijsJjxy4JZKzMPww2zQSRtMaJ8xVFl/Wye58C3NL4ZwhwVOn75xV
rDeo97aGSE/tgB371KKmvIFBdx8VTGH6jz3AfYCMWNflKt0qSzDOVcE38inE1MQQcKgMnNZkr2Fs
IMaMMqIsu3vJyanhopJWc+V1OvCgqEjAh17nLn/SOeQIw5812UMDmMtmER9wcD5xm+IjUjh9zdIT
j7Ai/LdCGBkdrf9ARmP8gKlmCBl86zQnlNjDvbeT4utvdrIOJCJx/Xfc74GVSGM/yLAXnEqRIoZZ
LvWqsQpMbnrh+4g8PT4hf3H/cpNwNO7pmV0ssK3WGMIvFPiMKxYsmjeWyLub5tpYrhcqURc1bTnb
fHEyRVvwym01CEPm8ojr2J8ZSeXX03EGSIWAO9R28JrKyfWE2XD8ckvnXZeiwtzja71T0k0FdP5i
s7QUrLfydYLGpqeQwYi9PvDjda31wCI2y1qJn1iskSIIGqnEkEZYbTyRq5y08YV3pa8TBj/O712q
BZiDmHuuHLkWHJ9Br0PEqZHa+obdIYPD/EtLsk7hKQYYejUuR8NTV8wK/1m9QLBlVxDlwUVDhXDO
5chk3uwaEQkHfmtpxsrXxMcze6YfT46PYWT7VffVyE5UN614l8a1stgvU/8KPTVBPBbeT0TbA5eE
f9N3cmFC8gFJX3MpGx8E7moTaH2HYUF7Zl40H7yM22Lmmv+suFx4+Av8jAKh3Kx/h/w+DY0Lixt+
NefO+q58Zw1yjic8Gzr4+E/zjMqpz7UG+LbxVByK46d1HFBy55cnXnjro33PJ2HkBRA/CFkIWpYh
RtOgKPEu95ZiYrHZMT4TJc3auwl1+Q7ctucQksCrgPOakPNYrx05FlU8xtY+2MXdsO45cUFROpQz
vkXdWDQOJ0brCSEBK5Pnk2OvatW4fhkx/VvLjKZh+//XJI9s9OkAcVkLt3wq7Qn7JPY9XOXb41Gw
2UWS7f+A4/+inTGfKIUfHQDg/GMx/DN/KESOcAFuw+qggd6OacfNZwvPHTllmgKXCs4RhI4I9PoK
OgbQlWO67vMYDAKA4vRTXs1F3VzVb4SQdDUZ3ZH4wXlEiDHiEp9APuP6V+BD4K/FVsuiBI0vmNJ3
8g1pb1RoQBWLJlId/u71ko6kAy2c2g76uX5WXWTKWfL4u9mYa7T6q/XwBTvXyYXCTHgbu+QyXDOw
hEE4YssdpQ++C0FZW6P72dO2WqKUxFuvSYjx2+sbMFEZz69f8rfBxB9hvR+8kBWG6dNeks5O6Ydi
rTKXqQEWXIFtzglqAopWaRSBt+LMy+Yopa0i90foUU1sCkjO4bGWRDsEU5aRQy9FuzB39efy9WcH
Nnj01nZQQI2oz8LO+XcO2BGXuoz8nQiXMz9vM6daWvAJk0XBJVRkNqXXc3ktRoOhTP1SJtMHtd6p
1YNOY2CYt5Y2EfzRxRi1PEvHulKatFun/E5bodULRHHYAKfO5csEtMh05Xh5SXq9RH8wL79CX+Ws
PL6sAMFwcLWbqhIQDtyBGszbGEdYq7oaV643hBoN8AjbC7W1bXrO/+RZUsrGRLjzIwzKPOj/2uds
OPPF3Lq6sx2+C+uzZTaxlFZe/WFA631zh2awM80ox3Tk0re+C0sLiJ/v6azbEVtq9RuDrGxh9le5
fVdwWR8NCkN6XZqs+4r+JzbqfD2f7ioCYT7LcMSf8PyxGPslneCEa67f622cd12ArZl8/3P+4oxf
6cwsRGcsfaCctree7KymECYHFHQqRdPzZuzMeXoXbNQ0oBCOwujNpbRFsHw0OBFwgHg43TnZLfV2
fZjH+iIkK5713dcvE6ihkqJwAH7l7AxacTGrl+gPOF0oEyJxMHrOQ1W5Bt2078p+wyY18Ve4IxVs
igubC//C48HrLxwJ/TMGW5iwxUqTrIDWtMl78GF2Q9q+IOEpxqEDIm==