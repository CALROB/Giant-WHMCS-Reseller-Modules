<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzy7a6GLqMXBvBq5HpUlqq2Up8VoaNXmvT8YQULvkw2d7tf66zCLFhITaKxHWOA9jO2ZZSka
yzsvwMErQDeDd3/Xi29AYBThWTJ+yvcBrzuCliAq0+BS6azGNia98t9opIvsiem//Scn8zRQauAl
XXYs6w36Kjrg6rn7kXwWteIFmT/zebQdSZ74EHCa0mLes3TqDSXOtuqYGf0DGqbYhvOdfnNGFZOC
d5CiEZ/543SROBcsw/4Qw3WtgwxQQXljptk6FQPiFId60JCDtXYV9zNr3uHkBObVZ4DhgS66/9PC
wojOKNQ4eqjI/xweRWlcaQf57KO2iu1JqvHdLLBQ08Z1cvRPS8OfvfJTDAIBD6I5VEV9YI98XVKD
cXtj0GfkVbGgdozt+vfSmnWAr4A7dbHNhHLETBzj2f802q1l9sCHYMKHUNA5KYhEunHwxWU5emw+
2XWfSlAz4B3g9/stJKVWjvtBRhcR1bo5W8+lxIb7JVL6DrLWqeq/NUcQ0CpB28Wrln75VFiT+qlh
oDIDWy5+JHyZCWa+VJ9Isk8CYPSG8ub7PJv3B/8Mm7nNj2rQKMkj6GVcqngK7Hub28xDPL7e5aNe
HB04r2D0RiK7yXFocdBgVv6JR9vLA3Wp61m4kkwSi6voeDsJe27/2zkpSX3dFoTmubyQOHYwm3Jx
v/JmBrz0qTvAZtF1JZ9byCV7GvM+CNuP+saxSQKrl5qLYr67cibNH7wyPWi77hUYojfFE860G1uO
XkCeehdidiC47G91EUBftCnrCeJw2SWKsD7Cl9Lx01fWg0IOmyfzagoDJCSZPZVgLNfjPxC0oh66
jW6ilsvZ2lTBSvBRaMNguzgkU6CH7A+IEdC1QqfeJhuNH6I+mfcwmgtwfpu9DI6iKODqNbQgA4NZ
vCiDSo4kQUjYyqf4ut/hMlhqUbm6ZqlXvwFdFeujlS+zN2CW0emd/X3L1kSsAJZ7CKk88eWWoy/d
FI7p7iNIBUXoVA0ZxMzldSEwSVPB9wdtKMjVCJIUa55MNSyETIaswU9yrn9vdcWYMZ3ZYYzpmfQH
hEGj0PpQX/OjKeDPyoUJd1WIAKFfVr7jXwwqaJabEoNlJbO8MMSb+MVeND3rGGlY1lRoG26zWkAc
emMQ6IHkPuCapWXfj/y4RONgKBrOjbW+XzoNn2bkHA9dqWf7lKjmQ3Y+5qLlclRetcFx8XyAGlz+
hkP1dDG=