<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrjB1zsJhFiIRl6I/ZziqXotwxnOs6XiZRwy41Or1LNLRpIXIQu4pCARcuFJSgK/qoDgJkuX
mnoC1gMfea58wDNDyqfWm8V+05NRXRd0lp9QESCIIXelhya6qFiLRqTIyDXjWzOoVv/akO9QrIi4
t3W7oXMwprAfhoo7BtOn1sgcWt0IGh99CMHw3NUBp/Bn7Y91SwIjj9rcKMtictQt13R89+FJxLfG
ML5ajQprS0/udvlDNVAe3U4vb1XdGkhEEOBfR2FKdmz+jGYF6xaDTPKaJvnFR+dlQLGEkXRty2iL
LD+WZ4GC2l/otxGz7PWoN6OOMHy+Pi2B6bcyj8CPEc859ZSIm6qf1KObN4wDMTgh3yMXyr1e9s5j
72MO6A4W3+2/WcndZp1ZU0bDxypcSlkCnl1dZZ7sTk5sC+8+glLF+qp+cxMfGEUromuIooA8Ke4h
i0MSGd+GxUf+ZkeNob9Ov2yAvbtJPKuVywClzRJjOCtgEaCfo1fGqvMDMvBPCb1ATT67gdaazCBA
MNbcvJa6txFq5JCU+BDst9SlLqFddst22xtoDQVSZiU88IVr9b1OU1f6JOLdrJSU++9WsCTwh+cf
zOvGoFoUyN7ppCpNv4yf1SEuoQ7uNhSlEBqNT1oqTVmBP5SS/wdjo5tvr/wCQkxnL+1rZ3IO6zat
ba1c/VQ3B7wPlbcgvCibUHZWB0cMs6PLKJ4Gn4gsyP5wlh7Pp+QXOqF/VxZkT1YmOJYnRPvUovK0
0nfe60alQCRaYU0Ziiv81lD9BhZcvDncG+MY0BUu7v75qdcRTcBIwW7/Ymfx9u3ta1hlTs0hm0aH
xD4NdDHKTA6NzDbqh9ctNLxjkXKaMMmdFRoUXL1xl3jFVp8m7WkLqo+60oDXmBxKKMnEE/UWPiJf
Ea52Z20abbImTme8rdJRm/BlltzEgxzQPVlSfRnl5AV1LItfWKAc/WVs2BVcYT+9XZw51aGHSwUq
eo5fgzjtd0qIbTcwx0IY8ct4uaSnFURi0tgBZGenFUUc1+HDqc8szFu4qZCroPNLI1rrdQQqp75M
jDdfWyHMmsevJjb005A0fHYAhmtHbMuoYCcU7R2AZa2SzSMHacXHiljalYx6miJGOHN/GrtoYtCB
zPJ9CdUb1prk6Hi7n3sAusMpfnEhRJCdcBpAh4AvG7TN+4c89+n4a1KUdXtwL9Q767nXAiWUkSKb
jksgyx7depXS+WO=