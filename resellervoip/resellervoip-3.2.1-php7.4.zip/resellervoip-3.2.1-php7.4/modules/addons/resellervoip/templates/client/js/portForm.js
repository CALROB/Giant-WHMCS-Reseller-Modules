// Tax wording for prices shown on the page, from the reseller's WHMCS settings (pbxConfig.taxSuffix: "ex VAT", "inc. VAT" or nothing).
if (typeof window.rvTax !== "function") { window.rvTax = function () { return (window.pbxConfig && pbxConfig.taxSuffix) ? " " + pbxConfig.taxSuffix : ""; }; }
var currentPage = 1;
var lastPage = 4;
$("#nextButton").attr('disabled', 'disabled');
$("#prevButton").hide();
$("#submitButton").hide();
$(".formPage").hide();
$("#formPage" + currentPage).show();

// ===== Guided stepper: reflect the current page + allow jumping back =====
function updatePortStepper() {
    $('.giant-step').each(function () {
        var s = parseInt($(this).attr('data-step'), 10);
        $(this).toggleClass('is-active', s === currentPage);
        $(this).toggleClass('is-done', s < currentPage);
    });
    // Once the signature page is visible, size its canvas correctly (no-op until
    // then, and only acts once). Defined later in this file — hoisted.
    if (typeof ensureSignatureSized === 'function') { ensureSignatureSized(); }
}
updatePortStepper();

$(document).off('click.giantStep', '.giant-port-form .giant-step');
$(document).on('click.giantStep', '.giant-port-form .giant-step', function () {
    var s = parseInt($(this).attr('data-step'), 10);
    if (!s || s >= currentPage) { return; }   // only jump back to completed steps
    currentPage = s;
    if (currentPage == 1) { $("#prevButton").hide(); } else { $("#prevButton").show(); }
    if (currentPage == lastPage) { $("#nextButton").hide(); $("#submitButton").show(); }
    else { $("#nextButton").show(); $("#submitButton").hide(); }
    $(".formPage").hide();
    $("#formPage" + currentPage).show();
    updatePortStepper();
});


// ===== UK bank holidays — ports can't complete on a bank holiday, so pull
// the gov.uk list (cached server-side) and block those dates in the port-date
// picker. Fetched as soon as the form opens, so it's ready by the time the
// customer reaches page 4. Keyed 'YYYY-MM-DD' => holiday name (for the tooltip).
var giantBankHolidaySet = {};
$.ajax({
    type: 'post',
    dataType: 'json',
    data: { pbxAction: 'getUkBankHolidays' },   // default region = all UK feeds
    success: function (resp) {
        if (!resp || !resp.ok || !resp.dates) return;
        for (var i = 0; i < resp.dates.length; i++) {
            var hd = resp.dates[i];
            if (hd && hd.date) {
                giantBankHolidaySet[hd.date] = hd.title || 'Bank holiday';
            }
        }
        // If the picker is already on screen, redraw so the holidays grey out.
        try {
            if (window._giantPortFp && typeof window._giantPortFp.redraw === 'function') {
                window._giantPortFp.redraw();
            }
        } catch (e) {}
    }
});

// flatpickr `disable` predicate: return true to BLOCK the day. Ports are
// working-day only, so weekends and any UK bank holiday are unselectable.
function giantPortDateIsBlocked(date) {
    var day = date.getDay();
    if (day === 0 || day === 6) { return true; }
    var key = date.getFullYear() + '-' +
        ('0' + (date.getMonth() + 1)).slice(-2) + '-' +
        ('0' + date.getDate()).slice(-2);
    return !!giantBankHolidaySet[key];
}

// Format a port charge (e.g. "12" or "12.5") as "£12.00".
function giantFmtPortPrice(v) {
    var n = parseFloat(v);
    return isNaN(n) ? ('£' + (v || '12')) : ('£' + n.toFixed(2));
}

// Every number this request ports: the MBN plus each extra row marked "Port".
// Retained and dropped numbers aren't charged. The server prices the list.
function giantPortedNumbers() {
    var list = [$.trim($("#mbnInput").val() || '')];
    $("[name='numberNumber[]']").each(function () {
        var $row   = $(this).closest('.row');
        var action = $row.find("[name='numberAction[]']").val();
        var value  = $.trim($(this).val() || '');
        if (value && action === 'port') { list.push(value); }
    });
    return list.filter(function (v) { return v !== ''; });
}

// "Total to pay" line for the last page: the total, and how it's made up
// when more than one number is charged.
function giantPortCostSummaryHtml(resp) {
    var esc   = function (s) { return $('<span>').text(s == null ? '' : String(s)).html(); };
    var count = parseInt(resp.count, 10) || 1;
    var items = resp.charges || [];
    var detail = '';
    if (count > 1) {
        var first = items.length ? parseFloat(items[0].charge) : NaN;
        var same  = !isNaN(first) && items.every(function (c) { return parseFloat(c.charge) === first; });
        detail = same
            ? count + ' numbers &times; ' + giantFmtPortPrice(first)
            : items.map(function (c) { return esc(c.number) + ' ' + giantFmtPortPrice(c.charge); }).join(', ');
        detail = ' <span style="opacity:.8;">(' + detail + ')</span>';
    }
    return '<i class="fa-solid fa-receipt"></i><span>Total to pay on submission: <b>' + giantFmtPortPrice(resp.cost) + rvTax() + '</b>' + detail + ' — invoiced when you submit this request.</span>';
}

// Parse a "yyyy-mm-dd" string into a LOCAL date (avoids the UTC shift of new Date("yyyy-mm-dd")).
function giantParseYmd(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s || ''));
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date();
}

// Local fallback earliest date (server calendar unavailable): count working days
// skipping weekends AND any known non-working day in giantBankHolidaySet.
function giantLocalMinDate(type) {
    var daysByType = { single: 4, multi: 7, sub_single: 7, sub_multi: 10 };
    var days = (daysByType[type] || 7) + 1 + (new Date().getHours() >= 16 ? 1 : 0);   // + the 4pm cut-off
    var d = new Date();
    var count = 0, guard = 0;
    while (count < days && guard < 400) {
        d.setDate(d.getDate() + 1);
        guard++;
        if (!giantPortDateIsBlocked(d)) { count++; }
    }
    return d;
}

// (Re)build the port-date picker with the given earliest selectable date.
function buildPortDatePicker(minDate) {
    window._giantPortMinDate = minDate;
    if (window._giantPortFp) { try { window._giantPortFp.destroy(); } catch (e) {} window._giantPortFp = null; }
    if (window.flatpickr) {
        window._giantPortFp = flatpickr("#portDateInput", {
            dateFormat: "Y-m-d",
            minDate: minDate,
            disableMobile: true,
            disable: [ giantPortDateIsBlocked ],
            onReady: function (sel, str, inst) { inst.calendarContainer.classList.add('giant-port-fp'); },
            onChange: function () { $("#portDateInput").removeClass("is-invalid"); }
        });
    }
}

// "Earliest date" shortcut — set the port-date field to the first selectable
// working day (honours the minimum notice period + weekends + bank holidays).
$('#portDateEarliestBtn').off('click').on('click', function (e) {
    e.preventDefault();
    var d = (window._giantPortMinDate instanceof Date) ? new Date(window._giantPortMinDate.getTime()) : new Date();
    var guard = 0;
    while (giantPortDateIsBlocked(d) && guard < 400) { d.setDate(d.getDate() + 1); guard++; }
    if (window._giantPortFp) {
        window._giantPortFp.setDate(d, true);
    } else {
        var key = d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
        $('#portDateInput').val(key).trigger('input');
    }
    $('#portDateInput').removeClass('is-invalid');
});


$("#giantModalAddForm").find("input").on("input", function () {
    $(this).removeClass("is-invalid");
});


// ===== Auto-fill from WHMCS account (address + personal details) =====
(function () {

    function readAccount() {
        var raw = document.getElementById('giantAccountAddressJson');
        if (!raw) return null;
        try { return JSON.parse(raw.textContent || raw.innerText || 'null'); }
        catch (_) { return null; }
    }

    // Overwrite the field with the account value. Clicking an autofill button
    // means "use my account data here", so we REPLACE what's there — this is
    // what makes it work on a rejected-port resubmit, where every field is
    // already populated. A blank account value is skipped so we never wipe a
    // field the account has nothing for.
    function setField(selector, value) {
        var $el = $(selector);
        if (!$el.length) return;
        if (value === undefined || value === null || String(value).trim() === '') return;
        $el.val(value).trigger('input').trigger('change');
    }

    function confirmFilled($btn) {
        var original = $btn.html();
        $btn.html('<i class="fa-solid fa-check" style="margin-bottom:0;"></i> Filled').prop('disabled', true);
        setTimeout(function () { $btn.html(original).prop('disabled', false); }, 1800);
    }

    // Split WHMCS address into premises (property/building) + thoroughfare (street).
    //   "York Eco Business Centre" + "Amy Johnson Way" → premises "York Eco Business Centre", thoroughfare "Amy Johnson Way"
    //   "63 Old Street"        → premises "63",           thoroughfare "Old Street"
    //   "Rose Cottage, Old Ln"  → premises "Rose Cottage", thoroughfare "Old Ln"
    //   "Old Street"           → premises "",             thoroughfare "Old Street"
    function splitPremises(addr1, addr2) {
        addr1 = (addr1 || '').trim();
        addr2 = (addr2 || '').trim();
        if (addr1 && addr2) return { premises: addr1, thoroughfare: addr2 };

        var only = addr1 || addr2;
        var premises = '', thoroughfare = '';
        if (only) {
            var m = /^(\d+[A-Za-z]?)\s+(.+)$/.exec(only);
            if (m) {
                premises = m[1]; thoroughfare = m[2];
            } else if (only.indexOf(',') > 0) {
                var parts = only.split(',');
                premises = parts.shift().trim();
                thoroughfare = parts.join(',').trim();
            } else {
                thoroughfare = only;
            }
        }
        return { premises: premises, thoroughfare: thoroughfare };
    }

    // Installation address.
    $('#autofillAddressBtn').off('click').on('click', function (e) {
        e.preventDefault();
        var addr = readAccount();
        if (!addr) return;
        var split = splitPremises(addr.address1, addr.address2);
        setField('#companyInput',      addr.companyname);
        setField('#premisesInput',     split.premises);
        setField('#thoroughfareInput', split.thoroughfare);
        setField('#localityInput',     addr.city);
        setField('#postcodeInput',     addr.postcode);
        confirmFilled($(this));
    });

    // Personal / end-user details.
    $('#autofillPersonalBtn').off('click').on('click', function (e) {
        e.preventDefault();
        var addr = readAccount();
        if (!addr) return;
        setField('#forenameInput', addr.firstname);
        setField('#nameInput',     addr.lastname);
        confirmFilled($(this));
    });

})();


$('#giantModalAddForm').off('submit');
$('#giantModalAddForm').on('submit', function (event) {

    event.preventDefault();

    // The declaration IS the letter of authorisation: no tick, no port.
    if (!$('#cloaAgreeInput').is(':checked')) {
        $('#cloaDeclaration').addClass('is-invalid');
        $('#cloaDeclaration')[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
    }

    $('.giantModalPanel').hide();
    $('#giantModalSpinnerDiv').show();

    $.ajax({
        type: 'post',
        data: $(this).serialize(),
        success: function (responseJson) {
            var response = jQuery.parseJSON(responseJson);

            if (response.error) {
                $('#giantModalAlertDiv').show();
                $('#giantModalAlert').html(response.error);
                // Neither carrier would take it: the signed letter is offered so
                // it can go on the support ticket.
                if (response.loa && response.loa.url) {
                    $('#giantModalAlert').append(
                        $('<div style="margin-top:10px;"></div>').append(
                            $('<a class="btn btn-default btn-sm giant-loa-download" target="_blank" rel="noopener"></a>')
                                .attr('href', response.loa.url)
                                .html('<i class="fa-solid fa-file-pdf"></i> ' + $('<span>').text(response.loa.label || 'Download your Letter of Authorisation').html())
                        )
                    );
                }
            }
            refreshList("port");
        }
    });
});

$("#checkPortabilityButton").click(function (event) {

    event.preventDefault();
    $("#nextButton").attr('disabled', 'disabled');
    $("#checkPortabilityButton").attr('disabled', 'disabled');
    $("#lcpDiv").hide();
    $(".lcpInfoDiv").hide();
    $.ajax({
        type: 'post',
        data: {
            pbxAction: "checkPortability",
            mbn: $("#mbnInput").val(),
            account_number: $("#accountNumberInput").val(),
        },
        success: function (responseJson) {

            $("#checkPortabilityButton").removeAttr('disabled');

            var response = jQuery.parseJSON(responseJson);

            $(".lcpInfoDiv").hide();

            // Port-to-self: the number is already on our network. Block it.
            if (response.alreadyOurs) {
                $('#lcpDiv').hide();
                $('#portCostHint')
                    .html('<i class="fa-solid fa-circle-exclamation"></i><span>This number is already on our network &mdash; there\'s nothing to port. If it isn\'t on your account yet, please contact us to have it assigned.</span>')
                    .css({ background: 'rgba(229,72,77,.08)', 'border-color': 'rgba(229,72,77,.35)', color: '#a3282c' })
                    .show();
                $("#nextButton").attr('disabled', 'disabled');
                return;
            }

            // Reset the cost hint styling (it may have been turned into a warning
            // by a previous "already ours" check).
            $('#portCostHint').css({ background: '', 'border-color': '', color: '' });

            // Per-number cost (geographic vs non-geographic). A multi-line port
            // charges this for the MBN and again for each extra number ported.
            if (response.cost !== undefined && response.cost !== null) {
                var costTxt = 'Porting this number costs <b>' + giantFmtPortPrice(response.cost) + rvTax() + '</b>. Each extra number you port is charged too; numbers you retain or drop are free.';
                if (response.nonGeo) { costTxt += ' <span style="opacity:.75;">(non-geographic number)</span>'; }
                $('#portCostHint').html('<i class="fa-solid fa-tag"></i><span>' + costTxt + '</span>').show();
            }

            // A non-geographic number (0800 / 03 / 084 …) whose range holder the
            // lookup couldn't name: straight to manual provider selection. With
            // a range holder it is confirmed below exactly like a geographic one.
            if (response.nonGeo && !response.rh) {
                $("#mbnShowInput").val($("#mbnInput").val());
                if (!response.isPortabilityPossible) {
                    $("#lcpInfo0Div").show();
                    return;
                }
                $("#currentRhInput").val("");
                $("#rhModeInput").val("manual");
                $("#lcpConfirmDiv").hide();
                $("#lcpChosenDiv").hide();
                $("#lcpSelectDiv").show();
                $("#lcpDiv").show();
                $("#nextButton").removeAttr('disabled');
                $("#lcpCupidSelect").change();
                return;
            }

            var rh = response.rh;
            if (!rh) {
                $("#lcpInfo0Div").show();
                return;
            }

            $("#mbnShowInput").val($("#mbnInput").val());

            var isPortabilityPossible = response.isPortabilityPossible;

            if (isPortabilityPossible) {
                $("#lcpInfo1Div").show();
            } else {
                $("#lcpInfo2Div").show();
            }

            $("#lcpSelectDiv").hide();
            // Reset the confirm state so re-checking always shows the Yes/No prompt.
            $("#lcpChosenDiv").hide();
            $("#lcpConfirmDiv").show();
            $(".currentLcpP").text(rh);
            $("#currentRhInput").val(rh);
            $("#lcpDiv").show();
        }
    });
});

function typeMode(mode) {

    let currentType = $("#typeSelect").find(":selected").val();

    if(mode == "sm") {

        if (currentType == 'sub_single' || currentType == 'sub_multi') {
            $("#typeSelect").val("single");
        }

        $("#typeSelect option[value='single']").show();
        $("#typeSelect option[value='multi']").show();

        $("#typeSelect option[value='sub_single']").hide();
        $("#typeSelect option[value='sub_multi']").hide();

    } else {

        if (currentType == 'single' || currentType == 'multi') {
            $("#typeSelect").val("sub_single");
        }

        $("#typeSelect option[value='single']").hide();
        $("#typeSelect option[value='multi']").hide();

        $("#typeSelect option[value='sub_single']").show();
        $("#typeSelect option[value='sub_multi']").show();
    }
}

$("#lcpCorrectButton").click(function (event) {
    event.preventDefault();
    $("#rhModeInput").val("auto");
    // Collapse the Yes/No prompt once answered — show a confirmation with a
    // "Change answer" link instead of leaving the buttons on screen.
    $("#lcpConfirmDiv").hide();
    $("#lcpSelectDiv").hide();
    var rh = $("#currentRhInput").val();
    $("#lcpChosenText").html('<i class="fa-solid fa-circle-check" style="color:#00d9a7; margin-right:6px;"></i>Current provider confirmed: <b>' + $('<span>').text(rh).html() + '</b>');
    $("#lcpChosenDiv").show();
    $("#nextButton").removeAttr('disabled');

    typeMode("sm");
});

$("#lcpElseButton").click(function (event) {
    event.preventDefault();
    $("#rhModeInput").val("manual");
    // Hide the Yes/No prompt and reveal the provider picker (with a way back).
    $("#lcpConfirmDiv").hide();
    $("#lcpChosenText").text("");
    $("#lcpChosenDiv").show();
    $("#lcpSelectDiv").show();
    $("#nextButton").removeAttr('disabled');

    $("#lcpCupidSelect").change();
});

// "Change answer" — restore the Yes/No prompt and reset the choice.
$("#lcpChangeLink").off('click').on('click', function (event) {
    event.preventDefault();
    $("#lcpChosenDiv").hide();
    $("#lcpSelectDiv").hide();
    $("#lcpConfirmDiv").show();
    $("#rhModeInput").val("");
    $("#nextButton").attr('disabled', 'disabled');
});

$("#lcpCupidSelect").change(function (event) {

    let detectedLcp = $("#currentRhInput").val();
    // Option value is "carrier|cupid|name" (legacy rows: "cupid|name").
    let parts = $(this).val().split("|");
    let selectedLcp = parts.length >= 3 ? parts.slice(2).join("|") : parts[1];

    // No detected range holder (e.g. non-geographic) → treat as a provide.
    if(!detectedLcp || detectedLcp == selectedLcp) {
        typeMode("sm");
    } else {
        typeMode("sssm");
    }
});


$(".removeNumberButton").off("click");
$(".removeNumberButton").click(function (event) {
    event.preventDefault();
    var row = $(this).parent().parent().parent();
    row.remove();
});

$("#addNumberButton").click(function (event) {
    event.preventDefault();
    var row = $(this).parent().parent().parent();
    var before = '<div class="row align-items-end">';

    before += '<div class="col-md-4"><div class="form-group"><label class="col-form-label">Number:</label><div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">+44</span></div><input type="text" class="form-control" name="numberNumber[]" value=""></div></div></div>';
    before += '<div class="col-md-3"><div class="form-group"><label class="col-form-label">Action:</label><select type="text" class="form-control" name="numberAction[]"><option value = "port">Port</option><option value = "retain">Retain</option><option value = "drop">Drop</option></select></div></div>';
    before += '<div class="col-md-3"><div class="form-group"><label class="col-form-label">Type:</label><select type="text" class="form-control" name="numberType[]"><option value = "other">Other</option><option value = "associated">Associated</option></select></div></div>';
    before += '<div class="col-md-2 align-bottom"><div class="form-group"><button class="removeNumberButton btn btn-danger">-</button></div></div>';
    before += '</div>';

    row.before(before);

    //row.before('<div class="row"><div class="col-md-10"><input type="text" class="form-control" name="number[]" value=""></div><div class="col-md-2"><div class="form-group"><button class="removeNumberButton btn btn-danger">-</button></div></div></div>');

    $(".removeNumberButton").off("click");
    $(".removeNumberButton").click(function (event) {
        event.preventDefault();
        var row = $(this).parent().parent().parent();
        row.remove();
    });
    $("#giantModalAddForm").find("input").off("input");
    $("#giantModalAddForm").find("input").on("input", function () {
        $(this).removeClass("is-invalid");
    });

});

// Enhance the "route incoming calls to" picker to match the rest of the
// addon: searchable, grouped by type (native <optgroup>s from the server) and
// with the same per-type destination icons as the Numbers editor. Purely
// cosmetic — the plain <select> still works if select2 isn't available.
if (window.jQuery && $.fn.select2 && $('#portDestinationInput').length && !$('#portDestinationInput').data('select2')) {
    var portDestCfg = { width: '100%', placeholder: 'Search destinations…', allowClear: true };
    if ($('#giantModal').length) { portDestCfg.dropdownParent = $('#giantModal'); }
    if (window.giantRenderDestOption) {
        portDestCfg.templateResult    = window.giantRenderDestOption;
        portDestCfg.templateSelection = window.giantRenderDestOption;
    }
    $('#portDestinationInput').select2(portDestCfg);
}

// Losing-provider (LCP) picker: show the industry CUPID as a pill next to each
// provider name. The option value is "carrier|cupid|name" (legacy: "cupid|name"),
// so we parse the CUPID out of it. Plain <select> still works if select2 isn't
// available — the name alone shows.
function giantRenderLcpOption(data) {
    if (!data || !data.id) { return data ? data.text : ''; }
    var parts = String(data.id).split('|');
    var cupid = parts.length >= 3 ? parts[1] : (parts.length === 2 ? parts[0] : '');
    var $row = $('<span class="giant-lcp-opt"></span>');
    $row.append($('<span class="giant-lcp-name"></span>').text(data.text));
    if (cupid) { $row.append($('<span class="giant-cupid-pill"></span>').text(cupid)); }
    return $row;
}

if (window.jQuery && $.fn.select2 && $('#lcpCupidSelect').length && !$('#lcpCupidSelect').data('select2')) {
    var lcpCfg = {
        width: '100%',
        placeholder: 'Search for your current provider…',
        templateResult: giantRenderLcpOption,
        templateSelection: giantRenderLcpOption
    };
    if ($('#giantModal').length) { lcpCfg.dropdownParent = $('#giantModal'); }
    // select2 fires a native 'change' on selection, so the existing
    // #lcpCupidSelect change handler (type-mode logic) keeps working.
    $('#lcpCupidSelect').select2(lcpCfg);
}

var signature = $('#signatureDiv').signature({
    syncField: '#sigpad',
    syncFormat: 'PNG',
    change: function (event, ui) {
        $("#signatureDiv").css("border-color", "#DEE0E3");
    }
});

// The signature plugin sizes its canvas once, at init — but page 4 (Address &
// sign) is hidden then, so the canvas is created 0-wide and drawing lands
// offset. Re-create it the first time page 4 is actually visible, at its real
// width. Guarded so it only runs once (later visits keep any drawing).
var sigSized = false;
function ensureSignatureSized() {
    if (sigSized) { return; }
    var $div = $('#signatureDiv');
    if (!$div.length || !$div.is(':visible') || !$div.width()) { return; }
    try { $div.signature('destroy'); } catch (e) {}
    $div.removeData();
    $div.empty();
    signature = $div.signature({
        syncField: '#sigpad',
        syncFormat: 'PNG',
        change: function () { $div.css('border-color', '#DEE0E3'); }
    });
    sigSized = true;
}

// ===== E-signature: Draw / Type =====
// Both modes end up as a PNG data-URI in #sigpad, so the backend (which embeds
// the signature image into the LOA .docx) is unchanged.
var sigMode = 'draw';
var sigFont = "'Dancing Script', cursive";

function renderTypedSignature() {
    var name = ($('#sigTypeInput').val() || '').trim();
    $('#sigTypePreview').css('font-family', sigFont).text(name);
    if (!name) { $('#sigpad').val(''); return; }

    var c = document.createElement('canvas');
    c.width = 750; c.height = 200;
    var ctx = c.getContext('2d');
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.fillStyle = '#0f172a';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    var size = 96;
    ctx.font = size + "px " + sigFont;
    while (size > 24 && ctx.measureText(name).width > c.width - 60) {
        size -= 4;
        ctx.font = size + "px " + sigFont;
    }
    ctx.fillText(name, c.width / 2, c.height / 2);
    $('#sigpad').val(c.toDataURL('image/png'));
    $('#sigTypeInput').removeClass('is-invalid');
}

$(document).off('click.giantSigTab', '.giant-sig-tab').on('click.giantSigTab', '.giant-sig-tab', function (e) {
    e.preventDefault();
    sigMode = $(this).data('sigmode');
    $('.giant-sig-tab').removeClass('is-active');
    $(this).addClass('is-active');
    if (sigMode === 'type') {
        $('#sigDrawWrap').hide();
        $('#sigTypeWrap').show();
        renderTypedSignature();
    } else {
        $('#sigTypeWrap').hide();
        $('#sigDrawWrap').show();
        $('#sigpad').val(signature.signature('isEmpty') ? '' : $('#sigpad').val());
    }
});

$(document).off('input.giantSig', '#sigTypeInput').on('input.giantSig', '#sigTypeInput', renderTypedSignature);

$(document).off('click.giantSigFont', '.giant-sig-font').on('click.giantSigFont', '.giant-sig-font', function (e) {
    e.preventDefault();
    sigFont = $(this).data('font');
    $('.giant-sig-font').removeClass('is-active');
    $(this).addClass('is-active');
    renderTypedSignature();
});

// Google Fonts load async — re-render once they're ready so the canvas uses the
// real script face, not the fallback.
if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(function () { if (sigMode === 'type') { renderTypedSignature(); } });
}

$(document).off('change.giantCloa', '#cloaAgreeInput').on('change.giantCloa', '#cloaAgreeInput', function () {
    if ($(this).is(':checked')) { $('#cloaDeclaration').removeClass('is-invalid'); }
});

$('#clearSignatureButton').click(function (e) {
    e.preventDefault();
    signature.signature('clear');
    $('#sigTypeInput').val('');
    $('#sigTypePreview').text('');
    $("#sigpad").val('');
});

$("#nextButton").click(function (event) {
    event.preventDefault();

    if (currentPage == 2) {

        if (!$("#linesInput").val()) {
            $("#linesInput").addClass("is-invalid");
        }

        if (!$("#channelsInput").val()) {
            $("#channelsInput").addClass("is-invalid");
        }

        $("[name='numberNumber[]']").each(function () {

            var value = $(this).val();
            if (!value || !value.match(/^[0-9]{10}$/)) {
                $(this).addClass("is-invalid");
            }
        });
    }

    if (currentPage == 3) {

        if (!$("#forenameInput").val()) {
            $("#forenameInput").addClass("is-invalid");
        }

        if (!$("#nameInput").val()) {
            $("#nameInput").addClass("is-invalid");
        }
    }

    var find = $("#formPage" + currentPage).find(".is-invalid");

    if (find.length) {
        return false;
    }

    currentPage++;
    if (currentPage > lastPage) {
        currentPage = lastPage;
    }
    if (currentPage == 1) {
        $("#prevButton").hide();
    } else {
        $("#prevButton").show();
    }
    if (currentPage == lastPage) {
        $("#nextButton").hide();
        $("#submitButton").show();
    } else {
        $("#nextButton").show();
        $("#submitButton").hide();
    }

    if (currentPage == lastPage) {
        $("#portDateInput").val("");

        // Pull the porting calendar for the chosen port type: the non-working
        // days to grey out (bank holidays + carrier non-porting days) and the
        // earliest valid date honouring the real lead time. Falls back to a
        // local estimate if the request fails.
        var portType = $("#typeSelect").val();
        $.ajax({
            type: 'post',
            dataType: 'json',
            data: {
                pbxAction: 'getPortCalendar',
                type: portType,
                channels: $("#channelsInput").val(),
                mbn: $("#mbnInput").val(),
                portNumbers: giantPortedNumbers()   // priced per number: the total shown is the invoice
            },
            success: function (resp) {
                if (resp && resp.holidays) {
                    for (var i = 0; i < resp.holidays.length; i++) {
                        var hd = resp.holidays[i];
                        if (hd) { giantBankHolidaySet[hd] = giantBankHolidaySet[hd] || 'Non-working day'; }
                    }
                }
                if (resp && resp.cost !== undefined && resp.cost !== null) {
                    $('#portCostSummary').html(giantPortCostSummaryHtml(resp));
                }
                buildPortDatePicker((resp && resp.earliest) ? giantParseYmd(resp.earliest) : giantLocalMinDate(portType));
                // Placed after 4pm: the carrier counts from the next working day.
                var $cut = $('#portDateCutoffNote');
                if (!$cut.length) $cut = $('<div id="portDateCutoffNote" class="text-muted small" style="margin-top:4px;"></div>').insertAfter($('#portDateInput').closest('.input-group'));
                $cut.html(resp && resp.cutoff ? '<i class="fa-solid fa-clock"></i> It\'s after 4pm, so the carrier counts this order from the next working day \u2014 the earliest date allows for that.' : '');
            },
            error: function () {
                buildPortDatePicker(giantLocalMinDate(portType));
            }
        });
    }

    $(".formPage").hide();
    $("#formPage" + currentPage).show();
    updatePortStepper();
});

$("#prevButton").click(function (event) {
    event.preventDefault();
    currentPage--;
    if (currentPage < 1) {
        currentPage = 1;
    }
    if (currentPage == 1) {
        $("#prevButton").hide();
    } else {
        $("#prevButton").show();
    }
    if (currentPage == lastPage) {
        $("#nextButton").hide();
        $("#submitButton").show();
    } else {
        $("#nextButton").show();
        $("#submitButton").hide();
    }
    $(".formPage").hide();
    $("#formPage" + currentPage).show();
    updatePortStepper();
});


$("#submitButton").click(function (event) {

    // Signature valid if drawn (draw mode) or a name typed (type mode).
    var hasSignature;
    if (sigMode === 'type') {
        hasSignature = (($('#sigTypeInput').val() || '').trim() !== '') && (($('#sigpad').val() || '') !== '');
        $('#sigTypeInput').toggleClass('is-invalid', !hasSignature);
    } else {
        hasSignature = !signature.signature('isEmpty');
        $("#signatureDiv").css("border-color", hasSignature ? "#DEE0E3" : "red");
    }

    $("#formPage" + currentPage).find("input").each(function () {
        var name = $(this).attr("name");
        // 'company' is optional; the typed-signature field is validated above.
        if (name === "company" || $(this).attr("id") === "sigTypeInput") { return; }
        if (!$(this).val()) {
            $(this).addClass("is-invalid");
        }
    });

    var find = $("#formPage" + currentPage).find(".is-invalid");

    if (find.length || !hasSignature) {
        return false;
    } else {
        return true;
    }
});


    