<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpl4TPVe4qxPyN/Wj7KpRxWw7Ttuat49cynIWHvaYkR7/8KhOxJCSSRst8u8H10omb9oK5KH
+sFTyH0U6i3mU8VaAqGAd9YTpRXln5tr3PRBQXM5gOPFibLjaUVlAIcbW+H08ZrRufUzQwSZkkb6
itZ6/kA4C/S3QL+cJzIMI/Kaiy+CMsilvnzXw+LAYWBRvO2zrry3ziF4Wn2D8kOMnRckGD2mx43U
9AaD4MZ/iI+bJfN85v0Y1lg0ecvVbZC80zl4C/eFBHP9Cn3spdkP512DIfZ/c7iYPy5jRTg4QLNY
LLLrRUyX8bWptqunWkauL0f7Jw9pJg++lCHBzy8i7VqP6py4VulcOIRrgJSwe36Smjw0zUJc/a1z
0eDGcdmhdghHCNH92enUxgE700mwr1LBN0kfohsW2iB+fzFOUyXIoFnbPsYvMkoujab0hrFaV5Le
yAKtxXL5asgJ7EOD2SBHzfLsipuesO8aC0Lx6DEsUOY7oqnOLzKAq19RaZXubKIcuNyHEcIDdYNN
lVj6kIj3ynx3VSAvA67Ozph1/qvsS90/DSZXeYmb9lAOAVQsLRwUMDnlp376uJcJkAg0MRBlBEYm
9P3ZxgYJP6iVEkh/TI+cSqNm8UDaIMyGDx4zh+a8uuTiI+bw86RTOd3/vsfZRL3S+JYfb251Oo+2
mPEs6LVN3vWKEGQikhE3eLiOO4bXiXX9AHeoggxpwZ43U8SzJYUwVRoEPkGY7bx7uDY0KXDpgYOL
q49z9JlOpgyhG3bPxq0d6A1Q+4V3z8DjjPywPUbrvVw+J6i5csdp+o6uaGqhyC7v0J0LIh9gWKMz
jVqOmLklZDeTd1P/zFOrIO/xT6T4Ge23U+DHUSU6GjE9TkS5HET2V6Qit8cUWD2NxZfOIRmkl3l/
1MNOFIdWMDYveMuKGEEB8jZAHqsCV98sgrFiyBrO0ZG6oOmVRBBciWGQpC/W1+u4Nq3DjjHx8tmD
KM3Nk5kJf2L6cVgB0CkYwfy+xRJ11/BKSLcxbqwNSsh49d05AqN/3gTyC++4vXpAn9lEA/TiPN2D
cRM/smAPLBxIrhMh699fbLToq7dAdSX/exAKl9KnG7SCelOQIuL6b76mje8Ae+AC7cjOxhytbyTk
SMkPzP70OWxzkpxMndBtyiZxNjb7afikFKRyJlxs0IbxnWc81tJ/KbwwfMHTVigPoRsKNPcfwe3S
0fNgBqq3cclUlv4fXrAKNUdNh89YQWd3cidncsYYfdUdXWnnLYpMMgaklYUeLBXUSF+F0m==