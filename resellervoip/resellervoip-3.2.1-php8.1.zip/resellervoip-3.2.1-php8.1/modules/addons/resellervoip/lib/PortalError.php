<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz/fbzXSCsmV7Ly2+tJ7FK1Mlvosp+LSy/gqewLVLFvnZJ/Fom64IHmwTrYDk1iOcUptfrKe
+6S7HmHQ7wtG9UUO8v/Mf4qjkhKsnW6k974nHUx4q23zuz7vIMmVN2+KWXOD0rF2eYf9kaFl2Ma6
n6jqYk2Irq6uYD4jr+5icBfh/G1DjOAPnF5HvkXrIrJ8VF5JHEZFSCQ1mSGNgWbzldiHEyE1nMi0
L28gDq0W+i2CqIdXorTfAB8Eim5RbUibmCouI/iEsv11vxBG2kpIiWT6wMep9CIFw6nptJZYsquc
KbOuUF6/p2p/TSmKBRwO+lrgvOHubII+EEJQKgudurl7VissUZ7HwM9Zrbqa/77Nsw++2UMM3GEc
QJPRIGkK27nCU2Z9mWMeA3QEKzrovjXL0XHtykkiWaXhb9V9H3BQaSA47yTfHGut7Z//9UNYi2Gx
3m8efsTw6dRKxKeI4xtOLLArNKNf3oW21AMW/gm8W4XClH4jBsG3/IkXquwxwHhmh4kDzacPrjDj
n9pnWQFvnV1BqgoxkyLECRZzEdfEbBFGpP1h2xUsdNi19T++XRHWuSXz5hmjSAYPw4I0sRFMIEW5
G5fRUKTWJzXX3YAlCz1HiSMxPZ6JfRRvPPY1HU/YnajcYA9GHlzge2HehkqVlYcMi2Z5D0o8+AfQ
vxE2Zm9vkpGVwi7CzTsDOQRulfIyETPck5t3w6b/4ET1GM1SSthnVs5tqlNrVh88PkvnDIcqz6wI
/UKMAzMJFxv7xy3lrYdCzUp/roojYlOjSbnelR3B1qbselEp6mk7IpMeVTDlIyoEt6dTOPqzze5W
c4a8JFKAjNDuP9khAj23rlNqFW01pm2890irq8QrITqAmwgJ5wryvOVYv1VCQHX/xJ+IZ6Q8TxK7
LyAhpnTb/EiEHz24vK7y8QVlfkqhO+Xh3H9PwrcW2+601PmdYP/Wi4kckt/i+JzBx7Cj3YJjJ2Xd
Lok3x4lKgKHB/+KwQfUzkDmc3CF8Nm3xNdDLgAvRkeTATzb9zPqtmViLHwmImf/VG5BCzn/JCO7Q
ORhSQFHMJ2eGwmBnVCAW82dx5b7aNlgzUMjI7knZTo6+kHYoDltWMDh9kv+1UZYAQhFUX0iLc/A7
Lz70xbtkagr7nHcNSSi+0Y3P743ZbZNed+z6GBylHpvGZq5T0e+cXYQyYHFPVIt+7mlfoT1w5XD3
qAu91e57Vs5G/O17UzH7e20pPzPA0FnvTWYxTggqZBEqjyYIjQ5Gmbs39zkLy2I6min3xo9e7aWD
H3BaPVkrfsS1roZwbsZnad3A1CuuP+ulaKJDtZ1uZjMshEzZ7YLMTP+Q+AhzdxiR1Lb1M8etfvHN
UI/P9eHF3avNxY4I2ODe/1rDE/zGVrhrcwqz/HwiOuDsw/X+5cVb5vJZHFDVJ4zNx99t1pq/Czpn
I6EqBcA49hDelGc5v1AemCASftU5cwxh5XRwALR5O1EfXiP/H6wRIe0LEmRkLajzXdwoOajJqEfv
1NlZRbwA0N0XdazYoq983SyU2suUqD1Mka+FNWMmQm8NHy2FwGCgW3gbhe3Fb/eBWm7VdxdYV5pf
1Mnnz/lTp2YVOwyqkU1rDrTR7ZqWkbAo7zQsl4K8MR4vrdB1uYSPPShEFUq26XXoChP/+dbk5+dS
haPVVouBYsBP0A94BV+fARNVnr/Ne8OAmCQPB02FxfejHoQ/+q9NGKul0vzP4EkStyUQnHLnjcqn
ZrDoa269yOazw6vTqsiheLnpcTouoRMlgQJA306JdW0RfWsjMzaz90LNlAX9w8WwysXbd+rEJKzn
tMdl6d13sChQG+XPvy0h7AmbCaWGj8f1ggpiHOzc64a0A0i6ktICkTeKtvlxLZjRhNiikqYYhAiG
tMoHVzl9JizudMrSnmy3BLg2FoLso+YO5sbty35XLEOSmyHAET9uhOdwCK0NHOs3/2U2Tcg5aa/u
2NWT9tOKEB0u+FGc6l9HmfawF/zBsMMRODE0Y7Xv+MDbvUpHv0Z2OrzgE0UQ3wgStD2ia7FkBlBH
eL+vcqsaMFrjVp1UT0nngqorzEFh1HlwPDqhrRYPVHE5KdsdjqbBUrf5YYfGbjHfXSRAoeFQrMig
4PMKs8cdwPZ7hbB3cC4wW0+ik2Fqh9mFhnjFoJKC8xFsikKD/WNQ0KSAtDoFw5P6oF2LcVQfYzcp
yOKwPhQ29yhJoSgfpqDXWsW48G1hxrsKDfAW7f8YoHrYso0qND5NLr3uUy0GcocD7HCFwPwJiUbk
U5/NZGzt6N/ZY/9vk7/bmwNvpOoyF/O7LhGDzcxu