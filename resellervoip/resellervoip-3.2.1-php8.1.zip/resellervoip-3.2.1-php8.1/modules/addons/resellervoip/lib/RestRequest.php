<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsRpHpkSHBp/q5r9qXW6LWeZAqgjYGAKuiaD44FUfkCEq6KeebLaLDgcTtGgPFadQaZvMsDw
zWmTxAAUKPzlA4SW1IoWlnQCHCHPd1hIOZE2lov9tz99xwGkFcsqr072REnVeJsc48CA24SG9XCw
7nSb9aL7T/R12ctNV5s43oSDefxpD7Ep1FdPUMmdDOg8VGVPUFBNkulbmPHCtF4ljvRz9PqxGAUc
/BTL/2OZADG6WTwVRuaQUxqaGp8fecXYcwL9cYigk1IGGUUoq0hiqfu7HkbgCoJ4Zq5Zu4CXi9It
1jzWb8XsmimVz42TIyUllbkvbKg3IbkiNbQidvfxouYmTmXJMR9qQ05sIUZf0maSGKBoXTczIRpe
j+7Av56WDoYh6Iax8P27xUeXvr1HX0xAXP9Ka7ua1K5mvYuvvUWg0iwbHlk15+RpP9lzpB2k3w+5
CVKXnS0sTtyzND1NvDYX4+yECT5P+S+BSAR/AwJeNK2oit/svqczZgyETqUKlD04wV2Kl8EByLU2
a/cHkUmAS4wn4VuwMMSQ4l1+Vqcf0OWx7ltWllPirxFFjHuT2TRxxvgs6naC1qVl5bgTkXaUf9Fk
FnNNOclEKE8kOBnqP/0+b0ffVMANQQSx7UsVC9imLmazZ5PlO2iNPYrKPrDo/fCaK95oD7DufQWv
4qXDpftf3QjdCx8BRr6hHjJ2UQwISGTxYGGJtK3JdqJ+kLUEj1nN9d2mM3D4UQUeyE+dSgsi0BjV
HoR1951tvX4P2oqRXwx7ADfOv4Kw23PrvIt4xId9wV6KeIQNiGYTCFxucxHzMc+X8auwvW7rMQUf
7XQhOOmDVaT2TqO3X16qQAqA9ZbMDk9WsKKDYFA+46F5+APB4Q6TYyAzDWWTHNJbDLF9uvLtIOlx
+kdzXDpXOityhVsaasEccn4/xPhkr4rk2KIW0tU7bvraRximOBzVbbN07edB2v9x1gSQ4G6HOs/i
cXMgEwxbSiHHxh13nGITBrYPrxGp4ZKv2swQHoKGqKBGFw2zLKHG0W1Ttx/Hi+86ig2VsCKb7qvQ
MpOgWwUUrDGVNA8b8ciDwZi2wxNvhgt2ChBbFt/+XdMphSB++kaSI1CkpO7e6cARJfHgmKM+eHzN
8m3nbBVn7hxDTTPEuXBhzQ+oH5bnmk23f/JeZw7T5u9U5ZjdIbdbogREwmzCgT2uvarlxrHe8a4P
kLXErXe=