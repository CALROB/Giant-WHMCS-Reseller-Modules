<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPya/rrCE6InaquL2S2li3ysGcudl2A5s6zE1CEJWnJ/QRxa8Wi/0wfQUkF5t81PgG4LZ2Y3J
WRmm/wNR7PdZRJeoDl8VxeNji/9M4GX2xGrPXoxRaiOhz/Ge3It+8kAI4L7Nrml2LDUav8dYVje4
3HzhbiVrTfSuBDLVnbFLELqvltuVOad917xj/iac/OfGQkxxUykVbDO/hOiRxpBeGZGDtqNkzBMV
d20TjJ27P7a2u5q3IR2bUAv4uMjQ0MmFW/eIkh9f5ewGGUUoq0hiqh47HkbgCoJ4Z/9i+pvp7QCh
pF33GNXnkymw/v4HyNNvpifEYcJaBtub9dEVW8Pq/t0LlC0D8pR9fcZ7Ig2m2UmpN0Ec9xbppmgc
uZVxU11g+vkCtBIa0IBOiseeTm8cThA+ZbC8JyO3qzva1nXEnZMr4ihojspXoeanIWoC9dzSk4Gq
BPc+05pEnoHSGXwlo/Qzw9SgW6xQBeFDdpOpLq0ICDYpWRW5xDiBB8oKNGtTpECPjvhJAxjuzArh
0GuWvqDkN3zyJPxd4/GsKL/0yFBMHCxD3O+V7RP9Eo36V4JMRnxK6OLZ2jIbura7a2/lHF1wdWdv
jfxs21YljGnelu4UJOLACUx7Urjp1lJtaCfDXRYOJWEadIOZc1VdVY3cmdZjXRcqAos1dUGot2ZH
QakdgGRNd0ZCzvNuKinTz0P8sBba0XaemS9Tt4KAO/Rnjl4hLBukDdzp8sl7US1V0muIWP67grEE
UuMz5K9yvE3SeQwlrtjkZ4x0fxaabOWNoSYoGTe8su49jjGYbST32sjpJSce6lAFLSk5xGvNpI9U
0JOKz7N1YDqSDGI/4h+3B/7/ttEDa6er7xQJI3KxYxHXNfkEAT2+bPmONHfHxlwAVwtFHOPP1sxo
Xu7P/rriT3X3eD+CdajBohtegoG6t3ZryKeO3gc6t1xcoIpToKcK28pXbuv25/0+E+ZLBNkksIAd
YGrroufeSFhvidUeMtoYj74rfv2BEMdQ466fdOWc5s+Lobt0NyZIAiBCJoji/N440e8HWGMhRNsC
q67ghlInxGeLVwiizFjwkAWD1iBI/vvETBPJKv0Jrm1ynpgEClqYYywZeUdoh37G874RRAM/UGhf
eJ6jz8HaHuch9an5nA/AHFDiFuKL8S/AfZj1aKe=