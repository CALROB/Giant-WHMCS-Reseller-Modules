<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyx8SQxkB4g2ytBaZHU2tXpqUHKn83iRgi8w093eC/EVRf8uZVqWxrIDG+zKjpROq0Rsb2cD
s1QffnmQE8V/alUpwCpr46i41PTb5vrMPGw5h/rolOY19hGueNboMH+jwxgdlujA3wrWBzhZp6JW
K8lP7UswM2nG7hNChSWvUXzIHLOxntbc2KzSCWVDwvHblxQv0rWrH31W6+dnc2sTHonDa7UuPheS
27RdevnNuuUwfx1aj3cGeXNIDUgMt+TP3pPOEttFu5lOfygTX4xdeyKNy+bkhlm8ssmNW8b+RDjs
OTfhPNqf3H0ZmuzQELeQUc6arqLwGuFr2FXdlvl2rYH08XV6Bu0tlU/uPMkGys1ZAv+/ayP201Au
guR+1F3dduIh3YuCO3aBXJuN7FpZt1f0UbM2hl2z2wgKMbLz1V7J7TIsK67R/G0ADUrgY67mRqWI
v5UO+5a3eHVuFH+twO62w/mqtCGcsnQyYAvEPV48M6tbWEe2Tu/kX4v0uInbEaRziSwwvqiH+/Pn
VqhsOEyPJLsZJdCz2iRPSL6Dr3kU0os20NwsbFOvrKtiSukBN3DY3bSzHTWQMAh1BuO6uoNAMXmL
glMNVvRERMHEsho9SjFgQRyglfdoizL5+hPVCFeWfklDMlNEDT71fsi7C/yLLRMPCBokCBKHveRZ
0jzE7jhteCiO7P7HOjCaOzlLf6fJCi3RHRAyUwC9xMx/FK00vLq8KxB26CFEX+zIqimSSn0FySA/
08WmQh4YwWc1KudlIbkVPeGg2LxORqhoVFUMnkPR2dtryFRAnqm/K5ELUFsntOD0H2wBkhg0HCTZ
5jdXV1/q85hxNWogVED5Q+IljRppOdQobxOibKGop7sr2+gHWYXKfB1c6nAQQBoMcNfPRck9QWB2
PrCeIeOtSSJMJrFLTJbvz7SZh13NGfdP0Xdo5thhxdjbx8L5KQV1Ryxlj+0BqF8tNj230FBzcHW3
dSwWLvrZs3U++RZVo5G8cPwVL7jA+XeqDACd5LeaiQLUHPHQ4HOp50hEBYsTS+aBvRhngOmjENDC
FnTLOqivRBpy4KTeHV+fJ6dWr4vcbpSlqKu/2gxu/b6euKK3tWQuu+DttRnT46w+hgL7e9AvpHEB
hcSs9Q74wWL0FfUTS8CsAuczd+KPDUwckmWniDTjfo/m49O4f8VEYh9VO28WRb7gpsV1dWhqIhR7
KZPd