<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqt/eaPjYnkxGbQ6qqvcoUdtcZeQI6Uu+FjTqe2lVqmFP+mYNFT28zhUIhmDNwBO813Qdpta
guldc+ZxIV+cY4eTMwI1UzhQFRTmgcHwPfbs1fKS1KHmFTCkA0h7HBpmdMAHcbgl/H03Oh5m0XJX
CyjuJTLsIOA7aLvEdneQi9WHkPKvSqs/P+L7zc7dGl5+IqbPSURdUMqKufbY4ZKdrmiD8CakbcbD
3TLVlBIEOJkSenrdXSg7u3qP25i7sMCEa4cECrISNB/OfygTX4xdeyKNy+bkhlm8Y6ddHvb8kDby
0h/eTO8Y3MYyR5KUi4BK2DMWKwABpF1UEZl/FbSsVEWwEP6DweX0m6lt3fUF8CsMBei7mj/TKJjn
mWz3m5efu0uVebtg2vWzBT4PGSMWZrTrjdRL+izTZ640vOdbW/+HyCuWLLgW7nrL6/k3vXRx/rTG
weRjj/hYwG1xZk1bhiZNHKN57WWlI58fjZ9Cwy7pvB5VB84msF2rdd26VrI55lRmsR2T4gbeonkR
lnCwpxSWYNMi8N2pxC3r459k1FQddBlJmTc8XqT2MhBJDEn1AVa2S3cDartTHXPAir0Cx/90W93B
68VexwL4/hPvXeOiNYIDTrklsu1ZzpXaa+9L5IAuEEEp0zG6qURwKYgpKq6CGQmCweoLA/onm7i/
srU4dZ/V1wQqh9iXn+4tULTsFXGDTLQr+BcI8dlKhauChi/KawZBf6fqmOpps64elM6haAWn/Rw4
RmyNAYQ9T0Y/sz2Uofl2mrw4HydVd2w74D9Se2q+VxrHacqqSHTBDC2fobZ25A6ai7OCfTvFNWfR
KXLmZLz5L40d7pK1gXCmvVjj0vYck+PG2/gYVx5fLc28CmIkeCjlxFTE9UM+O7PotwKkEzj2vOqA
my7ep5abTTMeoI0VVJ7V0KtLNjdkq9liOuMsqcuWGjJHdNeWJW1ZZO2tN11CocYwGpHtuRmsr/4M
kXVcGZHnWgJusFn994fSUzBVj6cQhyN83QrvkWqg+1b9LG/hgrij2LzU3xV5yGnIpYbjRPD2TKTg
lzNtUeh2p+M4kblypJWrNueRfQ2Y3vGugPDIOP2vu0tBT/k35w3pGsaN/T1d2chEVyOSb35O4SfZ
t+zqzE2+uTVGeZqsl9UrRtWVS+yCoR5CkxqYIceS