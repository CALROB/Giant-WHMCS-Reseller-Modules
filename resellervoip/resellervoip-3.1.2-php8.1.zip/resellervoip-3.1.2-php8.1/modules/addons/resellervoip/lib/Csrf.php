<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnfq8cbot9PE3yAtIfljNVBb2HcKgRwSCxcy+MqKomri3UQJfhdX5gHYnuDfSlKJ8bZ+sKlu
qE2IgCEMn+N6lmB5xL7+Pm5g7bIpA1NeOf1TadgmvumOtZaOaBIOxCQCfTvtYubfu10azi1wkwv4
fQhzdJhfBU3KcyFrCyPh3lC9727N6mTxDRRPREUNbFDTWJFOsVLnZ5E953NnM0EwZ9+8UZTSXX9H
cYpeGI74NL3bJ9fUlYSBINLaoWh4NMYV7aCrnAGi1DYdofs4JkUZnHVpwMwk/0YYRy+xBPSZYN0r
tWTjX2SDAYboBPzD2JSuWaPaGySgArhNV74M6jtj5dAPBm59Az4JI0e2+My7GrDZSefM3npysXDf
LhUY4S1Cg7J9zYe0G4pUjmSwGv7OGCGZZyeP3wT6hxl2XF5kOC15HsGCafdV3QZyPicYbrcLt+PB
1406SSc6W2/45s4/KVXtkuq03rEpen4wGqLx292lFN5QQsifuS1Mc27ginhzURo3gsQZ86bHT//u
e/vLK2luTjTt+7sPeE6u8sd02+lLWU6oudk14EhPk8vGTetuIC9mzLS5GkHJ40UPIBEAQwpGApHQ
TVS5p+OrnG+f5jmN9q8jSo0wNnHZbYVD9xOs2vEHJsy/XXT+X7JC1NuHJLnI/n5yzlxs/OD5KOZN
wYiF85hXWD93WO3F/AqBCVf4lsZOf0dzGWQCtZPGGNPsME8dN++gCYnQLVCbFwrapvGQC+Z6B/Nt
eBWG7wOAviV9bKsRODfF1bJvmLO0elnsDEKzP6xFU0eMNiC4Wxb3cqDtgQJB6vWZ1mAyvXAXmJk1
B3rUcO3XOuuNJG2Xm9p60tRgPn15oqw/v/6Fqa7jP8AYYL2vpp75n5lpjdhXEPn5/Nb3IXdum5hg
eITOqzEIclMXzTsfEHFIUyZRXk7oJOPkdQsaO92OZxbLxkIinCEzRehJR+WOMfIcLueGk9TrZkq8
N4nhlYtIPoJAl+eQqI476tx/rIkVAss+YhEBIGFr6nuMeIxuoPJwxdxKiviKqgDi0+9oGteHhtc9
emXCc3b0yx6XMPbhgSlPdRqx8UQ4ruPUSUadBm3AdiCNTOGK+05FHeEIfjCqRxjzsbcuLOJFDaBc
oNwzLKxNy3Byup3GFqhAdhr/a1vsZGlQFRUnK7eCZIfKtcrHXKtWsklSxqyF+6miNdE5Zed9qkzD
vkVefwma5qGa+7MSkJACXbI1FktkTPbsFGSiihT/gbjZvVjwyGNB4cvUpI05X4V2ZhX6jkrKJhGH
b33yoEpfjrSrjv4OBBYMMyA9uk14kau3r5dBCabpdgLmasxo9Obe4DM2UxT4Ml/G3PsQSiAe4GJe
C+GaOIceAn45H9xkZzoQ2qepoQwr8IaQa873aP+0I2ta4tdWzd9vlqtmZ7FJaWhrP/bjWQluffT2
6s8i7ikW/iGCQ2pk56jp1tTZrsyW7vx+1yA7sbdTegiJrt07MQwRIEE7Imjtl/3ZjryR/G8dykFu
/Q3ZsyBKFevskAFOpUSsP1fPkyLtErik4+5KUJPqNI0KFkIy4yAyHmmhNrgMpke+vmiz0XDc9sxp
vIBpgIij1FCCJXEF73xrHb2/hz5YuTZKcyA71CGQ87/SdDpstYlugo88zyegY16UTGy8svdPAiEF
WcgQZtX66OdStq1EKBoQbrvLYzqrgMVqwf21ThDAnrUnOHSpLwLFj6gtexLHQyPII19clLu+wtF0
/cvj+/ddH9/pSdboht1ZdwKzEuJAXa2WIsYzWkPqcl7wU5+LCiSJMoKMg+d+pQmMtskXGB5Gd4Kg
D1S83aOxPATn1oB4b/JrWwp7mac5qaxvmUEIaSW+1BYmUFY32kaQPom3GPMLp1Xp+THNg7DrYPKP
OvDvNog/2OsuT5sibGEqYdfKf3+S/Gro2DPuST+UspHEZhA80dGLmUwdE1HgdeSkWFMGAk1SUPUN
cuaNsInkOLBFsUDFooDXhxTySjdJV3epg8GBHQ1qra1TtaxLbJGWFSOZCCVHyg0V/LERPrBjCkIe
0aCdyO08u82QH9CMVPfV2WBNfp3jDluvtlOtJ41zewKCNHQ+yliABVbr8j674JMI2TIcq4PWPLfO
Q5qCeZ6Mtq+bq3+tVyJJD+fm6U8tPdoRUa4KhWg4ZmpCrod0CX5AGUfmtyTcHgniva1BYI47IETu
jza7rz3e5K5mQIsn0vcAPtRjbnKYZY+k2sWxQ4pC2ljR+3UJ52bZZtwNU0dP0rj7XnmkWSriNRn9
1yiVzThhVxMaifQNqllORqVFwgTxNXl7EU1b217EjWUAINSqWl40ysj58D+Oqh45J1z3QKyxYxbs
6lt4IvV7I9LNd21uR0b+yFWqJmiIr/dUT1z8TDq/OCI/0e4zwZADhyJjeO3Vd8CeqgB9Rb1l7qoi
b0zmKlpXZCgfqtO1LpboiAMqrr+eGx5YNXYgZE12xnTHeVLb5RTaeQE/8gExvycYABoLL27YvcXA
X6IIUQoP1HEjmiszcd1SSY/VMiSrbLNbgmqCEkAWM42ihm==