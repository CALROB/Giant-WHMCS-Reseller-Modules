<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/bEoNMjbp5whFjSLa9o1br+wD4WpK83RU4BUwJro6lmd7BQ7O2jiFsC7tz5mBURiOQ0hQP6
m0l4xE0lXKEmIXOJQgJ42VmhivjM3ytpuOtuMdrK/T42qmZkKx18TwEfI96uqbeN6gi9rrR2WIaf
QU+xsLTbIkEikMP4ViUt5rh0Ymit4O92GJvzJvvabl/9BoWuCWmngAbPTTb2xwrO0KGGZIoru1Ip
KIIKeqPv0WkRCaG6txNntzIioItewrgJsvIXUBiK9X3OfygTX4xdeyKNy+bkhlm8w6nENdWhEmIS
qcwlPVqa3GqD0Rk7ROEWl+UePDanI8rw52FhoGWE1drqR4BRIq8IqJZ+cMs19DQ5sCrmx8kuJkX3
e/vg9fIlPyqdmAcpmKB3ls/t5NFsYv8+2+DrSA2PSEwqDHklYAIzuX0D21KEA/+AHLvaidpFjaeI
QSu7aa/UDEiNj89A0EEOTu01Ni0uwg5wsazwGlNcMuCGmpgJb14Wi+RDJuM4Q+I0QwAMPtQq/07v
fqVsRUhB2AYcfEfu7g1QDg4Yh1aI3Zgdy5hUwp45AMdtvLkwpDbcMs5qIs9V7XJhEgPJZiMB9N7k
ViLFQUCvutFbkz5A8iSwo9vdfVQuwbourQkSY/GNAXmpDuvZImzDYsyjHV/j/XKEZR+vH8aUseKA
AvVE4Xwd3xe1KrcPw8+6+XAsu8roVBA0krJmY3+u4zrk8jnGEmUSQj7VDcLv6hOiBZr1sydjmYvX
lY1Q3NC9RmFHmRYN9dNDRwNaLatTvuaG4+N0jrGhEYF7Xah2VWn2HbM1Er617/AjJNyODh2aXQLz
sOoCId4fJ811JZtyfqtjcejDlvqsZUgLs+QSUeOFRNqb921ejMy5mElc6DUj0FEX0HXGt2lHRXUT
eICw39OAtz41J38uI/VkteMgW3ERpq++c9lPFZZfsdl1BfADP5nAlJB0rjnVuDStzbGY7usOTOz7
maLqSI9tFXclWk8sYjWm8SY5ADo+6aQlzfTmo7t5OAbEaWxaaHqtkIzYU3L4DROpMf2T4nbHT1/k
fDfZU/IwY6X7fNwwUt/EmjrNAkWuap4Qmmhx+fKgfUkLM5Sd6vwEFkj6jV4SZFut88FIDQkg3uH0
MQUtBKfBX2AQYlyS1yRyCku77HSP3X2nNZUf2imsOqavBtHcenvxK5Ji2I6tFmKwrVtmfNoDkJdZ
Tn5+7UGeOkHmnTyzAGT+Dzsgzcz67+k82/gmSd2OAAb6oLZYhFNf2FUeiAEKuLlf53fK13zzdL0V
RycNK9qxcKRnMz4CHZbuPpVZvPlXy8TdwUsOASfjHm54QiB4NJr8VCBY9ONocLKgDc//YzRjRTUi
yi4OAjyuSNAVql41bAS6GXOCO/xAfCRw2O7btQSouPPkQrnd92HmIaFHC1V6t2r/KPU2xW1cb2Dl
tDc3ASvDo+u0Y7KTmRaDBIRf9cRFjBNnc8QmlQ0Pw5GfKVDcZHygNGvzmUXyYkT9tFriDhv7spCG
q87ZyVWekiu7C9Jd5sI/CVOj2aoLgPDivGEBLUJ4A0WUxExJORXSeegzIRGFhr5lcVCHr1CXkH1+
aurPE2rr4i6CjVBOh1iT+vX+JAbNdrpU2Ou+bSC9p8Jy24/Z65u02Rz4FmziT+no2SDZecdqpPiN
OSHM57hvvN0NMh2Eba6BDkLj+BlQNGZhyUBhQRJCkPrMP/OEI6akyoWJOEE9GGchJU6QdABVxDps
ygY+WlcXCEkzh3jLo6u8Kbg1D+bwRRJmjvn+dLPXaE6y9KVmm+fWUZwv/rrIS5NPXw54ew0DbJKb
jKu3+XCDV4sVrEfVXKcgHssgXKo6yTPFj67UH8i17eBdrt83U0NLd9O0fuXXJUmQ++b9O0IQ4V6E
4xUbw7A6hYEVo3xsvjrfWfOIGJ95l/Hf7vfLEW9Bzryjj6K2VnOMSgQ1JyWzDajo9ltqu6bgQPGO
nRIr0e4TQv3iC04r+nZJdL8NkvE2r1ecfzND1HzDCMlzE9U+K/DkiFYJm9CgXaBuG7CxYkDuDOYG
UCebdsB7dxYyGPl7dTharsWKOxOCZlr+35mX6FxhXoxhAjU9o3xoBZJBsIjXjMkoE1RwkBcVpe0=