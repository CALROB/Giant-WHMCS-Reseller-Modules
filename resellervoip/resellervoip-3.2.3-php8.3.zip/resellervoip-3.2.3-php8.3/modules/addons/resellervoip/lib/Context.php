<?php //0032b
// Giant Reseller Phone System addon 3.2.3 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsQNKUPbOQh9T2t4nHAxh7WFnN6t5u6Nnvcymt4kkBuTpCKDmqBWJqMM3pEn+Z9Up2p+MOHl
Ot4pi1GRyEA1HCpubsf9unD3qcnpRSTE+uLuMk9lBCmTtHZSdb3QIxSVd75Kx8xFaKu2sY5rNXb5
l4SivVQHcd+rVuAVKrlHFvFmh7+fmFVMSPiPdWUZ39vKVSKqKpViU0Ry97UD8OlzIq5F/1fcgtZY
WGndHDkxcq3RBddM4VubOmgJsiYaDrcN1KR0T4spABwRNgmbLbpQNhtqUJCPQ4xnQihCHsieSDmy
WlzCUbGj8GBjL85WWM0bbMJK82tHxhspbp/YD/JfVSBE3Eg1oCEzPEUL0TeYKIUXUV5Oc7PuuJwz
Jy90f+L9MlWYCYhnJxbUJW/O0RQ5zUkJqQ06iHRBu6lw+UsiWtAtx2ZU6WHg0xHnaV2aBWTS9ivm
nQ3M8FFStNEMFS10XawbzQGCT4lyWTJj20JBMNIWnGzzVkhNKAMSZq8zggHGHeGVe5f3XTS/IvNe
vrEVHWXBGjzZbr4m9PGOVTB8q9jm5p5ZE0927/aVut1xxQrd+BKxRQJ+MlIUivVmOnC8sKM1Jnaq
xgszRmLYOWpjQ/0jeBIob9yA7Hcq1VI3WEyH98NIZ5hjA7pQqAYXlPhGmvAA0CkvH0k6IOqneZ8L
QBDenmKbLikBISO2fyZ3/sjblXa9k9HUl2cGaw7LtsEU0mfvKGdyIqe1Tw8JwsSDtdmmza54x+8/
adh6vIgK2wk1VVgEK4nhUE14pwzbfQYTB001jqeahxmz+7Q12V2wTMb1Te9KFqDym3scHw0jlef5
n9ZBkdJcgdilKLdGCyJe+Lf+p2wlyvfBPpwnvHOXdYhBRV25OkKHUnH/8mkZPRi97OYn/9NO/5X3
2d3a/xt3UQh5joGIN5uw2j4eQ1E6eu05I3DynIOxx6H1dDzt0azWK7mFCbDagYlwtPgbgUWC0364
He79FGDlqvEk7zFaFtqX2qCPBgvmV57YfYP4DEhjVQxB3C2Mz2OMxnWUmMHvnOhXhpSPGLeSjguG
O0GgebnRlhna/wJ3XOYaTLEBOTfYG7Iy2aF2o7hCRihLwxK54WdS+k4kZqRKXjI7YIf/6mD7HayS
/vM0rsZNDL22Y81Jf0E/Y/kA4wl5JAcmihElPZTDhCInG4Er2G==