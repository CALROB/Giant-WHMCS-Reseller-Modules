<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+Id9YP+ZPi90n6p1JDVl+UNiCUY2/k1TUnWSWHS2Q83oqUc5GgJn2nu2tPZwGRx95N9A4AT
GxT+FdoPe0P3iQ1/jhM63kcagIVvuUefbqdmrOTv/bqqZR8IYObrIncV1JMF3TI1vPXS4r+Vm7y0
CPfikoS7sxTyxyd5qGetal8b6tKJ/NyVom5nkKwYrhe0o9ue4XjKMAPSi0LNVfdT9oI+SYH+EqWL
M+c7rbX/LxkfFRy2XCyoVc+4+8abZ1ka6StH70TQXUCvCJyrUEnc2BG20389oMtFT9ZAOh+f24e0
snVTFfYD5rbDUl/OXt9a1NLdnh/t8bEM8FOWel/E4TXxYaljB5et9pv9T7o4qxR2O+eYIhvlYgOP
8nsATKgmQ8LsbQJDMymfiga+bQIy1YI42J+6PLNkVUwmdKJWMW9L17wU5hC50WYgOJLPhUoQayAP
ZfKc3IBbH78iI/DkM9+y1O+q4fpI50UesFzFs0KX+L6E6Ng2VzMQ7NF5qfN6FcZ/U9R6UgAnJizC
PtRyfVFXxlA19ywi4dnmhuon/i60k2s5nEi2wHoEhXPtozVgzGwGmMQW9+dTRID/tn1EsuIi5to4
zfSHBIaHHdQjUtS2292A6ZeIytoJ9T7fD8Vcuei+I/p+xo7PFL0640SKTUcLQwl74vlGpXS2VuU6
VZS6UgJGSMV5bnH1NS+5vJ80eA6hUW1EI7xLqQLOL2RBcrCNa1xdHBlq+aTIkFV/d+BdXf47eVJy
fMAt3w61iAnPh00dTasOc368QO2DsMsoiVyj6jBusU3Ra6IeIdlsLDwT0kCmOekaDe5RCubp4ZCJ
4MS3yVtWR5KpGaeq5rTxw4dwBUKRuiCYpf1uSoc5TAJtq33dlS8uzblzPVyQheV+6CR9BWGDPTAK
fe28Q5exUVsJGwesB/dnmBzvKNL/6IDwcBwRrIQls1fMZIagSqBOVscAvVxPgq4iWPBRUCFW6ekS
t+9/uYxC7ki2r+BosWe1BHlNmKCrtS4Fugq6+HUyO2RhtIu4Jw6c6h/Ghxc0WzQMzpbFaj6hAiRQ
a44o9YAd3sl4Mv3zXZr7+i63e1PtU/HagMFz0lno5JW4j61MRD+dqcKTiS312NOo+NTaDzT7mRdU
CV9mQyljBWGDn4Ynl02wazLzEIIltdGTyaYY7OkdQtLrRVJZb94rhbio4VyfWnojVAvDwkz3+gjt
4uLPIQhQZt6mG/ac/A+SS1Ca93dNv3EAkbMMIZ50nDwbscb+BqZCci/geVL+DOUb+KK371qOh4iV
UqCvA5RGBK+ii3PZgMYmORRvCiBxFdX6SFzCt1NRjK/YJH2c69719H1wuwNYI+WMHCZEm+E7z79a
UF/Ew/NAqNJpz+zVrfQm3YnSVEWP/07uKoVFzhZRrc+7iu8I7eR2NlMfglQDcDbd9PkUc/c+ZHrC
mDEDraN45YJtNeA6U08AXGFuxEY1hPLNb+DqmI35gmCIyAwlsQbBJ4rf91eezyqaqc2sIPp2Nzoy
5/Vk79tkwi9R561QOldhAWzWrnTNULiJW9E7Ox1VhLR8DdeQleCzcmeoEWq3toy4qrIlJZEqD5eC
ozyGQ1kssqkLzahTa6xFwBewcKlXqMYn6SVR4IIHc3udY+3YCKgg4zTvQqYV5VwDqBMOThrBajLM
hCGnANB6VSx4ws9ze0LG7fjOBDjQAkQS5K9rNQKMBogaEzzKN11vwTunHBO6N4dFDsl5z5CNnOmm
vgCdO20t9LexqEAIpA+Cc46hHzcpbXPMke5eKr3s34XRT5WpQ72hCUaGXTuocT31LwaaoArn11Cx
J5XXwRRxnXq72qewfgzfO1qjV4Vij8uisDNOCG5dCLtTQj63WFwtLn0voqwmZ5gasTxczCdwXeUs
fTZr+jn0/9R91K8hCsQ0MrakyKa6EuqDthBvJzhamPfi8kcjkuuYoPghlPejzyRp5okrYO0b0j+f
k4Yhym1AeJU9MHwGOCMS4bxKCAEZrFSkw/A2OxIq15SQfexJE6jqmvQoQXIcMDgmfmO6DHX+OSca
WKtqaomBWYFONYpCRYcRLfMf8/cDv4ENRG4egUBkmOAMTWJ/BF/7T1vzK2fka7DCQu1qGeQiKo42
pC43cUMmp6IQJ0y25DbSdkoJ5SSNczg/VtIVAiyYppY5DyyBY0vO8lPyBm0pZDbc67RCvaCFd+tL
fzc+gr0bsSb/UYMBbIi4fWDQ9nN0xZDm1qhSgpRiMBWYvvJFoW1pOPaGkWBSVGrQeQ8c1ZhEHFwD
AfF5UiCJirElcy+tw7xLWl/1HOXvbzZec3usrmdZoC3UxR6hwZlGA6bBBOOPMm+zaxz732Dtk7K2
paW=