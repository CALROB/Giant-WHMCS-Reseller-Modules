<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzivixK37mYwteCcbhveum5M4bAJBtrWpvsyYWyf7t+QvrepubTSMEEYG0ZY0aoGXh5wYr61
QUFpMlgu+wj5eMWGGdkf8EJVhPfTkTxI0Qwc73gVnLPsZNU1zSmW16ykdnKVqzwtN8ctPJUgEieP
t1aE0BDDa0dv/o7vxMvRA3EfoCL3G8jrfq0BS0MLz8juT1YOMqgvwtpIjHinGOkSYSONz4ZlzMlA
IV7AFuu2klARYgb7dle2gnaqkk2+Ns+I/g4CEfJ/WJyrUEnc2BG20389oMtFT9WvQLZXNgYm91wX
ZEvj5c5DRV+q+Bllp5/5/m9Zw21p+Y3T/bsII47aJ0vujtlf/wmWdjp/nJC+uwEqPBi3l/yj3zrY
LU7fiY6g76wYWWq+BNWKSmjtcYDDnxmWGJbJ3kz2hYfKCBa3IrRjQj8VRzhf7gh8mLQGbZ9o+a0N
RIRUhKEOCuWqTM3hWFrToHv0wTkLwSmU9eqphBKFnK3vy9BJi5Nki5+yvNxNCinA6I+m4NUwPSQa
tm6xzJTkU5BLunL3qtRtcWeYQOqBXDXrmn5rddhc5d9/TCGCgUiZGcQ3EPEDJvXmM4Vwpon96itF
V3G/NfwKTNWPVlSvSDYLFsQwKkRq0evGULxbZ7qoGvHaNdyh/z7fc7Smu7Y2r5UWzQCMLu5Ve/KK
6pk8CKS1GfxHAUXKARoopXT0SZgrzTHNkb8thpsUMa+OLkMYgxO/RdbEXcL76JSulOzI8zKHHC46
csQtFP3dPzpHy2pXYMaxnXiGhvQXLJrAFpKlcmGG6a1G8WirjAhj9EcqR3vo+sZI/Ypq3fVKLNCa
7BPU7iwvle2a+SP6h2TTsIjbuhEcVD5Y9gu3QtE9nCA9u03xNYZC+ABdSCM0zoNXnoP4WpRmCtJt
gQe/fGPVRyCj5Mo985wVG8SLD5lq0Lw24Q6+zZTQzC2vmqdf/CA6/uNv3blkDvLjAuszh1mHfkx3
PXVlwjDkTbAN+/tDX6WoC00UoRQ4mJ5Oqs3nFgzTA+OVUhkaJXwAQj4dNutv8T6sLihFeZWUAxvs
pMBaV5vroYc9+0ebN9W6yO2rPJ3Yz9ibjTFNwsm7+sLg1vrWCvvJGZad9lP5M0KSfT6a4d0wUjW5
2XVq9fyCK2Tq4Uxi/oZK8FQvd9slaOxYkGSqqY4zEk94beRzmFbU73ZNHlkb/w+TJV+Yy0==