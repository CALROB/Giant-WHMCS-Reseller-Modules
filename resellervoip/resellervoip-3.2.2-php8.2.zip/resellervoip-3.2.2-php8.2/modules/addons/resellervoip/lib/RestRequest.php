<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw07rH7PqIqceBr0CZFRb1KE4GDajUi9leQyma5I7AmFguazJVxKLhD5pbliN0KasqYrj2vK
431ygqOkTfyhzBiksvmACJDcAFs+kEnphiNNgfYZtrZb294s9/I7+4pmtV9Lh1Gbwb7HqUJd+AkZ
q1xm1Ln4VIDzl2sEyYb0Jsf/qn3z/IMzoaATnQn+Y3J7a0H/SmlBon4rt3b2thVbbtzXPEitzWbb
kicS7m0BEeD/g4hahYwkqCr24FfqEmPHy8aMgEDfWdDfFRm80MzCP6RgXNhniitUQeT14E6v75Vf
lRX+yo4DT0wrezFZMre6rKbskj2bIPGCMV2ywy3kuTncoIfu+UJSteRQ+uu5WfsDYn4VdPeSD74Y
oe97Zw+5/LT2DmZ4n3GX3kWe78FdpRQmrcvLVOAaZWOsfrJ7FRtcuDeoB7h2wBZan66CQj2yi6ut
oCRufS1xd+rIghE8kF3RwG6v6sRy8lxt11Zt714aNnIVOpLCPKfK5SZ5NmclyswIRL17fABjhDh6
TDe/ICouoiiPn1A05PZYEAN8+aZM1v1Ps2SqKq1pElqgHjxIb8unpd5AyLKPIFX9Ii2KHfkeHzvJ
sTSulS5bZPLoIqnGdmH0T8wpNwUrSv3Ql8AGl7XLC+HdKULqoE4K/tT2Zq6zlTGfgJvFd91rLOvw
hvfPWgK4cl/7Q69sYf1TdL0SofNa3vG5pxzWULRpch2hoDKksmtX59i5h/wZNV7lQPK/9cNdH2nV
HyqjZ373qZkIHqSR8gshNVvjAD+58cMz5CjF/xmF0sdEAYCloE193+pT0iOJ9SUW3CQ4uj5FeI1O
mqzsbut6ovWwbbce/1nW0LWXt2mPWXiaaSDj7NDYV/DonHMNeoNNICKt5Q2lcN6HwsmimcJ4vPJn
a4gs2mWoGqSzWDI6KEWmcdDwlE3JOntRem6wjXtgefQN6knp8P3yY/YnnK9UK4/Kp5s0JuqnoBPR
kv97qnbLqtzKx4sOc9lmwe4W6an6goG6Wn9L7Qm99twpHiiCAQFFJI9FDVbAnC+rjpuNusQ4c6x5
VwX6zkhPbKb4ol3x5jC9Zvy0CQnfg563LQ2l3vZJXYcKV41dibFTmsK/Vz4UgVTTcVZrv+YjJbJt
CGdjoJLFHfyK0m2X1mHGonZnz335i79wl8OiUqXnr1a8SvZ9ubbzKE6QXE1PYEKGvn+qq5NCVW==