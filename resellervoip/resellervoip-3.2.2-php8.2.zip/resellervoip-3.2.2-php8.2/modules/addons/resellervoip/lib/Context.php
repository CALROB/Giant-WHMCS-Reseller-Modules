<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv9ms4/on21WZyfDRBIBbaQN8zx1d3Xr3RsyMvZ3hQDoLr7v1mK86gxLj8lR1wtpNsFo3c37
zZrV28Kpq40u7weMZI3368BdSF2Qv341le/z98WiVgwZw0dyu3/EiaWcbgtQtrYr4EWctlI9XmDo
Fz8FGDFVGBdsG6Ma+QLYJfgs0BCiX9Auf0/x2GsRzbOXwG3w+WL6JIUXBXYx9VZ+Nd8KxN7mzDV8
5/mY8mBpCgmr9gW6aZknq8C5466lQwGBskrzr2iOcpyrUEnc2BG20389oMtFT9WTQInKPulZ+APB
HzPj5bbD3l++Rgq0Fx/4W7FFlRdRk61qmw6f8sbFzaeCtZ5qIIlMmc9Jh2GSSkW4w82c0aziDgSB
4arLeFUojMW7tk1ihCTLBeXHeitrEmXjctoTokp2SB6fXyGpFSSCPOIMzfbZdd2ic5ViSAPJYA6x
9MPp0o0FzOuccF+uNkhNXedyqpySct28xBdO0IHlm+wZYfkSc/YOAW7g9NIidyuGv7A98yAaR0zI
DEjecGdpiYjZSF7/GUf7IY9bJRwg3UCfsMKz64MwJIJNTEuDJh6LhviEWKInBkyL7RYaWV65Wjfn
vJ0jdCyW+r17zDVdzKQd1DrEtaNN022G4cpcCjp391x5CdSjjV/W0C16e2KW4sGJKPwK+WDFTox+
UDviBb/nZE3O2Yv4ReK/CyTVfzxr+LCRQV2xTNWivXXxeLYITbAouoFj+9d0qo95DaltEtkO5Qqw
ryWwi5pS+xkNVpVgukO0Uokv4uYecPgGnHJoJGSIl7WrCOYhy2K1SrRE/mXP/qZCjtcoLVl85DwG
tYJV7X8Fivx1jvB+6hSlY2+LPdOEOG/eUNF0JUF/YC+5X46V4UJN+KzznssZKBcDAmv9Ox2y/1Ke
9Kwn4nX0bhySafklqbB4vorG1n94n6kw9Rpvd0k7cndSXLs2NgEMX8yUqjg4Z+68vgTsxXsBsRB2
lQKRqE/xXQK5YLbziHkYS9ziQcXc6JBnQ1b9xj6If40OR6wzG7cK3yUKkm1DoBdlrigk+acGdAGP
/CBYnl1Ii0VwJ1/tqqtQ5c4siH18xxqblB73+38HtOH74lVieU4MCV8s/l1kDzTrDqkZVDEdthcG
PAN2iZisnl2iAlXLoCwpwT+jJ14/2yQzzqpzgW==