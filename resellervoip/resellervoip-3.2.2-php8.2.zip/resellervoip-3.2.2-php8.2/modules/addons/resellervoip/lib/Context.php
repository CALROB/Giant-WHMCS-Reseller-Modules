<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwl/8vgag5b/Yx553uVpKTyZkkxI3k2KNlb17f4PawDzkO5PBYhRUOVfTzBSmjl+LJUIExPp
PEEV+icW1zl3T/bmkC4Ql1bnT/fDMYYdRBkPbaDFEiOUjgrqTGs3UkW9dmfqpFrNgC+jDuGoObVW
B5acwmRX+GxPM5BHUAdEpiql/coMSOxC21xbpHFzKfbfw89pDmv0QBunCPdYd/UAGpbHTO17shDn
og1zvaL9lQ4+KgSAVzfOs3xrRoNKhw1uH8O11hp79vTpQJsy205lJ6HcweLwyRBDacy9DaBwRfzs
qp9sxl8P3G7/SZeCA9oWpPIUr/wCwjfv3owy0yU9Kbo/ekGUtqkb3faxzawQkP0guLD6Fezvfp0D
QP6jBhZtLBhdvf84uDg3YqzpQ1rte9qwan4deQfcAnWTpPboVtNNlUDb2KA3Exx4wFMvuE0mDYNn
OCrgIiMJkYQuWyuGwU1UGPTDe9UrqSpupfJKJCvi2wGEYa8KZxWU29Ixz8mYyTsUBo/HJLjFtRSA
McEG40Junz0vueINjnsX+H8PPRg6DlWRff6A9P1eD0GEG+tVRxEksmDNTEHbwE6sLxj9EpiI7ZXQ
n/PhcgV0ZEgxn5DCfRPZH+7GutDMXfKBfhNe0G2m4K0oUmD7HQIelcDSQ20iKmUPNfJ/P4PdAphq
mC3FqmuwbpW4wUlS2P8vMNiO+ma6bVUchb5re/QRzf48Glh3K6NL9fQ+UE9MptFR2UVaq589d+Yq
88ccp52k0f7acbr3fQGTUPKO3YIClHnXmeyxy8OfnGT9+9SoqF2C7XwNV1b0vKuEL/Angh3X/jR5
6/O3Kwd7/W1aOFgPmYJv63QmbIAv62d9s0miKrx85eLIJbhb2wLXAIx1JBlHFn5u6jq/pkUH2XM4
sBk8RPvoLqHytkxRShAra+CUo7ZlAsmdLI5gBdy/ovMmh+yz2GLbSQWujqBqRo1K1TYVPD5xaXO5
rO8Ueme+Oo0wzRTmVIFGeKVbny9HVIuLFsIjiQpsRt3EoxR/s+2eirAh04BHWNk87cW815iaN2rT
re5fNEmAEkCVFgDPdmRiVz1owpfwg5K+ECU7juApoeLv3Y+waTMcZB2j5dl4vaZXyZBlV28dCeNK
/8WZrzxN7gfIrCFzhkHrsnGEu7Lenw7ohwL3Pm4=