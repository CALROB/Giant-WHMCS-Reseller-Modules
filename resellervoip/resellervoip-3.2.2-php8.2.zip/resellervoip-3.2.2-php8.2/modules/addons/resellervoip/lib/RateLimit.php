<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyf0ygEJgyQKRlPdW8baz64pR+UdAiZ2wBkyjekqLIpX8XlkWJG/DdHWpkxw+uqvSjfM5QQB
T+vxhwCIBCiYMmrhpRzG63B71w6e2mvrs5zTsb/6uA41mT+d4YpFcQg4+cm3XohtDqG7VCJN/mlX
5nt8SZX8Qn2MNbug4zjqulynkGJTr2ng/X4MNzAwO/OA1INqzWaYEyA6NIW4N6oYSzjXiARlVDfD
DGVO3eg0dN5obO+PjnSEXDqdqBUlPPP9wqEz0+C0EJyrUEnc2BG20389oMtFT9XiQ9xwLMGeOfyR
0mkD5rXD3h6K0xKsjR9307HjDKIWL8iaBpA0h/4DQ56NhXs4z9BhL2GAOUmvUygldONBU/aUtira
No8UGHpvoz4lNknOwKr6nu/+2bD96Ify2ikwZm9Ed2E3VXo9RG8Iv4o18vVwUj2AWWuqy72IKOpS
UinIX5wvD5cU8OqdUC7rnIpApCiPUXlvbyKdKeYVp7GpOYH5tOD3Ko0iDKH824ZmDiSfYU6dImVj
35U1cGTUFjzX8BlRqkcEdHjDRsyPLMdVgINZ/RlGEOEJuBx5yOyCiDtYlUv+y+IDk+8Gq5Acld/B
JtxMkvi94PtD3nBw3RkYnn5cQrWhO2EnIbMZXi0LujzEQZcHAVaXjq2vMjk5RdbbiIFY/Tq/Aqc9
HBOgw6ygDgF05B1dQ+r1DWJlvZwyV2v+21B2tfA+fnmKZUfDZ9zm+G7jHb4kvHaR1Sbwbz68mSGA
+X+YffC8b3liLhKd05ZPS34sqLD43EQUOJs1HqvLzH7zzRk/fjFndUVIHUy9wxBfWLmFQvC4Tu9/
K1JZAaL7gBSqSQVXFNJdzKjCyArN3Ha8OLObw3udwFOJUhXvUUJFwEIR1WFWmrWkBYgfde6PRqU5
o2bE+ZDhPdM7NluO8g971nUPOsSGgVgn9Xn8qpjGiCouDpwBmSu6WDW1YqRiqUhNMTNbuoGR6rQS
B067Vn+3lcnEGpLwutP/6piG+Uq+ZBMF7obW2Z5L8g6wXLUMiIsNL0U6J7NgAsY+UbHEGZlPb1nC
AAT7kVCuB6fxugfJ7i5uZtmRFI1VQmR0BzNGV86i6s36FsP0fQo7wSuH3q7XaZkLJcD+xmCaekEH
9GwEOUpLY3xKCayqtDsKe9Qdlx2zlM4ULw/D8fRY86LiRgWtCBo1BrWQ++rq+Sej+NZtVhQzYXuJ
HWQdJeAdGwpfgzcpmx1VgSsKamxCLkqQI+ticE7DbJAZSM/8UPTIwFr/bjf5ziLbDqtmQCf+9ibo
y4tF7ijPUdBy0tpmD6LLDXrPR80wKncjbcvu1Q9iN/LVc6K66Cdf+P1RnrBdI6zTM/zGLi9YmKKN
GAbdVvXXdhVqOMWQze2xGP9+9RDS2qm8sQunUFDjXQWNEok2+yiXO0eG2Tp8Og7ijb9l54kEJXIg
jkPseXrmgdsy82rn9pd4JM5I+CjK1XOOgPtEwvO3eyMJ7ivWJsL7605uXdl2TWuWKY3tbZaeRSGF
tGnfnqsjkh9ZVPyj45hGX2l76eIVi98413XlR46rzNZGuHaA+Oyzu6TdWUOVc5K+Zz5lS2sYjD/I
VC1Wv7DskrmS2Tmmt0oXGhVtNSjf2+ackPWfyozOu9qTd2X1QSU7towVV/wPAPd8s95TNjqNYhKE
nitkVccO+bDrb52n/dGWQHceNKfWFSb7Co8Ot0m8cM8+5cUOHo2uMNuuwhjndhuwA9REtI8VihwM
tDhbgb0NmO2SqEHuL4YoyPtfL2+JP29TdaA0UK10wlQ7rBjp1+eHfcrrJWaTzLdzwfsbXzwd/4vr
B8aYrT+y8IvgkewtxXjFvKLZagGaIIEhKtULM8xFsJll6eZvUu3uJc+/M8S8dQcFhmEuc90pR7yi
1S7SR642llg9aLdey3XW4P3AiZwEMrX5THMUzN2TwbvGph/LpyxyvkmA0/PI+iWCHef2Z++D7ZPl
8o03MFUp8cA1odt0LpIs0Te4cNRjvmAJ8UmgslJ6o1e5yY4PpJYE5JyGzmQf88kB+sizXbRB6Yde
GYn4UPBK5Fz0cWp0GllP8DjTn4i+muP447KpHaxl+FamDw1aYZN5L4HO9FoGA+pmZEPFo5Xhlswd
kTe50ffhV3MME+/tjl+C/Yw8tOnPFaabZkUDvGP9TM+AdpPT4FTKoF8MetrO2li90pJxgPnwRdE1
jvthJEXDFgHiYx/orhCuZbLo4hEgRhoSizQuy72l9YkFQyP0acoeW475clGq7n+gLPX8o8UbRoCR
/NrjCObumVKUkvCcrMvFzopYOkMx0jLX+AfbbB6p6gPsqOOETwX+feubLp5aNuBHhu5jO2gLgcuG
GwUFSqi29X7qpiYsVCu1i498oDRWwlGFsxyt887IJbDdMyrrUHSSjTBPg/DTqQRK6tfmkDLqym77
/r/Xegmh4l+7B0==