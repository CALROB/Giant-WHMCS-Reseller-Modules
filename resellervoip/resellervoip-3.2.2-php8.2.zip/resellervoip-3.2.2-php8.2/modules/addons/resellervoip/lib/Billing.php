<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzqaaWpo3MSZZv47B+q3FPItt61Zgc5uPQQy1xEQhaK7IN5Lz1IJunqWkrSfaoY0Mrpr3Dil
slEK2n0HYnkEvV8izmpcv7uNwx2XyQHU9qejJZSaQ+hZxeSgSiDPykpL8OSYVO3MuQwlrOyTSeOt
vAWe/iJBhRjBPwsy0Oj0hnuw1yRCy8VYv0pWaW23ga517AyalXTfN8e1NsM7VwDaHgB5vuZc8Yv7
dWHXndoBlUcQ2zu3e8avcgK52Wq8LZ1CZhCC44cYJtDfFRm80MzCP6RgXNhniirzPReXhpYTkyim
U+S+SI0DIF+ELiV8y29nGSNwJ2EEl50Z6nQqLAIgqM63ioD9OvoILJzWSES5FsOl3/lcU00MCf7/
Bwm7Zi1kpzgiAherSc7gLWAj6+JBOyUUKJy+Yv5wbVcKaFvbZRvNj/XuMJqqmCGdWSOsoPWIAHjg
XscXELwCyDJM024RWZQXm+1d6LaxD3QZcjVEWhdmLS6UTQmXdVerS1nztKTQJyevVJWEIB7+vEI/
8TsnJWftlScFhN1zD0hhkrmau0nbn1eWUZfzsn4frznHqLZWCnM01jVQD5tAkOe7xMKXOBraac44
71AKNowzxiMI3CQmRK5cZEg/YVd55tHLkRsp2OqVSB2GuGHG/oh7/nCuWIlu/ShCs28m07hlTZQ3
aNNr4YL0nobePighRNPavNHMWTFOS0gt/PQo8p5kMzCM4SsqDbLssLKF3S6tuuk4/5PKM3Ri8fH3
7wRtnhIJjxX2AIuUJP+2WKybqeuZmOPFUB4mUtf/qE/XVs3a2eDCzpFHRocnRTQuyNPjkZCzKsDT
coFaDpL5PyMmAX+9PXLT8Kp+fygdtlQnyRIS8iqKqfKKyW/ZVm/AqpMA2j8fYxN+VBslGwpOyhB/
s5aovs1aj+v8ct9nBsoYtu0w8MDP9CBc/PB4lX++x3fLtVurSE5F5eHaHx3+cWT5ohraSfVevdHr
6FbCaW5a3IN/pARIW8esvzdYFqJEVtCkEt1qr1vzYXhCNIUeC8wUxbQRVrDMO0hjmK2PY2vZvGth
OSIOY3Ix+L7GOgvypBrgNuAR5KQBR7AZRCzpfyM0OJisFoGQnGxsuVymNWMIpyGxIKZ6T0XWgyve
HIzBOV0FEkJA7b+jGlqWI6DyObdLjyRuJrX6Q6mObPXKDeWe7g5Z8ybHHdiCCmFzno0KsqheFeNo
5luDpvtYAbrsIXcIE+I9vnLy6/WxZPPn0pU9eG+zLvu/w+Un0yoDpJ85jZSmFNQgWYi+p1ad15fJ
zW3Bj4oCExytJE5P34vANA7Ewpb9oWmStLtaZj/y9wh98i0qFdsFP3EzWMShYc7nWVUmUiGTQdF7
i7Xe7P/yWFv+mu1dlqril6Z3ACw6X3zvpaiAwy76f25zBhYNhPh0qlP/yskJo16wgJMo2iwNcOzi
94L0oW3SRPlaKOR7b3+0JesbeCPm4jBm4YCzItWSWu56AnTppn8DNafLZr2pkhNSEPxvTO46LKgg
iYM1ll9RjKE03UbrnCLHN39xdIi0IBwiVjWrcMshsggVPiBfZnH4ibeB/35AAanmMVfCBLpSQsAO
QXa4Vk9fKFJJj2qR1xHOyVhQS7JY+8ymsXkuW2EG4N8cQ0y9r2ErnvYAcQ5Q/gW3d6TgoYj+4Aem
VIlTK5la/Lhl/5GBDHU1/Uu+7vPle/jJOIKqLKCGsU5jq/Yk0m+S1V2Qlps3UYVjBgSOJMr+UQWC
0L3xhKsa5uC8Yxb6LXhR3GAHfCjlGG+XFZkJYGXG9+5re6C2aQt3ovyY3FMVQntS+Y1zDndoT9LA
2MRQfTSM9gNOLfJu62L5REzrHMmqR2w1OIkw3mWgfico1lF/xmR5lJMZXje7SXbMkDkH3MHMhC8F
G2iZuXhJuz4G6Gnjpv3YE/2WY6lJoued7Khk0McEJB5Hq9qcsGLt4hmwsBqCeklgGSVqeUixMLU3
a9Dfm15DmbsIkNlZwoB6AVW7dk/VxIHRYSYPYnHMsDOOdMUFfa65VhMMc/A1Nr4zRYqLWiUlmFh5
YefWdmfrOhnBwDnAEs3ZhNE2xKUP8D143yMfWrILeEzIQeNUh5ZFsklorgGhGhE0XFM7wBD8dQ6H
