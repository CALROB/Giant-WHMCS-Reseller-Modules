<?php //0032b
// Giant Reseller Phone System addon 3.2.2 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsRmhtWgMHH/DqKwMnyCo+jO7FwQZqO4i+vsH/tGCQJD7nGLoHiE3WYU3SlEdZBsBLxIcufl
8lKbht2KR9tIc2EsfISzWbzMx9yItvQi+AzvaDm47yzms+oesrmFswYAZKalMVWDwKsQn039SRiH
A/GSRmeSHG+1plgjV49dzlV8rqjy0h/buYnk5ynrbKNoABD5JBTwhoW3QKNu/6OIphhSoFqdKTsC
jY0R7/6+e6JTdkfnIe+d5C1biYbM/0N4UKMFu6S6EPe/DNZiPWYq0W0o2SbjptIOwMYtyeNObdGV
mBjZRPPVJN1b7VXS/M62SjV5cFRnSjcqJNNgbpKmkDw8C2pz84k4OYMbNBKa6LOHBQMCEIaCbb3O
zHHyaikY/AvZapOV/k+7YGBhyxm0rri5hsJYm1nt42tKKBbjt1edsIiSh9sMqL7LrcQ1NScGDmMP
vEZ/00Hsbo44Gc2h3UbzHnKlqjt4MVDMBJGhJycBeq8X8UW3dHruHdgIhOyZLGGho49foWqSWjBi
xa7PQOlyZ5bjCOfTFxPodSqWW3vZFN4tlNesbgSXC7UU0Xx5NnG0Pn4Gik12rxHzATM3Jqn560CR
2vhfzPKfdC5qI3Fn70QJB/UT0hObEmgZVlE4TwmP1+1RmENyqkTMRm5GZ+vY/Ga91eifjTZcZ2sz
JB/rFi8n+7dHWdWzMkm7IOmde0QL/vD9JGMJ+CZGOoazuTaaI7d8Cxrq0PVcaght6sgRODFZMoT0
Pyq4SkMtHmTD8AC0rV3zZRFq0fudSQYwZVA3/Ju4vhITUMFKjVCX9qd8vgg0Yj77KZzPDVY8Bm6/
p33QXatxjwqz8cLImaazyvQmcz1taXRWxBH1c4/fIB2obqcxrVIA66BN/81WYvUAcSX2acHgDLqn
iaVxcdQ1OPa8EUjN3/t4qUvXQk0fvQVJZGH2cP2Lor3yYff7fQueP1U/4rhV0++N1QDPIj9D5zxm
UvPiZHq3nel/cyHLjluN/mw92ig/hcB6XcSn2kt7cA2vMU9kq27Mt2DTxWsk91lFmm+cYZDG3FBP
HHScIy/5r3STLwF/CUZT6MZCWlCr2OKRHlNgGdrXc51BFRG+UQ6g0qKzaf77dzed3/Wk7ax8eQ9E
VEyBcvDFSTZc2CcLKsn2a4UFmOrHpodvdIhMG4xGwWbTBkAwcd2g7az6VzlN84pCpQxhC/qJauUO
3yCx8LYt7W4lGRukOsa0XJUeJbGlQgNnGCMttXZI0LafOL2m/ifLjqw8YWfbWDX7R1ECuQQ7Nx2a
xKuuOsrecIxJx04RMCFlCculITU5tzum6q3j4HicuhgscI29W4Y4h+mGzmJ/dZc2g2yuHnVqIlT8
K3bvP/4HIK1zqQ0GHolAMv3EJSp1P6NIC2q1zuJO9uHVlSGYE7YIFME9cgx9cBRnsRKpccllB9kE
fofSyQaJDgpBpbZ3bdDFp2rgaPoFouKXl5BpAVGzoYnG3hvZ39++q/qgK0kighq/a3d4GpHgpwkx
0bMxBkjmgFWJjD9Vo5/yIUyr9TPnJjsJu30J6pJpzZS93ZTINZzk+G29u2uuo5VEcAjBjgOGZSB0
EgCn6ea1WWW4z/D40KKT7alodzmxBzP0XdNCWosLTqRDxAQt8Hia8WGV0OVRkuz0ooYrPecuHftu
lgo7UWvzYW14QaHBRhpXQsfSoGzqYzHJhNePv8G1Nttw13xfUH1sxBV0paC0+09CjV2P0ax/b+Hu
Qtl3zRZpVdDo9ey1EpJ0yrMfcw28yky13Uhapl1EbwQvmWbq970GRseIft7WnUboqx01oX2IeVyq
WGqGIK4SmCTvYxSHQxDXdidpQbZSvaBDTKz2mpNRw0SleYmfMKDPZUx4L1ccyX1g56GugZjW4r/F
IldB8QAuRZqCEkfHtXKCOByB8g2UzDsW3+TetjmKHvCsLs+Xdj6jy8bFVqecS5jCX12uKHKLHaW7
RVhbVFaraHLU5OrhSC4PS/50WFkjTa9dXFzOj9izqvvvNH84U6+KK/1mUJWNk+9Q4ONWizWbEHR6
7aVsXVTIu/S8Tr/8ijKiuSLqplODwWE2odhjL/Ou4QLYyNKhA9aZL7YhpKyKTAhdnLk9IZ4V3geZ
c3ZK