<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs+lbzBNZcpbgXG2yO7TTbREOfD2VvkJpOyxwFcSCM/AB66hPO6XTGAFtmqhy2RDjcl4CIJN
qyk3huUoiFc3eLJ1Z8uzedwg64sYgdTO5humqDRe/LRe0M7bHgjVYRt+nrssRVs+Yz7CBFmXFuoH
967UahSGNjkQZgjLNotUVrDTGftOe3Jv8rt06WDVela8MX3Eh7Zfhz+0urWFITawX33/A7bpCfgN
2m1KLM0QHvbbCWifnfpDri+yvdzHAEYf3A9Hc7r/re4MmpI83rlxb5cuKBUob0K53RN/IAbm1quo
uvgLN8qMM4kDY+yz3/nKrvAqJnbKLae4doBhH9qOQzuzCrLf0zzpq69nYxsUOgrwJuQEjXiiwBvt
54NNmoMswwXDbO3a1tT9nMe38fnEsuIKcl7y4aI6zigJseSg9/QZcsTUjlTAznfKr3A0G72D9A+3
3oTSbjWm4PtGeVMJim4/k/kD2PQcS5lQacEVU+1xeCFPuXJWHLEvJrlTdrCXwJ6kp+U49+zXyBUD
syjF0uzzhJkvBAFdo+bCyLkYE1ueAAqvA8D1UpLrj8jsHI8GQDo50/ybBdXKOarqyyu9an5RNa06
iFyo3//zAc701oCwCgjQzZw9Ek3YSEBPsb2BfrWGVQZUO+/MK5krjU93kiQA3mLf+tj0rNu9DilR
Iluz4HydgpvLSH86uOUpLUF7bzc7l78YGfiVvJaB1IIoJHJqIknUBgjs/lZElJNutJ1lYpVX8sJe
IGvEti7sboFVzvGGbhOFPzOtSS3eY/vhu+Ct/3ad9Tj4jvRXiDY3XL5U4mYyx+kNHoQSIrgWXoPg
MqHVDfwUaZHSlQdAZoEKhiCRUsmLsIhBOmvyLRYBptS6rdST95xBPdEdBk7mIccmqq1PMhk2Duw0
9FN44V9dE9dmVcHNGUqliI0O2eRrZKfMIi+zJl2PiyEeoN3lE2HO93A2XYUK20iaA6zLtU1bKn6p
WKzTtHQWHKSYhO2LEIWe6sv53eMyQ0lIbgq68iHjNW3oAo+dKOtVWnAb3K/CPFCe/3HH/w+csU9H
B4dxiHljrNOdzOOil4fWZ7jtlt/D1FODdfeCOOkGEjt7BYJwG83Wc973XLRYbwivcbCif24P5Zjw
V0Kq/tGmhtJj2Q0emtp2d9/8mPbf/LB0Krqg1xDsfcAayeWxLNi8FQjWjhPSY/tcHXgnbzt9g+Gv
Yanh/kDQxzTj5yS71M31+NndzpCWVOjk7TyroyrDwMtpY3FoRMilykaDR/2vuWBBpzVrz0qmfbze
4by=