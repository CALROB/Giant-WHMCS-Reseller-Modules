<?php

/**
 * The customer-facing wording the addon's own code uses (notices and
 * refusals). The portal pages' own labels live in templates/client, which
 * you can edit too. Copy to <language>.php to translate.
 */
return [
    'setting_up'          => 'Your phone system is being set up. It will appear here once it is ready.',
    'unavailable'         => 'Your phone system is not available just now. Please try again later.',
    'no_services'         => 'You have no phone system services yet.',

    // Refusals and errors the page script shows
    'session_expired'     => 'Your session has expired. Please sign in again.',
    'action_not_allowed'  => 'That is not available on this service. Please contact us if you need it.',
    'action_refused'      => 'That could not be done. Please check the details and try again, or contact us.',
    'action_try_later'    => 'That cannot be done just now. Please try again shortly.',
    'action_failed'       => 'Something went wrong. Please try again, or contact us.',
    'please_wait'         => 'Too many changes at once. Please wait a moment and try again.',
    'not_found'           => 'That item was not found. It may have been removed.',
    'unknown_op'          => 'That request is not recognised.',
    'service_not_found'   => 'That service is not on your account.',
    'service_suspended'   => 'This service is suspended, so changes cannot be made.',
    'service_not_active'  => 'This service is not active.',
    'method_not_allowed'  => 'That request must be sent as a form post.',
    'disa_pin_short'      => 'A dial-in PIN must be at least 6 digits.',
    'number_premium_blocked'       => 'Premium-rate (09) numbers cannot be used as a destination. Please contact us if you need this.',
    'number_international_blocked' => 'International numbers cannot be used as a destination. Please contact us if you need this.',
    'number_nongeo_blocked'        => '084 and 087 numbers cannot be used as a destination. Please contact us if you need this.',
    'upload_failed'       => 'The file could not be uploaded. Please try again.',
    'upload_too_big'      => 'That file is too big.',
    'upload_wrong_type'   => 'That file type cannot be used here.',
    'integration_signin_unavailable' => 'Signing in to that system is not available yet. Please contact us to set it up.',
];
