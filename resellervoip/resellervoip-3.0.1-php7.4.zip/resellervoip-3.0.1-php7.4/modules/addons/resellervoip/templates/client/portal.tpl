{* Phone System: the customer's phone-system page, run through the reseller's own WHMCS. *}
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/css/select2.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/js/select2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.13/flatpickr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.13/flatpickr.min.js"></script>
<script src="{$assets}/js/inputMask/jquery.inputmask.js?v={$version}"></script>
<script src="{$assets}/js/jquery-ui/jquery-ui.min.js?v={$version}"></script>
<link rel="stylesheet" href="{$assets}/js/jquery-ui/jquery-ui.min.css?v={$version}">
<script src="{$assets}/js/jquery-signature/jquery.signature.js?v={$version}"></script>
<script src="{$assets}/js/qrcode.min.js?v={$version}"></script>
<script>
    window.pbxConfig = {$pbxConfig};
    // Port charges (ex VAT) from the addon settings: index.js builds the port
    // modal descriptions from them, so they must be set before it loads.
    window.giantPortPricing = {
        geographic:    "{$portPricing.geographic|escape:'javascript'}",
        nonGeographic: "{$portPricing.nonGeographic|escape:'javascript'}",
        mobile:        "{$portPricing.mobile|escape:'javascript'}"
    };
</script>
<script src="{$assets}/js/pbx-shim.js?v={$version}"></script>
<script src="{$assets}/js/index.js?v={$version}"></script>
<script src="{$assets}/js/teamsGuide.js?v={$version}"></script>
<script>
    // Feature gate for the external ("AI receptionist") agent provider, read by
    // aiAgent.js when building the AI type picker. Must be set before aiAgent.js.
    window.gvFeatureVoiceAgent = {if $gvFeatures.voiceAgent}true{else}false{/if};
</script>
<script src="{$assets}/js/aiAgent.js?v={$version}"></script>
<link rel="stylesheet" href="{$assets}/css/aiAgent.css?v={$version}">
<link rel="stylesheet" href="{$assets}/css/index.css?v={$version}">
<link rel="stylesheet" href="{$assets}/css/dark-sweep.css?v={$version}">
<link rel="stylesheet" href="{$assets}/css/pbx-shim.css?v={$version}">
{if $sandbox}<div class="alert alert-warning" style="margin-bottom:12px">Sandbox service: changes are checked but not made.</div>{/if}

<!-- ===== TODAY ===== -->
<div class="giant-section giant-today" id="todayStatsSection">
    <div class="giant-section-header">
        <div class="giant-section-title">
            <i class="fa-duotone fa-chart-mixed" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
            Today
        </div>
        <div class="giant-today-updated" id="todayStatsUpdated">
            <span class="giant-today-pulse"></span>
            <span>Updating&hellip;</span>
        </div>
    </div>

    <div class="giant-today-kpi-grid">
        <div class="giant-today-kpi" data-accent="total">
            <div class="giant-today-kpi-head">
                <i class="fa-solid fa-phone giant-today-kpi-ico"></i>
                <span class="giant-today-kpi-label">Calls</span>
            </div>
            <div class="giant-today-kpi-value" id="kpiTotalCalls">0</div>
            <div class="giant-today-kpi-sub" id="kpiTotalCallsSub">0 out &middot; 0 in</div>
        </div>
        <div class="giant-today-kpi" data-accent="outbound">
            <div class="giant-today-kpi-head">
                <i class="fa-solid fa-arrow-up-right giant-today-kpi-ico"></i>
                <span class="giant-today-kpi-label">Outbound talk</span>
            </div>
            <div class="giant-today-kpi-value" id="kpiOutboundTalk">0m</div>
            <div class="giant-today-kpi-sub" id="kpiOutboundTalkSub">0 answered</div>
        </div>
        <div class="giant-today-kpi" data-accent="inbound">
            <div class="giant-today-kpi-head">
                <i class="fa-solid fa-arrow-down-left giant-today-kpi-ico"></i>
                <span class="giant-today-kpi-label">Inbound talk</span>
            </div>
            <div class="giant-today-kpi-value" id="kpiInboundTalk">0m</div>
            <div class="giant-today-kpi-sub" id="kpiInboundTalkSub">0 answered</div>
        </div>
        <div class="giant-today-kpi" data-accent="combined">
            <div class="giant-today-kpi-head">
                <i class="fa-solid fa-clock giant-today-kpi-ico"></i>
                <span class="giant-today-kpi-label">Total talk</span>
            </div>
            <div class="giant-today-kpi-value" id="kpiCombinedTalk">0m</div>
            <div class="giant-today-kpi-sub">so far today</div>
        </div>
        <div class="giant-today-kpi" data-accent="rate">
            <div class="giant-today-kpi-head">
                <i class="fa-solid fa-bullseye giant-today-kpi-ico"></i>
                <span class="giant-today-kpi-label">Answered</span>
            </div>
            <div class="giant-today-kpi-value" id="kpiConnectRate">0%</div>
            <div class="giant-today-kpi-sub" id="kpiConnectRateSub">0/0 answered</div>
        </div>
        <div class="giant-today-kpi" data-accent="long">
            <div class="giant-today-kpi-head">
                <i class="fa-solid fa-stopwatch giant-today-kpi-ico"></i>
                <span class="giant-today-kpi-label">Calls over 5 min</span>
            </div>
            <div class="giant-today-kpi-value" id="kpiCallsOver5m">0</div>
            <div class="giant-today-kpi-sub" id="kpiCallsOver5mSub">0m talk</div>
        </div>
    </div>
</div>

{if $setup.show}
<!-- ===== SET-UP CHECKLIST (until the account can take a call) ===== -->
{assign var=stepNo value=0}
<div class="giant-section giant-setup" id="giantSetup" data-tenant="{$tenantId|escape}">
    <div class="giant-section-header">
        <div class="giant-section-title">
            <i class="fa-duotone fa-wand-magic-sparkles" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
            Let&rsquo;s get your phone system ready
        </div>
        <button type="button" class="giant-setup-hide" id="giantSetupHide" title="Hide this checklist on this device">Hide</button>
    </div>
    <p class="giant-setup-sub" id="giantSetupSub">A few steps and your first call rings through. Do them in any order.</p>
    <ol class="giant-setup-steps">
        {if $setup.extEnabled}
        {assign var=stepNo value=$stepNo+1}
        <li class="giant-setup-step{if $setup.extensions > 0} is-done{/if}" data-setup-step="extension">
            <span class="giant-setup-num" data-n="{$stepNo}">{if $setup.extensions > 0}<i class="fa-solid fa-check"></i>{else}{$stepNo}{/if}</span>
            <div class="giant-setup-text">
                <strong>Add an extension</strong>
                <span>{if $setup.extensions > 0}{$setup.extensions} added{else}A person or desk that can take calls{/if}</span>
            </div>
            <button type="button" class="giant-setup-btn" data-setup-open="extension">{if $setup.extensions > 0}Manage{else}Add extension{/if}</button>
        </li>
        {/if}
        {assign var=stepNo value=$stepNo+1}
        <li class="giant-setup-step{if $setup.numbers > 0} is-done{/if}" data-setup-step="number">
            <span class="giant-setup-num" data-n="{$stepNo}">{if $setup.numbers > 0}<i class="fa-solid fa-check"></i>{else}{$stepNo}{/if}</span>
            <div class="giant-setup-text">
                <strong>Get a number</strong>
                <span>{if $setup.numbers > 0}{$setup.numbers} on your account{else}The number people will ring{/if}</span>
            </div>
            {if $numberAddonUrl}
            <a class="giant-setup-btn" href="{$numberAddonUrl}">{if $setup.numbers > 0}Add another{else}Add a number{/if}</a>
            {elseif $gvFeatures.destination}
            <button type="button" class="giant-setup-btn" data-setup-open="destination">{if $setup.numbers > 0}Manage{else}See numbers{/if}</button>
            {/if}
        </li>
        {assign var=stepNo value=$stepNo+1}
        {assign var=routeDone value=($setup.numbers > 0 && $setup.unrouted == 0)}
        <li class="giant-setup-step{if $routeDone} is-done{/if}" data-setup-step="route">
            <span class="giant-setup-num" data-n="{$stepNo}">{if $routeDone}<i class="fa-solid fa-check"></i>{else}{$stepNo}{/if}</span>
            <div class="giant-setup-text">
                <strong>Point your {if $setup.numbers == 1}number{else}numbers{/if} at your team</strong>
                <span>{if $routeDone}{if $setup.numbers == 1}Your number is routed{else}All {$setup.numbers} numbers routed{/if}{elseif $setup.routed > 0}{$setup.unrouted} of {$setup.numbers} numbers left to configure{elseif $setup.numbers > 1}{$setup.numbers} numbers to point somewhere: a person, a group or a menu{else}Pick who answers: a person, a group or a menu{/if}</span>
            </div>
            {if $gvFeatures.callFlow}
            <button type="button" class="giant-setup-btn" data-setup-open="callFlow">{if $routeDone}Review{else}Build a call flow{/if}</button>
            {elseif $gvFeatures.destination}
            <button type="button" class="giant-setup-btn" data-setup-open="destination">Set a destination</button>
            {/if}
        </li>
        {if $setup.appEnabled}
        {assign var=stepNo value=$stepNo+1}
        <li class="giant-setup-step{if $setup.app > 0} is-done{/if}" data-setup-step="app">
            <span class="giant-setup-num" data-n="{$stepNo}">{if $setup.app > 0}<i class="fa-solid fa-check"></i>{else}{$stepNo}{/if}</span>
            <div class="giant-setup-text">
                <strong>Invite your team to the app</strong>
                <span>{if $setup.app > 0}{$setup.app} {if $setup.app == 1}person{else}people{/if} on the app{else}Sign your people in on their phones and laptops{/if}</span>
            </div>
            <button type="button" class="giant-setup-btn" data-setup-open="voiceCloud">{if $setup.app > 0}Manage{else}Invite to the app{/if}</button>
        </li>
        {/if}
        {if $gvFeatures.extension}
        {assign var=stepNo value=$stepNo+1}
        <li class="giant-setup-step is-checking" data-setup-step="online">
            <span class="giant-setup-num" data-n="{$stepNo}">{$stepNo}</span>
            <div class="giant-setup-text">
                <strong>Get a phone online</strong>
                <span>Checking who&rsquo;s online&hellip;</span>
            </div>
            <button type="button" class="giant-setup-btn" data-setup-open="phone">Set up a device</button>
        </li>
        {/if}
    </ol>
</div>
<button type="button" class="giant-setup-restore" id="giantSetupRestore" hidden title="Show the set-up guide again">
    <i class="fa-duotone fa-wand-magic-sparkles" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
    <span>Set-up guide</span>
    <b id="giantSetupRestoreCount"></b>
    <em>Show</em>
</button>
{/if}

<!-- ===== TOOLS ===== -->
<div class="giant-tools" id="giantTools">
    <div class="giant-find" id="giantFind">
        <label class="giant-find-box" for="giantFindInput">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="search" id="giantFindInput" placeholder="Find a tool, a number or a name&hellip;" autocomplete="off" spellcheck="false" aria-label="Find a tool, a number or a name">
        </label>
        <div class="giant-find-results" id="giantFindResults" hidden></div>
        <p class="giant-find-empty" id="giantFindEmpty" hidden>Nothing here matches. Try a plainer word, like &ldquo;menu&rdquo; or &ldquo;ring group&rdquo;.</p>
    </div>
{foreach from=$tileGroups item=g}
    <section class="giant-tools-group" id="tools-{$g.key}">
        <div class="giant-tools-eyebrow">
            <span class="giant-tools-eyebrow-label">{$g.label}</span>
            <span class="giant-tools-eyebrow-blurb">{$g.blurb}</span>
        </div>
        {if $g.key eq 'routing' && $gvFeatures.callFlow}
        <div class="giant-routing-hero">
            <div class="giant-routing-hero-text">
                <div class="giant-routing-hero-title">How should your calls work?</div>
                <div class="giant-routing-hero-sub">Draw where a call goes when someone rings: who answers, what callers hear, and what happens after hours. Menus, ring groups, queues and voicemail are the ingredients. The flow puts them together.</div>
                {if $setup.numbers > 0}
                <div class="giant-routing-hero-state{if $setup.unrouted > 0} is-warn{/if}">
                    {if $setup.unrouted > 0}<i class="fa-solid fa-triangle-exclamation"></i> {$setup.unrouted} of {$setup.numbers} numbers {if $setup.unrouted == 1}isn&rsquo;t{else}aren&rsquo;t{/if} routed yet{else}<i class="fa-solid fa-circle-check"></i> {if $setup.numbers == 1}Your number is routed{else}All {$setup.numbers} numbers are routed{/if}{/if}
                </div>
                {/if}
            </div>
            <div class="giant-routing-hero-actions">
                <button type="button" class="giant-hero-btn" data-setup-open="callFlow"><i class="fa-duotone fa-diagram-project"></i> Build a call flow</button>
                <span class="giant-hero-soon" title="Coming soon"><i class="fa-duotone fa-wand-magic-sparkles"></i> Describe it in plain English <em>Soon</em></span>
                <span class="giant-hero-soon" title="Coming soon"><i class="fa-duotone fa-layer-group"></i> Start from a template <em>Soon</em></span>
            </div>
        </div>
        {/if}
        <div class="tile-grid">
        {foreach from=$g.tiles item=t}
            <div class="tile-item">
                <button class="tile{if $t.beta || $t.pro} has-badge{/if}" id="tour-{$t.key}" data-name="{$t.key}" data-toggle="modal" data-target="{$t.target}">
                    <span class="tile-icon"><i class="fa-duotone {$t.icon} fa-2xl" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i></span>
                    <span class="tile-body">
                        <span class="tile-label">{$t.label}</span>
                        <span class="tile-state{if $t.kind eq 'count'} is-count{/if}" data-tile-state="{$t.key}">{$t.state|escape}</span>
                    </span>
                    {if $t.beta}<span class="tile-badge">Beta</span>{elseif $t.pro}<span class="tile-badge is-pro">Pro</span>{/if}
                </button>
            </div>
        {/foreach}
        </div>
        {if $g.advanced|@count > 0}
        <div class="giant-tools-advanced" data-group="{$g.key}" data-open="{if $g.advancedUsed}1{else}0{/if}">
            <button type="button" class="giant-tools-advanced-toggle" aria-expanded="false">
                <i class="fa-solid fa-chevron-right"></i>
                Advanced routing
                <b>{$g.advanced|@count}</b>
                <span>{foreach from=$g.advanced item=t name=adv}{$t.label}{if !$smarty.foreach.adv.last}, {/if}{/foreach}</span>
            </button>
            <div class="tile-grid" hidden>
            {foreach from=$g.advanced item=t}
                <div class="tile-item">
                    <button class="tile{if $t.beta || $t.pro} has-badge{/if}" id="tour-{$t.key}" data-name="{$t.key}" data-toggle="modal" data-target="{$t.target}">
                        <span class="tile-icon"><i class="fa-duotone {$t.icon} fa-2xl" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i></span>
                        <span class="tile-body">
                            <span class="tile-label">{$t.label}</span>
                            <span class="tile-state{if $t.kind eq 'count'} is-count{/if}" data-tile-state="{$t.key}">{$t.state|escape}</span>
                        </span>
                        {if $t.beta}<span class="tile-badge">Beta</span>{elseif $t.pro}<span class="tile-badge is-pro">Pro</span>{/if}
                    </button>
                </div>
            {/foreach}
            </div>
        </div>
        {/if}
    </section>
{/foreach}
    <div class="giant-jump">
        <span class="giant-jump-label">Further down</span>
        {if $gvFeatures.extension}<a href="#extensionStatusSection"><i class="fa-solid fa-signal-bars"></i> Who&rsquo;s online</a>{/if}
        {if $gvFeatures.phone}<a href="#phoneStatusSection"><i class="fa-solid fa-mobile-screen"></i> Devices</a>{/if}
        <a href="#billingSection"><i class="fa-solid fa-file-invoice"></i> Billing history</a>
    </div>
</div>

<!-- ===== THIS PERIOD (charges + inclusive minutes, one card) ===== -->
<div class="giant-section giant-period" id="periodSection">
    <div class="giant-section-header">
        <div class="giant-section-title">
            <i class="fa-duotone fa-calendar-range" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
            This period
        </div>
        <div class="giant-period-meta">
            {if $currentBilling}<span>{$currentBilling->dateFrom} &ndash; {$currentBilling->dateTo}</span>{/if}
            <span><i class="fa-duotone fa-calendar-day" style="--fa-primary-color: rgb(var(--muted)); --fa-secondary-color: rgb(var(--muted) / .65);"></i>Next invoice <strong>{$nextDueDate}</strong></span>
        </div>
    </div>

    {if $currentBilling}
    <div class="giant-period-grid">
        <div class="giant-period-charges">
            <div class="giant-period-big">&pound;{$currentBilling->amount|number_format:2}</div>
            <div class="giant-period-big-label">Call charges so far{if $freeMinutesUsage && $freeMinutesUsage|@count > 0}, after inclusive minutes{/if}</div>
        </div>
        <div class="giant-period-stats">
            <div class="giant-period-stat">
                <i class="fa-duotone fa-phone-arrow-down-left"></i>
                <b>{$currentBilling->inboundCalls|number_format}</b>
                <span>calls in</span>
            </div>
            <div class="giant-period-stat">
                <i class="fa-duotone fa-phone-arrow-up-right"></i>
                <b>{$currentBilling->outboundCalls|number_format}</b>
                <span>calls out</span>
            </div>
            <div class="giant-period-stat">
                <i class="fa-duotone fa-clock"></i>
                <b>{$paygSummary.minutes|number_format}</b>
                <span>minutes on calls</span>
            </div>
        </div>
    </div>
    {else}
    <div class="giant-empty-state giant-period-empty">
        <i class="fa-duotone fa-chart-line-down fa-2x" style="--fa-primary-color: rgb(var(--muted) / .55); --fa-secondary-color: rgb(var(--muted) / .35);"></i>
        <p>No call charges in this period yet. They&rsquo;ll appear here as calls happen.</p>
    </div>
    {/if}

    {if $freeMinutesUsage && $freeMinutesUsage|@count > 0}
    <div class="giant-period-divider"><span>Inclusive minutes</span><em>Reset on your next invoice</em></div>
    <div class="giant-freemins-grid">
        {foreach from=$freeMinutesUsage item=fm}
            <div class="giant-freemins-card" data-state="{$fm.state}">
                <div class="giant-freemins-card-head">
                    <div class="giant-freemins-card-titleblock">
                        <div class="giant-freemins-card-title">
                            {if $fm.friendlyLabel}{$fm.friendlyLabel|escape}{else}{$fm.productName|escape}{/if}
                        </div>
                        <div class="giant-freemins-card-prefixes">
                            {if $fm.friendlyLabel}{$fm.productName|escape}{else}Prefixes: {$fm.prefixes|escape}{/if}
                        </div>
                    </div>
                    {if $fm.state eq 'over'}
                        <span class="giant-freemins-pill is-over">Over allowance</span>
                    {elseif $fm.state eq 'critical'}
                        <span class="giant-freemins-pill is-critical">{$fm.pct}% used</span>
                    {elseif $fm.state eq 'warn'}
                        <span class="giant-freemins-pill is-warn">{$fm.pct}% used</span>
                    {else}
                        <span class="giant-freemins-pill is-ok">{$fm.pct}% used</span>
                    {/if}
                </div>
                <div class="giant-freemins-bar">
                    <div class="giant-freemins-bar-fill" style="width: {$fm.pctBar}%;"></div>
                </div>
                <div class="giant-freemins-stats">
                    <div>
                        <span class="giant-freemins-stat-value">{$fm.usedMinutes|number_format}</span>
                        <span class="giant-freemins-stat-label"> / {$fm.capMinutes|number_format} min</span>
                    </div>
                    {if $fm.state eq 'over'}
                        <div class="giant-freemins-remaining is-over">
                            <i class="fa fa-exclamation-triangle"></i>
                            Allowance used up &mdash; extra calls at the standard rate
                        </div>
                    {else}
                        <div class="giant-freemins-remaining">
                            <strong>{$fm.remainingMinutes|number_format}</strong> min left
                        </div>
                    {/if}
                </div>
                {if $fm.units && $fm.perExtensionMinutes}
                    <div class="giant-freemins-detail">
                        {$fm.perExtensionMinutes|number_format} min per {$fm.unitLabel} &times; {$fm.units} {$fm.unitLabelPlural}
                    </div>
                {/if}
                {if $fm.state ne 'ok'}
                    <div class="giant-freemins-cta">
                        {if $fm.upgrade}
                            <a class="giant-freemins-cta-btn" href="upgrade.php?type=package&id={$serviceHostingId}">
                                <i class="fa fa-arrow-up"></i>
                                Upgrade to <strong>{$fm.upgrade.productName|escape}</strong>
                                <span class="giant-freemins-cta-meta">+{$fm.upgrade.extraMinutes|number_format} min each</span>
                            </a>
                        {else}
                            <a class="giant-freemins-cta-btn is-contact" href="submitticket.php">
                                <i class="fa fa-envelope"></i>
                                Need more minutes? <strong>Contact us</strong>
                            </a>
                        {/if}
                    </div>
                {/if}
            </div>
        {/foreach}
    </div>
    {else}
    <div class="giant-period-payg">
        <div class="giant-period-payg-text">
            <strong>Pay as you go.</strong> Every call is billed at the standard rate, so there&rsquo;s nothing to run out of.
        </div>
        {if $paygUpgrade}
            <a class="giant-freemins-cta-btn" href="upgrade.php?type=package&id={$serviceHostingId}">
                <i class="fa fa-arrow-up"></i>
                Upgrade to <strong>{$paygUpgrade.productName|escape}</strong>
                <span class="giant-freemins-cta-meta">{$paygUpgrade.perExtensionMinutes|number_format} min per extension included</span>
            </a>
        {else}
            <a class="giant-freemins-cta-btn is-contact" href="submitticket.php">
                <i class="fa fa-envelope"></i>
                Want inclusive minutes? <strong>Contact us</strong>
            </a>
        {/if}
    </div>
    {/if}

    {if $freeMinutesInvoiceLine}
    {* Same wording that lands on the invoice (Ofcom GC C3), so the portal and the bill agree. *}
    <p class="giant-period-note">
        <i class="fa-duotone fa-gift" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
        {$freeMinutesInvoiceLine}
    </p>
    {/if}
</div>

<!-- ===== YOUR NUMBERS ===== -->
<div class="giant-section" id="numbersSection">
    <div class="giant-section-header">
        <div class="giant-section-title">
            <i class="fa-duotone fa-phone" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
            Your numbers
            {if $numbers|@count > 0}<span class="giant-section-count">{$numbers|@count}</span>{/if}
        </div>
        {if $numberAddonUrl}
            <a href="{$numberAddonUrl}" class="giant-section-action">
                <i class="fa-solid fa-plus"></i> Add numbers
            </a>
        {/if}
    </div>
    {if $numbers|@count > 0}
    <div class="giant-numbers-grid" id="phoneNumbersGrid">
        {foreach from=$numbers item=n}
        <button type="button" class="giant-number-card{if $n.routeKnown && !$n.routeName} is-unrouted{/if}" data-setup-open="destination" data-open-search="{$n.search|escape}" title="Open this number">
            <span class="giant-number-card-top">
                <img src="modules/addons/resellervoip/templates/client/img/gb.svg" alt="" class="giant-phone-flag">
                <span class="giant-number-card-num">{$n.display|escape}</span>
                {if $n.recording}<span class="giant-number-badge" title="Calls on this number are recorded"><i class="fa-solid fa-circle-dot"></i> Rec</span>{/if}
                {if $n.diverted}<span class="giant-number-badge is-divert" title="An unconditional divert is on"><i class="fa-solid fa-arrow-turn-down-right"></i> Diverted</span>{/if}
            </span>
            {if $n.label}<span class="giant-number-card-label">{$n.label|escape}</span>{/if}
            {if $n.routeKnown}
            <span class="giant-number-card-route">
                {if $n.routeName}<i class="fa-solid fa-arrow-right"></i> <span class="giant-number-card-dest">{$n.routeName|escape}</span>{if $n.routeType} <em>{$n.routeType|escape}</em>{/if}{else}<i class="fa-solid fa-triangle-exclamation"></i> Not routed yet{/if}
            </span>
            {/if}
        </button>
        {/foreach}
    </div>
    {else}
    <p class="giant-muted-line">No numbers on this account yet.</p>
    {/if}
</div>

<!-- ===== CALL CHART ===== -->
{if $showChart}
<div class="giant-section">
    <div class="giant-section-header">
        <div class="giant-section-title">
            <i class="fa-duotone fa-chart-mixed" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
            Calls, day by day
        </div>
        <span class="giant-muted-line">This period, in and out</span>
    </div>
    <div class="giant-chart-wrap">
        <canvas id="myChart" height="150"></canvas>
    </div>
</div>
{/if}

<!-- Recording playback popup (injected into body by JS) -->
<div id="giantRecPopup" style="display:none;"></div>

<!-- Onboarding Tour — cards injected by JS -->

<!-- modal -->
<div class="modal fade" id="giantModal" tabindex="-1" role="dialog" aria-labelledby="giantModal" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content giant-modal-content">
            <div class="modal-header giant-modal-header">
                <div class="giant-modal-header-inner">
                    <h5 class="modal-title giant-modal-title" id="giantModalTitle">Extensions</h5>
                    <button type="button" class="giant-modal-close" data-dismiss="modal" aria-label="Close">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
                <p class="giant-modal-description" id="giantModalDescription"></p>
            </div>
            <div class="modal-body giant-modal-body">

                <div id="giantModalSpinnerDiv" class="giantModalPanel">
                    <div class="giant-spinner">
                        <i class="fa-duotone fa-spinner fa-spin-pulse fa-2xl" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent));"></i>
                        <p class="giant-spinner-text">Loading...</p>
                    </div>
                </div>
                <div id="giantModalListDiv" class="giantModalPanel">
                    <div id="giantModalAlertDiv" style="display:none;">
                        <div id="giantModalAlert" class="giant-alert" role="alert">
                        </div>
                    </div>
                    <div id="giantModalListTableDiv">
                        <table id="giantModalList">
                            <thead id="giantModalListHead">
                            </thead>
                            <tbody id="giantModalListBody">
                            </tbody>
                        </table>
                    </div>
                </div>
                <div id="giantModalAddFormDiv" class="giantModalPanel">
                    <form id="giantModalAddForm" class="modalForm giant-form" method="post">

                    </form>
                </div>
                <div id="giantModalQrDiv" class="giantModalPanel">
                    <form id="giantModalSendEmailForm" class="modalForm giant-form" method="post">

                    </form>
                </div>
                <div id="giantModalAdditionalDataDiv" class="giantModalPanel">

                </div>
            </div>
        </div>
    </div>
</div>

<!-- ===== DIAL MODAL (shared by all click-to-call buttons) ===== -->
<div id="giantDialModal" class="giant-dial-modal" style="display:none;">
    <div class="giant-dial-backdrop"></div>
    <div class="giant-dial-dialog" role="dialog" aria-modal="true" aria-labelledby="giantDialTitle">
        <button type="button" class="giant-dial-close" aria-label="Close">&times;</button>
        <div class="giant-dial-header">
            <div class="giant-dial-icon"><i class="fa-solid fa-phone"></i></div>
            <div>
                <div id="giantDialTitle" class="giant-dial-title">Place a call</div>
                <div class="giant-dial-sub">Dialling from extension <strong id="giantDialSource"></strong></div>
            </div>
        </div>
        <div class="giant-dial-body">
            <label for="giantDialDest" class="giant-dial-label">Destination number</label>
            <input type="tel" id="giantDialDest" class="giant-dial-input" placeholder="e.g. 07900000000" autocomplete="off" inputmode="tel">
            <p class="giant-dial-hint">Your extension will ring first — answer it to connect the call.</p>
        </div>
        <div class="giant-dial-footer">
            <button type="button" class="giant-dial-cancel btn btn-secondary">Cancel</button>
            <button type="button" class="giant-dial-submit btn btn-primary"><i class="fa-solid fa-phone"></i> Call</button>
        </div>
    </div>
</div>

{if $gvFeatures.extension}
<!-- ===== EXTENSION STATUS (live polling) ===== -->
<div class="giant-section" id="extensionStatusSection">
    <div class="giant-section-header">
        <div class="giant-section-title">
            <i class="fa-duotone fa-signal-bars" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
            Extensions
        </div>
        <div class="giant-ext-filters">
            <span class="giant-ext-filter-pill is-active" data-state="AVAILABLE"><i class="fa-solid fa-circle giant-dot-online"></i> Available</span>
            <span class="giant-ext-filter-pill is-active" data-state="INUSE"><i class="fa-solid fa-circle giant-dot-busy"></i> On Call</span>
            <span class="giant-ext-filter-pill is-active" data-state="RINGING"><i class="fa-solid fa-circle giant-dot-ringing"></i> Ringing</span>
            <span class="giant-ext-filter-pill is-active" data-state="UNAVAILABLE"><i class="fa-solid fa-circle giant-dot-offline"></i> Offline</span>
        </div>
    </div>
    <div id="extensionStatusGrid" class="giant-ext-status-grid">
        <div class="giant-spinner" style="padding:20px;">
            <i class="fa-duotone fa-spinner fa-spin-pulse" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent));"></i>
        </div>
    </div>
    <div id="extensionStatusEmpty" class="giant-empty-state" style="display:none; padding:20px;">
        <i class="fa-duotone fa-user-slash fa-2x" style="--fa-primary-color: rgb(var(--muted) / .55); --fa-secondary-color: rgb(var(--muted) / .35);"></i>
        <p>No extensions found.</p>
    </div>
</div>

{/if}
{if $gvFeatures.phone}
<!-- ===== DEVICES / PHONES ===== -->
<div class="giant-section" id="phoneStatusSection">
    <div class="giant-section-header">
        <div class="giant-section-title">
            <i class="fa-duotone fa-mobile-screen" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
            Devices
        </div>
    </div>
    <div id="phoneStatusGrid" class="giant-ext-status-grid">
        <div class="giant-spinner" style="padding:20px;">
            <i class="fa-duotone fa-spinner fa-spin-pulse" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent));"></i>
        </div>
    </div>
    <div id="phoneStatusEmpty" class="giant-empty-state" style="display:none; padding:20px;">
        <i class="fa-duotone fa-mobile-screen-button fa-2x" style="--fa-primary-color: rgb(var(--muted) / .55); --fa-secondary-color: rgb(var(--muted) / .35);"></i>
        <p>No devices provisioned yet.</p>
    </div>
</div>

{/if}
<!-- ===== BILLING HISTORY ===== -->
<style>
    .giant-billing-loading { display:flex; flex-direction:column; align-items:center; justify-content:center; gap:12px; padding:44px 20px; }
    .giant-billing-loading span { font-size:13px; color:rgb(var(--muted)); }
    #productTable_wrapper .dataTables_processing {
        background: rgb(var(--bg));
        color: rgb(var(--muted));
        border: 0;
        box-shadow: 0 4px 18px rgb(0 0 0 / .12);
        border-radius: 10px;
        font-size: 13px;
        padding: 10px 16px;
    }
    .giant-dt-processing i { color: rgb(var(--accent)); margin-right: 6px; }
</style>
<div class="giant-section" id="billingSection">
    <div class="giant-section-header">
        <div class="giant-section-title">
            <i class="fa-duotone fa-file-invoice" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
            Billing History
        </div>
    </div>
    <div class="giant-table-wrap">
        <div id="billingLoading" class="giant-billing-loading">
            <i class="fa-duotone fa-spinner fa-spin-pulse fa-2x" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent));"></i>
            <span>Loading billing history&hellip;</span>
        </div>
        <table id="productTable" class="table table-list dataTable no-footer" style="border-collapse:collapse; width:100%; display:none;">
            <thead>
            <tr>
                <th>Service</th>
                <th>Period</th>
                <th>Duration</th>
                <th>Calls</th>
                <th>Amount</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>

<!-- ===== VOICECLOUD SETTINGS (overlay) =====
     Rendered as a custom overlay appended INSIDE #giantModal (same pattern as
     the the app edit-user dialog) rather than a stacked Bootstrap modal —
     that's what keeps it above the open modal instead of behind its backdrop,
     and avoids Bootstrap's focus trap. -->
<style>
    .giant-vcset-row { display:flex; align-items:center; justify-content:space-between; gap:16px; padding:12px 0; border-bottom:1px solid rgb(var(--muted) / .12); }
    .giant-vcset-row:last-of-type { border-bottom:0; }
    .giant-vcset-label { font-weight:600; font-size:14px; }
    .giant-vcset-hint { font-size:12px; color:rgb(var(--muted)); margin-top:2px; }
    .giant-vcset-field { margin-top:14px; }
    .giant-vcset-field label { font-weight:600; font-size:13px; display:block; margin-bottom:4px; }
    .giant-vcset-field textarea { width:100%; }
    .giant-vcset-row input[type=checkbox] { width:20px; height:20px; accent-color:#00d9a7; flex:0 0 auto; }
</style>
<script>
window.GiantVcSettings = (function () {
    function esc(s) { return $('<div>').text(s == null ? '' : String(s)).html(); }

    function toggleRow(id, label, hint, checked) {
        return '<div class="giant-vcset-row">' +
                 '<div><div class="giant-vcset-label">' + label + '</div>' +
                 '<div class="giant-vcset-hint">' + hint + '</div></div>' +
                 '<input type="checkbox" id="' + id + '"' + (checked ? ' checked' : '') + '>' +
               '</div>';
    }

    function open() {
        $('.giant-vcset-overlay').remove();

        var $ov = $(
            '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay giant-vcset-overlay">' +
              '<div class="giant-cdr-tag-dialog giant-vc-modal-fancy">' +
                '<div class="giant-vc-modal-head">' +
                  '<div class="giant-vc-modal-avatar"><i class="fa-duotone fa-sliders"></i></div>' +
                  '<div class="giant-vc-modal-title"><h4>the app Settings</h4>' +
                    '<div class="giant-vc-modal-sub">AI, transcription &amp; recording</div></div>' +
                  '<button type="button" class="giant-vc-modal-close giant-vcset-close" aria-label="Close">&times;</button>' +
                '</div>' +
                '<div class="giant-vc-modal-body giant-vcset-body">' +
                  '<div style="text-align:center; padding:24px;"><i class="fa-solid fa-spinner fa-spin fa-2x" style="color:#00d9a7;"></i></div>' +
                '</div>' +
                '<div class="giant-vc-modal-foot">' +
                  '<button type="button" class="btn giant-vc-btn-ghost giant-vcset-close">Cancel</button>' +
                  '<button type="button" class="btn giant-vc-btn-primary giant-vcset-save" disabled><i class="fa-regular fa-floppy-disk"></i> <span>Save settings</span></button>' +
                '</div>' +
              '</div>' +
            '</div>'
        ).appendTo('#giantModal');

        // Stop dialog clicks reaching the backdrop; bind close handlers directly.
        $ov.find('.giant-cdr-tag-dialog').on('click mousedown', function (e) { e.stopPropagation(); });
        var close = function () { $ov.remove(); $(document).off('keydown.giantVcSet'); };
        $ov.find('.giant-vcset-close').on('click', close);
        $ov.on('click', function (e) { if (e.target === $ov[0]) close(); });
        $(document).on('keydown.giantVcSet', function (e) { if (e.key === 'Escape') close(); });

        $.ajax({
            type: 'post',
            dataType: 'json',
            data: { pbxAction: 'getVoiceCloudSettings' },
            success: function (resp) {
                if (!resp || !resp.success) {
                    $ov.find('.giant-vcset-body').html('<div class="alert alert-danger">' + esc((resp && resp.error) || 'Could not load settings.') + '</div>');
                    return;
                }
                $ov.find('.giant-vcset-body').html(
                    toggleRow('vcAiConnect',     'Enable AI features', 'Master switch for AI transcription &amp; summaries', resp.aiConnect) +
                    toggleRow('vcTranscription', 'Call transcription', 'Turn recorded calls into searchable text', resp.transcription) +
                    toggleRow('vcRecording',     'Call recording', 'Record inbound &amp; outbound calls (needed for transcription)', resp.recording) +
                    toggleRow('vcBetaUpdates',   'Beta updates', 'Receive early app updates before general release', resp.betaUpdates) +
                    '<div class="giant-vcset-field"><label>Transcription prompt</label>' +
                      '<textarea id="vcTranscriptionPrompt" class="form-control" rows="3" placeholder="How calls should be transcribed">' + esc(resp.transcriptionPrompt || '') + '</textarea></div>' +
                    '<div class="giant-vcset-field"><label>Summarisation prompt</label>' +
                      '<textarea id="vcSummarizationPrompt" class="form-control" rows="3" placeholder="How calls should be summarised">' + esc(resp.summarizationPrompt || '') + '</textarea></div>'
                );
                $ov.find('.giant-vcset-save').prop('disabled', false).on('click', function () { save($ov, $(this)); });
            },
            error: function () {
                $ov.find('.giant-vcset-body').html('<div class="alert alert-danger">Could not load settings. Please try again.</div>');
            }
        });
    }

    function save($ov, $btn) {
        var savedHtml = $btn.html();
        $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> <span>Saving&hellip;</span>');
        $.ajax({
            type: 'post',
            dataType: 'json',
            data: {
                pbxAction:         'saveVoiceCloudSettings',
                aiConnect:           $ov.find('#vcAiConnect').is(':checked') ? 'true' : 'false',
                transcription:       $ov.find('#vcTranscription').is(':checked') ? 'true' : 'false',
                recording:           $ov.find('#vcRecording').is(':checked') ? 'true' : 'false',
                betaUpdates:         $ov.find('#vcBetaUpdates').is(':checked') ? 'true' : 'false',
                transcriptionPrompt: $ov.find('#vcTranscriptionPrompt').val(),
                summarizationPrompt: $ov.find('#vcSummarizationPrompt').val()
            }
        }).done(function (resp) {
            if (resp && resp.success) {
                if (typeof giantToast === 'function') giantToast('the app settings saved.', 'success');
                $ov.remove();
                $(document).off('keydown.giantVcSet');
            } else {
                if (typeof giantToast === 'function') giantToast((resp && resp.error) || 'Could not save settings.', 'error');
                else alert((resp && resp.error) || 'Could not save settings.');
                $btn.prop('disabled', false).html(savedHtml);
            }
        }).fail(function () {
            if (typeof giantToast === 'function') giantToast('Network error.', 'error'); else alert('Network error.');
            $btn.prop('disabled', false).html(savedHtml);
        });
    }

    return { open: open };
})();
</script>

<!-- Call-destinations heatmap styling (inline so it ships without a CSS cache-bust) -->
<style>
    .giant-geo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; align-items: start; }
    @media (max-width: 800px) { .giant-geo-grid { grid-template-columns: 1fr; } }
    .giant-geo-map-wrap { position: relative; width: 100%; max-width: 320px; margin: 0 auto; aspect-ratio: 6.6 / 9.2; }
    .giant-geo-list { display: flex; flex-direction: column; gap: 6px; max-height: 460px; overflow-y: auto; padding-right: 4px; }
    .giant-geo-row { position: relative; display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 7px 10px; border-radius: 8px; overflow: hidden; background: rgb(var(--muted) / .06); }
    .giant-geo-bar { position: absolute; left: 0; top: 0; bottom: 0; background: rgb(var(--accent) / .18); z-index: 0; }
    .giant-geo-name { position: relative; z-index: 1; font-size: 12px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .giant-geo-count { position: relative; z-index: 1; font-size: 12px; font-weight: 700; color: rgb(var(--accent)); }
    .giant-geo-divider { font-size: 10.5px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: rgb(var(--muted)); margin: 8px 0 2px; }
    .giant-geo-note { align-items: flex-end; padding-bottom: 8px; pointer-events: none; }
    .giant-geo-loading { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; background: rgb(var(--bg) / .55); z-index: 2; }
    .giant-geo-spinner { width: 30px; height: 30px; border-radius: 50%; border: 3px solid rgb(var(--muted) / .25); border-top-color: rgb(var(--accent)); animation: giantGeoSpin .8s linear infinite; }
    @keyframes giantGeoSpin { to { transform: rotate(360deg); } }
</style>

<!-- ===== ANALYTICS MODAL ===== -->
<div class="modal fade giant-analytics-modal" id="giantAnalyticsModal" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog giant-analytics-dialog" role="document">
        <div class="modal-content giant-analytics-content">
            <div class="giant-analytics-header">
                <div class="giant-analytics-title-group">
                    <div class="giant-analytics-title">
                        <i class="fa-duotone fa-chart-mixed" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
                        Call Analytics
                    </div>
                    <div class="giant-analytics-subtitle" id="giantAnalyticsRangeLabel">&hellip;</div>
                </div>
                <div class="giant-analytics-header-actions">
                    <button type="button" class="giant-analytics-pdf" id="giantAnalyticsPdf" title="Export PDF">
                        <i class="fa-duotone fa-file-pdf" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55); margin-bottom:0;"></i>
                        <span>PDF</span>
                    </button>
                    <button type="button" class="giant-analytics-refresh" id="giantAnalyticsRefresh" title="Refresh">
                        <i class="fa-duotone fa-arrows-rotate" style="margin-bottom:0;"></i>
                    </button>
                    <button type="button" class="giant-analytics-close" data-dismiss="modal" aria-label="Close">
                        <i class="fa-solid fa-xmark" style="margin-bottom:0;"></i>
                    </button>
                </div>
            </div>

            <div class="giant-analytics-rangebar">
                <div class="giant-range-pills" id="giantRangePills">
                    <button type="button" class="giant-range-pill is-active" data-range="day">Today</button>
                    <button type="button" class="giant-range-pill" data-range="yesterday">Yesterday</button>
                    <span class="giant-range-sep"></span>
                    <button type="button" class="giant-range-pill" data-range="week">This week</button>
                    <button type="button" class="giant-range-pill" data-range="lastweek">Last week</button>
                    <span class="giant-range-sep"></span>
                    <button type="button" class="giant-range-pill" data-range="month">This month</button>
                    <button type="button" class="giant-range-pill" data-range="lastmonth">Last month</button>
                    <span class="giant-range-sep"></span>
                    <div class="giant-range-dropdown">
                        <button type="button" class="giant-range-pill" id="giantRangeQuartersBtn">Quarters <i class="fa-solid fa-chevron-down" style="font-size:9px; margin-left:2px; margin-bottom:0;"></i></button>
                        <div class="giant-range-dropdown-menu" id="giantRangeQuartersMenu" style="display:none;"></div>
                    </div>
                    <span class="giant-range-sep"></span>
                    <button type="button" class="giant-range-pill" data-range="year">This year</button>
                    <button type="button" class="giant-range-pill" data-range="lastyear">Last year</button>
                    <span class="giant-range-sep"></span>
                    <button type="button" class="giant-range-pill" data-range="custom" id="giantRangeCustomBtn">Custom</button>
                </div>
                <div class="giant-range-custom" id="giantRangeCustom" style="display:none;">
                    <input type="date" id="giantRangeCustomStart" class="giant-range-date">
                    <span class="giant-range-to">to</span>
                    <input type="date" id="giantRangeCustomEnd" class="giant-range-date">
                    <button type="button" class="giant-range-apply" id="giantRangeCustomApply">Apply</button>
                </div>
                <div class="giant-analytics-updated" id="giantAnalyticsUpdated"></div>
            </div>

            <div class="giant-analytics-body" id="giantAnalyticsBody">
                <div class="giant-analytics-loading" id="giantAnalyticsLoading">
                    <i class="fa-duotone fa-spinner fa-spin-pulse" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>
                    <p>Loading analytics&hellip;</p>
                </div>
                <div class="giant-analytics-error" id="giantAnalyticsError" style="display:none;"></div>

                <div class="giant-analytics-main" id="giantAnalyticsMain" style="display:none;">

                    <div class="giant-analytics-kpis" id="giantAnalyticsKpis"></div>

                    <div class="giant-analytics-charts-row">
                        <div class="giant-analytics-chart-card">
                            <div class="giant-analytics-chart-label">Direction split</div>
                            <div class="giant-analytics-chart-wrap">
                                <canvas id="giantChartDirection"></canvas>
                                <div class="giant-analytics-chart-center">
                                    <div class="v" id="giantChartDirectionValue">0</div>
                                    <div class="l">calls</div>
                                </div>
                            </div>
                        </div>
                        <div class="giant-analytics-chart-card">
                            <div class="giant-analytics-chart-label">Outcome breakdown</div>
                            <div class="giant-analytics-chart-wrap">
                                <canvas id="giantChartOutcome"></canvas>
                                <div class="giant-analytics-chart-center">
                                    <div class="v" id="giantChartOutcomeValue">0%</div>
                                    <div class="l">connected</div>
                                </div>
                            </div>
                        </div>
                        <div class="giant-analytics-chart-card">
                            <div class="giant-analytics-chart-label">Talk time by extension</div>
                            <div class="giant-analytics-chart-wrap">
                                <canvas id="giantChartExtension"></canvas>
                                <div class="giant-analytics-chart-center">
                                    <div class="v" id="giantChartExtensionValue">0m</div>
                                    <div class="l">total talk</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="giant-analytics-chart-card giant-analytics-combo">
                        <div class="giant-analytics-chart-label">Daily call volume &amp; talk time</div>
                        <div class="giant-analytics-combo-wrap">
                            <canvas id="giantChartDaily"></canvas>
                        </div>
                    </div>

                    <div class="giant-analytics-section">
                        <div class="giant-analytics-section-head">
                            <div class="giant-analytics-section-title">Call destinations</div>
                            <div class="giant-analytics-section-hint">Where your calls go &amp; come from</div>
                        </div>
                        <div class="giant-geo-grid">
                            <div class="giant-analytics-chart-card">
                                <div class="giant-analytics-combo-wrap giant-geo-map-wrap">
                                    <canvas id="giantChartGeoMap"></canvas>
                                    <div class="giant-geo-loading" id="giantGeoLoading" style="display:none;"><div class="giant-geo-spinner"></div></div>
                                </div>
                            </div>
                            <div class="giant-analytics-side-card">
                                <div class="giant-analytics-section-title">Top areas</div>
                                <div class="giant-geo-list" id="giantAnalyticsTopAreas"></div>
                            </div>
                        </div>
                    </div>

                    <div class="giant-analytics-section" id="giantAnalyticsAiSection">
                        <div class="giant-analytics-section-head">
                            <div class="giant-analytics-section-title">AI insights</div>
                            <div class="giant-analytics-section-hint">Sentiment &amp; what callers talked about</div>
                        </div>
                        <div class="giant-ai-insights" id="giantAnalyticsAi">
                            <div class="giant-geo-loading" id="giantAiLoading" style="display:flex;"><div class="giant-geo-spinner"></div></div>
                        </div>
                    </div>

                    <div class="giant-analytics-section">
                        <div class="giant-analytics-section-head">
                            <div class="giant-analytics-section-title">Extension performance</div>
                            <div class="giant-analytics-section-hint">Click a row to see day-by-day breakdown</div>
                        </div>
                        <div class="giant-analytics-ext-table" id="giantAnalyticsExtensions"></div>
                    </div>

                    <div class="giant-analytics-side-grid">
                        <div class="giant-analytics-side-card">
                            <div class="giant-analytics-section-title">Leaderboard</div>
                            <div class="giant-analytics-leaderboard" id="giantAnalyticsLeaderboard"></div>
                        </div>
                        <div class="giant-analytics-side-card">
                            <div class="giant-analytics-section-title">Hourly distribution</div>
                            <div class="giant-analytics-hourly" id="giantAnalyticsHourly"></div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        // Fire `cb` once, the first time `el` scrolls near the viewport. Used to
        // lazy-load the heavier below-the-fold widgets (billing table, live
        // extension + device status) so page load doesn't pay for their requests
        // (and repeated polling) until the user actually scrolls down to them.
        // Falls back to firing immediately if IntersectionObserver is missing or
        // the element isn't present.
        window.giantWhenVisible = function (el, cb) {
            if (!el) { cb(); return; }
            if (!('IntersectionObserver' in window)) { cb(); return; }
            var fired = false;
            var io = new IntersectionObserver(function (entries) {
                for (var i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting && !fired) {
                        fired = true;
                        io.disconnect();
                        cb();
                        break;
                    }
                }
            }, { rootMargin: '200px 0px' });
            io.observe(el);
        };

        // Fold long phone-number lists
        if (typeof window.giantSetupShowMore === 'function') {
            window.giantSetupShowMore('#phoneNumbersGrid', 15, 'number', 'numbers');
        }

        // Billing history — lazy-init the (server-side) table so its ajax only
        // fires when the section scrolls into view. Spinner shows until the
        // first page of data lands.
        giantWhenVisible(document.getElementById('billingSection'), function () {
            var $billingTable = $('#productTable');
            $billingTable.DataTable({
                "dom": '<"listtable"fit>pl',
                "processing": true,
                "serverSide": true,
                "ajax": "index.php?m=resellervoip&action=getbillings&service={$serviceHostingId}",
                "searching": true,
                "order": [[1, 'desc']],
                "language": {
                    "processing": '<span class="giant-dt-processing"><i class="fa-duotone fa-spinner fa-spin-pulse"></i> Loading&hellip;</span>'
                },
                "initComplete": function () {
                    var api = this.api();
                    $('#billingLoading').fadeOut(150, function () {
                        $billingTable.show();
                        api.columns.adjust();
                    });
                }
            });
        });

        // ===== ONBOARDING TOUR (simple tooltip + highlight) =====
        {literal}
        (function() {
            var TOUR_KEY = 'giantVoipTourDone';
            if (localStorage.getItem(TOUR_KEY)) return;

            var steps = [
                { target: '#tour-callFlow', title: 'Call Flows', desc: 'Visually design how incoming calls are routed. Drag and drop steps like IVR menus, queues, extensions, and voicemail to build your call routing.' },
                { target: '#tour-extension', title: 'Extensions', desc: 'Each extension is a user on your phone system with their own number, password, and caller ID. Create extensions for every person or device that needs to make or receive calls.' },
                { target: '#tour-destination', title: 'Telephone Numbers', desc: 'View and manage your inbound phone numbers. Set where each number routes to, add labels, and enable or disable call recording per number.' },
                { target: '#tour-callLog', title: 'Call Logs', desc: 'Browse your complete call history with detailed records. Filter by date, search by number, listen to call recordings, and track costs.' },
                { target: '#tour-voiceCloud', title: 'the app Softphone', desc: 'Set up the softphone app for your team. This is the only way to onboard users onto the softphone \u2014 link each user to an extension so they can make and receive calls from any device.' },
                { target: '#tour-ivr', title: 'IVR Menus', desc: 'Create automated voice menus like "Press 1 for Sales, Press 2 for Support". Route callers to extensions, queues, or external numbers based on their selection.' },
                { target: '#tour-queue', title: 'Call Queues', desc: 'Set up call queues so incoming calls are distributed to a team of agents. Callers hear hold music while waiting for the next available person.' },
                { target: '#tour-huntList', title: 'Hunt Lists / Ring Groups', desc: 'Ring multiple phones simultaneously. When a call comes in, every phone in the group rings at once \u2014 whoever picks up first takes the call.' },
                { target: '#tour-condition', title: 'Time Conditions', desc: 'Route calls differently based on the time of day, day of the week, or holidays. For example, send calls to voicemail outside business hours.' },
                { target: '#tour-voicemail', title: 'Voicemail', desc: 'Create voicemail boxes for your extensions and enable voicemail-to-email. Callers can leave a message when you are unavailable.' },
                { target: '#tour-media', title: 'Media Files', desc: 'Upload audio files used for hold music, welcome greetings, and IVR announcements. Drag and drop to upload, click to preview.' },
                { target: '#tour-musicOnHold', title: 'Music on Hold', desc: 'Choose which audio files play when callers are placed on hold or waiting in a queue. Build a playlist for a better experience.' },
                { target: '#tour-customDestination', title: 'Additional Destinations', desc: 'Create extra destinations to send calls to external numbers like mobiles. Useful for out-of-office diversions or overflow routing.' },
                { target: '#tour-aiAgent', title: 'AI Agents', desc: 'Configure AI agents that can answer calls in your chosen voice and language. Pick a model, set creativity, and route calls straight to the agent.' },
                { target: '#tour-aiAgentLog', title: 'AI Conversations', desc: 'Browse the full history of caller conversations with each AI agent. Filter by date and view the transcript of any conversation.' },
                { target: '#tour-phone', title: 'Devices', desc: 'Auto-provision your desk phones and hardware. Register a new device with one click for rapid deployment \u2014 no manual configuration needed.' },
                { target: '#tour-port', title: 'Port Numbers', desc: 'Transfer your existing phone numbers from another provider. Submit a port request and we will handle the rest automatically.' },
                { target: '#tour-featureCode', title: 'Feature Codes', desc: 'A reference list of dial codes you can use from your handset. For example, dial a code to withhold your number, pick up a ringing phone, or toggle Do Not Disturb.' },
                { target: '#tour-smsLog', title: 'SMS Messages', desc: 'View your inbound and outbound SMS message history. Send new SMS messages to any UK mobile or landline number.' },
                { target: '#tour-shortNumber', title: 'Short Numbers', desc: 'Set up speed-dial codes for your most-called numbers. For example, dial 1 to reach reception or 2 to reach a mobile.' },
                { target: '#tour-phoneBook', title: 'Phone Books', desc: 'Manage a shared cloud phone book that syncs across all your registered desk phones automatically.' },
                { target: '#tour-apiAccess', title: 'API Access', desc: 'Manage your API keys for programmatic access to the VoIP platform. Build custom integrations and automations.' },
                { target: '#tour-teamsRouting', title: 'Teams Direct Routing', desc: 'Follow our step-by-step guide to connect Microsoft Teams to the app via Direct Routing. Make and receive PSTN calls directly from Teams.' },
            ];

            steps = steps.filter(function(s) { return $(s.target).length; });
            if (steps.length === 0) return;

            var cur = 0;

            function dots() {
                var h = '';
                for (var i = 0; i < steps.length; i++) h += '<div class="giant-tour-dot' + (i === cur ? ' active' : '') + '"></div>';
                return h;
            }

            function go(idx) {
                $('.giant-tour-highlight').removeClass('giant-tour-highlight');
                $('.giant-tour-card').remove();

                cur = idx;
                var s = steps[idx];
                var $el = $(s.target).first();
                if (!$el.length) return;

                $el.addClass('giant-tour-highlight');

                // Build card
                var card = '<div class="giant-tour-card">';
                card += '<div class="giant-tour-card-arrow"></div>';
                card += '<div class="giant-tour-step-badge">Step ' + (idx + 1) + ' of ' + steps.length + '</div>';
                card += '<h4 class="giant-tour-title">' + s.title + '</h4>';
                card += '<p class="giant-tour-desc">' + s.desc + '</p>';
                card += '<div class="giant-tour-card-actions">';
                card += '<button class="giant-tour-btn giant-tour-skip" onclick="window._tourEnd()">Skip</button>';
                card += '<div class="giant-tour-card-nav">';
                if (idx > 0) card += '<button class="giant-tour-btn giant-tour-prev" onclick="window._tourPrev()"><i class="fa-solid fa-arrow-left" style="margin-bottom:0;"></i></button>';
                if (idx < steps.length - 1) {
                    card += '<button class="giant-tour-btn giant-tour-next" onclick="window._tourNext()">Next <i class="fa-solid fa-arrow-right" style="margin-bottom:0;"></i></button>';
                } else {
                    card += '<button class="giant-tour-btn giant-tour-next" onclick="window._tourEnd()"><i class="fa-solid fa-check" style="margin-bottom:0;"></i> Finish</button>';
                }
                card += '</div></div>';
                card += '<div class="giant-tour-progress">' + dots() + '</div>';
                card += '</div>';

                // Inject into tile-item parent
                var $parent = $el.closest('.tile-item');
                if ($parent.length) {
                    $parent.append(card);
                } else {
                    $el.after(card);
                }

                if (window.giantToolsReveal) window.giantToolsReveal($el);
                $el[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
            }

            function end() {
                localStorage.setItem(TOUR_KEY, '1');
                $('.giant-tour-highlight').removeClass('giant-tour-highlight');
                $('.giant-tour-card').remove();
                $('.giant-tour-welcome').remove();
            }

            // Expose for onclick handlers
            window._tourNext = function() { if (cur < steps.length - 1) go(cur + 1); };
            window._tourPrev = function() { if (cur > 0) go(cur - 1); };
            window._tourEnd = end;

            // Welcome card
            var wh = '<div class="giant-tour-welcome"><div class="giant-tour-welcome-card">';
            wh += '<i class="fa-duotone fa-hand-wave fa-3x" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>';
            wh += '<h3>Welcome to your VoIP Dashboard</h3>';
            wh += '<p>Take a quick tour to learn what each feature does and how to get the most out of your phone system.</p>';
            wh += '<div class="giant-tour-welcome-actions">';
            wh += '<button class="giant-tour-btn giant-tour-prev" id="tourWelcomeSkip">Skip for now</button>';
            wh += '<button class="giant-tour-btn giant-tour-next" id="tourWelcomeStart"><i class="fa-solid fa-rocket" style="margin-bottom:0;"></i> Start Tour</button>';
            wh += '</div></div></div>';
            $('body').append(wh);

            $('#tourWelcomeSkip').on('click', end);
            $('#tourWelcomeStart').on('click', function() {
                $('.giant-tour-welcome').fadeOut(200, function() { $(this).remove(); });
                go(0);
            });
        })();
        {/literal}

        // Load voicemail count badge
        {literal}
        $.ajax({
            type: 'post',
            data: { pbxAction: 'getVoicemailCount' },
            success: function(json) {
                try {
                    var resp = (typeof json === 'object') ? json : jQuery.parseJSON(json);
                    if (resp && resp.count > 0) {
                        $('#tour-voicemail').append('<span class="giant-tile-badge">' + resp.count + '</span>');
                    }
                } catch(e) {}
            }
        });
        {/literal}

        //fix numbers in Additional Information
        try {
            var numbersSpan = $("#additionalinfo").find(".list-info-text").last();
            var numbers = numbersSpan.html();
            if (numbers) {
                numbersSpan.html(numbers.replace(/-simwood/g, ""));
            }
        } catch(e) {}

        // ===== LIVE EXTENSION STATUS POLLING (proxied through PHP) =====
        {literal}
        (function() {
            if (!document.getElementById('extensionStatusGrid')) return;   // section not on this product
            var refreshMs = 5000;
            var inFlight = false;
            var paused = false;
            var activeStates = new Set(['INUSE', 'RINGING', 'AVAILABLE', 'UNAVAILABLE']);
            var lastData = [];

            function stateFrom(item) {
                var s = (item.st_state || '').toString().toUpperCase().trim();
                if (s === 'RINGINUSE') return 'INUSE';
                if (s.indexOf('RING') > -1) return 'RINGING';
                if (s === 'INUSE' || s === 'BUSY' || s === 'ONHOLD') return 'INUSE';
                if (s === 'AVAILABLE' || s === 'IDLE' || s === 'NOT_INUSE') return 'AVAILABLE';
                return 'UNAVAILABLE';
            }

            function renderList(data) {
                if (Array.isArray(data)) {
                    var liveOn = 0;
                    data.forEach(function (x) { if (stateFrom(x) !== 'UNAVAILABLE') liveOn++; });
                    if (window.giantTileState && data.length) giantTileState('extension', data.length + (data.length === 1 ? ' extension' : ' extensions') + ' \u00b7 ' + liveOn + ' online', true);
                    if (window.giantSetupLive) giantSetupLive('online', liveOn > 0,
                        liveOn > 0 ? (liveOn + (liveOn === 1 ? ' extension is' : ' extensions are') + ' online right now') : 'Nothing is online yet. Register a desk phone or sign in to the app.',
                        liveOn > 0 ? 'Devices' : 'Set up a device');
                }
                if (!Array.isArray(data) || data.length === 0) {
                    $('#extensionStatusGrid').hide();
                    $('#extensionStatusEmpty').show();
                    return;
                }

                var priority = { INUSE: 0, RINGING: 1, AVAILABLE: 2, UNAVAILABLE: 3 };
                data.sort(function(a, b) {
                    var sa = stateFrom(a), sb = stateFrom(b);
                    if (priority[sa] !== priority[sb]) return priority[sa] - priority[sb];
                    var an = parseInt(a.ex_number || 0, 10);
                    var bn = parseInt(b.ex_number || 0, 10);
                    return (isNaN(an) ? 9999 : an) - (isNaN(bn) ? 9999 : bn);
                });

                var filtered = data.filter(function(item) { return activeStates.has(stateFrom(item)); });

                var html = '';
                if (filtered.length === 0) {
                    html = '<div style="color: rgb(var(--muted)); font-size:13px; padding:10px;">No extensions match the selected filters.</div>';
                } else {
                    filtered.forEach(function(item) {
                        var state = stateFrom(item);
                        var name = item.ex_name || ('Ext ' + item.ex_number);
                        var num = item.ex_number || '';
                        var dnd = (item.ex_dnd || '').toString().toLowerCase();
                        var isDnd = dnd === 'on' || dnd === 'yes' || dnd === 'true' || dnd === '1';

                        var stateClass = 'giant-ext-' + state.toLowerCase().replace('_', '');
                        if (state === 'AVAILABLE') stateClass = 'giant-ext-online';
                        else if (state === 'INUSE') stateClass = 'giant-ext-busy';
                        else if (state === 'RINGING') stateClass = 'giant-ext-ringing';
                        else stateClass = 'giant-ext-offline';

                        var icons = { AVAILABLE: 'fa-circle-check', INUSE: 'fa-phone', RINGING: 'fa-bell', UNAVAILABLE: 'fa-circle-xmark' };
                        var labels = { AVAILABLE: 'Available', INUSE: 'On Call', RINGING: 'Ringing', UNAVAILABLE: 'Offline' };

                        html += '<div class="giant-ext-item ' + stateClass + '">';
                        html += '<div class="giant-ext-indicator"></div>';
                        html += '<div class="giant-ext-info">';
                        html += '<div class="giant-ext-name">' + name + '</div>';
                        html += '<div class="giant-ext-number">Ext. ' + num + '</div>';
                        html += '</div>';
                        if (isDnd) {
                            html += '<span class="giant-ext-dnd"><i class="fa-solid fa-ban" style="margin-bottom:0;"></i> DND</span>';
                        }
                        if (item.ex_password && item.username_combined) {
                            html += '<button type="button" class="giant-webphone-launch" title="Open WebPhone for Ext. ' + num + '"' +
                                ' data-webphone_ext="' + item.username_combined + '"' +
                                ' data-webphone_pass="' + item.ex_password + '"' +
                                ' data-webphone_name="' + (item.ex_name || '').replace(/"/g, '&quot;') + '">' +
                                '<i class="fa-solid fa-headset"></i></button>';
                        }
                        if (num && (state === 'INUSE' || state === 'RINGING')) {
                            var hangupTitle = state === 'RINGING' ? 'Cancel ringing call' : 'Hang up active call';
                            html += '<button type="button" class="giant-hangup" title="' + hangupTitle + '" data-source="' + num + '"><i class="fa-solid fa-phone-slash"></i></button>';
                        } else if (num) {
                            html += '<button type="button" class="giant-click-to-call" title="Click-to-call" data-source="' + num + '"><i class="fa-solid fa-phone"></i></button>';
                        }
                        html += '<div class="giant-ext-badge"><i class="fa-solid ' + (icons[state] || 'fa-circle-question') + '"></i> ' + (labels[state] || 'Unknown') + '</div>';
                        html += '</div>';
                    });
                }

                $('#extensionStatusEmpty').hide();
                $('#extensionStatusGrid').html(html).show();
                window.giantSetupShowMore('#extensionStatusGrid', 6, 'extension', 'extensions');
            }

            // Filter pill clicks
            $(document).on('click', '.giant-ext-filter-pill', function() {
                var s = $(this).data('state');
                if (activeStates.has(s)) {
                    if (activeStates.size > 1) activeStates.delete(s);
                } else {
                    activeStates.add(s);
                }
                $(this).toggleClass('is-active', activeStates.has(s));
                renderList(lastData);
            });

            function fetchExtensions() {
                if (paused || inFlight) return;
                inFlight = true;

                $.ajax({
                    type: 'post',
                    data: { pbxAction: 'getExtensionStatuses' },
                    success: function(json) {
                        try {
                            var resp = (typeof json === 'object') ? json : jQuery.parseJSON(json);
                            if (resp && resp.extensions && Array.isArray(resp.extensions)) {
                                lastData = resp.extensions;
                            } else {
                                lastData = [];
                            }
                        } catch(e) {
                            lastData = [];
                        }

                        // Share live state per extension number so the Devices widget
                        // can derive each phone's live status from its registered lines.
                        var liveMap = {};
                        lastData.forEach(function (item) {
                            var num = item.ex_number || item.number;
                            if (!num) return;
                            var st = stateFrom(item);
                            liveMap[String(num)] = st;
                        });
                        window._giantLiveExtStates = liveMap;
                        if (typeof window._giantRerenderPhones === 'function') {
                            window._giantRerenderPhones();
                        }

                        renderList(lastData);
                    },
                    error: function() {
                        // Silently keep showing last data
                    },
                    complete: function() {
                        inFlight = false;
                    }
                });
            }

            var started = false;
            document.addEventListener('visibilitychange', function() {
                paused = document.hidden;
                if (!paused && started) fetchExtensions();
            });

            // Lazy start: don't poll extension status until the section scrolls
            // into view. Exposed so the Devices widget (which derives its live
            // state from extensions) can force it to start too.
            window._giantStartExtStatus = function () {
                if (started) return;
                started = true;
                fetchExtensions();
                setInterval(fetchExtensions, refreshMs);
            };
            giantWhenVisible(document.getElementById('extensionStatusSection'), window._giantStartExtStatus);
        })();

        // ===== DEVICES POLLING =====
        (function () {
            if (!document.getElementById('phoneStatusGrid')) return;   // section not on this product
            var phoneRefreshMs = 15000;
            var phonePaused    = false;
            var phoneInFlight  = false;
            var phoneLast      = null;

            function esc(s) { return $('<div>').text(s == null ? '' : s).html(); }

            // Derive the phone's effective live state from its line extensions:
            //   any RINGING → 'RINGING', any INUSE → 'INUSE', any AVAILABLE → 'AVAILABLE',
            //   all UNAVAILABLE → 'UNAVAILABLE'. Falls back to the config ph_active flag
            //   when the live extension map isn't populated yet.
            function derivePhoneLiveState(p) {
                if (p.ph_status !== 'active') return 'DISABLED';
                var liveMap = window._giantLiveExtStates || {};
                if (!p.ph_extensions) return 'UNKNOWN';
                var nums = String(p.ph_extensions).split(',').map(function (e) {
                    var m = e.trim().match(/^(\d+)/); return m ? m[1] : null;
                }).filter(Boolean);
                if (nums.length === 0) return 'UNKNOWN';

                var hasAvailable = false, hasInUse = false, hasRinging = false, seenLive = 0;
                nums.forEach(function (n) {
                    if (!(n in liveMap)) return;
                    seenLive++;
                    var s = liveMap[n];
                    if (s === 'AVAILABLE') hasAvailable = true;
                    else if (s === 'INUSE') hasInUse = true;
                    else if (s === 'RINGING') hasRinging = true;
                });
                if (seenLive === 0) return 'UNKNOWN';
                if (hasRinging)   return 'RINGING';
                if (hasInUse)     return 'INUSE';
                if (hasAvailable) return 'AVAILABLE';
                return 'UNAVAILABLE';
            }

            function renderPhones(data) {
                if (window.giantTileState && Array.isArray(data) && data.length) {
                    var devOn = 0;
                    data.forEach(function (p) { var st = derivePhoneLiveState(p); if (st === 'AVAILABLE' || st === 'INUSE' || st === 'RINGING') devOn++; });
                    giantTileState('phone', data.length + (data.length === 1 ? ' device' : ' devices') + ' \u00b7 ' + devOn + ' online', true);
                }
                if (!Array.isArray(data) || data.length === 0) {
                    $('#phoneStatusGrid').hide();
                    $('#phoneStatusEmpty').show();
                    return;
                }

                var stateMeta = {
                    AVAILABLE:   { cls: 'giant-ext-online',   icon: 'fa-circle-check',     label: 'Online',    rank: 1 },
                    INUSE:       { cls: 'giant-ext-busy',     icon: 'fa-phone',            label: 'On Call',   rank: 0 },
                    RINGING:     { cls: 'giant-ext-ringing',  icon: 'fa-bell',             label: 'Ringing',   rank: 0 },
                    UNAVAILABLE: { cls: 'giant-ext-offline',  icon: 'fa-circle-xmark',     label: 'Offline',   rank: 2 },
                    DISABLED:    { cls: 'giant-ext-offline',  icon: 'fa-circle-xmark',     label: 'Inactive',  rank: 3 },
                    UNKNOWN:     { cls: 'giant-ext-unknown',  icon: 'fa-circle-question',  label: 'Unknown',   rank: 2 },
                };

                data.forEach(function (p) { p._liveState = derivePhoneLiveState(p); });

                data.sort(function (a, b) {
                    var ra = (stateMeta[a._liveState] || stateMeta.UNKNOWN).rank;
                    var rb = (stateMeta[b._liveState] || stateMeta.UNKNOWN).rank;
                    if (ra !== rb) return ra - rb;
                    return String(a.ph_name || '').localeCompare(String(b.ph_name || ''));
                });

                var html = '';
                data.forEach(function (p) {
                    var meta       = stateMeta[p._liveState] || stateMeta.UNKNOWN;
                    var stateClass = meta.cls;
                    var badgeIcon  = meta.icon;
                    var badgeLabel = meta.label;
                    var isActive   = (p._liveState === 'AVAILABLE' || p._liveState === 'INUSE' || p._liveState === 'RINGING');
                    // Only show the pill for non-default states — reduces visual noise
                    // when every phone is "Online" (the colored dot already conveys that).
                    var showBadge = (p._liveState !== 'AVAILABLE');

                    var imgSrc = (typeof resolvePhoneModelSrc === 'function')
                        ? resolvePhoneModelSrc(p.pm_image_src, p.ph_pm_id, p.pm_image_ver)
                        : '';
                    var imgHtml = imgSrc
                        ? '<img class="giant-phone-dash-img" src="' + imgSrc + '" alt="" decoding="async" loading="eager">'
                        : '<span class="giant-phone-dash-img giant-phone-dash-img-empty"><i class="fa-solid fa-mobile"></i></span>';

                    var extText = p.ph_extensions ? esc(p.ph_extensions) : '<span class="text-muted">No extensions</span>';

                    var modelFmtOpts = p.pm_mfg_src ? { stripManufacturer: p.pm_mfg_name } : null;
                    var modelHtml = (typeof formatPhoneModelName === 'function')
                        ? formatPhoneModelName(p.ph_pm_name || '', modelFmtOpts)
                        : esc(p.ph_pm_name || '');
                    var mfgTag = (typeof manufacturerLogoTag === 'function')
                        ? manufacturerLogoTag(p.pm_mfg_src, p.pm_mfg_name, 'giant-phone-dash-mfg')
                        : '';

                    // Combined info line: "Ext 203 · W6X DECT Base Station"
                    var infoBits = [];
                    if (p.ph_extensions) {
                        // Strip any trailing "name" after the number on each ext, keep just the numbers
                        var extNums = String(p.ph_extensions).split(',').map(function (e) {
                            var m = e.trim().match(/^(\d+)/);
                            return m ? m[1] : null;
                        }).filter(Boolean);
                        if (extNums.length) infoBits.push('Ext ' + extNums.join(', '));
                    }
                    if (p.ph_pm_name) infoBits.push(modelHtml);
                    var infoLine = infoBits.join(' <span class="giant-phone-dot">·</span> ');

                    html += '<div class="giant-ext-item giant-phone-item ' + stateClass + '">';
                    html += '<div class="giant-ext-indicator"></div>';
                    html += imgHtml;
                    html += '<div class="giant-ext-info giant-phone-info">';
                    html += '<div class="giant-ext-name" title="' + esc(p.ph_name) + '">' + esc(p.ph_name) + '</div>';
                    html += '<div class="giant-phone-infoline">' + infoLine + '</div>';
                    html += '</div>';
                    // Pick the phone's first line extension as the click-to-call source.
                    var firstExtNum = '';
                    if (p.ph_extensions) {
                        var firstEntry = String(p.ph_extensions).split(',')[0].trim();
                        var m = firstEntry.match(/^(\d+)/);
                        if (m) firstExtNum = m[1];
                    }

                    html += '<div class="giant-phone-right">';
                    if (firstExtNum && isActive) {
                        if (p._liveState === 'INUSE' || p._liveState === 'RINGING') {
                            var hangTitle = p._liveState === 'RINGING' ? 'Cancel ringing call' : 'Hang up active call';
                            html += '<button type="button" class="giant-hangup" title="' + hangTitle + '" data-source="' + esc(firstExtNum) + '"><i class="fa-solid fa-phone-slash"></i></button>';
                        } else {
                            html += '<button type="button" class="giant-click-to-call" title="Click-to-call from ' + esc(firstExtNum) + '" data-source="' + esc(firstExtNum) + '"><i class="fa-solid fa-phone"></i></button>';
                        }
                    }

                    // RPS management menu — only for supported manufacturers with a MAC on file.
                    var supportedMfgs = {
                        auerswald: 1, gigaset: 1, panasonic: 1, snom: 1, yealink: 1,
                        grandstream: 1, fanvil: 1, giant: 1, poly: 1, polycom: 1
                    };
                    var mfgKey = String(p.pm_mfg_name || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
                    var mac    = String(p.ph_mac || '').trim();
                    if (mac && supportedMfgs[mfgKey]) {
                        html += '<div class="giant-device-rps">' +
                            '<button type="button" class="giant-device-rps-btn" title="Manage RPS registration" data-mac="' + esc(mac) + '">' +
                              '<i class="fa-duotone fa-cloud-arrow-up" style="--fa-primary-color: rgb(var(--muted)); --fa-secondary-color: rgb(var(--muted) / .65); margin-bottom:0;"></i>' +
                            '</button>' +
                            '<div class="giant-device-rps-menu">' +
                              '<div class="giant-device-rps-menu-h">RPS &middot; ' + esc(p.pm_mfg_name || '') + '</div>' +
                              '<button type="button" data-rps-action="check"  data-mac="' + esc(mac) + '"><i class="fa-solid fa-magnifying-glass"></i> Check status</button>' +
                              '<button type="button" data-rps-action="add"    data-mac="' + esc(mac) + '"><i class="fa-solid fa-cloud-arrow-up"></i> Register</button>' +
                              '<button type="button" data-rps-action="remove" data-mac="' + esc(mac) + '" class="is-danger"><i class="fa-solid fa-link-slash"></i> Unregister</button>' +
                            '</div>' +
                          '</div>';
                    }

                    if (showBadge) {
                        html += '<div class="giant-ext-badge"><i class="fa-solid ' + badgeIcon + '"></i> ' + badgeLabel + '</div>';
                    }
                    html += '</div>';
                    html += '</div>';
                });

                $('#phoneStatusEmpty').hide();
                $('#phoneStatusGrid').html(html).show();
                window.giantSetupShowMore('#phoneStatusGrid', 6, 'device', 'devices');
            }

            function fetchPhones() {
                if (phonePaused || phoneInFlight) return;
                phoneInFlight = true;
                $.ajax({
                    type: 'post',
                    data: { pbxAction: 'getPhoneList' },
                    success: function (json) {
                        try {
                            var resp = (typeof json === 'object') ? json : jQuery.parseJSON(json);
                            var list = [];
                            if (resp && resp.data) {
                                list = Array.isArray(resp.data) ? resp.data : Object.values(resp.data);
                            }
                            phoneLast = list;
                        } catch (e) { phoneLast = []; }
                        renderPhones(phoneLast);
                    },
                    complete: function () { phoneInFlight = false; }
                });
            }

            var phoneStarted = false;
            document.addEventListener('visibilitychange', function () {
                phonePaused = document.hidden;
                if (!phonePaused && phoneStarted) fetchPhones();
            });

            // Let the Extensions widget trigger a quick re-render whenever live state refreshes,
            // so phone cards flip between Online/On Call/Ringing/Offline in near-real-time.
            window._giantRerenderPhones = function () {
                if (phoneLast) renderPhones(phoneLast);
            };

            // Lazy start when the Devices section scrolls into view. Devices derive
            // their live state from extension status, so make sure that poller is
            // running too (idempotent if the user already scrolled past it).
            giantWhenVisible(document.getElementById('phoneStatusSection'), function () {
                if (phoneStarted) return;
                phoneStarted = true;
                if (typeof window._giantStartExtStatus === 'function') { window._giantStartExtStatus(); }
                fetchPhones();
                setInterval(fetchPhones, phoneRefreshMs);
            });
        })();

        // ===== Dial modal (shared by all click-to-call buttons) =====
        window.openDialModal = function (source) {
            if (!source) return;
            $('#giantDialSource').text(source);
            $('#giantDialDest').val('');
            $('#giantDialModal').data('source', source).fadeIn(120, function () {
                setTimeout(function () { $('#giantDialDest').focus(); }, 50);
            });
        };
        function closeDialModal() {
            $('#giantDialModal').fadeOut(120);
        }
        function submitDial() {
            var $modal = $('#giantDialModal');
            var source = $modal.data('source');
            var dest = String($('#giantDialDest').val() || '').replace(/\s+/g, '');
            if (!/^\+?[0-9]{3,20}$/.test(dest)) {
                if (typeof giantToast === 'function') giantToast('Please enter a valid phone number.', 'error');
                return;
            }
            var $submit = $modal.find('.giant-dial-submit');
            $submit.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> Calling…');
            $.ajax({
                type: 'post',
                data: { pbxAction: 'dialCall', source: source, dest: dest },
                success: function (json) {
                    var resp;
                    try { resp = (typeof json === 'object') ? json : jQuery.parseJSON(json); } catch (e) { resp = {}; }
                    if (resp && resp.error) {
                        if (typeof giantToast === 'function') giantToast(resp.error, 'error');
                    } else {
                        if (typeof giantToast === 'function') giantToast('Calling ' + dest + ' from ' + source + '…', 'success');
                        closeDialModal();
                    }
                },
                error: function () { if (typeof giantToast === 'function') giantToast('Could not start the call.', 'error'); },
                complete: function () {
                    $submit.prop('disabled', false).html('<i class="fa-solid fa-phone"></i> Call');
                }
            });
        }
        $(document).off('click', '.giant-click-to-call').on('click', '.giant-click-to-call', function (e) {
            e.preventDefault();
            openDialModal($(this).data('source'));
        });
        $(document).off('click.dialModal').on('click.dialModal', '.giant-dial-backdrop, .giant-dial-close, .giant-dial-cancel', closeDialModal);
        $(document).on('click.dialSubmit', '.giant-dial-submit', submitDial);
        $(document).on('keydown.dialModal', function (e) {
            if ($('#giantDialModal').is(':visible')) {
                if (e.key === 'Escape') closeDialModal();
                if (e.key === 'Enter' && $(e.target).is('#giantDialDest')) submitDial();
            }
        });

        // ===== Hangup handler =====
        $(document).off('click', '.giant-hangup');
        $(document).on('click', '.giant-hangup', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var source = $btn.data('source');
            if (!source) return;

            $btn.prop('disabled', true);
            $.ajax({
                type: 'post',
                data: { pbxAction: 'hangupCall', source: source },
                success: function (json) {
                    var resp;
                    try { resp = (typeof json === 'object') ? json : jQuery.parseJSON(json); } catch (err) { resp = {}; }
                    if (resp && resp.error) {
                        if (typeof giantToast === 'function') giantToast(resp.error, 'error');
                    } else {
                        if (typeof giantToast === 'function') giantToast('Hung up extension ' + source + '.', 'success');
                    }
                },
                error: function () {
                    if (typeof giantToast === 'function') giantToast('Could not hang up the call.', 'error');
                },
                complete: function () { $btn.prop('disabled', false); }
            });
        });

        // ===== WebPhone launcher (shared) =====
        $(document).off('click', '.giant-webphone-launch');
        $(document).on('click', '.giant-webphone-launch', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var ext  = $btn.data('webphone_ext');
            var pass = $btn.data('webphone_pass');
            var name = $btn.data('webphone_name') || '';
            if (!ext || !pass) {
                if (typeof giantToast === 'function') giantToast('Missing WebPhone credentials for this extension.', 'error');
                return;
            }
            if (typeof giantToast === 'function') giantToast('The web phone is not available on this service.', 'warn');
            return;
            var url = '' +
                      '&pass=' + encodeURIComponent(pass) +
                      '&name=' + encodeURIComponent(name);
            var w = window.open(url, '_blank', 'noopener,noreferrer');
            if (!w && typeof giantToast === 'function') {
                giantToast('Your browser blocked the WebPhone popup. Allow popups for this site.', 'warn');
            }
        });

        // True when the upstream RPS message signals that the "check" action is
        // unsupported for this manufacturer (e.g. Fanvil FDPS).
        function giantRpsCheckUnsupported(resp) {
            if (!resp || !resp.message) return false;
            return /not\s+support(ed)?|unsupported/i.test(String(resp.message));
        }

        // ===== RPS toast — summarises a server-side tryRpsAction result =====
        window.showRpsToast = function (rps) {
            if (!rps || typeof giantToast !== 'function') return;
            var mfg = rps.manufacturer ? (' (' + rps.manufacturer + ')') : '';
            if (!rps.attempted) {
                // Skipped — unsupported manufacturer or no MAC. Don't spam the user.
                return;
            }
            if (rps.success) {
                var verb = rps.action === 'remove' ? 'Unregistered from RPS' : 'Registered with RPS';
                giantToast(verb + mfg, 'success');
            } else {
                var msg = rps.message || ('RPS ' + rps.action + ' failed');
                giantToast(msg, 'warn');
            }
        };

        // The confirm dialog (giantConfirm) lives in index.js — one implementation,
        // Promise + callbacks. Do not redefine it here.

        // Phone remove dialog — specialised use of giantConfirm with the RPS toggle.
        window.showPhoneRemoveDialog = function ($form, onConfirm) {
            giantConfirm({
                title:        'Remove device?',
                body:         '<p>This will permanently remove the device from your account.</p>',
                icon:         'trash',
                variant:      'danger',
                confirmLabel: 'Remove',
                checkboxes:   [{ id: 'rpsRemove', label: 'Also remove from auto-provisioning', checked: true }],
                onConfirm: function (checks) {
                    $form.find('input[name="rpsRemove"]').remove();
                    if (checks.rpsRemove) {
                        $form.append('<input type="hidden" name="rpsRemove" value="1">');
                    }
                    if (typeof onConfirm === 'function') onConfirm();
                }
            });
        };

        // ===== 999 bulk status check =====
        // Fires a check for every 999 pill on list render. Browser caps concurrency
        // to ~6 per origin; each call goes via our backend which enforces tenant
        // ownership before hitting the external provider.
        window.giantKick999Checks = function () {
            $('.giant-999-status.is-checking').each(function () {
                var $pill = $(this);
                var diId  = $pill.data('di-id');
                if (!diId) return;
                $.ajax({
                    type: 'post',
                    data: { pbxAction: 'check999Data', di_id: diId },
                    success: function (json) {
                        var resp;
                        try { resp = (typeof json === 'object') ? json : jQuery.parseJSON(json); }
                        catch (e) { resp = {}; }

                        $pill.removeClass('is-checking is-set is-incomplete is-missing is-error is-not-simwood');
                        // Stash the full number from the response so the
                        // click handler can route an unmanaged-carrier
                        // pill straight into the port form without a
                        // round-trip.
                        if (resp && resp.number) {
                            $pill.attr('data-number', resp.number);
                        }
                        if (resp && resp.error) {
                            $pill.addClass('is-error').attr('title', resp.error)
                                 .html('<i class="fa-solid fa-triangle-exclamation"></i> 999 Error');
                        } else if (resp && resp.notSimwood) {
                            // Truly unknown carrier — the carrier numbers no
                            // longer hit this branch because their 999 API
                            // is now wired up. Only third-party DIDs that
                            // we can't manage end up here. Offer a
                            // self-serve port-in instead of the dead-end
                            // "contact support" message.
                            $pill.addClass('is-not-simwood')
                                 .attr('title', "We don't manage this number's carrier yet — click to start a port request and bring it onto our network.")
                                 .html('<i class="fa-solid fa-right-left-large"></i> Port to us');
                        } else if (resp && resp.hasData && resp.incomplete) {
                            // Has *some* data but is missing one or more
                            // required fields — emergency services need
                            // every required field, so flag it amber until
                            // the user fills the rest in.
                            var miss = (resp.missingFields || []).join(', ');
                            var tip  = miss
                                ? '999 record is incomplete — missing ' + miss + '. Click to fix.'
                                : '999 record is incomplete. Click to fix.';
                            $pill.addClass('is-incomplete').attr('title', tip)
                                 .html('<i class="fa-solid fa-shield-exclamation"></i> 999 Incomplete');
                        } else if (resp && resp.hasData) {
                            $pill.addClass('is-set').attr('title', 'Click to edit 999 record')
                                 .html('<i class="fa-solid fa-shield-check"></i> 999 Set');
                        } else {
                            $pill.addClass('is-missing').attr('title', 'No 999 record — click to set it now')
                                 .html('<i class="fa-solid fa-siren-on"></i> 999 Missing');
                        }
                    },
                    error: function () {
                        $pill.removeClass('is-checking').addClass('is-error')
                             .html('<i class="fa-solid fa-triangle-exclamation"></i> 999 Error');
                    }
                });
            });
        };

        // Click the pill on a telephone-number row to open the 999 edit dialog.
        // Unmanaged-carrier pills get a self-serve port-in shortcut instead.
        $(document).off('click', '.giant-999-status');
        $(document).on('click', '.giant-999-status', function (e) {
            e.preventDefault();
            var $p = $(this);
            if ($p.hasClass('is-not-simwood')) {
                var num = $p.attr('data-number') || '';
                if (num && typeof window.giantStartPort === 'function') {
                    window.giantStartPort(num);
                }
                return;
            }
            var diId = $p.data('di-id');
            if (!diId || typeof show999Dialog !== 'function') return;
            show999Dialog(diId);
        });

        // Open the existing port form with the MBN pre-filled. Used by
        // the unmanaged-carrier 999 pill — turns the dead-end "we don't
        // manage this carrier" message into a one-click "start a port"
        // flow. The form's MBN input shows "+44" as a fixed prefix, so
        // we strip any leading +/44/0 to leave just the subscriber
        // digits.
        //
        // We drive the modal directly rather than triggering the
        // #tour-port tile, because the 999 pill is itself rendered
        // inside #giantModal (the destinations list is shown there) —
        // and the tile uses Bootstrap's data-toggle="modal", which on
        // an already-open modal just toggles → closes.
        window.giantStartPort = function (fullNumber) {
            var n = String(fullNumber || '').replace(/[^\d]/g, '');
            if (n.indexOf('44') === 0) n = n.substring(2);
            else if (n.indexOf('0') === 0) n = n.substring(1);
            if (!n) return;

            var $modal = $('#giantModal');
            var $btn   = $('#tour-port');

            // Mirror what the show.bs.modal handler does for tile buttons.
            if ($btn.length) {
                $modal.find('#giantModalTitle').html($btn.html());
            } else {
                $modal.find('#giantModalTitle').html('<i class="fa-duotone fa-right-left-large"></i> Port Number');
            }
            var desc = (window.modalDescriptions && window.modalDescriptions.port) || '';
            $modal.find('#giantModalDescription').html(desc);
            $('#giantModalAlertDiv').hide();
            $modal.find('.modal-dialog').removeClass('giant-modal-wide');

            // Swap to the add form. showForm hides every .giantModalPanel
            // and shows the add-form panel, so this works whether the
            // modal is open or not.
            $('.giantModalPanel').hide();
            showForm('port', 'add', 'dynamic', { mbn: n });

            // Open the modal if it isn't already. The show.bs.modal
            // handler will bail because there's no tile relatedTarget,
            // leaving our setup above intact.
            if (!$modal.hasClass('show') && !$modal.is(':visible')) {
                $modal.modal('show');
            }
        };

        // ===== 999 edit dialog =====
        window.show999Dialog = function (diId) {
            $('#giant999Dialog').remove();

            // Loading placeholder
            var $dlg = $(
              '<div id="giant999Dialog" class="giant-confirm-overlay">' +
                '<div class="giant-confirm giant-999-dialog" data-variant="primary">' +
                  '<div class="giant-confirm-head">' +
                    '<div class="giant-confirm-icon"><i class="fa-duotone fa-circle-exclamation"></i></div>' +
                    '<div class="giant-confirm-title">999 Emergency Data</div>' +
                  '</div>' +
                  '<div class="giant-confirm-body">' +
                    '<div class="giant-999-loading" style="padding:20px; text-align:center; color: rgb(var(--muted));">' +
                      '<i class="fa-duotone fa-spinner fa-spin-pulse fa-2xl" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>' +
                      '<p style="margin-top:10px; font-size:13px;">Loading 999 record…</p>' +
                    '</div>' +
                  '</div>' +
                '</div>' +
              '</div>'
            );
            // Append inside the currently-open Bootstrap modal so its focus trap
            // doesn't steal focus from our inputs. Fall back to body otherwise.
            var $hostModal = $('.modal.in, .modal.show').first();
            if ($hostModal.length) {
                $hostModal.append($dlg);
            } else {
                $('body').append($dlg);
            }

            var close = function () { $(document).off('keydown.giant999'); $dlg.remove(); };
            $dlg.on('click', function (e) { if (e.target === this) close(); });
            $(document).on('keydown.giant999', function (e) { if (e.key === 'Escape') close(); });

            $.ajax({
                type: 'post',
                data: { pbxAction: 'check999Data', di_id: diId },
                success: function (json) {
                    var resp;
                    try { resp = (typeof json === 'object') ? json : jQuery.parseJSON(json); }
                    catch (e) { resp = {}; }
                    if (!resp || resp.error) {
                        $dlg.find('.giant-confirm-body').html(
                          '<div class="giant-alert">' + ((resp && resp.error) || 'Could not load 999 record.') + '</div>' +
                          '<div style="text-align:right; margin-top:12px;"><button type="button" class="giant-confirm-cancel">Close</button></div>'
                        );
                        $dlg.find('.giant-confirm-cancel').on('click', close);
                        return;
                    }
                    render999Form($dlg, diId, resp, close);
                },
                error: function () {
                    $dlg.find('.giant-confirm-body').html(
                      '<div class="giant-alert">Could not reach the 999 service.</div>' +
                      '<div style="text-align:right; margin-top:12px;"><button type="button" class="giant-confirm-cancel">Close</button></div>'
                    );
                    $dlg.find('.giant-confirm-cancel').on('click', close);
                }
            });
        };

        function render999Form($dlg, diId, resp, close) {
            var d   = resp.data || {};
            var acc = resp.accountAddress || null;
            var esc = function (s) { return $('<div>').text(s == null ? '' : s).html(); };

            // Decode HTML entities — the external provider (and historic WHMCS saves) sometimes
            // return values pre-encoded (e.g. "St. Martin&#039;s Lane", or
            // double-encoded "St. Martin&amp;#039;s Lane"). Loop until idempotent
            // so nested encodings get fully unwound; a single textarea.innerHTML
            // pass only peels one layer at a time.
            var decodeEntities = function (s) {
                if (s == null || s === '') return '';
                var cur = String(s);
                var prev = null;
                var i = 0;
                var t = document.createElement('textarea');
                while (cur !== prev && i < 5) {
                    prev = cur;
                    t.innerHTML = cur;
                    cur = t.value;
                    i++;
                }
                return cur;
            };
            ['title','forename','name','bussuffix','premises','thoroughfare','locality','postcode'].forEach(function (k) {
                d[k] = decodeEntities(d[k]);
            });

            // Detect the initial mode from existing data. A bussuffix or obviously
            // business-y name pattern signals Business; title/forename signals Personal.
            // Default to Personal when in doubt.
            var initialMode = 'personal';
            if ((d.bussuffix || '').trim() !== '') initialMode = 'business';
            else if ((d.title || '').trim() === '' && (d.forename || '').trim() === '' && (d.name || '').trim() !== '') initialMode = 'business';
            else if ((d.title || '').trim() !== '' || (d.forename || '').trim() !== '') initialMode = 'personal';

            var formHtml =
              '<div class="giant-999-number">Number <strong>' + esc(resp.numberDisplay || resp.number) + '</strong></div>' +
              '<div class="giant-999-mode" role="tablist">' +
                '<button type="button" class="giant-999-mode-option' + (initialMode === 'personal' ? ' is-active' : '') + '" data-mode="personal">' +
                  '<i class="fa-solid fa-user"></i> Personal' +
                '</button>' +
                '<button type="button" class="giant-999-mode-option' + (initialMode === 'business' ? ' is-active' : '') + '" data-mode="business">' +
                  '<i class="fa-solid fa-briefcase"></i> Business' +
                '</button>' +
              '</div>' +
              (acc && acc.address1 ? '<button type="button" class="giant-999-autofill"><i class="fa-duotone fa-user" style="margin-bottom:0; --fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i> Use my account address</button>' : '') +
              '<div class="giant-999-form" data-mode="' + initialMode + '">' +
                // Personal-only: Title + Forename
                '<div class="giant-form-row giant-form-two giant-999-personal-only">' +
                  '<div>' +
                    '<label>Title</label>' +
                    '<input type="text" name="title" maxlength="20" value="' + esc(d.title) + '" placeholder="Mr / Mrs / Dr">' +
                    '<small class="giant-999-help">Optional.</small>' +
                  '</div>' +
                  '<div>' +
                    '<label>Forename</label>' +
                    '<input type="text" name="forename" maxlength="20" value="' + esc(d.forename) + '" placeholder="First name">' +
                    '<small class="giant-999-help">Optional.</small>' +
                  '</div>' +
                '</div>' +
                // Name — label changes per mode via CSS pseudo
                '<div class="giant-form-row">' +
                  '<label class="giant-999-name-label">' +
                    '<span class="mode-personal">Surname <span class="req">*</span></span>' +
                    '<span class="mode-business">Business name <span class="req">*</span></span>' +
                  '</label>' +
                  '<input type="text" name="name" maxlength="50" value="' + esc(d.name) + '">' +
                  '<small class="giant-999-help">' +
                    '<span class="mode-personal">The end-user\'s surname.</span>' +
                    '<span class="mode-business">The trading name &mdash; the name &ldquo;over the door&rdquo;, not a parent or holding company.</span>' +
                  '</small>' +
                '</div>' +
                // Business-only: Business suffix
                '<div class="giant-form-row giant-999-business-only">' +
                  '<label>Business suffix</label>' +
                  '<input type="text" name="bussuffix" maxlength="50" value="' + esc(d.bussuffix) + '" placeholder="Ltd, Plc, Hotel, Hospital, Fuel Depot &hellip;">' +
                  '<small class="giant-999-help">Legal suffix (Ltd, Plc, LLP) <em>and/or</em> a short descriptor that helps emergency services identify the site.</small>' +
                '</div>' +
                // Shared address fields
                '<div class="giant-form-row giant-form-two">' +
                  '<div>' +
                    '<label>Property name / number <span class="req">*</span></label>' +
                    '<input type="text" name="premises" maxlength="60" value="' + esc(d.premises) + '" placeholder="e.g. 104, Thatched Cottage">' +
                    '<small class="giant-999-help">The house number or building name that identifies the premises on its street.</small>' +
                  '</div>' +
                  '<div>' +
                    '<label>Street <span class="req">*</span></label>' +
                    '<input type="text" name="thoroughfare" maxlength="55" value="' + esc(d.thoroughfare) + '" placeholder="e.g. King Street">' +
                    '<small class="giant-999-help">The street name (e.g. King Street, Station Road).</small>' +
                  '</div>' +
                '</div>' +
                '<div class="giant-form-row giant-form-two">' +
                  '<div>' +
                    '<label>Town / City <span class="req">*</span></label>' +
                    '<input type="text" name="locality" maxlength="30" value="' + esc(d.locality) + '" placeholder="e.g. York">' +
                    '<small class="giant-999-help">Village or area within a town, plus the town itself if relevant.</small>' +
                  '</div>' +
                  '<div>' +
                    '<label>Postcode <span class="req">*</span></label>' +
                    '<input type="text" name="postcode" maxlength="12" value="' + esc(d.postcode) + '" placeholder="e.g. YO30 4AG">' +
                    '<small class="giant-999-help">Full UK postcode, out-code space in-code (e.g. YO30 4AG).</small>' +
                  '</div>' +
                '</div>' +
              '</div>' +
              '<div class="giant-999-notice">' +
                '<i class="fa-solid fa-circle-info" style="margin-right:6px;"></i>' +
                'This record is used by the emergency services to locate the caller, so keep it accurate. Enter the <strong>site</strong> details (where the phone physically lives) &mdash; not the billing contact.' +
              '</div>' +
              '<div class="giant-999-alert" style="display:none;"></div>';

            var actionsHtml =
              '<div class="giant-confirm-actions">' +
                '<button type="button" class="giant-confirm-cancel">Cancel</button>' +
                '<button type="button" class="giant-confirm-ok">Save 999 record</button>' +
              '</div>';

            $dlg.find('.giant-confirm-body').html(formHtml);
            if (!$dlg.find('.giant-confirm-actions').length) {
                $dlg.find('.giant-confirm').append(actionsHtml);
            }

            $dlg.find('.giant-confirm-cancel').off('click').on('click', close);

            // Personal/Business mode toggle — hides the wrong-mode fields and makes
            // sure we don't send both (the external provider rejects mixed records).
            $dlg.find('.giant-999-mode-option').on('click', function () {
                var mode = $(this).data('mode');
                $dlg.find('.giant-999-mode-option').removeClass('is-active');
                $(this).addClass('is-active');
                $dlg.find('.giant-999-form').attr('data-mode', mode);
            });

            // Auto-fill from WHMCS account
            $dlg.find('.giant-999-autofill').on('click', function () {
                function splitPremises(a1, a2) {
                    a1 = (a1 || '').trim(); a2 = (a2 || '').trim();

                    var patterns = [
                        // "Unit 1 34 Regent Street" / "Flat 3A The Maltings" / "Suite 3, 102 …"
                        /^((?:Unit|Flat|Apartment|Apt|Suite|Office|Shop|Studio|Room|Plot|Lot|Block)\s+\d+[A-Za-z]?(?:[\s\-\/]\d+[A-Za-z]?)?),?\s+(.+)$/i,
                        // "48 Lyndhurst Road" / "12A High Street" / "45-47 The Strand"
                        /^(\d+[A-Za-z]?(?:[\s\-\/]\d+[A-Za-z]?)?),?\s+(.+)$/
                    ];
                    var streetRx = /\b(street|st|road|rd|lane|ln|avenue|ave|way|close|drive|dr|crescent|park|square|sq|gardens?|terrace|place|court|hill|view|grove|mews|broadway|boulevard|blvd|parade|walk|rise|chase|wharf|quay|bridge|cross|circus|row|highway|approach|esplanade|promenade|passage|docks?)\b/i;

                    function trySplit(line) {
                        if (!line) return null;
                        for (var i = 0; i < patterns.length; i++) {
                            var m = patterns[i].exec(line);
                            if (m) {
                                // Recurse once into the right side so
                                // "Suite 3, 102 Regent Street" becomes
                                // "Suite 3, 102" + "Regent Street" rather
                                // than "Suite 3" + "102 Regent Street".
                                var inner = null;
                                for (var j = 0; j < patterns.length; j++) {
                                    inner = patterns[j].exec(m[2]);
                                    if (inner) break;
                                }
                                if (inner) {
                                    return { premises: m[1].trim() + ', ' + inner[1].trim(), thoroughfare: inner[2].trim() };
                                }
                                return { premises: m[1].trim(), thoroughfare: m[2].trim() };
                            }
                        }
                        return null;
                    }

                    var splitA1 = trySplit(a1);
                    var splitA2 = trySplit(a2);
                    var hasStreetA1 = streetRx.test(a1);
                    var hasStreetA2 = streetRx.test(a2);

                    // Shape A: addr1 splits cleanly ("26 Hope Street").
                    // addr2 is a locality hint (suburb) unless it also
                    // has a street suffix (then fold into premises).
                    if (splitA1) {
                        var premA = splitA1.premises;
                        var extraLoc = '';
                        if (a2) {
                            if (hasStreetA2) premA = premA ? (premA + ', ' + a2) : a2;
                            else             extraLoc = a2;
                        }
                        return { premises: premA, thoroughfare: splitA1.thoroughfare, extraLocality: extraLoc };
                    }

                    // Shape B: addr1 is a building name, addr2 has the
                    // unit/number + street ("Make North Docks" + "Unit 1 34 Regent Street").
                    if (splitA2) {
                        var premB = splitA2.premises;
                        if (a1) premB = premB ? (premB + ', ' + a1) : a1;
                        return { premises: premB, thoroughfare: splitA2.thoroughfare, extraLocality: '' };
                    }

                    // Shape C: neither line splits cleanly. Pick the line
                    // with a street suffix as the thoroughfare candidate.
                    var pickStreet = hasStreetA1 ? a1 : (hasStreetA2 ? a2 : a1);
                    var pickOther  = (pickStreet === a1) ? a2 : a1;
                    if (!pickStreet) pickStreet = a1 || a2;

                    var thoroC = pickStreet || '';
                    var innerExtra = '';

                    // Comma-split pickStreet, picking whichever half has
                    // the street suffix as thoroughfare. Catches both:
                    //   "The Old Mill, Mill Lane" (street on right)
                    //   "Selby Place, Stanley Industrial Estate" (street on left)
                    var c = pickStreet ? pickStreet.indexOf(',') : -1;
                    if (c > 0) {
                        var left  = pickStreet.substring(0, c).trim();
                        var right = pickStreet.substring(c + 1).trim();
                        if (streetRx.test(left) && !streetRx.test(right)) {
                            thoroC = left;
                            innerExtra = right;
                        } else {
                            thoroC = right;
                            innerExtra = left;
                        }
                    }

                    // pickOther (building name from the other line) leads
                    // premises; inner-comma extras follow.
                    var premC = '';
                    if (pickOther)   premC = pickOther;
                    if (innerExtra)  premC = premC ? (premC + ', ' + innerExtra) : innerExtra;
                    return { premises: premC, thoroughfare: thoroC, extraLocality: '' };
                }
                function combineLocality(extra, city) {
                    extra = (extra || '').trim(); city = (city || '').trim();
                    if (!extra) return city;
                    if (!city)  return extra;
                    var combined = extra + ', ' + city;
                    return combined.length <= 30 ? combined : extra;
                }
                // Split a UK company name off its legal suffix (Ltd, Limited, Plc, LLP, …)
                // so the business name goes in `name` and the suffix in `bussuffix`.
                function splitCompany(full) {
                    full = (full || '').trim();
                    if (!full) return { biz: '', suffix: '' };
                    var m = /^(.+?)[\s,]+(Ltd\.?|Limited|P\.?L\.?C\.?|LLP|L\.L\.P\.?|CIC|C\.I\.C\.?|LP|Inc\.?|Incorporated|Co\.?)\s*$/i.exec(full);
                    if (m) return { biz: m[1].trim(), suffix: m[2].trim() };
                    return { biz: full, suffix: '' };
                }

                var sp = splitPremises(acc.address1, acc.address2);
                // On explicit auto-fill click, overwrite every field we have a value for —
                // the user asked for the account address so they want the full swap, not a merge.
                var setVal = function (name, value) {
                    var $el = $dlg.find('input[name="' + name + '"]');
                    if ($el.length) $el.val(value || '');
                };

                // If the WHMCS account has a company, switch the toggle to Business
                // and fill only business-relevant fields. Otherwise switch to Personal.
                var switchMode = function (mode) {
                    $dlg.find('.giant-999-mode-option').removeClass('is-active')
                        .filter('[data-mode="' + mode + '"]').addClass('is-active');
                    $dlg.find('.giant-999-form').attr('data-mode', mode);
                };

                if (acc.companyname) {
                    switchMode('business');
                    var co = splitCompany(acc.companyname);
                    setVal('name',      co.biz);
                    setVal('bussuffix', co.suffix);
                    // Business mode — blank the personal-only fields so nothing stale leaks on save
                    setVal('title',     '');
                    setVal('forename',  '');
                } else {
                    switchMode('personal');
                    setVal('forename',  acc.firstname);
                    setVal('name',      acc.lastname);
                    setVal('bussuffix', '');
                }

                setVal('premises',     sp.premises);
                setVal('thoroughfare', sp.thoroughfare);
                setVal('locality',     combineLocality(sp.extraLocality, acc.city));
                setVal('postcode',     acc.postcode);

                var $btn = $(this);
                var orig = $btn.html();
                $btn.html('<i class="fa-solid fa-check" style="margin-bottom:0;"></i> Filled').prop('disabled', true);
                setTimeout(function () { $btn.html(orig).prop('disabled', false); }, 1600);
            });

            // Save
            $dlg.find('.giant-confirm-ok').off('click').on('click', function () {
                var $btn = $(this);
                var $alert = $dlg.find('.giant-999-alert').hide();
                var payload = { pbxAction: 'save999Data', di_id: diId };
                ['title','forename','name','bussuffix','premises','thoroughfare','locality','postcode'].forEach(function (k) {
                    payload[k] = $dlg.find('input[name="' + k + '"]').val() || '';
                });

                // Enforce Personal/Business exclusivity — the external provider rejects mixed records.
                var mode = $dlg.find('.giant-999-form').attr('data-mode') || 'personal';
                if (mode === 'business') {
                    payload.title    = '';
                    payload.forename = '';
                } else {
                    payload.bussuffix = '';
                }

                $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> Saving…');
                $.ajax({
                    type: 'post',
                    data: payload,
                    success: function (json) {
                        var r;
                        try { r = (typeof json === 'object') ? json : jQuery.parseJSON(json); }
                        catch (e) { r = {}; }
                        if (r && r.success) {
                            var msg;
                            if (r.verified) {
                                msg = '999 record saved & verified for ' + (resp.numberDisplay || resp.number);
                            } else {
                                msg = '999 record accepted for ' + (resp.numberDisplay || resp.number) + ' — verification pending';
                            }
                            if (typeof giantToast === 'function') {
                                giantToast(msg, r.verified ? 'success' : 'warn');
                            }
                            // Mirror the bulk-check rule: any missing
                            // required field flips the pill to amber
                            // "Incomplete" so the user keeps seeing it
                            // until they fix it. Computed from the
                            // payload we just submitted to avoid a
                            // round-trip.
                            var requiredLabels = {
                                name: 'name',
                                premises: 'property name/number',
                                thoroughfare: 'street',
                                locality: 'town/city',
                                postcode: 'postcode'
                            };
                            var missingNow = [];
                            Object.keys(requiredLabels).forEach(function (k) {
                                if (!String(payload[k] || '').trim()) missingNow.push(requiredLabels[k]);
                            });

                            var $pill = $('.giant-999-status[data-di-id="' + diId + '"]');
                            $pill.removeClass('is-checking is-set is-incomplete is-missing is-error');
                            if (missingNow.length) {
                                $pill.addClass('is-incomplete')
                                     .attr('title', '999 record is incomplete — missing ' + missingNow.join(', ') + '. Click to fix.')
                                     .html('<i class="fa-solid fa-shield-exclamation"></i> 999 Incomplete');
                            } else {
                                $pill.addClass('is-set')
                                     .attr('title', r.verified ? 'Click to edit 999 record' : 'Saved — waiting for confirmation. Re-open to re-check.')
                                     .html('<i class="fa-solid fa-shield-check"></i> 999 Set');
                            }
                            close();
                        } else {
                            $alert.text((r && r.error) || 'Save failed.').show();
                            $btn.prop('disabled', false).html('Save 999 record');
                        }
                    },
                    error: function () {
                        $alert.text('Could not save. Try again in a moment.').show();
                        $btn.prop('disabled', false).html('Save 999 record');
                    }
                });
            });
        }

        // ===== RPS bulk status check =====
        // Called after a phone list renders — fires parallel AJAX checks for every
        // supported device and swaps each pill to Adopted / Unadopted / Check N/A / Error.
        window.giantKickRpsChecks = function () {
            $('.giant-rps-status.is-checking').each(function () {
                var $pill = $(this);
                var mac   = $pill.data('mac');
                if (!mac) return;
                $.ajax({
                    type: 'post',
                    data: { pbxAction: 'rpsDevice', rpsAction: 'check', mac: mac },
                    success: function (json) {
                        var resp;
                        try { resp = (typeof json === 'object') ? json : jQuery.parseJSON(json); }
                        catch (e) { resp = {}; }

                        $pill.removeClass('is-checking is-adopted is-unadopted is-error is-check-na');
                        if (resp && resp.error) {
                            $pill.addClass('is-error')
                                 .attr('title', resp.error)
                                 .html('<i class="fa-solid fa-triangle-exclamation"></i> Error');
                        } else if (resp && resp.success) {
                            $pill.addClass('is-adopted')
                                 .attr('title', resp.message || 'Registered with ' + (resp.manufacturerLabel || 'RPS'))
                                 .html('<i class="fa-solid fa-circle-check"></i> Adopted');
                        } else if (giantRpsCheckUnsupported(resp)) {
                            $pill.addClass('is-check-na')
                                 .attr('title', resp.message || 'This manufacturer does not support status checks')
                                 .html('<i class="fa-solid fa-circle-question"></i> Check N/A');
                        } else {
                            $pill.addClass('is-unadopted')
                                 .attr('title', (resp && resp.message) ? resp.message : 'Not registered with RPS')
                                 .html('<i class="fa-solid fa-circle-minus"></i> Unadopted');
                        }
                    },
                    error: function () {
                        $pill.removeClass('is-checking')
                             .addClass('is-error')
                             .attr('title', 'Could not reach RPS.')
                             .html('<i class="fa-solid fa-triangle-exclamation"></i> Error');
                    }
                });
            });
        };

        // ===== RPS management dropdown (per-device) =====
        $(document).off('click', '.giant-device-rps-btn');
        $(document).on('click', '.giant-device-rps-btn', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $wrap = $(this).closest('.giant-device-rps');
            // Close any other open menus
            $('.giant-device-rps.is-open').not($wrap).removeClass('is-open');
            $wrap.toggleClass('is-open');
        });

        // Close menu on outside click
        $(document).off('click.giantRps').on('click.giantRps', function (e) {
            if (!$(e.target).closest('.giant-device-rps').length) {
                $('.giant-device-rps.is-open').removeClass('is-open');
            }
        });

        $(document).off('click', '.giant-device-rps-menu button');
        $(document).on('click', '.giant-device-rps-menu button', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $btn   = $(this);
            var mac    = $btn.data('mac');
            var act    = $btn.data('rps-action');
            var phId   = $btn.data('ph-id');
            var phAct  = $btn.data('phone-action');
            var $wrap  = $btn.closest('.giant-device-rps');
            $wrap.removeClass('is-open');

            // Reboot / re-register actions — different menu entries hung off
            // the same dropdown component. Confirm before reboot since it
            // takes the phone offline for ~30s; re-register is fast and
            // doesn't drop active calls so it skips the confirm.
            if (phId && phAct) {
                var fireReboot = function () {
                    var label = phAct === 'reboot' ? 'Rebooting phone…' : 'Re-registering phone…';
                    if (typeof giantToast === 'function') giantToast(label, 'info');
                    $.ajax({
                        type: 'post',
                        data: { pbxAction: 'rebootPhone', ph_id: phId, mode: phAct },
                        dataType: 'json'
                    }).done(function (resp) {
                        if (resp && resp.ok) {
                            if (typeof giantToast === 'function') giantToast(resp.message || 'Done.', 'success');
                        } else {
                            if (typeof giantToast === 'function') giantToast((resp && resp.error) || 'Could not reach the phone.', 'error');
                        }
                    }).fail(function () {
                        if (typeof giantToast === 'function') giantToast('Could not reach the phone.', 'error');
                    });
                };

                if (phAct === 'reboot') {
                    giantConfirm({
                        title:        'Reboot this phone?',
                        body:         '<p>The phone will go offline for around 30 seconds while it restarts. Active calls on this phone will drop.</p>',
                        icon:         'power',
                        variant:      'danger',
                        confirmLabel: 'Reboot',
                        onConfirm:    fireReboot
                    });
                } else {
                    fireReboot();
                }
                return;
            }

            if (!mac || !act) return;

            var runAction = function () { fireRpsAction(act, mac); };

            if (act === 'remove') {
                giantConfirm({
                    title:        'Unregister from RPS?',
                    body:         '<p>This will remove <strong>' + mac + '</strong> from the manufacturer RPS. The phone will stop receiving Auto-provisioning on its next boot.</p>',
                    icon:         'unlink',
                    variant:      'danger',
                    confirmLabel: 'Unregister',
                    onConfirm:    runAction
                });
                return;
            }
            if (act === 'add') {
                giantConfirm({
                    title:        'Register with RPS?',
                    body:         '<p>Register <strong>' + mac + '</strong> with the manufacturer RPS so the phone picks up Auto-provisioning on its next boot.</p>',
                    icon:         'cloud-up',
                    variant:      'primary',
                    confirmLabel: 'Register',
                    onConfirm:    runAction
                });
                return;
            }

            // Check — no confirm needed
            runAction();
        });

        // Actual RPS action fire — extracted so giantConfirm can trigger it.
        function fireRpsAction(act, mac) {
            var verbProg = act === 'check' ? 'Checking' : act === 'add' ? 'Registering' : 'Unregistering';
            if (typeof giantToast === 'function') giantToast(verbProg + ' ' + mac + '…', 'info');

            $.ajax({
                type: 'post',
                data: { pbxAction: 'rpsDevice', rpsAction: act, mac: mac },
                success: function (json) {
                    var resp;
                    try { resp = (typeof json === 'object') ? json : jQuery.parseJSON(json); } catch (e) { resp = { success: false, error: 'Bad response' }; }
                    var mfg = resp.manufacturerLabel || '';
                    if (resp.success) {
                        var verbPast = act === 'check' ? 'Checked' : act === 'add' ? 'Registered' : 'Unregistered';
                        var msg = verbPast + ' ' + mac + (mfg ? ' with ' + mfg : '') + '.';
                        if (resp.message) msg += ' ' + resp.message;
                        if (typeof giantToast === 'function') giantToast(msg, 'success');
                    } else {
                        var err = resp.error || resp.message || 'RPS ' + act + ' failed.';
                        if (typeof giantToast === 'function') giantToast(err, 'error');
                    }

                    // Update any matching status pill so the UI reflects the new state
                    var $pill = $('.giant-rps-status[data-mac="' + String(mac).replace(/"/g, '\\"') + '"]');
                    if ($pill.length) {
                        $pill.removeClass('is-checking is-adopted is-unadopted is-error is-check-na');
                        if (resp.error) {
                            $pill.addClass('is-error').attr('title', resp.error)
                                 .html('<i class="fa-solid fa-triangle-exclamation"></i> Error');
                        } else if (act === 'check') {
                            if (resp.success) {
                                $pill.addClass('is-adopted').attr('title', resp.message || 'Registered')
                                     .html('<i class="fa-solid fa-circle-check"></i> Adopted');
                            } else if (giantRpsCheckUnsupported(resp)) {
                                $pill.addClass('is-check-na').attr('title', resp.message || 'This manufacturer does not support status checks')
                                     .html('<i class="fa-solid fa-circle-question"></i> Check N/A');
                            } else {
                                $pill.addClass('is-unadopted').attr('title', resp.message || 'Not registered')
                                     .html('<i class="fa-solid fa-circle-minus"></i> Unadopted');
                            }
                        } else if (act === 'add' && resp.success) {
                            $pill.addClass('is-adopted').attr('title', resp.message || 'Registered')
                                 .html('<i class="fa-solid fa-circle-check"></i> Adopted');
                        } else if (act === 'remove' && resp.success) {
                            $pill.addClass('is-unadopted').attr('title', resp.message || 'Unregistered')
                                 .html('<i class="fa-solid fa-circle-minus"></i> Unadopted');
                        }
                    }
                },
                error: function () {
                    if (typeof giantToast === 'function') giantToast('Could not reach RPS. Try again in a moment.', 'error');
                    var $pill = $('.giant-rps-status[data-mac="' + String(mac).replace(/"/g, '\\"') + '"]');
                    if ($pill.length) {
                        $pill.removeClass('is-checking is-adopted is-unadopted').addClass('is-error')
                             .attr('title', 'Could not reach RPS.')
                             .html('<i class="fa-solid fa-triangle-exclamation"></i> Error');
                    }
                }
            });
        }
        {/literal}
    });
    var labels = JSON.parse('{$labels}');
    var inboundCalls = JSON.parse('{$inboundCalls}');
    var outboundCalls = JSON.parse('{$outboundCalls}');


    if (inboundCalls.length > 0 && outboundCalls.length > 0) {
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    lineTension: 0.4,
                    label: 'Outbound',
                    data: outboundCalls,
                    fill: 'start',
                    backgroundColor: window.gvColor('accent', .15),
                    borderColor: window.gvColor('accent'),
                    borderWidth: 2,
                    pointRadius: 3,
                    pointBackgroundColor: window.gvColor('accent'),
                }, {
                    lineTension: 0.4,
                    label: 'Inbound',
                    data: inboundCalls,
                    fill: 'start',
                    backgroundColor: window.gvColor('accent-2', .15),
                    borderColor: window.gvColor('accent-2'),
                    borderWidth: 2,
                    pointRadius: 3,
                    pointBackgroundColor: window.gvColor('accent-2'),
                }]
            },
            options: {
                plugins: {
                    legend: {
                        position: "bottom",
                        labels: {
                            usePointStyle: true,
                            pointStyle: 'circle',
                            padding: 20,
                            font: { size: 12, weight: '600' }
                        }
                    },
                    title: {
                        display: false
                    },
                    subtitle: {
                        display: true,
                        text: "Calls per day for current billing cycle",
                        font: { size: 12 },
                        color: window.gvColor('muted'),
                        padding: { bottom: 16 }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            display: false,
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    {literal}
    // ===== "Show more" helper — folds long grids (phones, extensions, devices) =====
    window.giantSetupShowMore = function (gridSelector, threshold, labelSingular, labelPlural) {
        var $grid = $(gridSelector);
        if (!$grid.length) return;

        // Clear previous button (re-run safe for polled grids)
        var existingId = 'showmore-for-' + gridSelector.replace(/[^\w-]/g, '_');
        $('#' + existingId).remove();

        var $items = $grid.children().not('.giant-show-more-wrap');
        if ($items.length <= threshold) {
            $grid.removeClass('is-collapsed');
            $items.removeAttr('data-overflow');
            return;
        }

        var wasExpanded = $grid.data('giant-expanded') === true;
        $items.removeAttr('data-overflow');
        $items.slice(threshold).attr('data-overflow', '1');
        $grid.toggleClass('is-collapsed', !wasExpanded);

        var hidden = $items.length - threshold;
        var moreLabel = hidden === 1 ? (labelSingular || 'more') : (labelPlural || labelSingular + 's');
        var $btn = $('<button type="button" class="giant-show-more"></button>');
        var paint = function (collapsed) {
            $btn.html(collapsed
                ? '<i class="fa-solid fa-chevron-down" style="margin-bottom:0; margin-right:6px;"></i>Show ' + hidden + ' more ' + moreLabel
                : '<i class="fa-solid fa-chevron-up" style="margin-bottom:0; margin-right:6px;"></i>Show less');
        };
        paint(!wasExpanded);

        var $wrap = $('<div class="giant-show-more-wrap"></div>').attr('id', existingId).append($btn);
        $grid.after($wrap);

        $btn.on('click', function () {
            var collapsed = $grid.toggleClass('is-collapsed').hasClass('is-collapsed');
            $grid.data('giant-expanded', !collapsed);
            paint(collapsed);
        });
    };

    // ===== Shared analytics helpers (used by both the card and the modal) =====
    window.GiantAnalytics = (function () {
        function fmtDuration(sec) {
            sec = Math.max(0, Math.floor(Number(sec) || 0));
            var h = Math.floor(sec / 3600);
            var m = Math.floor((sec % 3600) / 60);
            var s = sec % 60;
            if (h > 0) return h + 'h ' + (m < 10 ? '0' : '') + m + 'm';
            if (m > 0) return m + 'm ' + (s < 10 ? '0' : '') + s + 's';
            return s + 's';
        }
        function fmtShortDuration(sec) {
            sec = Math.max(0, Math.floor(Number(sec) || 0));
            var h = Math.floor(sec / 3600);
            var m = Math.floor((sec % 3600) / 60);
            if (h > 0) return h + 'h ' + (m < 10 ? '0' : '') + m + 'm';
            return m + 'm';
        }
        function fmtDate(yyyyMmDd, opts) {
            try {
                var d = new Date(yyyyMmDd + 'T00:00:00');
                return d.toLocaleDateString('en-GB', opts || { day: 'numeric', month: 'short' });
            } catch (e) { return yyyyMmDd; }
        }
        function setText(el, v) { if (el && el.textContent !== String(v)) el.textContent = v; }
        function escapeHtml(s) { return (s == null ? '' : String(s)).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]); }); }
        function initials(name) {
            var p = (name || '').split(/\s+/).filter(Boolean);
            if (p.length >= 2) return (p[0][0] + p[p.length - 1][0]).toUpperCase();
            return (name || '').substring(0, 2).toUpperCase();
        }
        function colorFromName(name) {
            var palette = [window.gvColor('accent'), window.gvColor('accent', .55), window.gvColor('accent-2'), window.gvColor('warn'), window.gvColor('accent-2', .65), window.gvColor('danger'), window.gvColor('accent', .75), window.gvColor('danger', .65), window.gvColor('accent', .85), window.gvColor('accent-2', .85)];
            var h = 0;
            for (var i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
            return palette[Math.abs(h) % palette.length];
        }
        var outcomeColors = {
            'ANSWERED':   window.gvColor('accent'),
            'NO ANSWER':  window.gvColor('accent', .55),
            'BUSY':       window.gvColor('accent-2', .65),
            'CONGESTION': window.gvColor('danger'),
            'FAILED':     window.gvColor('warn'),
            'UNKNOWN':    window.gvColor('muted', .55)
        };
        return {
            fmtDuration: fmtDuration,
            fmtShortDuration: fmtShortDuration,
            fmtDate: fmtDate,
            setText: setText,
            escapeHtml: escapeHtml,
            initials: initials,
            colorFromName: colorFromName,
            outcomeColors: outcomeColors,
            extensionPalette: [window.gvColor('accent'), window.gvColor('accent', .55), window.gvColor('accent-2'), window.gvColor('warn'), window.gvColor('accent-2', .65), window.gvColor('danger'), window.gvColor('accent', .75), window.gvColor('danger', .65)]
        };
    })();

    // ===== TODAY'S CALL STATS CARD =====
    (function () {
        var refreshMs = 60000;
        var inFlight  = false;
        var paused    = false;

        var kpi = {
            total:        document.getElementById('kpiTotalCalls'),
            totalSub:     document.getElementById('kpiTotalCallsSub'),
            outbound:     document.getElementById('kpiOutboundTalk'),
            outboundSub:  document.getElementById('kpiOutboundTalkSub'),
            inbound:      document.getElementById('kpiInboundTalk'),
            inboundSub:   document.getElementById('kpiInboundTalkSub'),
            combined:     document.getElementById('kpiCombinedTalk'),
            connect:      document.getElementById('kpiConnectRate'),
            connectSub:   document.getElementById('kpiConnectRateSub'),
            over5m:       document.getElementById('kpiCallsOver5m'),
            over5mSub:    document.getElementById('kpiCallsOver5mSub'),
            updated:      document.querySelector('#todayStatsUpdated span:last-child')
        };

        if (!kpi.total) return; // section not on page

        var G = window.GiantAnalytics;

        function render(s) {
            var t = s.totals || {};
            if (window.giantTileState && (t.totalCalls || 0) > 0) giantTileState('callLog', (t.totalCalls || 0) + ' calls today', true);
            if (kpi.connect && kpi.connect.closest('.giant-today-kpi')) {
                var rate = Number(t.connectRate || 0);
                kpi.connect.closest('.giant-today-kpi').setAttribute('data-health', (t.totalCalls || 0) ? (rate >= 70 ? 'good' : rate >= 40 ? 'warn' : 'low') : '');
            }
            G.setText(kpi.total,       t.totalCalls || 0);
            G.setText(kpi.totalSub,    (t.outCalls || 0) + ' out \u00b7 ' + (t.inCalls || 0) + ' in');
            G.setText(kpi.outbound,    G.fmtShortDuration(t.outTalk));
            G.setText(kpi.outboundSub, (t.outAnswered || 0) + ' answered');
            G.setText(kpi.inbound,     G.fmtShortDuration(t.inTalk));
            G.setText(kpi.inboundSub,  (t.inAnswered || 0) + ' answered');
            G.setText(kpi.combined,    G.fmtShortDuration(t.combinedTalk));
            G.setText(kpi.connect,     (t.connectRate || 0) + '%');
            G.setText(kpi.connectSub,  (t.answered || 0) + '/' + (t.totalCalls || 0) + ' answered');
            G.setText(kpi.over5m,      t.over5mCount || 0);
            G.setText(kpi.over5mSub,   G.fmtShortDuration(t.over5mTalk) + ' total talk');
            G.setText(kpi.updated,     'Updated ' + (s.generatedAt || ''));
        }

        function fetchStats() {
            if (paused || inFlight) return;
            inFlight = true;
            $.ajax({
                type: 'post',
                data: { pbxAction: 'getCallAnalytics', range: 'day' },
                success: function (json) {
                    try {
                        var resp = (typeof json === 'object') ? json : jQuery.parseJSON(json);
                        if (resp && !resp.error) render(resp);
                        else if (resp && resp.error) G.setText(kpi.updated, 'Error');
                    } catch (e) {
                        G.setText(kpi.updated, 'Error');
                    }
                },
                error: function () { G.setText(kpi.updated, 'Retry in 1m'); },
                complete: function () { inFlight = false; }
            });
        }

        document.addEventListener('visibilitychange', function () {
            paused = document.hidden;
            if (!paused) fetchStats();
        });

        fetchStats();
        setInterval(fetchStats, refreshMs);
    })();

    // ===== ANALYTICS MODAL =====
    (function () {
        if (!document.getElementById('giantAnalyticsModal')) return;

        var G = window.GiantAnalytics;
        var state = { range: 'day', start: '', end: '', data: null, inFlight: false, expanded: {} };
        var charts = { direction: null, outcome: null, extension: null, daily: null, geo: null };

        // Equirectangular projection tuned for the UK: longitude is squashed by
        // cos(~54.5°N) so the country keeps its true (tall) proportions instead
        // of being stretched wide. Shared by the live map and the PDF export, so
        // both look identical. GEO_ASPECT is width/height of the plotted extent.
        var GEO_COS    = 0.58;
        var GEO_X      = { min: -5.3, max: 1.3 };   // projected lng (lng * GEO_COS)
        var GEO_Y      = { min: 49.8, max: 59.0 };  // latitude
        var GEO_ASPECT = (GEO_X.max - GEO_X.min) / (GEO_Y.max - GEO_Y.min);
        function geoX(lng) { return lng * GEO_COS; }

        // Low-poly UK coastline ([lng, lat] rings: Great Britain + NI), drawn
        // behind the destination bubbles. It shares the bubble chart's scales,
        // so it stays aligned at any canvas size.
        var UK_OUTLINE = [
            [[-5.71,50.07],[-5.05,49.96],[-4.14,50.37],[-3.55,50.22],[-2.45,50.60],[-1.30,50.73],[-0.14,50.82],[0.27,50.74],[1.41,51.14],[1.42,51.39],[0.74,51.51],[1.28,51.95],[1.75,52.48],[1.29,52.93],[0.34,52.90],[0.34,53.14],[-0.05,53.62],[-0.08,54.12],[-0.62,54.49],[-1.18,54.69],[-1.42,55.02],[-1.78,55.63],[-2.03,55.81],[-2.58,56.05],[-2.60,56.28],[-2.09,57.15],[-2.07,57.70],[-3.06,57.70],[-3.78,57.86],[-3.09,58.44],[-3.02,58.64],[-4.40,58.55],[-5.00,58.62],[-5.16,57.90],[-5.65,57.55],[-5.90,57.40],[-5.55,56.95],[-5.71,56.62],[-5.50,56.00],[-5.80,55.30],[-4.86,55.30],[-5.00,54.90],[-3.60,54.88],[-3.57,54.64],[-3.20,54.10],[-3.05,53.82],[-3.10,53.40],[-3.78,53.32],[-4.63,53.31],[-4.40,52.90],[-4.08,52.40],[-4.70,52.12],[-5.30,51.90],[-5.10,51.70],[-4.30,51.62],[-3.98,51.57],[-3.18,51.40],[-2.97,51.35],[-3.40,51.18],[-4.06,51.08],[-4.55,50.83],[-5.08,50.42],[-5.71,50.07]],
            [[-5.70,54.66],[-5.47,54.49],[-5.55,54.25],[-6.05,54.05],[-6.34,54.11],[-7.05,54.20],[-7.55,54.13],[-8.05,54.45],[-7.45,55.05],[-7.05,55.20],[-6.65,55.21],[-6.05,55.05],[-5.70,54.86],[-5.70,54.66]]
        ];
        var ukMapPlugin = {
            id: 'ukMap',
            beforeDatasetsDraw: function (chart) {
                var xs = chart.scales.x, ys = chart.scales.y;
                if (!xs || !ys) return;
                var ctx = chart.ctx;
                ctx.save();
                ctx.beginPath();
                UK_OUTLINE.forEach(function (ring) {
                    ring.forEach(function (pt, i) {
                        var px = xs.getPixelForValue(pt[0] * GEO_COS), py = ys.getPixelForValue(pt[1]);
                        if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
                    });
                });
                ctx.fillStyle = window.gvColor('muted', .08);
                ctx.fill();
                ctx.lineWidth = 1;
                ctx.strokeStyle = window.gvColor('muted', .35);
                ctx.stroke();
                ctx.restore();
            }
        };

        // Move to <body> so WHMCS layout containers can't clip the modal (matches #giantModal pattern)
        $('#giantAnalyticsModal').appendTo('body');

        var $modal   = $('#giantAnalyticsModal');
        var $pills   = $('#giantRangePills');
        var $loading = $('#giantAnalyticsLoading');
        var $main    = $('#giantAnalyticsMain');
        var $error   = $('#giantAnalyticsError');
        var $refresh = $('#giantAnalyticsRefresh');
        var $custom  = $('#giantRangeCustom');
        var $customBtn = $('#giantRangeCustomBtn');
        var $customStart = $('#giantRangeCustomStart');
        var $customEnd   = $('#giantRangeCustomEnd');
        var $quartersBtn  = $('#giantRangeQuartersBtn');
        var $quartersMenu = $('#giantRangeQuartersMenu');

        function setActiveRange(r) {
            $pills.find('.giant-range-pill').removeClass('is-active');
            var qm = /^q([1-4])_(\d{4})$/.exec(r);
            if (qm) {
                $quartersBtn.addClass('is-active').html('Q' + qm[1] + ' ' + qm[2] + ' <i class="fa-solid fa-chevron-down" style="font-size:9px; margin-left:2px; margin-bottom:0;"></i>');
                return;
            }
            $quartersBtn.removeClass('is-active').html('Quarters <i class="fa-solid fa-chevron-down" style="font-size:9px; margin-left:2px; margin-bottom:0;"></i>');
            $pills.find('.giant-range-pill[data-range="' + r + '"]').addClass('is-active');
        }

        function buildQuartersMenu() {
            var now = new Date();
            var y   = now.getFullYear();
            var cq  = Math.floor(now.getMonth() / 3) + 1;
            var html = '<div class="giant-range-dropdown-hdr">' + y + '</div>';
            for (var q = 1; q <= cq; q++) {
                var lbl = q === cq ? 'Q' + q + ' (current)' : 'Q' + q;
                html += '<button type="button" data-range="q' + q + '_' + y + '">' + lbl + '</button>';
            }
            for (var yy = 1; yy <= 2; yy++) {
                var py = y - yy;
                html += '<div class="giant-range-dropdown-hdr">' + py + '</div>';
                for (var q2 = 1; q2 <= 4; q2++) {
                    html += '<button type="button" data-range="q' + q2 + '_' + py + '">Q' + q2 + '</button>';
                }
            }
            $quartersMenu.html(html);
        }

        function fetchData() {
            state.inFlight = true;
            $refresh.addClass('is-spinning');
            $error.hide();

            // If we already have data, keep it visible behind a subtle overlay (avoid full-clear flicker)
            if (!state.data) {
                $main.hide();
                $loading.show();
            } else {
                $main.addClass('is-refreshing');
            }

            var params = { pbxAction: 'getCallAnalytics', range: state.range };
            if (state.range === 'custom' && state.start && state.end) {
                params.start = state.start;
                params.end   = state.end;
            }

            $.ajax({
                type: 'post',
                data: params,
                success: function (json) {
                    try {
                        var resp = (typeof json === 'object') ? json : jQuery.parseJSON(json);
                        if (!resp) { showError('Empty response'); return; }
                        if (resp.error && (!resp.totals || resp.totals.totalCalls === 0)) {
                            showError(resp.error);
                            return;
                        }
                        state.data = resp;
                        render(resp);
                        fetchGeoMap();
                        fetchAiInsights();
                    } catch (e) {
                        showError('Could not parse analytics response.');
                    }
                },
                error: function () { showError('Could not load analytics. Check your connection and try again.'); },
                complete: function () {
                    state.inFlight = false;
                    $refresh.removeClass('is-spinning');
                    $loading.hide();
                    $main.removeClass('is-refreshing').show();
                }
            });
        }

        function showError(msg) {
            $main.hide();
            $loading.hide();
            $error.html('<i class="fa-duotone fa-triangle-exclamation" style="--fa-primary-color: rgb(var(--warn)); --fa-secondary-color: rgb(var(--warn) / .65);"></i><p>' + G.escapeHtml(msg) + '</p>').show();
        }

        // ── Rendering ─────────────────────────────────────────────────────
        function render(s) {
            var r = s.range || {};
            $('#giantAnalyticsRangeLabel').text(r.label || '');
            $('#giantAnalyticsUpdated').text(s.generatedAt ? 'Updated ' + s.generatedAt : '');

            renderKpis(s);
            renderCharts(s);
            renderExtensions(s);
            renderLeaderboard(s);
            renderHourly(s);
        }

        // ── Call-destinations heatmap ─────────────────────────────────────
        // Fetched separately from getCallAnalytics (which the Today card polls
        // every 60s) so the call-log scan only runs when the modal is open.
        function fetchGeoMap() {
            var params = { pbxAction: 'getCallDestinationMap', range: state.range };
            if (state.range === 'custom' && state.start && state.end) {
                params.start = state.start;
                params.end   = state.end;
            }
            $('#giantGeoLoading').css('display', 'flex');
            $.ajax({
                type: 'post',
                data: params,
                success: function (json) {
                    try {
                        var resp = (typeof json === 'object') ? json : jQuery.parseJSON(json);
                        renderGeoMap(resp && !resp.error ? resp : { points: [], topAreas: [] });
                    } catch (e) {
                        renderGeoMap({ points: [], topAreas: [] });
                    }
                },
                error: function () { renderGeoMap({ points: [], topAreas: [] }); },
                complete: function () { $('#giantGeoLoading').hide(); }
            });
        }

        // ── AI insights ───────────────────────────────────────────────────
        // Separate on-demand fetch (per-call /aianalysis is too heavy for the
        // 60s Today-card poll). Stashes to state.ai for the PDF export.
        function fetchAiInsights() {
            var params = { pbxAction: 'getCallAiAnalytics', range: state.range };
            if (state.range === 'custom' && state.start && state.end) {
                params.start = state.start;
                params.end   = state.end;
            }
            $('#giantAnalyticsAi').html('<div class="giant-geo-loading" style="display:flex;"><div class="giant-geo-spinner"></div></div>');
            $.ajax({
                type: 'post',
                data: params,
                success: function (json) {
                    try {
                        var resp = (typeof json === 'object') ? json : jQuery.parseJSON(json);
                        state.ai = (resp && resp.ai) ? resp.ai : null;
                        renderAiInsights(state.ai);
                    } catch (e) { state.ai = null; renderAiInsights(null); }
                },
                error: function () { state.ai = null; renderAiInsights(null); }
            });
        }

        function giantSentColour(score) {
            var n = Number(score);
            if (isNaN(n)) { return { bg: '#f1f5f9', fg: '#475569', bd: '#e2e8f0' }; }
            if (n < 0) { n = (n + 1) / 2; }
            n = Math.max(0, Math.min(1, n));
            var hue = Math.round(n * 120);
            return { bg: 'hsl(' + hue + ',72%,92%)', fg: 'hsl(' + hue + ',55%,28%)', bd: 'hsl(' + hue + ',60%,80%)' };
        }

        function renderAiInsights(ai) {
            var $box = $('#giantAnalyticsAi');
            if (!$box.length) { return; }
            var esc = G.escapeHtml;

            if (!ai || (!ai.sentiment && !(ai.topWords && ai.topWords.length) && !(ai.analysedCalls))) {
                $box.html('<div class="giant-ai-empty">No AI-analysed calls in this range yet. Recorded calls are transcribed &amp; scored automatically.</div>');
                return;
            }

            var s = ai.sentiment;
            var html = '<div class="giant-ai-cards">';
            html += '<div class="giant-ai-card"><div class="giant-ai-card-value">' + esc(ai.analysedCalls || 0) + '</div><div class="giant-ai-card-label">Calls analysed</div></div>';
            html += '<div class="giant-ai-card"><div class="giant-ai-card-value">' + esc(ai.transcribedCalls || 0) + '</div><div class="giant-ai-card-label">Transcribed</div></div>';
            if (s) {
                var ac = giantSentColour(s.avg);
                html += '<div class="giant-ai-card"><div class="giant-ai-card-value" style="color:' + ac.fg + ';">' + esc(s.avg) + '</div><div class="giant-ai-card-label">Avg sentiment · ' + esc(s.avgLabel || '') + '</div></div>';
            }
            html += '</div>';

            if (s && (s.lowest || s.highest)) {
                html += '<div class="giant-ai-callrows">';
                [['Lowest', s.lowest, 'fa-face-frown'], ['Highest', s.highest, 'fa-face-smile']].forEach(function (p) {
                    var c = p[1]; if (!c) { return; }
                    var col = giantSentColour(c.score);
                    html += '<div class="giant-ai-callrow">' +
                        '<div class="giant-ai-callrow-label"><i class="fa-solid ' + p[2] + '"></i> ' + p[0] + ' sentiment</div>' +
                        '<div class="giant-ai-callrow-body">' +
                          '<span class="giant-ai-scorepill" style="background:' + col.bg + ';color:' + col.fg + ';border:1px solid ' + col.bd + ';">' + esc(c.label || '') + ' · ' + esc(Number(c.score).toFixed(2)) + '</span>' +
                          '<span class="giant-ai-callmeta">' + (c.number ? esc(c.number) : 'Unknown') + (c.date ? ' · ' + esc(c.date) : '') + '</span>' +
                        '</div>' +
                      '</div>';
                });
                html += '</div>';
            }

            function chips(list) {
                if (!list || !list.length) { return ''; }
                var max = list[0].count || 1;
                var h = '<div class="giant-ai-chips">';
                list.forEach(function (w) {
                    var scale = 0.85 + 0.55 * ((w.count || 0) / max);
                    h += '<span class="giant-ai-chip" style="font-size:' + scale.toFixed(2) + 'em;">' + esc(w.word) + ' <b>' + esc(w.count) + '</b></span>';
                });
                return h + '</div>';
            }
            if (ai.topWords && ai.topWords.length) {
                html += '<div class="giant-ai-block"><div class="giant-ai-block-title">Most-said words</div>' + chips(ai.topWords) + '</div>';
            }
            if (ai.topSubjects && ai.topSubjects.length) {
                html += '<div class="giant-ai-block"><div class="giant-ai-block-title">Common subjects</div>' + chips(ai.topSubjects) + '</div>';
            }
            if (ai.capped) {
                html += '<div class="giant-ai-note">Based on the most recent ' + esc(ai.consideredCalls || 0) + ' answered calls in this range.</div>';
            }

            $box.html(html);
        }

        function renderGeoMap(s) {
            state.geo = s || {};   // stash for the PDF export
            var canvas = document.getElementById('giantChartGeoMap');
            var listEl = document.getElementById('giantAnalyticsTopAreas');
            var points = (s && s.points) || [];

            if (canvas) {
                var wrap = canvas.parentNode;
                var emptyEl = wrap.querySelector('.giant-analytics-chart-empty');
                // The UK outline always draws; bubbles only when there is
                // something to place. With nothing to place, a note sits
                // along the bottom of the map rather than replacing it.
                if (!points.length) {
                    if (!emptyEl) {
                        emptyEl = document.createElement('div');
                        emptyEl.className = 'giant-analytics-chart-empty giant-geo-note';
                        wrap.appendChild(emptyEl);
                    }
                    emptyEl.textContent = 'No calls to place on the map in this range';
                } else if (emptyEl) {
                    emptyEl.remove();
                }
                var maxCount = points.reduce(function (m, p) { return Math.max(m, p.count || 0); }, 0) || 1;
                var data = points.map(function (p) {
                    return {
                        x: geoX(p.lng), y: p.lat,
                        r: 5 + 22 * Math.sqrt((p.count || 0) / maxCount),
                        label: p.label, count: p.count, cin: p['in'], cout: p.out
                    };
                });
                if (charts.geo) charts.geo.destroy();
                // Schematic UK map: bubbles placed by lng/lat. x range is
                // padded to ~2x the lat range so the country isn't stretched.
                charts.geo = new Chart(canvas.getContext('2d'), {
                    type: 'bubble',
                    plugins: [ukMapPlugin],
                    data: { datasets: [{
                        data: data,
                        backgroundColor: window.gvColor('accent', .40),
                        borderColor: window.gvColor('accent'),
                        borderWidth: 1.5,
                        hoverBackgroundColor: window.gvColor('accent', .70)
                    }]},
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        scales: {
                            x: { display: false, min: GEO_X.min, max: GEO_X.max },
                            y: { display: false, min: GEO_Y.min, max: GEO_Y.max }
                        },
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                backgroundColor: window.gvColor('text'), padding: 10, cornerRadius: 8,
                                titleFont: { size: 12, weight: '700' }, bodyFont: { size: 12 },
                                callbacks: {
                                    title: function (items) { return items.length ? items[0].raw.label : ''; },
                                    label: function (ctx) {
                                        var d = ctx.raw;
                                        return (d.count || 0) + ' calls  (' + (d.cout || 0) + ' out · ' + (d.cin || 0) + ' in)';
                                    }
                                }
                            }
                        }
                    }
                });
            }

            if (listEl) {
                // UK areas ranked first, then everything the map can't place —
                // mobile, non-geographic, freephone, premium, international,
                // internal, withheld — ranked the same way. Bars share one scale.
                var areas = (s && s.topAreas) || [];
                var cats  = (s && s.categories) || [];
                if (!areas.length && !cats.length) {
                    listEl.innerHTML = '<div class="giant-analytics-empty">No calls in this range</div>';
                } else {
                    var max2 = areas.concat(cats).reduce(function (m, a) { return Math.max(m, a.count || 0); }, 0) || 1;
                    var rowHtml = function (a) {
                        var pct   = Math.round(100 * (a.count || 0) / max2);
                        var split = (a['in'] != null && a.out != null) ? ' title="' + (a.out || 0) + ' out · ' + (a['in'] || 0) + ' in"' : '';
                        return '<div class="giant-geo-row"' + split + '>' +
                            '<div class="giant-geo-bar" style="width:' + pct + '%"></div>' +
                            '<span class="giant-geo-name">' + G.escapeHtml(a.label || a.code) + '</span>' +
                            '<span class="giant-geo-count">' + (a.count || 0) + '</span>' +
                          '</div>';
                    };
                    var html = areas.map(rowHtml).join('');
                    if (cats.length) {
                        html += '<div class="giant-geo-divider">' + (areas.length ? 'Other destinations' : 'Destinations by type') + '</div>';
                        html += cats.map(rowHtml).join('');
                    }
                    listEl.innerHTML = html;
                }
            }
        }

        function renderKpis(s) {
            var t = s.totals || {};
            var cards = [
                { a: 'teal',  l: 'Total calls',   v: t.totalCalls || 0,                  sub: (t.outCalls || 0) + ' out \u00b7 ' + (t.inCalls || 0) + ' in' },
                { a: 'lime',  l: 'Outbound talk', v: G.fmtShortDuration(t.outTalk),      sub: (t.outAnswered || 0) + ' answered' },
                { a: 'blue',  l: 'Inbound talk',  v: G.fmtShortDuration(t.inTalk),       sub: (t.inAnswered || 0) + ' answered' },
                { a: 'amber', l: 'Combined talk', v: G.fmtShortDuration(t.combinedTalk), sub: (s.range ? s.range.days + (s.range.days === 1 ? ' day' : ' days') : '') },
                { a: 'cyan',  l: 'Connect rate',  v: (t.connectRate || 0) + '%',         sub: (t.answered || 0) + '/' + (t.totalCalls || 0) + ' answered' },
                { a: 'red',   l: 'Calls > 5m',    v: t.over5mCount || 0,                 sub: G.fmtShortDuration(t.over5mTalk) + ' talk' }
            ];
            var html = cards.map(function (c) {
                return '<div class="giant-today-kpi" data-accent="' + c.a + '">' +
                    '<div class="giant-today-kpi-label">' + c.l + '</div>' +
                    '<div class="giant-today-kpi-value">' + G.escapeHtml(c.v) + '</div>' +
                    '<div class="giant-today-kpi-sub">' + G.escapeHtml(c.sub) + '</div>' +
                  '</div>';
            }).join('');
            $('#giantAnalyticsKpis').html(html);
        }

        function sameArray(a, b) {
            if (!a || !b || a.length !== b.length) return false;
            for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
            return true;
        }

        function doughnutOpts(tooltipFmt) {
            var opts = {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '72%',
                animation: { duration: 450, easing: 'easeOutCubic' },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { usePointStyle: true, pointStyle: 'circle', padding: 12, boxWidth: 8, font: { size: 11, weight: '600' }, color: window.gvColor('muted') }
                    },
                    tooltip: {
                        backgroundColor: window.gvColor('text'), padding: 10, titleFont: { size: 12, weight: '700' },
                        bodyFont: { size: 12 }, cornerRadius: 8, displayColors: true, boxPadding: 4
                    }
                }
            };
            if (tooltipFmt === 'duration') {
                opts.plugins.tooltip.callbacks = { label: function (ctx) { return ctx.label + ': ' + G.fmtDuration(ctx.parsed); } };
            }
            return opts;
        }

        function renderDoughnut(key, canvasId, labels, data, colors, tooltipFmt) {
            var el = document.getElementById(canvasId);
            if (!el) return;
            var hasData = data.some(function (v) { return Number(v) > 0; });
            var wrap = el.parentNode;
            var emptyEl = wrap.querySelector('.giant-analytics-chart-empty');

            if (!hasData) {
                if (charts[key]) {
                    charts[key].data.labels = [];
                    charts[key].data.datasets[0].data = [];
                    charts[key].update('none');
                }
                if (!emptyEl) {
                    emptyEl = document.createElement('div');
                    emptyEl.className = 'giant-analytics-chart-empty';
                    emptyEl.textContent = 'No data in this range';
                    wrap.appendChild(emptyEl);
                }
                return;
            }
            if (emptyEl) emptyEl.remove();

            if (!charts[key]) {
                charts[key] = new Chart(el.getContext('2d'), {
                    type: 'doughnut',
                    data: {
                        labels: labels.slice(),
                        datasets: [{ data: data.slice(), backgroundColor: colors.slice(), borderColor: window.gvColor('bg'), borderWidth: 3, hoverOffset: 8, borderRadius: 4, spacing: 1 }]
                    },
                    options: doughnutOpts(tooltipFmt)
                });
                return;
            }

            var c = charts[key];
            var labelsChanged = !sameArray(c.data.labels, labels);
            var colorsChanged = !sameArray(c.data.datasets[0].backgroundColor, colors);
            if (labelsChanged) c.data.labels = labels.slice();
            if (colorsChanged) c.data.datasets[0].backgroundColor = colors.slice();
            c.data.datasets[0].data = data.slice();
            c.update(labelsChanged || colorsChanged ? undefined : 'active');
        }

        function renderCharts(s) {
            var t = s.totals || {};

            // Direction
            G.setText(document.getElementById('giantChartDirectionValue'), t.totalCalls || 0);
            renderDoughnut('direction', 'giantChartDirection',
                ['Outbound', 'Inbound'],
                [t.outCalls || 0, t.inCalls || 0],
                [window.gvColor('accent', .55), window.gvColor('accent-2')]);

            // Outcome
            G.setText(document.getElementById('giantChartOutcomeValue'), (t.connectRate || 0) + '%');
            var outcome = s.outcome || {};
            var oLabels = Object.keys(outcome);
            var oData   = oLabels.map(function (k) { return outcome[k]; });
            var oColors = oLabels.map(function (k) { return G.outcomeColors[k] || window.gvColor('muted', .55); });
            renderDoughnut('outcome', 'giantChartOutcome', oLabels, oData, oColors);

            // Extension (top 8)
            G.setText(document.getElementById('giantChartExtensionValue'), G.fmtShortDuration(t.combinedTalk));
            var exts = (s.extensions || []).slice(0, 8);
            var eLabels = exts.map(function (e) { return e.name; });
            var eData   = exts.map(function (e) { return e.combinedTalk || 0; });
            var eColors = exts.map(function (e, i) { return G.extensionPalette[i % G.extensionPalette.length]; });
            renderDoughnut('extension', 'giantChartExtension', eLabels, eData, eColors, 'duration');

            // Daily combo
            renderDailyChart(s);
        }

        function renderDailyChart(s) {
            var daily = (s.daily || []).slice().sort(function (a, b) { return a.date.localeCompare(b.date); });
            var labels  = daily.map(function (d) { return G.fmtDate(d.date); });
            var outData = daily.map(function (d) { return d.outCalls || 0; });
            var inData  = daily.map(function (d) { return d.inCalls  || 0; });
            var outMin  = daily.map(function (d) { return Math.round((d.outTalk || 0) / 60); });
            var inMin   = daily.map(function (d) { return Math.round((d.inTalk  || 0) / 60); });

            var el = document.getElementById('giantChartDaily');
            if (!el) return;

            if (!charts.daily) {
                charts.daily = new Chart(el.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [
                            { label: 'Outbound calls', data: outData, backgroundColor: window.gvColor('accent', .7),  borderRadius: 4, order: 2, yAxisID: 'y' },
                            { label: 'Inbound calls',  data: inData,  backgroundColor: window.gvColor('accent-2', .55), borderRadius: 4, order: 2, yAxisID: 'y' },
                            { label: 'Outbound talk (min)', data: outMin, type: 'line', borderColor: window.gvColor('accent'), backgroundColor: window.gvColor('accent', .1), fill: true, tension: 0.3, pointRadius: 3, pointBackgroundColor: window.gvColor('accent'), borderWidth: 2, order: 1, yAxisID: 'y1' },
                            { label: 'Inbound talk (min)',  data: inMin,  type: 'line', borderColor: window.gvColor('warn'), backgroundColor: window.gvColor('warn', .08), fill: true, tension: 0.3, pointRadius: 3, pointBackgroundColor: window.gvColor('warn'), borderWidth: 2, order: 1, yAxisID: 'y1' }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        interaction: { mode: 'index', intersect: false },
                        plugins: {
                            legend: { position: 'bottom', labels: { usePointStyle: true, pointStyle: 'circle', color: window.gvColor('muted'), font: { size: 11, weight: '600' }, padding: 14, boxWidth: 8 } },
                            tooltip: { backgroundColor: window.gvColor('text'), padding: 10, cornerRadius: 8, titleFont: { size: 12, weight: '700' }, bodyFont: { size: 12 } }
                        },
                        scales: {
                            x: { ticks: { color: window.gvColor('muted'), font: { size: 10 } }, grid: { color: 'rgb(0 0 0 / .03)' } },
                            y: { position: 'left', beginAtZero: true, ticks: { color: window.gvColor('muted'), font: { size: 10 }, precision: 0 }, grid: { color: 'rgb(0 0 0 / .04)' }, title: { display: true, text: 'Calls', color: window.gvColor('muted'), font: { size: 10, weight: '600' } } },
                            y1: { position: 'right', beginAtZero: true, ticks: { color: window.gvColor('muted'), font: { size: 10 }, precision: 0 }, grid: { display: false }, title: { display: true, text: 'Talk (min)', color: window.gvColor('muted'), font: { size: 10, weight: '600' } } }
                        }
                    }
                });
            } else {
                var c = charts.daily;
                c.data.labels = labels;
                c.data.datasets[0].data = outData;
                c.data.datasets[1].data = inData;
                c.data.datasets[2].data = outMin;
                c.data.datasets[3].data = inMin;
                c.update('active');
            }
        }

        function renderExtensions(s) {
            var exts = s.extensions || [];
            if (exts.length === 0) {
                $('#giantAnalyticsExtensions').html('<div class="giant-analytics-empty">No extension activity in this range</div>');
                return;
            }
            var maxCombined = Math.max.apply(null, exts.map(function (e) { return e.combinedTalk || 0; })); maxCombined = maxCombined || 1;
            var html = '<div class="giant-ext-head">' +
                '<div class="cn">Extension</div>' +
                '<div class="c">Out talk</div>' +
                '<div class="c">In talk</div>' +
                '<div class="c">Dialled</div>' +
                '<div class="c">Answered</div>' +
                '<div class="c">&gt; 5m</div>' +
                '<div class="cb">Talk time</div>' +
                '</div>';
            html += exts.map(function (e) {
                var color = G.colorFromName(e.name);
                var isExp = !!state.expanded[e.name];
                var pct   = Math.round(((e.combinedTalk || 0) / maxCombined) * 100);
                var row = '<div class="giant-ext-row ' + (isExp ? 'is-expanded' : '') + '" data-ext="' + G.escapeHtml(e.name) + '">' +
                    '<div class="cn">' +
                      '<span class="giant-ext-av" style="background:' + color + '22; color:' + color + ';">' + G.initials(e.name) + '</span>' +
                      '<span class="giant-ext-nm">' + G.escapeHtml(e.name) + '</span>' +
                      '<i class="fa-solid fa-chevron-down giant-ext-caret" style="margin-bottom:0;"></i>' +
                    '</div>' +
                    '<div class="c"><span class="giant-ext-mono" style="color: rgb(var(--accent));">' + G.fmtShortDuration(e.outTalk) + '</span></div>' +
                    '<div class="c"><span class="giant-ext-mono" style="color: rgb(var(--accent-2));">' + G.fmtShortDuration(e.inTalk) + '</span></div>' +
                    '<div class="c"><span class="giant-ext-mono">' + (e.outCalls || 0) + '</span></div>' +
                    '<div class="c"><span class="giant-ext-mono" style="color: rgb(var(--accent) / .85);">' + ((e.outAnswered || 0) + (e.inAnswered || 0)) + '</span></div>' +
                    '<div class="c"><span class="giant-ext-mono" style="color: rgb(var(--warn));">' + (e.over5mCount || 0) + '</span></div>' +
                    '<div class="cb">' +
                      '<div class="giant-ext-bar"><div class="giant-ext-bar-fill" style="width:' + pct + '%; background:' + color + ';"></div></div>' +
                      '<div class="giant-ext-bar-lbl">' + G.fmtShortDuration(e.combinedTalk) + '</div>' +
                    '</div>' +
                    '</div>';
                if (isExp) row += renderExtensionDrill(e);
                return row;
            }).join('');
            $('#giantAnalyticsExtensions').html(html);
        }

        function renderExtensionDrill(e) {
            var daily = (e.daily || []).slice().sort(function (a, b) { return b.date.localeCompare(a.date); });
            var avgOut = e.outAnswered ? Math.round(e.outTalk / e.outAnswered) : 0;
            var avgIn  = e.inAnswered  ? Math.round(e.inTalk  / e.inAnswered)  : 0;

            var rows = daily.map(function (d) {
                return '<div class="giant-ext-day">' +
                    '<span class="giant-ext-day-date">' + G.escapeHtml(G.fmtDate(d.date, { weekday: 'short', day: 'numeric', month: 'short' })) + '</span>' +
                    '<span class="giant-ext-day-stat"><i class="fa-solid fa-arrow-up-right-from-square" style="color: rgb(var(--accent));margin-bottom:0;"></i> ' + (d.outAnswered || 0) + ' <span class="giant-ext-day-mono">(' + G.fmtShortDuration(d.outTalk) + ')</span></span>' +
                    '<span class="giant-ext-day-stat"><i class="fa-solid fa-arrow-down-left-from-square" style="color: rgb(var(--accent-2));margin-bottom:0;"></i> ' + (d.inAnswered || 0) + ' <span class="giant-ext-day-mono">(' + G.fmtShortDuration(d.inTalk) + ')</span></span>' +
                    '</div>';
            }).join('');

            var sparkMax = Math.max.apply(null, daily.map(function (d) { return d.outTalk || 0; })) || 1;
            var sparkBars = daily.slice(0, 14).reverse().map(function (d) {
                var h = d.outTalk > 0 ? Math.max(Math.round((d.outTalk / sparkMax) * 40), 2) : 0;
                return '<div class="giant-ext-spark-item"><span class="giant-ext-spark-bar" style="height:' + h + 'px;"></span><span class="giant-ext-spark-lbl">' + G.fmtDate(d.date, { weekday: 'narrow' }) + '</span></div>';
            }).join('');

            return '<div class="giant-ext-drill">' +
                '<div class="giant-ext-drill-grid">' +
                  '<div class="giant-ext-drill-card">' +
                    '<div class="giant-ext-drill-h">Summary</div>' +
                    '<div class="giant-ext-drill-stat"><span>Outbound talk</span><span style="color: rgb(var(--accent));">' + G.fmtDuration(e.outTalk) + '</span></div>' +
                    '<div class="giant-ext-drill-stat"><span>Inbound talk</span><span style="color: rgb(var(--accent-2));">' + G.fmtDuration(e.inTalk) + '</span></div>' +
                    '<div class="giant-ext-drill-stat"><span>Combined</span><span style="color: rgb(var(--accent) / .85);">' + G.fmtDuration(e.combinedTalk) + '</span></div>' +
                    '<div class="giant-ext-drill-stat"><span>Avg outbound call</span><span>' + (avgOut ? G.fmtDuration(avgOut) : '—') + '</span></div>' +
                    '<div class="giant-ext-drill-stat"><span>Avg inbound call</span><span>' + (avgIn  ? G.fmtDuration(avgIn)  : '—') + '</span></div>' +
                    '<div class="giant-ext-drill-stat"><span>Calls &gt; 5m</span><span style="color: rgb(var(--warn));">' + (e.over5mCount || 0) + ' (' + G.fmtShortDuration(e.over5mTalk) + ')</span></div>' +
                  '</div>' +
                  (daily.length > 0 ? '<div class="giant-ext-drill-card">' +
                    '<div class="giant-ext-drill-h">Daily outbound talk</div>' +
                    '<div class="giant-ext-spark">' + sparkBars + '</div>' +
                  '</div>' : '') +
                '</div>' +
                (daily.length > 1 ? '<div class="giant-ext-drill-card giant-ext-drill-days">' +
                  '<div class="giant-ext-drill-h">Day by day</div>' + rows +
                '</div>' : '') +
                '</div>';
        }

        function renderLeaderboard(s) {
            var exts = (s.extensions || []).filter(function (e) { return (e.combinedTalk || 0) > 0; }).slice(0, 6);
            if (exts.length === 0) {
                $('#giantAnalyticsLeaderboard').html('<div class="giant-analytics-empty">No talk time in this range</div>');
                return;
            }
            var html = exts.map(function (e, i) {
                var rank = i + 1;
                var medal = rank === 1 ? 'gold' : rank === 2 ? 'silver' : rank === 3 ? 'bronze' : '';
                return '<div class="giant-lb-row">' +
                    '<div class="giant-lb-rank ' + medal + '">' + rank + '</div>' +
                    '<div class="giant-lb-info">' +
                      '<div class="giant-lb-name">' + G.escapeHtml(e.name) + '</div>' +
                      '<div class="giant-lb-sub">' + G.fmtShortDuration(e.outTalk) + ' out \u00b7 ' + G.fmtShortDuration(e.inTalk) + ' in</div>' +
                    '</div>' +
                    '<div class="giant-lb-value">' + G.fmtShortDuration(e.combinedTalk) + '</div>' +
                    '</div>';
            }).join('');
            $('#giantAnalyticsLeaderboard').html(html);
        }

        function renderHourly(s) {
            var hourly = s.hourly || [];
            // Trim to business hours 7..20 if activity is contained, otherwise full 24
            var nonzero = hourly.filter(function (h) { return (h.outCalls + h.inCalls) > 0; });
            var startH = 7, endH = 20;
            if (nonzero.length > 0) {
                startH = Math.min(startH, nonzero[0].hour);
                endH = Math.max(endH, nonzero[nonzero.length - 1].hour);
            }
            var visible = hourly.filter(function (h) { return h.hour >= startH && h.hour <= endH; });
            var max = Math.max.apply(null, visible.map(function (h) { return h.outCalls + h.inCalls; })) || 1;

            if (visible.every(function (h) { return (h.outCalls + h.inCalls) === 0; })) {
                $('#giantAnalyticsHourly').html('<div class="giant-analytics-empty">No calls in this range</div>');
                return;
            }

            var html = '<div class="giant-hourly-legend">' +
                '<span><span class="giant-hourly-sw" style="background: rgb(var(--accent));"></span>Out</span>' +
                '<span><span class="giant-hourly-sw" style="background: rgb(var(--accent-2));"></span>In</span>' +
                '</div>';
            html += visible.map(function (h) {
                var outPct = Math.round((h.outCalls / max) * 100);
                var inPct  = Math.round((h.inCalls  / max) * 100);
                var total  = h.outCalls + h.inCalls;
                return '<div class="giant-hourly-row">' +
                    '<span class="giant-hourly-label">' + (h.hour < 10 ? '0' : '') + h.hour + ':00</span>' +
                    '<div class="giant-hourly-track">' +
                      '<div class="giant-hourly-bar" style="width:' + outPct + '%; background: rgb(var(--accent));"></div>' +
                      '<div class="giant-hourly-bar" style="width:' + inPct  + '%; background: rgb(var(--accent-2));"></div>' +
                    '</div>' +
                    '<span class="giant-hourly-value">' + total + '</span>' +
                    '</div>';
            }).join('');
            $('#giantAnalyticsHourly').html(html);
        }

        // ── PDF export ────────────────────────────────────────────────────
        // Returns a JPEG data URL of a Chart.js chart rendered offscreen.
        // JPEG + lower scale + PDF compression brings exports from ~30MB to 2-4MB.
        function renderChartImage(cfg, w, h) {
            var scale = 1.5;
            var c = document.createElement('canvas');
            c.width = w * scale; c.height = h * scale;
            c.style.width = w + 'px'; c.style.height = h + 'px';
            c.getContext('2d').scale(scale, scale);
            cfg.options = cfg.options || {};
            cfg.options.animation = false;
            cfg.options.responsive = false;
            var ch = new Chart(c, cfg);

            // JPEG doesn't support transparency — flatten onto a white canvas so labels/arcs
            // don't land on a black background.
            var out    = document.createElement('canvas');
            out.width  = c.width;
            out.height = c.height;
            var octx   = out.getContext('2d');
            octx.fillStyle = window.gvColor('bg');
            octx.fillRect(0, 0, out.width, out.height);
            octx.drawImage(c, 0, 0);
            var img = out.toDataURL('image/jpeg', 0.82);

            ch.destroy();
            return img;
        }

        function exportPdf() {
            if (!state.data || !window.jspdf) {
                if (!window.jspdf && typeof giantToast === 'function') giantToast('PDF library not loaded yet.', 'error');
                return;
            }
            var $btn = $('#giantAnalyticsPdf');
            $btn.addClass('is-loading');
            setTimeout(function () {
                try { buildPdf(state.data); }
                catch (err) {
                    if (typeof giantToast === 'function') giantToast('PDF generation failed: ' + err.message, 'error');
                }
                $btn.removeClass('is-loading');
            }, 50);
        }

        function buildPdf(s) {
            var jsPDF = window.jspdf.jsPDF;
            var pdf   = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4', compress: true });
            var W = 210, H = 297, M = 15, CW = W - 2 * M;
            var t = s.totals || {}, r = s.range || {}, pageNum = 0;

            function header() {
                pageNum++;
                pdf.setFillColor(26, 26, 46);  pdf.rect(0, 0, W, 26, 'F');
                pdf.setFillColor(0, 217, 167); pdf.rect(0, 26, W, 1.2, 'F');
                pdf.setTextColor(255, 255, 255);
                pdf.setFontSize(17); pdf.setFont('helvetica', 'bold');
                pdf.text('Call Analytics', M, 13);
                pdf.setFontSize(9); pdf.setFont('helvetica', 'normal');
                pdf.setTextColor(180, 190, 200);
                pdf.text(r.label || '', M, 20);
                pdf.setFontSize(8);
                pdf.text('Generated ' + new Date().toLocaleString('en-GB'), W - M, 13, { align: 'right' });
                pdf.text('Page ' + pageNum, W - M, 20, { align: 'right' });
            }

            function footer() {
                pdf.setDrawColor(230, 232, 235); pdf.line(M, H - 14, W - M, H - 14);
                pdf.setTextColor(130, 130, 130); pdf.setFontSize(7); pdf.setFont('helvetica', 'normal');
                pdf.text((window.pbxConfig && window.pbxConfig.brand && window.pbxConfig.brand.name) || '', M, H - 9);
                pdf.text('Confidential', W - M, H - 9, { align: 'right' });
            }

            function section(title, y) {
                pdf.setTextColor(26, 26, 46); pdf.setFontSize(11); pdf.setFont('helvetica', 'bold');
                pdf.text(title.toUpperCase(), M, y);
                pdf.setDrawColor(0, 217, 167); pdf.setLineWidth(0.6);
                pdf.line(M, y + 1.5, M + 30, y + 1.5);
                return y + 8;
            }

            function needPage(y, needed) {
                if (y + needed > H - 20) { footer(); pdf.addPage(); header(); return 36; }
                return y;
            }

            // ── PAGE 1 — Summary + top charts ──
            header();
            var y = section('Summary', 36);

            var kpis = [
                { l: 'TOTAL CALLS',   v: String(t.totalCalls  || 0),         sub: (t.outCalls || 0) + ' out / ' + (t.inCalls || 0) + ' in',                 c: [0, 196, 154] },
                { l: 'OUTBOUND TALK', v: G.fmtShortDuration(t.outTalk),      sub: (t.outAnswered || 0) + ' answered',                                        c: [108, 165, 52] },
                { l: 'INBOUND TALK',  v: G.fmtShortDuration(t.inTalk),       sub: (t.inAnswered  || 0) + ' answered',                                        c: [59, 130, 246] },
                { l: 'COMBINED TALK', v: G.fmtShortDuration(t.combinedTalk), sub: (r.days || 1) + (r.days === 1 ? ' day' : ' days'),                         c: [217, 119, 6]  },
                { l: 'CONNECT RATE',  v: (t.connectRate || 0) + '%',         sub: (t.answered || 0) + '/' + (t.totalCalls || 0) + ' answered',               c: [8, 145, 178]  },
                { l: 'CALLS > 5M',    v: String(t.over5mCount || 0),         sub: G.fmtShortDuration(t.over5mTalk) + ' talk',                                c: [220, 38, 38]  }
            ];
            var kw = (CW - 8) / 3, kh = 26;
            kpis.forEach(function (k, i) {
                var col = i % 3, row = Math.floor(i / 3);
                var kx = M + col * (kw + 4), ky = y + row * (kh + 4);
                pdf.setFillColor(250, 251, 252); pdf.roundedRect(kx, ky, kw, kh, 1.5, 1.5, 'F');
                pdf.setFillColor(k.c[0], k.c[1], k.c[2]); pdf.rect(kx + kw * 0.25, ky, kw * 0.5, 0.5, 'F');
                pdf.setTextColor(140, 148, 158); pdf.setFontSize(7); pdf.setFont('helvetica', 'bold');
                pdf.text(k.l, kx + 4, ky + 6);
                pdf.setTextColor(k.c[0], k.c[1], k.c[2]); pdf.setFontSize(16); pdf.setFont('helvetica', 'bold');
                pdf.text(k.v, kx + 4, ky + 15);
                pdf.setTextColor(140, 148, 158); pdf.setFontSize(7); pdf.setFont('helvetica', 'normal');
                pdf.text(k.sub, kx + 4, ky + 21);
            });
            y += 2 * (kh + 4) + 8;

            // Direction + Outcome doughnuts
            y = section('Call Distribution', y);
            var dirImg = renderChartImage({
                type: 'doughnut',
                data: {
                    labels: ['Outbound (' + (t.outCalls || 0) + ')', 'Inbound (' + (t.inCalls || 0) + ')'],
                    datasets: [{ data: [t.outCalls || 0, t.inCalls || 0], backgroundColor: [window.gvColor('accent', .55), window.gvColor('accent-2')], borderWidth: 2, borderColor: window.gvColor('bg') }]
                },
                options: {
                    plugins: {
                        legend: { position: 'bottom', labels: { color: window.gvColor('text'), font: { size: 11, family: 'Helvetica' }, padding: 8, boxWidth: 12 } },
                        title: { display: true, text: 'Direction split', color: window.gvColor('text'), font: { size: 12, weight: 'bold', family: 'Helvetica' }, padding: { bottom: 8 } }
                    }
                }
            }, 500, 400);

            var outcome = s.outcome || {};
            var oLabels = Object.keys(outcome);
            var oPalette = [window.gvColor('accent'), window.gvColor('accent', .55), window.gvColor('accent-2', .65), window.gvColor('danger'), window.gvColor('warn'), window.gvColor('muted', .55)];
            var outImg = renderChartImage({
                type: 'doughnut',
                data: {
                    labels: oLabels.map(function (k) { return k + ' (' + outcome[k] + ')'; }),
                    datasets: [{ data: oLabels.map(function (k) { return outcome[k]; }), backgroundColor: oPalette.slice(0, oLabels.length), borderWidth: 2, borderColor: window.gvColor('bg') }]
                },
                options: {
                    plugins: {
                        legend: { position: 'bottom', labels: { color: window.gvColor('text'), font: { size: 11, family: 'Helvetica' }, padding: 8, boxWidth: 12 } },
                        title: { display: true, text: 'Outcome breakdown', color: window.gvColor('text'), font: { size: 12, weight: 'bold', family: 'Helvetica' }, padding: { bottom: 8 } }
                    }
                }
            }, 500, 400);

            var halfW = (CW - 6) / 2, chartH = halfW * 0.85;
            pdf.addImage(dirImg, 'JPEG', M, y, halfW, chartH, undefined, 'FAST');
            pdf.addImage(outImg, 'JPEG', M + halfW + 6, y, halfW, chartH, undefined, 'FAST');
            y += chartH + 6;
            footer();

            // ── PAGE 2 — Trends ──
            pdf.addPage(); header();
            y = section('Daily Volume & Talk Time', 36);

            var daily = (s.daily || []).slice().sort(function (a, b) { return a.date.localeCompare(b.date); });
            if (daily.length > 0) {
                var dLbl = daily.map(function (d) { return G.fmtDate(d.date); });
                var comboImg = renderChartImage({
                    type: 'bar',
                    data: {
                        labels: dLbl,
                        datasets: [
                            { label: 'Outbound calls', data: daily.map(function (d) { return d.outCalls; }), backgroundColor: window.gvColor('accent', .55), borderRadius: 2, order: 2, yAxisID: 'y' },
                            { label: 'Inbound calls',  data: daily.map(function (d) { return d.inCalls;  }), backgroundColor: window.gvColor('accent-2'), borderRadius: 2, order: 2, yAxisID: 'y' },
                            { label: 'Out talk (min)', data: daily.map(function (d) { return Math.round(d.outTalk / 60); }), type: 'line', borderColor: window.gvColor('accent'), backgroundColor: window.gvColor('accent', .1), fill: true, tension: 0.3, pointRadius: 2, borderWidth: 2, order: 1, yAxisID: 'y1' },
                            { label: 'In talk (min)',  data: daily.map(function (d) { return Math.round(d.inTalk  / 60); }), type: 'line', borderColor: window.gvColor('warn'), backgroundColor: window.gvColor('warn', .08), fill: true, tension: 0.3, pointRadius: 2, borderWidth: 2, order: 1, yAxisID: 'y1' }
                        ]
                    },
                    options: {
                        plugins: { legend: { position: 'bottom', labels: { color: window.gvColor('text'), font: { size: 10, family: 'Helvetica' }, padding: 8, boxWidth: 12 } } },
                        scales: {
                            x: { ticks: { color: window.gvColor('muted'), font: { size: 9, family: 'Helvetica' }, maxRotation: 45 }, grid: { color: 'rgb(0 0 0 / .05)' } },
                            y: { position: 'left', beginAtZero: true, ticks: { color: window.gvColor('muted'), font: { size: 9, family: 'Helvetica' }, precision: 0 }, grid: { color: 'rgb(0 0 0 / .05)' }, title: { display: true, text: 'Calls', color: window.gvColor('muted'), font: { size: 9, family: 'Helvetica' } } },
                            y1: { position: 'right', beginAtZero: true, ticks: { color: window.gvColor('muted'), font: { size: 9, family: 'Helvetica' }, precision: 0 }, grid: { display: false }, title: { display: true, text: 'Talk (min)', color: window.gvColor('muted'), font: { size: 9, family: 'Helvetica' } } }
                        }
                    }
                }, 900, 380);
                pdf.addImage(comboImg, 'JPEG', M, y, CW, 80, undefined, 'FAST');
                y += 86;
            } else {
                pdf.setTextColor(156, 163, 175); pdf.setFontSize(10); pdf.setFont('helvetica', 'italic');
                pdf.text('No daily activity in this range.', W / 2, y + 10, { align: 'center' });
                y += 24;
            }

            // Extension talk doughnut
            y = section('Talk Time by Extension', y);
            var exts = (s.extensions || []).slice(0, 10);
            if (exts.length > 0) {
                var extPalette = [window.gvColor('accent'), window.gvColor('accent', .55), window.gvColor('accent-2'), window.gvColor('warn'), window.gvColor('accent-2', .65), window.gvColor('danger'), window.gvColor('accent', .75), window.gvColor('danger', .65), window.gvColor('accent', .85), window.gvColor('accent-2', .85)];
                var extImg = renderChartImage({
                    type: 'doughnut',
                    data: {
                        labels: exts.map(function (e) { return e.name + ' (' + G.fmtShortDuration(e.combinedTalk) + ')'; }),
                        datasets: [{ data: exts.map(function (e) { return e.combinedTalk; }), backgroundColor: extPalette.slice(0, exts.length), borderWidth: 2, borderColor: window.gvColor('bg') }]
                    },
                    options: {
                        plugins: { legend: { position: 'right', labels: { color: window.gvColor('text'), font: { size: 10, family: 'Helvetica' }, padding: 6, boxWidth: 12 } } }
                    }
                }, 700, 380);
                pdf.addImage(extImg, 'JPEG', M, y, CW, 80, undefined, 'FAST');
                y += 84;
            } else {
                pdf.setTextColor(156, 163, 175); pdf.setFontSize(10); pdf.setFont('helvetica', 'italic');
                pdf.text('No extension activity.', W / 2, y + 10, { align: 'center' });
                y += 24;
            }
            footer();

            // ── Call destinations (area codes) ──
            var geo       = (state && state.geo) ? state.geo : {};
            var topAreas  = geo.topAreas || [];
            var geoCats   = geo.categories || [];
            var geoPoints = geo.points || [];
            if (state && state.geo) {   // the page and its map always print, even with nothing to place
                pdf.addPage(); header();
                y = section('Call Destinations', 36);

                if (geo.mappedCalls != null && geo.totalCalls != null) {
                    pdf.setTextColor(120, 128, 138); pdf.setFontSize(8); pdf.setFont('helvetica', 'normal');
                    pdf.text(geo.mappedCalls + ' of ' + geo.totalCalls + ' calls mapped to UK geographic areas; the rest listed by number type', M, y);
                    y += 6;
                }

                var topStart = y, listX = M, listW = CW;

                // UK bubble map on the left — always, bubbles or not.
                {
                    var maxC = geoPoints.reduce(function (m, p) { return Math.max(m, p.count || 0); }, 0) || 1;
                    var mapImg = renderChartImage({
                        type: 'bubble',
                        plugins: [ukMapPlugin],
                        data: { datasets: [{
                            data: geoPoints.map(function (p) {
                                return { x: geoX(p.lng), y: p.lat, r: 4 + 16 * Math.sqrt((p.count || 0) / maxC) };
                            }),
                            backgroundColor: window.gvColor('accent', .40),
                            borderColor: window.gvColor('accent'),
                            borderWidth: 1
                        }]},
                        options: {
                            plugins: { legend: { display: false } },
                            scales: {
                                x: { display: false, min: GEO_X.min, max: GEO_X.max },
                                y: { display: false, min: GEO_Y.min, max: GEO_Y.max }
                            }
                        }
                    }, 430, Math.round(430 / GEO_ASPECT));
                    var mapW = CW * 0.42, mapH = mapW / GEO_ASPECT;
                    pdf.addImage(mapImg, 'JPEG', M, y, mapW, mapH, undefined, 'FAST');
                    listX = M + mapW + 6; listW = CW - mapW - 6;
                }

                // Top areas ranked with mini bars, then the number types the
                // map can't place (mobile, non-geographic, international, …).
                var ly = topStart;
                var pdfRows  = topAreas.slice(0, 15).concat(geoCats);
                var maxCount = pdfRows.reduce(function (m, a) { return Math.max(m, a.count || 0); }, 0) || 1;
                var drawRow  = function (a) {
                    var barW = listW * (a.count || 0) / maxCount;
                    pdf.setFillColor(224, 247, 240); pdf.rect(listX, ly, barW, 6, 'F');
                    pdf.setTextColor(40, 40, 50); pdf.setFontSize(8.5); pdf.setFont('helvetica', 'normal');
                    pdf.text(String(a.label || a.code), listX + 2, ly + 4.2);
                    pdf.setTextColor(0, 150, 110); pdf.setFont('helvetica', 'bold');
                    pdf.text(String(a.count || 0), listX + listW - 2, ly + 4.2, { align: 'right' });
                    ly += 8;
                };
                if (pdfRows.length === 0) {
                    pdf.setTextColor(120, 128, 138); pdf.setFontSize(8.5); pdf.setFont('helvetica', 'normal');
                    pdf.text('No calls in this range', listX, ly + 4.2);
                }
                topAreas.slice(0, 15).forEach(drawRow);
                if (geoCats.length > 0) {
                    ly += 2;
                    pdf.setTextColor(120, 128, 138); pdf.setFontSize(7.5); pdf.setFont('helvetica', 'bold');
                    pdf.text(topAreas.length ? 'OTHER DESTINATIONS' : 'DESTINATIONS BY TYPE', listX, ly + 3.5);
                    ly += 7;
                    geoCats.forEach(drawRow);
                }
                footer();
            }

            // ── PAGE 3 — Extension performance table ──
            var allExts = s.extensions || [];
            if (allExts.length > 0) {
                pdf.addPage(); header();
                y = section('Extension Performance', 36);

                var cols = [
                    { l: 'Extension', w: 58 },
                    { l: 'Out talk',  w: 24 },
                    { l: 'In talk',   w: 24 },
                    { l: 'Dialled',   w: 18 },
                    { l: 'Answered',  w: 22 },
                    { l: '> 5m',      w: 16 },
                    { l: 'Total',     w: 18 }
                ];
                pdf.setFillColor(26, 26, 46); pdf.rect(M, y, CW, 7, 'F');
                pdf.setTextColor(255, 255, 255); pdf.setFontSize(7.5); pdf.setFont('helvetica', 'bold');
                var cx = M + 3;
                cols.forEach(function (c) { pdf.text(c.l.toUpperCase(), cx, y + 5); cx += c.w; });
                y += 7;

                allExts.forEach(function (e, idx) {
                    y = needPage(y, 7);
                    if (idx % 2 === 0) { pdf.setFillColor(246, 248, 250); pdf.rect(M, y, CW, 6.5, 'F'); }
                    pdf.setTextColor(40, 40, 50); pdf.setFontSize(8); pdf.setFont('helvetica', 'normal');
                    var vals = [
                        e.name,
                        G.fmtShortDuration(e.outTalk),
                        G.fmtShortDuration(e.inTalk),
                        String(e.outCalls || 0),
                        String((e.outAnswered || 0) + (e.inAnswered || 0)),
                        String(e.over5mCount || 0),
                        G.fmtShortDuration(e.combinedTalk)
                    ];
                    var vx = M + 3;
                    vals.forEach(function (v, j) { pdf.text(String(v), vx, y + 4.5); vx += cols[j].w; });
                    y += 6.5;
                });
                y += 6;

                // Leaderboard
                var lb = allExts.filter(function (e) { return (e.combinedTalk || 0) > 0; }).slice(0, 8);
                if (lb.length > 0) {
                    y = needPage(y, 70);
                    y = section('Leaderboard', y);
                    lb.forEach(function (e, i) {
                        y = needPage(y, 12);
                        pdf.setTextColor(i === 0 ? 217 : i === 1 ? 107 : i === 2 ? 180 : 156, i === 0 ? 119 : 114, i === 0 ? 6 : 128);
                        pdf.setFontSize(12); pdf.setFont('helvetica', 'bold');
                        pdf.text(String(i + 1), M + 2, y + 5);
                        pdf.setTextColor(26, 26, 46); pdf.setFontSize(10);
                        pdf.text(e.name, M + 12, y + 5);
                        pdf.setTextColor(0, 196, 154); pdf.setFontSize(10); pdf.setFont('helvetica', 'bold');
                        pdf.text(G.fmtShortDuration(e.combinedTalk), W - M - 3, y + 5, { align: 'right' });
                        pdf.setTextColor(156, 163, 175); pdf.setFontSize(8); pdf.setFont('helvetica', 'normal');
                        pdf.text(G.fmtShortDuration(e.outTalk) + ' out / ' + G.fmtShortDuration(e.inTalk) + ' in', M + 12, y + 10);
                        y += 12;
                    });
                }
                footer();
            }

            // ── AI insights ──
            var ai = (state && state.ai) ? state.ai : null;
            if (ai && (ai.analysedCalls || ai.sentiment || (ai.topWords && ai.topWords.length))) {
                pdf.addPage(); header();
                y = section('AI Insights', 36);

                var aiCards = [{ l: 'CALLS ANALYSED', v: String(ai.analysedCalls || 0), sub: (ai.transcribedCalls || 0) + ' transcribed', c: [0, 196, 154] }];
                if (ai.sentiment) {
                    aiCards.push({ l: 'AVG SENTIMENT', v: String(ai.sentiment.avg), sub: ai.sentiment.avgLabel || '', c: [0, 150, 136] });
                    if (ai.sentiment.lowest)  { aiCards.push({ l: 'LOWEST',  v: Number(ai.sentiment.lowest.score).toFixed(2),  sub: (ai.sentiment.lowest.label  || '') + (ai.sentiment.lowest.number  ? ' - ' + ai.sentiment.lowest.number  : ''), c: [220, 38, 38] }); }
                    if (ai.sentiment.highest) { aiCards.push({ l: 'HIGHEST', v: Number(ai.sentiment.highest.score).toFixed(2), sub: (ai.sentiment.highest.label || '') + (ai.sentiment.highest.number ? ' - ' + ai.sentiment.highest.number : ''), c: [8, 145, 52] }); }
                }
                var akw = (CW - 8) / 3, akh = 26;
                aiCards.forEach(function (k, i) {
                    var col = i % 3, row = Math.floor(i / 3);
                    var kx = M + col * (akw + 4), ky = y + row * (akh + 4);
                    pdf.setFillColor(250, 251, 252); pdf.roundedRect(kx, ky, akw, akh, 1.5, 1.5, 'F');
                    pdf.setFillColor(k.c[0], k.c[1], k.c[2]); pdf.rect(kx + akw * 0.25, ky, akw * 0.5, 0.5, 'F');
                    pdf.setTextColor(140, 148, 158); pdf.setFontSize(7); pdf.setFont('helvetica', 'bold');
                    pdf.text(k.l, kx + 4, ky + 6);
                    pdf.setTextColor(k.c[0], k.c[1], k.c[2]); pdf.setFontSize(16); pdf.setFont('helvetica', 'bold');
                    pdf.text(String(k.v), kx + 4, ky + 15);
                    pdf.setTextColor(140, 148, 158); pdf.setFontSize(7); pdf.setFont('helvetica', 'normal');
                    pdf.text(String(k.sub).substring(0, 34), kx + 4, ky + 21);
                });
                y += Math.ceil(aiCards.length / 3) * (akh + 4) + 8;

                var pdfWordList = function (list, yy) {
                    var maxC = list.reduce(function (m, w) { return Math.max(m, w.count || 0); }, 0) || 1;
                    list.slice(0, 15).forEach(function (w) {
                        yy = needPage(yy, 8);
                        pdf.setFillColor(224, 247, 240); pdf.rect(M, yy, CW * (w.count || 0) / maxC, 6, 'F');
                        pdf.setTextColor(40, 40, 50); pdf.setFontSize(8.5); pdf.setFont('helvetica', 'normal');
                        pdf.text(String(w.word), M + 2, yy + 4.2);
                        pdf.setTextColor(0, 150, 110); pdf.setFont('helvetica', 'bold');
                        pdf.text(String(w.count || 0), M + CW - 2, yy + 4.2, { align: 'right' });
                        yy += 8;
                    });
                    return yy + 4;
                };

                if (ai.topWords && ai.topWords.length) {
                    y = needPage(y, 16); y = section('Most-said Words', y); y = pdfWordList(ai.topWords, y);
                }
                if (ai.topSubjects && ai.topSubjects.length) {
                    y = needPage(y, 16); y = section('Common Subjects', y); y = pdfWordList(ai.topSubjects, y);
                }
                footer();
            }

            var safeName = (r.label || 'range').replace(/[^\w-]+/g, '-').toLowerCase().replace(/^-|-$/g, '').substring(0, 40);
            pdf.save('call-analytics-' + safeName + '.pdf');
        }

        // ── Events ────────────────────────────────────────────────────────
        $pills.on('click', '.giant-range-pill', function () {
            // Quarters dropdown toggle handled separately below
            if (this.id === 'giantRangeQuartersBtn') return;

            var r = $(this).data('range');
            $quartersMenu.hide();
            setActiveRange(r);
            if (r === 'custom') {
                $custom.show();
                if (!$customStart.val() || !$customEnd.val()) {
                    var today = new Date();
                    var weekAgo = new Date(today.getTime() - 6 * 86400000);
                    var pad = function (d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
                    $customStart.val(pad(weekAgo));
                    $customEnd.val(pad(today));
                }
                return;
            }
            $custom.hide();
            state.range = r;
            state.expanded = {};
            fetchData();
        });

        $quartersBtn.on('click', function (e) {
            e.stopPropagation();
            $custom.hide();
            $quartersMenu.toggle();
        });

        $quartersMenu.on('click', 'button', function (e) {
            e.stopPropagation();
            var r = $(this).data('range');
            if (!r) return;
            $quartersMenu.hide();
            $custom.hide();
            state.range = r;
            state.expanded = {};
            setActiveRange(r);
            fetchData();
        });

        $(document).on('click', function (e) {
            if (!$(e.target).closest('.giant-range-dropdown').length) {
                $quartersMenu.hide();
            }
        });

        $('#giantRangeCustomApply').on('click', function () {
            var start = $customStart.val(), end = $customEnd.val();
            if (!start || !end) return;
            if (start > end) { var t = start; start = end; end = t; $customStart.val(start); $customEnd.val(end); }
            state.range = 'custom';
            state.start = start;
            state.end   = end;
            state.expanded = {};
            setActiveRange('custom');
            fetchData();
        });

        $refresh.on('click', function () {
            if (state.inFlight) return;
            fetchData();
        });

        $('#giantAnalyticsPdf').on('click', exportPdf);

        $('#giantAnalyticsExtensions').on('click', '.giant-ext-row', function () {
            var name = $(this).data('ext');
            if (!name) return;
            state.expanded[name] = !state.expanded[name];
            if (state.data) renderExtensions(state.data);
        });

        $modal.on('shown.bs.modal', function () {
            buildQuartersMenu();
            // First render on open if no data yet
            if (!state.data) fetchData();
            // Chart.js needs a nudge after the modal's layout settles
            setTimeout(function () {
                Object.keys(charts).forEach(function (k) { if (charts[k]) charts[k].resize(); });
            }, 120);
        });

    })();
    {/literal}

</script>
