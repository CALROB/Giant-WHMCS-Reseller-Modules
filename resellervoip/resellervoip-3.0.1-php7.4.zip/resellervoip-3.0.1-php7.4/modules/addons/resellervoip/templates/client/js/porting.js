// Port a Number page (templates/porting.tpl). Kept out of the template so
// Smarty never touches it and errors report this file and line.
(function () {
    // The service page's forms need jQuery and a few plugins. Nothing here
    // assumes when the theme loads jQuery or what "$" means on this page:
    // wait for jQuery, then pull the plugins in on demand, in order.
    var VENDOR = {
        select2:   'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js',
        flatpickr: 'https://cdn.jsdelivr.net/npm/flatpickr',
        inputmask: 'modules/addons/resellervoip/templates/client/js/inputMask/jquery.inputmask.js',
        jqueryui:  'modules/addons/resellervoip/templates/client/js/jquery-ui/jquery-ui.min.js',
        signature: 'modules/addons/resellervoip/templates/client/js/jquery-signature/jquery.signature.js'
    };
    var loaded = {};
    function loadScript(src) {
        return new Promise(function (resolve, reject) {
            if (loaded[src]) return resolve();
            var s = document.createElement('script');
            s.src = src;
            s.onload = function () { loaded[src] = true; resolve(); };
            s.onerror = function () { reject(new Error('Could not load ' + src)); };
            document.head.appendChild(s);
        });
    }
    var ensure = window.__portingEnsure || function (keys) {
        return keys.reduce(function (p, k) { return p.then(function () { return loadScript(VENDOR[k]); }); }, Promise.resolve());
    };

    function init($) {
        var state = { service: null, serviceName: '', type: null };
        var productUrl = function (id) { return 'clientarea.php?action=productdetails&id=' + encodeURIComponent(id); };
        var escHtml = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

        // The service page's port form talks to "this page" — inside the
        // service page that's the service itself. Here, send those requests
        // to the chosen service instead, so its forms work unchanged.
        // pbx-shim.js sends every pbxAction request to the addon's endpoint for
        // the chosen service (pbxApi.setService below).

        // ----- step 1: the service -----
        function selectService(id, name) {
            state.service = String(id);
            if (window.pbxApi) pbxApi.setService(state.service);
            state.serviceName = name || '';
            $('.porting-service').removeClass('is-on').filter(function () { return $(this).find('input').val() === state.service; }).addClass('is-on');
            $('#portingStep2').prop('hidden', false);
            $('#portingSeeService').attr('href', productUrl(state.service));
            $('#portingTarget').html('<i class="fa-solid fa-server"></i> ' + escHtml(state.serviceName));
            // A different service: start the form again for it.
            $('#portingStep3').prop('hidden', true);
            $('.porting-type').removeClass('is-on');
            state.type = null;
        }
        function scrollTo(sel) { var el = $(sel)[0]; if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
        $(document).on('change', 'input[name="portingService"]', function () {
            selectService($(this).val(), $(this).data('name'));
            scrollTo('#portingStep2');
        });

        // Many services: a searchable picker instead of a wall of cards.
        var $pick = $('#portingServiceSelect');
        if ($pick.length) {
            var optHtml = function (o) {
                if (!o.id) return o.text;
                var $o = $(o.element);
                return $('<span class="porting-opt">' +
                    '<span class="porting-opt-name">' + escHtml($o.data('name')) + '</span>' +
                    '<span class="porting-opt-sub"><span>' + escHtml($o.data('product')) + '</span>' +
                    '<span><i class="fa-solid fa-phone"></i> ' + escHtml($o.data('numbers')) + ' number' + (String($o.data('numbers')) === '1' ? '' : 's') + '</span>' +
                    '<span class="porting-badge is-' + escHtml($o.data('statuskey')) + '">' + escHtml($o.data('status')) + '</span></span>' +
                '</span>');
            };
            var selHtml = function (o) {
                if (!o.id) return o.text;
                var $o = $(o.element);
                return $('<span class="porting-opt-sel"><b>' + escHtml($o.data('name')) + '</b><span class="porting-opt-sub">' + escHtml($o.data('product')) + '</span><span class="porting-badge is-' + escHtml($o.data('statuskey')) + '">' + escHtml($o.data('status')) + '</span></span>');
            };
            var matcher = function (params, data) {
                var q = $.trim(params.term || '').toLowerCase();
                if (!q) return data;
                if (!data.id) return null;
                var $o = $(data.element);
                var hay = [$o.data('name'), $o.data('product'), $o.data('tenant'), data.text].join(' ').toLowerCase();
                return hay.indexOf(q) > -1 ? data : null;
            };
            $pick.on('change', function () {
                var v = $(this).val();
                if (!v) return;
                selectService(v, $(this).find('option:selected').data('name'));
                scrollTo('#portingStep2');
            });
            ensure(['select2']).then(function () {
                if (!$.fn.select2) return;
                $pick.select2({ width: '100%', placeholder: 'Search your services…', templateResult: optHtml, templateSelection: selHtml, matcher: matcher });
            }, function () { /* the plain select still works */ });
        }

        // ----- step 2: the kind of number -----
        function selectType(type) {
            state.type = type;
            $('.porting-type').removeClass('is-on').filter('[data-type="' + type + '"]').addClass('is-on');
            loadForm();
        }
        $(document).on('click', '.porting-type', function () {
            if (!state.service) { scrollTo('#portingStep1'); return; }
            selectType($(this).data('type'));
        });

        // ----- step 3: the form -----
        function panels(show) {
            $('#portingFormHost .giantModalPanel').hide();
            if (show) $(show).show();
        }
        function showError(msg) {
            $('#giantModalAlert').html(msg || 'Something went wrong. Please try again in a moment.');
            panels(null);
            $('#giantModalAlertDiv').show();
            $('#giantModalAddFormDiv').show();
        }
        function loadForm() {
            $('#portingStep3').prop('hidden', false);
            panels('#giantModalSpinnerDiv');
            scrollTo('#portingStep3');
            if (state.type === 'mobile') { renderMobileForm(); return; }
            // Landline: the service page's own form, fetched from that
            // service, once the plugins it relies on are in.
            ensure(['select2', 'flatpickr', 'inputmask', 'jqueryui', 'signature']).then(fetchLandlineForm, function () {
                showError('Could not load the form tools. Please refresh and try again, or use the Port tile on the service page.');
            });
        }
        function fetchLandlineForm() {
            $.ajax({
                type: 'post',
                data: { pbxAction: 'getForm', formName: 'port', formType: 'add' },
                success: function (json) {
                    var r = {};
                    try { r = (typeof json === 'object') ? json : jQuery.parseJSON(json); } catch (e) {}
                    if (!r || !r.formHtml) { showError((r && r.error) || 'Could not load the port form. Please try again in a moment.'); return; }
                    $('#giantModalAddForm').replaceWith(r.formHtml);   // brings its own script along
                    panels('#giantModalAddFormDiv');
                },
                error: function () { showError('Could not load the port form. Please try again in a moment.'); }
            });
        }
        // The service page's form calls this when it has finished submitting.
        window.refreshList = function () {
            $('#giantModalSpinnerDiv').hide();
            if ($('#giantModalAlertDiv').is(':visible')) { $('#giantModalAddFormDiv').show(); return; }   // fix and retry
            submitted();
        };
        function submitted() {
            panels('#portingDone');
            loadRows();
        }
        $(document).on('click', '#portingAnother', function () {
            state.type = null;
            $('.porting-type').removeClass('is-on');
            $('#portingStep3').prop('hidden', true);
            scrollTo('#portingStep2');
        });

        // Mobile: a short form of our own, posted to the chosen service.
        function workingDaysFrom(n) {
            var d = new Date(); d.setHours(0, 0, 0, 0);
            var left = n;
            while (left > 0) { d.setDate(d.getDate() + 1); if (d.getDay() !== 0 && d.getDay() !== 6) left--; }
            return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
        }
        // Working days only: weekends and UK bank holidays never carry a port.
        var holidays = {};
        var isoOf = function (d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); };
        var isOffDay = function (d) { var n = d.getDay(); return n === 0 || n === 6 || !!holidays[isoOf(d)]; };
        var earliestPortDate = function () {
            var d = new Date(); d.setHours(0, 0, 0, 0);
            var left = 2;
            while (left > 0) { d.setDate(d.getDate() + 1); if (!isOffDay(d)) left--; }
            return d;
        };
        var nextWorkingDay = function (d) { var x = new Date(d.getTime()); for (var i = 0; i < 30; i++) { x.setDate(x.getDate() + 1); if (!isOffDay(x)) return x; } return d; };
        function fetchHolidays() {
            // The service page's own list (gov.uk, cached); nothing lost if it fails.
            return $.ajax({ type: 'post', data: { pbxAction: 'getUkBankHolidays' }, dataType: 'json' })
                .then(function (r) { ((r && r.dates) || []).forEach(function (x) { if (x && x.date) holidays[x.date] = x.title || 'a bank holiday'; }); }, function () {});
        }
        function setupMobileDate() {
            var min = earliestPortDate();
            var $d = $('#portMobileDate');
            if (!$d.length) return;
            $d.val(isoOf(min));
            if (window.flatpickr) {
                window.flatpickr($d[0], {
                    dateFormat: 'Y-m-d', minDate: min, defaultDate: min, locale: { firstDayOfWeek: 1 },
                    disable: [function (d) { return isOffDay(d); }]
                });
                $('#portMobileDateNote').text('Weekends and bank holidays are greyed out.');
            } else {
                $d.attr('type', 'date').attr('min', isoOf(min));
                $d.on('change', function () {
                    var v = $(this).val(); if (!v) return;
                    var d = new Date(v + 'T00:00:00');
                    if (isOffDay(d)) { var m = nextWorkingDay(d); $(this).val(isoOf(m)); $('#portMobileDateNote').text('Ports don\'t complete on ' + (holidays[v] || 'a weekend') + ' \u2014 moved to ' + isoOf(m) + '.'); }
                    else $('#portMobileDateNote').text('');
                });
            }
        }
        function renderMobileForm() {
            var min = workingDaysFrom(2);
            var h = '<form id="giantModalAddForm" class="modalForm is-mobile" method="post">';
            h += '<input type="hidden" name="pbxAction" value="addMobilePort">';
            h += '<div class="porting-mobile-note"><b>You\'ll need a PAC.</b> Text <b>PAC</b> to 65075 from the mobile and your current provider replies with a code valid for 30 days. Ports complete on working days only \u2014 the earliest is two working days from today.</div>';
            h += '<div class="row">';
            h += '<div class="col-md-6"><div class="form-group"><label for="portMsisdn">Mobile number</label><input type="text" class="form-control" id="portMsisdn" name="msisdn" inputmode="numeric" placeholder="07700 900123" required></div></div>';
            h += '<div class="col-md-6"><div class="form-group"><label for="portPac">PAC code</label><input type="text" class="form-control" id="portPac" name="pac" placeholder="ABC123456" maxlength="12" style="text-transform:uppercase;" required></div></div>';
            h += '</div>';
            h += '<div class="row"><div class="col-md-6"><div class="form-group"><label for="portMobileDate">Port date</label><input type="text" class="form-control" id="portMobileDate" name="port_date" value="' + min + '" placeholder="Choose a working day" autocomplete="off"><div class="text-muted small" id="portMobileDateNote" style="margin-top:4px;"></div></div></div></div>';
            h += '<button type="submit" class="btn btn-primary"><i class="fa-solid fa-paper-plane"></i> Submit port request</button>';
            h += '</form>';
            $('#giantModalAddForm').replaceWith(h);
            panels('#giantModalAddFormDiv');
            ensure(['flatpickr']).then(function () { return fetchHolidays(); }, function () { return fetchHolidays(); }).then(setupMobileDate, setupMobileDate);
            $('#giantModalAddForm.is-mobile').on('submit', function (e) {
                e.preventDefault();
                var picked = $('#portMobileDate').val();
                if (picked && isOffDay(new Date(picked + 'T00:00:00'))) {
                    showError('Mobile ports don\'t complete at weekends or on bank holidays \u2014 please choose a working day.');
                    return;
                }
                var data = $(this).serialize();
                panels('#giantModalSpinnerDiv');
                $.ajax({
                    type: 'post',
                        data: data,
                    success: function (json) {
                        var r = {};
                        try { r = (typeof json === 'object') ? json : jQuery.parseJSON(json); } catch (e) {}
                        if (r && r.error) { showError(r.error); return; }
                        submitted();
                    },
                    error: function () { showError('Could not send the request. Please try again in a moment.'); }
                });
            });
        }

        // ----- the account's requests -----
        function renderRows(rows) {
            var $b = $('#portingRows').empty();
            if (!rows || !rows.length) { $('#portingTable').hide(); $('#portingEmpty').show(); return; }
            $('#portingTable').show(); $('#portingEmpty').hide();
            rows.forEach(function (r) {
                var num = escHtml(r.number || r.ref) + (r.extra ? ' <span class="muted">+' + r.extra + ' more</span>' : '');
                var status = '<span class="porting-badge is-' + escHtml(r.statusKey) + '">' + escHtml(r.status) + '</span>' + (r.remote ? ' <span class="muted">' + escHtml(r.remote) + '</span>' : '');
                $b.append('<tr>' +
                    '<td class="num">' + num + '</td>' +
                    '<td>' + escHtml(r.service) + '</td>' +
                    '<td>' + escHtml(r.type) + '</td>' +
                    '<td>' + escHtml(r.requested || '') + '</td>' +
                    '<td>' + escHtml(r.portDate || '—') + '</td>' +
                    '<td>' + status + '</td>' +
                    '<td>' + (r.loaUrl ? '<a href="' + escHtml(r.loaUrl) + '" target="_blank" rel="noopener" title="Download the signed Letter of Authorisation"><i class="fa-solid fa-file-pdf"></i> Letter</a> &nbsp; ' : '') +
                        '<a href="' + productUrl(r.serviceId) + '">Details <i class="fa-solid fa-arrow-right"></i></a></td>' +
                '</tr>');
            });
        }
        function loadRows() {
            $.ajax({
                type: 'get',
                data: { pbxAction: 'portingRows' },
                dataType: 'json',
                success: function (r) { renderRows((r && r.rows) || []); }
            });
        }
        var initial = [];
        try { initial = JSON.parse($('#portingRowsJson').text() || '[]'); } catch (e) {}
        renderRows(initial);

        // ----- where to start -----
        var $pre = $('input[name="portingService"]:checked');
        var preId = $pre.length ? $pre.val() : ($pick.length && $pick.val() ? $pick.val() : '');
        var preName = $pre.length ? $pre.data('name') : ($pick.length ? $pick.find('option:selected').data('name') : '');
        if (preId) {
            selectService(preId, preName);
            if (portingPresetType === 'mobile' || portingPresetType === 'landline') selectType(portingPresetType);
        }
        window.__portingReady = true;
    }

    // Wait for jQuery and the DOM, then start; say so in the console if it can't.
    var tries = 0;
    (function boot() {
        if (window.jQuery) {
            window.jQuery(function () {
                try { init(window.jQuery); }
                catch (e) { if (window.console) console.error('Port a Number: failed to start', e); }
            });
            return;
        }
        if (++tries < 400) setTimeout(boot, 50);
        else if (window.console) console.error('Port a Number: jQuery never loaded on this page');
    })();
    setTimeout(function () {
        var fb = document.getElementById('portingFallback');
        if (fb && !window.__portingReady) fb.hidden = false;
    }, 6000);
})();
