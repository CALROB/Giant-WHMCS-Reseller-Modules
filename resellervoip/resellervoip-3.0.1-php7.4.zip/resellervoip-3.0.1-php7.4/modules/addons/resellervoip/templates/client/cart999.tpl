<script>window.rvCart999 = {ldelim}"fieldIds": {$fieldIds}, "fieldMeta": {$fieldMeta}, "account": {$account}{rdelim};</script>
{literal}
<style>
.rv-cart-999 { margin-top:20px; background:#fff; border:1px solid #e5e7eb; border-radius:12px; overflow:hidden; }
.rv-cart-999-head { padding:14px 18px; border-bottom:1px solid #f3f4f6; display:flex; align-items:center; gap:10px; }
.rv-cart-999-head .ic { width:32px; height:32px; border-radius:8px; background:#fef2f2; color:#dc2626; display:flex; align-items:center; justify-content:center; font-size:16px; }
.rv-cart-999-title { font-weight:700; font-size:14px; color:#1a1a2e; line-height:1.2; }
.rv-cart-999-sub { font-size:12px; color:#6b7280; }
.rv-cart-999-body { padding:18px; }
.rv-cart-999-mode { display:inline-flex; border:1.5px solid #e5e7eb; border-radius:10px; overflow:hidden; margin-bottom:14px; }
.rv-cart-999-mode button { background:#fff; color:#6b7280; border:none; padding:8px 16px; font-size:13px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:6px; }
.rv-cart-999-mode button.is-active { background:#2a78d6; color:#fff; }
.rv-cart-999-autofill { margin-left:10px; background:#f3f4f6; border:1.5px solid #e5e7eb; color:#374151; padding:7px 14px; border-radius:10px; font-size:12px; font-weight:600; cursor:pointer; display:inline-flex; align-items:center; gap:6px; }
.rv-cart-999-autofill[disabled] { opacity:.5; cursor:not-allowed; }
.rv-cart-999-grid { display:grid; grid-template-columns:repeat(2, 1fr); gap:12px 16px; }
.rv-cart-999-grid .full { grid-column:1 / -1; }
.rv-cart-999-grid label { display:block; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; color:#6b7280; margin-bottom:4px; }
.rv-cart-999-grid label .req { color:#dc2626; }
.rv-cart-999-grid input[type="text"], .rv-cart-999-grid select { width:100%; padding:10px 12px; border:1.5px solid #e5e7eb; border-radius:8px; font-size:13px; background:#fff; font-family:inherit; }
.rv-cart-999-grid .help { font-size:11px; color:#9ca3af; margin-top:4px; }
.rv-cart-999-body[data-mode="personal"] .business-only, .rv-cart-999-body[data-mode="business"] .personal-only { display:none; }
.rv-cart-999-body[data-mode="personal"] .name-bizlabel { display:none; }
.rv-cart-999-body[data-mode="business"] .name-personalabel { display:none; }
.rv-cart-999-notice { margin-top:14px; padding:10px 12px; background:#fef3c7; border:1px solid #fcd34d; border-radius:8px; font-size:12px; color:#78350f; }
@media (max-width:600px) { .rv-cart-999-grid { grid-template-columns:1fr; } }
html.dark .rv-cart-999 { background:rgb(var(--surface-2, 30 41 59)); border-color:rgb(var(--border, 51 65 85)); }
html.dark .rv-cart-999-title { color:rgb(var(--text, 226 232 240)); }
html.dark .rv-cart-999-grid input[type="text"], html.dark .rv-cart-999-grid select { background:rgb(var(--surface, 15 23 42)); border-color:rgb(var(--border, 51 65 85)); color:rgb(var(--text, 226 232 240)); }
</style>
<script>
(function () {
    if (typeof jQuery === 'undefined') { return; }
    if (!window.rvCart999) { return; }
    var fieldIds  = window.rvCart999.fieldIds || {};
    var fieldMeta = window.rvCart999.fieldMeta || {};
    var acc       = window.rvCart999.account;

    function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
    function findOriginal(id) { return jQuery("[name='customfield[" + id + "]']").first(); }

    function buildTitleControl(current) {
        var meta = fieldMeta && fieldMeta.title;
        if (meta && (meta.type === 'dropdown' || meta.type === 'radio') && meta.options && meta.options.length) {
            var html = '<select data-key="title"><option value=""></option>';
            meta.options.forEach(function (opt) { html += '<option value="' + esc(opt) + '"' + (String(current || '') === String(opt) ? ' selected' : '') + '>' + esc(opt) + '</option>'; });
            return html + '</select>';
        }
        return '<input type="text" data-key="title" maxlength="20" value="' + esc(current) + '" placeholder="Mr / Mrs / Dr">';
    }

    function detectMode(v) {
        if ((v.bussuffix || '').trim() !== '') return 'business';
        if ((v.title || '').trim() === '' && (v.forename || '').trim() === '' && (v.name || '').trim() !== '') return 'business';
        return 'personal';
    }

    function buildForm(v) {
        var mode = detectMode(v);
        var hasAcc = !!(acc && (acc.address1 || acc.companyname));
        return '<div class="rv-cart-999"><div class="rv-cart-999-head"><div class="ic"><i class="fa fa-exclamation-triangle"></i></div><div>' +
            '<div class="rv-cart-999-title">999 emergency address</div><div class="rv-cart-999-sub">Where this number physically lives, so the emergency services can find the caller.</div></div></div>' +
            '<div class="rv-cart-999-body" data-mode="' + mode + '"><div>' +
            '<div class="rv-cart-999-mode" role="tablist"><button type="button" data-mode="personal" class="' + (mode === 'personal' ? 'is-active' : '') + '"><i class="fa fa-user"></i> Personal</button>' +
            '<button type="button" data-mode="business" class="' + (mode === 'business' ? 'is-active' : '') + '"><i class="fa fa-briefcase"></i> Business</button></div>' +
            '<button type="button" class="rv-cart-999-autofill"' + (hasAcc ? '' : ' disabled') + '><i class="fa fa-magic"></i> Use my account address</button></div>' +
            '<div class="rv-cart-999-grid" style="margin-top:14px;">' +
            '<div class="personal-only"><label>Title</label>' + buildTitleControl(v.title) + '<div class="help">Optional.</div></div>' +
            '<div class="personal-only"><label>First name</label><input type="text" data-key="forename" maxlength="20" value="' + esc(v.forename) + '" placeholder="First name"><div class="help">Optional.</div></div>' +
            '<div class="full"><label><span class="name-personalabel">Surname <span class="req">*</span></span><span class="name-bizlabel">Business name <span class="req">*</span></span></label><input type="text" data-key="name" maxlength="50" value="' + esc(v.name) + '">' +
            '<div class="help"><span class="personal-only">The end user\'s surname.</span><span class="business-only">The trading name: what is on the door, not a parent company.</span></div></div>' +
            '<div class="full business-only"><label>Business suffix</label><input type="text" data-key="bussuffix" maxlength="50" value="' + esc(v.bussuffix) + '" placeholder="Ltd, Plc, Hotel, Surgery…"><div class="help">Legal suffix and/or a short site description.</div></div>' +
            '<div><label>Property name / number <span class="req">*</span></label><input type="text" data-key="premises" maxlength="60" value="' + esc(v.premises) + '" placeholder="e.g. 104, Thatched Cottage"></div>' +
            '<div><label>Street <span class="req">*</span></label><input type="text" data-key="thoroughfare" maxlength="55" value="' + esc(v.thoroughfare) + '" placeholder="e.g. King Street"></div>' +
            '<div><label>Town / City <span class="req">*</span></label><input type="text" data-key="locality" maxlength="30" value="' + esc(v.locality) + '" placeholder="e.g. York"></div>' +
            '<div><label>Postcode <span class="req">*</span></label><input type="text" data-key="postcode" maxlength="12" value="' + esc(v.postcode) + '" placeholder="e.g. YO30 4AG"></div>' +
            '</div><div class="rv-cart-999-notice"><i class="fa fa-info-circle"></i> Enter the <strong>site</strong> address (where the phone lives), not the billing contact. Required for 999 calls.</div></div></div>';
    }

    function decode(s) {
        if (s == null || s === '') return '';
        var cur = String(s), prev = null, i = 0, t = document.createElement('textarea');
        while (cur !== prev && i < 5) { prev = cur; t.innerHTML = cur; cur = t.value; i++; }
        return cur;
    }

    function readValues() {
        var out = {};
        Object.keys(fieldIds).forEach(function (k) { var $el = findOriginal(fieldIds[k]); out[k] = $el.length ? decode($el.val() || '') : ''; });
        return out;
    }

    function writeBack(k, v) { var $el = findOriginal(fieldIds[k]); if ($el.length) $el.val(v); }

    function hideOriginals() {
        Object.keys(fieldIds).forEach(function (k) {
            var $el = findOriginal(fieldIds[k]);
            if (!$el.length) return;
            var $row = $el.closest('.form-group, tr, .row, div');
            if ($row.length) $row.hide();
        });
    }

    function splitPremises(a1, a2) {
        a1 = (a1 || '').trim(); a2 = (a2 || '').trim();
        var patterns = [/^((?:Unit|Flat|Apartment|Apt|Suite|Office|Shop|Studio|Room|Plot|Lot|Block)\s+\d+[A-Za-z]?(?:[\s\-\/]\d+[A-Za-z]?)?),?\s+(.+)$/i, /^(\d+[A-Za-z]?(?:[\s\-\/]\d+[A-Za-z]?)?),?\s+(.+)$/];
        for (var i = 0; i < patterns.length; i++) { var m = patterns[i].exec(a1); if (m) return { premises: m[1].trim(), thoroughfare: m[2].trim(), extra: a2 }; }
        if (a2) return { premises: a1, thoroughfare: a2, extra: '' };
        var c = a1.indexOf(',');
        if (c > 0) return { premises: a1.substring(0, c).trim(), thoroughfare: a1.substring(c + 1).trim(), extra: '' };
        return { premises: '', thoroughfare: a1, extra: '' };
    }
    function combineLocality(extra, city) {
        extra = (extra || '').trim(); city = (city || '').trim();
        if (!extra) return city; if (!city) return extra;
        var both = extra + ', ' + city; return both.length <= 30 ? both : extra;
    }
    function splitCompany(full) {
        full = (full || '').trim(); if (!full) return { biz: '', suffix: '' };
        var m = /^(.+?)[\s,]+(Ltd\.?|Limited|P\.?L\.?C\.?|LLP|L\.L\.P\.?|CIC|C\.I\.C\.?|LP|Inc\.?|Incorporated|Co\.?)\s*$/i.exec(full);
        return m ? { biz: m[1].trim(), suffix: m[2].trim() } : { biz: full, suffix: '' };
    }

    function init() {
        var any = false;
        Object.keys(fieldIds).forEach(function (k) { if (findOriginal(fieldIds[k]).length) any = true; });
        if (!any) return;
        var values = readValues();
        hideOriginals();
        var $c = jQuery(buildForm(values));

        function place() {
            var $picker = jQuery('.phone-filters').first().closest('.panel');
            if ($picker.length) { $picker.after($c); return true; }
            return false;
        }
        if (!place()) {
            var n = 0, t = setInterval(function () {
                n++;
                if (place() || n > 20) {
                    clearInterval(t);
                    if (!$c.parent().length) { var $f = jQuery('#productConfigurableOptions'); if ($f.length) $f.after($c); else jQuery('form').first().prepend($c); }
                }
            }, 100);
        }

        $c.on('click', '.rv-cart-999-mode button', function () {
            var mode = jQuery(this).data('mode');
            $c.find('.rv-cart-999-mode button').removeClass('is-active'); jQuery(this).addClass('is-active');
            $c.find('.rv-cart-999-body').attr('data-mode', mode);
            if (mode === 'business') { writeBack('title', ''); writeBack('forename', ''); } else { writeBack('bussuffix', ''); }
        });
        $c.on('input change', '[data-key]', function () { writeBack(jQuery(this).data('key'), jQuery(this).val()); });
        $c.on('click', '.rv-cart-999-autofill', function () {
            if (!acc) return;
            var sp = splitPremises(acc.address1, acc.address2);
            function setVal(k, v) { $c.find('[data-key="' + k + '"]').val(v || '').trigger('change'); }
            if (acc.companyname) {
                $c.find('.rv-cart-999-mode button[data-mode="business"]').click();
                var co = splitCompany(acc.companyname); setVal('name', co.biz); setVal('bussuffix', co.suffix); setVal('title', ''); setVal('forename', '');
            } else {
                $c.find('.rv-cart-999-mode button[data-mode="personal"]').click();
                setVal('forename', acc.firstname); setVal('name', acc.lastname); setVal('bussuffix', '');
            }
            setVal('premises', sp.premises); setVal('thoroughfare', sp.thoroughfare); setVal('locality', combineLocality(sp.extra, acc.city)); setVal('postcode', acc.postcode);
            var $b = jQuery(this), orig = $b.html();
            $b.html('<i class="fa fa-check"></i> Filled').prop('disabled', true);
            setTimeout(function () { $b.html(orig).prop('disabled', false); }, 1600);
        });
    }

    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();
</script>
{/literal}
