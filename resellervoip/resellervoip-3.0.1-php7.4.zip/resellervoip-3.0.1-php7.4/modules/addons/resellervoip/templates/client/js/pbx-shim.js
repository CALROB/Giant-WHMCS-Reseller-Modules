/**
 * Phone System: the page script's transport.
 *
 * The portal script posts every request to "this page" with a pbxAction
 * field. Here each such request is sent to the addon's endpoint instead
 * (index.php?m=resellervoip&action=api) with the service id and WHMCS's form
 * token, and the answer is handed back exactly as the script expects it.
 *
 * window.pbxConfig = { endpoint, service (or null on account pages), token, brand, sandbox }
 * is set by the template before this file loads.
 */
(function ($) {
    'use strict';

    var cfg = window.pbxConfig || { endpoint: 'index.php?m=resellervoip&action=api', service: null, token: '', brand: {} };
    window.pbxConfig = cfg;

    function opOf(d) {
        if (typeof d === 'string') { var m = /(?:^|&)pbxAction=([^&]*)/.exec(d); return m ? decodeURIComponent(m[1]) : null; }
        if (d && typeof d.get === 'function') { return d.get('pbxAction'); }
        if (d && typeof d === 'object') { return d.pbxAction || null; }
        return null;
    }

    function has(d, k) {
        if (typeof d === 'string') { return new RegExp('(^|&)' + k + '=').test(d); }
        if (d && typeof d.has === 'function') { return d.has(k); }
        return !!(d && typeof d === 'object' && Object.prototype.hasOwnProperty.call(d, k));
    }

    function extras(d) {
        var e = { token: cfg.token };
        if (cfg.service !== null && cfg.service !== undefined && !has(d, 'service')) { e.service = cfg.service; }
        return e;
    }

    // The answer, in the shape the script was written for. The endpoint already
    // answers that way; this only guards against a login page (session gone).
    function unwrap(raw) {
        if (typeof raw !== 'string') { return raw; }
        var s = raw.replace(/^\s+/, '');
        if (s === '') { return raw; }
        if (s[0] !== '{' && s[0] !== '[') {
            sessionLost();
            return '{"error":"Your session has expired. Please sign in again.","success":false,"ok":false,"message":"Your session has expired. Please sign in again.","code":"session"}';
        }
        return raw;
    }

    var lostShown = false;
    function sessionLost() {
        if (lostShown) { return; }
        lostShown = true;
        if (typeof giantToast === 'function') { giantToast('Your session has expired. Reloading…', 'error'); }
        setTimeout(function () { window.location.reload(); }, 1500);
    }

    $.ajaxPrefilter(function (options, original) {
        var d = original ? original.data : null;
        if (!opOf(d)) { return; }

        options.url = cfg.endpoint;
        options.type = 'POST';
        var e = extras(d);

        if (typeof d === 'string') {
            options.data = d + '&' + $.param(e);
        } else if (d && typeof d.append === 'function') {
            $.each(e, function (k, v) { d.set ? d.set(k, v) : d.append(k, v); });
            options.data = d;
        } else {
            options.data = $.extend({}, d, e);
        }

        // Callbacks written for the old page parse a string themselves.
        if (!original || !original.dataType) { options.dataTypes = ['text']; }

        var inner = options.dataFilter;
        options.dataFilter = function (raw, type) {
            var t = unwrap(raw);
            return inner ? inner(t, type) : t;
        };
    });

    window.pbxApi = {
        /** A GET URL for an op: files, images, downloads. */
        url: function (op, params) {
            var q = cfg.endpoint + '&pbxAction=' + encodeURIComponent(op);
            if (cfg.service !== null && cfg.service !== undefined) { q += '&service=' + encodeURIComponent(cfg.service); }
            if (params) { q += '&' + $.param(params); }
            return q;
        },
        /** A form-encoded body with the service and token added. */
        body: function (legacy) {
            var b = String(legacy || '');
            if (cfg.service !== null && cfg.service !== undefined && !/(^|&)service=/.test(b)) { b += '&service=' + encodeURIComponent(cfg.service); }
            return b + '&token=' + encodeURIComponent(cfg.token);
        },
        /** Hidden inputs for a plain form post to the endpoint. */
        hidden: function () {
            var h = '<input type="hidden" name="token" value="' + $('<div>').text(cfg.token).html() + '">';
            if (cfg.service !== null && cfg.service !== undefined) { h += '<input type="hidden" name="service" value="' + parseInt(cfg.service, 10) + '">'; }
            return h;
        },
        endpoint: function () { return cfg.endpoint; },
        /** The page's service, when an account page picks one. */
        setService: function (id) { cfg.service = id === null || id === undefined || id === '' ? null : id; }
    };
})(jQuery);
