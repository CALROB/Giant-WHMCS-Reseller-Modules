<form id="giantModalAddForm" class="modalForm giant-vc-form" method="post">
    <input type="hidden" class="form-control" name="pbxAction" value="addVoiceCloud">

    <div class="giant-vc-form-page" id="page1">

        <div class="giant-vc-form-section">
            <div class="giant-vc-form-section-head">
                <span class="giant-vc-form-section-num">1</span>
                <div>
                    <div class="giant-vc-form-section-title">Basic info</div>
                    <div class="giant-vc-form-section-sub">Required &mdash; this is what they'll sign in with.</div>
                </div>
            </div>
            <div class="giant-vc-form-grid">
                <div class="giant-vc-form-field giant-vc-form-field-full">
                    <label for="fullNameInput">Full name <span class="req">*</span></label>
                    <input type="text" class="form-control" id="fullNameInput" name="fullName" value="" autocomplete="off" placeholder="Jane Doe">
                    <small class="giant-vc-form-hint">Display name shown across the app.</small>
                </div>
                <div class="giant-vc-form-field">
                    <label for="emailInput">Email <span class="req">*</span></label>
                    <input type="email" class="form-control" id="emailInput" name="email" value="" autocomplete="off" placeholder="jane@example.com">
                    <small class="giant-vc-form-hint">Used to sign in and receive the invite.</small>
                </div>
                <div class="giant-vc-form-field">
                    <label for="mobileInput">Mobile <span class="req">*</span></label>
                    <input type="text" class="form-control" id="mobileInput" name="mobile" value="" autocomplete="off" placeholder="07&hellip;">
                    <small class="giant-vc-form-hint">SMS invite is sent here. Shown in the user's profile.</small>
                </div>
            </div>
        </div>

        <div class="giant-vc-form-section">
            <div class="giant-vc-form-section-head">
                <span class="giant-vc-form-section-num">2</span>
                <div>
                    <div class="giant-vc-form-section-title">Profile <span class="giant-vc-form-section-tag">optional</span></div>
                    <div class="giant-vc-form-section-sub">Extra context that appears on the user's card.</div>
                </div>
            </div>
            <div class="giant-vc-form-grid">
                <div class="giant-vc-form-field">
                    <label for="phoneInput">Direct phone</label>
                    <input type="text" class="form-control" id="phoneInput" name="phone" value="" autocomplete="off" placeholder="Office line">
                    <small class="giant-vc-form-hint">Direct office number on their profile.</small>
                </div>
                <div class="giant-vc-form-field">
                    <label for="companyInput">Company</label>
                    <input type="text" class="form-control" id="companyInput" name="company" value="" autocomplete="off">
                    <small class="giant-vc-form-hint">Company name on their profile.</small>
                </div>
                <div class="giant-vc-form-field giant-vc-form-field-full">
                    <label for="positionInput">Position / job title</label>
                    <input type="text" class="form-control" id="positionInput" name="position" value="" autocomplete="off" placeholder="e.g. Sales Manager">
                </div>
            </div>
        </div>

        <div class="giant-vc-form-section">
            <div class="giant-vc-form-section-head">
                <span class="giant-vc-form-section-num">3</span>
                <div>
                    <div class="giant-vc-form-section-title">
                        Extensions <span class="req">*</span>
                        <span id="giantVcExtCount" class="giant-vc-form-count">0 selected</span>
                    </div>
                    <div class="giant-vc-form-section-sub">Pick the extensions for this user, then star the one that's the <strong>main app user</strong> &mdash; the rest are attached to it.</div>
                </div>
            </div>
            <span id="extensionsError" class="giant-vc-form-error" style="display: none">Select at least one extension</span>
            <input type="hidden" name="primaryExtension" id="primaryExtensionInput" value="">
            <div class="giant-vc-ext-grid">
                {foreach from=$extensions item=extension name=extensions}
                    <label class="giant-vc-ext-tile" for="extensionsInput{$extension->ex_id}">
                        <input type="checkbox" class="extensionsInput giant-vc-ext-input"
                               data-number="{$extension->ex_number}{if $extension->ex_name} - {$extension->ex_name}{/if}"
                               id="extensionsInput{$extension->ex_id}"
                               name="extensions[]" value="{$extension->ex_id}">
                        <span class="giant-vc-ext-check"><i class="fa-solid fa-check"></i></span>
                        <span class="giant-vc-ext-meta">
                            <span class="giant-vc-ext-num">{$extension->ex_number}</span>
                            {if $extension->ex_name}<span class="giant-vc-ext-name">{$extension->ex_name}</span>{/if}
                        </span>
                        <button type="button" class="giant-vc-ext-main-btn" data-ex-id="{$extension->ex_id}" tabindex="-1" title="Make this the main app user">
                            <i class="fa-solid fa-star"></i><span class="giant-vc-ext-main-txt">Main</span>
                        </button>
                    </label>
                {/foreach}
            </div>
        </div>

        <div class="giant-vc-form-actions">
            <button id="nextButton" class="btn giant-vc-btn-primary">
                <span>Next</span> <i class="fa-solid fa-arrow-right"></i>
            </button>
        </div>
    </div>

    <div class="giant-vc-form-page" id="page2" style="display: none">
        <div class="giant-vc-form-section">
            <div class="giant-vc-form-section-head">
                <span class="giant-vc-form-section-num"><i class="fa-solid fa-check"></i></span>
                <div>
                    <div class="giant-vc-form-section-title">Review &amp; send</div>
                    <div class="giant-vc-form-section-sub">An invitation will be sent by SMS to the mobile number above.</div>
                </div>
            </div>
            <div class="giant-vc-summary">
                <div class="giant-vc-summary-row">
                    <span class="giant-vc-summary-label">Full name</span>
                    <span class="giant-vc-summary-value" id="summaryName"></span>
                </div>
                <div class="giant-vc-summary-row">
                    <span class="giant-vc-summary-label">Email</span>
                    <span class="giant-vc-summary-value" id="summaryEmail"></span>
                </div>
                <div class="giant-vc-summary-row giant-vc-summary-row-stack">
                    <span class="giant-vc-summary-label">Linked extensions</span>
                    <div class="giant-vc-summary-chips" id="summaryExtensions"></div>
                </div>
            </div>
        </div>

        <div class="giant-vc-form-actions giant-vc-form-actions-split">
            <button id="prevButton" class="btn giant-vc-btn-ghost">
                <i class="fa-solid fa-arrow-left"></i> <span>Back</span>
            </button>
            <button id="submitButton" class="btn giant-vc-btn-primary">
                <i class="fa-solid fa-paper-plane"></i> <span>Send invitation</span>
            </button>
        </div>
    </div>


</form>
<script src="modules/addons/resellervoip/templates/client/js/voiceCloudForm.js?cahebaypas={$smarty.now}"></script>
