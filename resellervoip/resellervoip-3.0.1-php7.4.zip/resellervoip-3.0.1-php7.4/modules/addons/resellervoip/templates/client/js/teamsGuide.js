/**
 * Teams Direct Routing — Setup Guide
 * Renders a step-by-step guide inside the us modal.
 */
function renderTeamsRoutingGuide(response, tileName) {

    var $container = $('#giantModalListTableDiv');
    $container.children().remove();

    var tenantCode = response.tenantCode || 'your-tenant';
    var tenantName = response.tenantName || tenantCode;
    // The SBC address is the reseller's own (addon setting), never shown as a guess.
    var sbcDomain  = (window.pbxConfig && window.pbxConfig.sbcDomain) || '';
    var sbcFqdn    = sbcDomain ? tenantCode + '.' + sbcDomain : 'ask us for your SBC address';

    var steps = [
        {
            title: 'Add Your Domain to Microsoft 365',
            desc: 'In the Microsoft 365 admin centre, navigate to <code>Settings</code> &rarr; <code>Domains</code> &rarr; <code>Add domain</code>. Enter <code>' + sbcFqdn + '</code> as the domain.',
            image: ''
        },
        {
            title: 'Select Verification Method',
            desc: 'Choose your preferred verification method. In this example, we verify by adding a TXT record in DNS.',
            image: ''
        },
        {
            title: 'Collect Verification Data',
            desc: 'Note down the verification data provided by Microsoft &mdash; you will need this for the next step.',
            image: ''
        },
        {
            title: 'Add the TXT Record',
            desc: 'Insert the TXT record in your DNS using the data provided by Microsoft to verify domain ownership.',
            image: ''
        },
        {
            title: 'Configure Domain Use',
            desc: 'If the domain will only be used for voice calls, deselect <code>Exchange and Exchange Online Protection</code> during verification.',
            image: ''
        },
        {
            title: 'Add a User with the New Domain',
            desc: 'Go to <code>Users</code> &rarr; <code>Active users</code> &rarr; <code>Add a user</code> and assign them the newly verified domain.',
            image: ''
        },
        {
            title: 'Assign Licences',
            desc: 'Assign the required licences to the user &mdash; such as Phone Standard, Business Basic, or E3.',
            image: ''
        },
        {
            title: 'Connect to Teams PowerShell',
            desc: 'Install the Microsoft Teams PowerShell module and connect. Run these commands in PowerShell as Administrator:' +
                '<div class="tg-code"><pre>Install-Module -Name MicrosoftTeams -Force\nConnect-MicrosoftTeams</pre></div>' +
                '<div class="tg-note"><i class="fa-solid fa-circle-info"></i> Sign in with your Microsoft 365 admin credentials when prompted.</div>'
        },
        {
            title: 'Open Teams Admin Centre',
            desc: 'Navigate to the <code>Microsoft Teams admin center</code> &rarr; <code>Voice</code> &rarr; <code>Direct Routing</code>.',
            image: ''
        },
        {
            title: 'Manage PSTN Usage Records',
            desc: 'At the top-right of the page, select <code>Manage PSTN usage records</code> and add <code>sbc</code> as a new record.' +
                '<div class="tg-code-alt"><strong>PowerShell alternative:</strong><pre>Set-CsOnlinePstnUsage -Identity Global `\n  -Usage @{Add="GiantPSTN"}</pre></div>',
            image: ''
        },
        {
            title: 'Configure the SBC',
            desc: 'In <code>Voice</code> &rarr; <code>Direct Routing</code> &rarr; <code>SBCs</code>, click <code>Add</code>. Ensure both <code>Enabled</code> and <code>Send SIP options</code> are ticked.' +
                '<div class="tg-code-alt"><strong>PowerShell alternative:</strong><pre>New-CsOnlinePSTNGateway `\n  -Fqdn "' + sbcFqdn + '" `\n  -SipSignalingPort 5061 `\n  -MaxConcurrentSessions 10 `\n  -Enabled $true `\n  -MediaBypass $false `\n  -ForwardCallHistory $true `\n  -ForwardPai $true</pre></div>' +
                '<div class="tg-note"><i class="fa-solid fa-circle-info"></i> Adjust <code>MaxConcurrentSessions</code> based on your expected call volume. Contact us to increase capacity.</div>',
            image: ''
        },
        {
            title: 'Check Activation Status',
            desc: 'The domain will appear but remain inactive until the remaining configuration steps are completed.' +
                '<div class="tg-code-alt"><strong>Verify via PowerShell:</strong><pre>Get-CsOnlinePSTNGateway `\n  -Identity "' + sbcFqdn + '"</pre></div>' +
                '<div class="tg-note"><i class="fa-solid fa-clock"></i> It can take up to 15 minutes for the SBC pairing to become active.</div>',
            image: ''
        },
        {
            title: 'Create a Voice Route',
            desc: 'Go to <code>Voice</code> &rarr; <code>Direct Routing</code> &rarr; <code>Voice routes</code> &rarr; <code>Add</code>. Set the dialled number pattern regex, then add your SBC and the PSTN usage record you created earlier.' +
                '<div class="tg-code-alt"><strong>PowerShell alternative:</strong><pre>New-CsOnlineVoiceRoute `\n  -Identity "GiantRoute" `\n  -NumberPattern ".*" `\n  -OnlinePstnGatewayList "' + sbcFqdn + '" `\n  -OnlinePstnUsages "GiantPSTN" `\n  -Priority 1</pre></div>',
            image: ''
        },
        {
            title: 'Create a Voice Routing Policy',
            desc: 'Under <code>Voice</code> &rarr; <code>Voice routing policies</code>, click <code>Add</code> to create a new policy and attach your PSTN usage record.' +
                '<div class="tg-code-alt"><strong>PowerShell alternative:</strong><pre>New-CsOnlineVoiceRoutingPolicy `\n  -Identity "GiantDirectRouting" `\n  -OnlinePstnUsages "GiantPSTN"</pre></div>',
            image: ''
        },
        {
            title: 'Edit the User',
            desc: 'Navigate to <code>Users</code> &rarr; <code>Manage users</code> and select the user you added earlier.',
            image: ''
        },
        {
            title: 'Assign the Voice Routing Policy',
            desc: 'Go to <code>Policies</code> &rarr; <code>Voice routing policy</code> &rarr; <code>Edit</code> and apply the routing policy you created.' +
                '<div class="tg-code-alt"><strong>PowerShell alternative:</strong><pre>Grant-CsOnlineVoiceRoutingPolicy `\n  -Identity "user@yourdomain.co.uk" `\n  -PolicyName "GiantDirectRouting"</pre></div>',
            image: ''
        },
        {
            title: 'Update General Account Info',
            desc: 'Update the user\'s general account information under <code>Account</code> &rarr; <code>General information</code> &rarr; <code>Edit</code>.',
            image: ''
        },
        {
            title: 'Assign a Phone Number',
            desc: 'Set the <code>Phone number type</code> to <code>Direct Routing</code> and enter the phone number to assign to this user.' +
                '<div class="tg-code-alt"><strong>PowerShell alternative:</strong><pre>Set-CsPhoneNumberAssignment `\n  -Identity "user@yourdomain.co.uk" `\n  -PhoneNumber "+441234567890" `\n  -PhoneNumberType DirectRouting</pre></div>' +
                '<div class="tg-note"><i class="fa-solid fa-circle-info"></i> Replace with the actual user email and their assigned DID number in E.164 format.</div>',
            image: ''
        },
        {
            title: 'Configuration Complete',
            desc: '<div class="tg-completion">' +
                '<div class="tg-completion-icon"><i class="fas fa-check"></i></div>' +
                '<div class="tg-completion-body">' +
                '<strong>Your setup is ready.</strong><br>' +
                'Once the app is activated as the SBC, your users will be able to make and receive calls directly from Microsoft Teams.' +
                '</div></div>' +
                '<div class="tg-code-alt"><strong>Bulk assign routing policy to multiple users:</strong><pre>$users = @(\n  "user1@yourdomain.co.uk",\n  "user2@yourdomain.co.uk"\n)\nforeach ($user in $users) {\n  Grant-CsOnlineVoiceRoutingPolicy `\n    -Identity $user `\n    -PolicyName "GiantDirectRouting"\n}</pre></div>'
        }
    ];

    var totalSteps = steps.length;
    var html = '<div class="teams-guide">';

    /* ── Info tiles ── */
    html += '<div class="tg-info-grid">';
    html += '<div class="tg-info-tile"><div class="tg-info-label">Account Name</div><div class="tg-info-value">' + tenantName + '</div></div>';
    html += '<div class="tg-info-tile"><div class="tg-info-label">SBC FQDN</div><div class="tg-info-value">' + sbcFqdn + '</div></div>';
    html += '</div>';

    /* ── CTA ── */
    html += '<div class="tg-cta">';
    html += '<a href="#" target="_blank" class="tg-btn-giant"><i class="fas fa-external-link-alt"></i> Open the app Panel</a>';
    html += '</div>';

    /* ── Section header ── */
    html += '<div class="tg-section-header"><h3>Setup Guide</h3></div>';

    /* ── Progress bar ── */
    html += '<div class="tg-progress">';
    html += '<div class="tg-progress-bar" id="teamsGuideProgressBar"></div>';
    html += '<span class="tg-progress-text" id="teamsGuideProgressText">Step 1 of ' + totalSteps + '</span>';
    html += '</div>';

    /* ── Steps (one at a time) ── */
    html += '<div class="tg-steps" id="teamsGuideSteps">';
    steps.forEach(function(step, idx) {
        var num = String(idx + 1).padStart(2, '0');
        html += '<div class="tg-step' + (idx === 0 ? ' active' : '') + '" data-step="' + idx + '">';
        html += '<div class="tg-step-grid">';
        html += '<div class="tg-step-marker">' + num + '</div>';
        html += '<div class="tg-step-content">';
        html += '<div class="tg-step-title">' + step.title + '</div>';
        html += '<div class="tg-step-desc">' + step.desc + '</div>';
        if (step.image) {
            html += '<div class="tg-step-image"><img src="' + step.image + '" alt="' + step.title + '" loading="lazy"></div>';
        }
        html += '</div></div></div>';
    });
    html += '</div>';

    /* ── Navigation ── */
    html += '<div class="tg-nav">';
    html += '<button class="btn tg-nav-btn tg-nav-prev" id="teamsGuidePrev" disabled><i class="fa-solid fa-chevron-left"></i> Previous</button>';
    html += '<span class="tg-nav-step-label" id="tgNavLabel"></span>';
    html += '<button class="btn tg-nav-btn tg-nav-next" id="teamsGuideNext">Next <i class="fa-solid fa-chevron-right"></i></button>';
    html += '</div>';

    html += '</div>';

    $container.html(html);

    /* ── Navigation logic ── */
    var currentStep = 0;

    function updateNavLabel(idx) {
        $('#tgNavLabel').text(steps[idx].title);
    }

    function goToStep(idx) {
        if (idx < 0 || idx >= totalSteps) return;
        currentStep = idx;

        var $steps = $('#teamsGuideSteps .tg-step');
        $steps.removeClass('active');
        $steps.eq(idx).addClass('active');

        // Progress
        var pct = ((idx + 1) / totalSteps) * 100;
        $('#teamsGuideProgressBar').css('width', pct + '%');
        $('#teamsGuideProgressText').text('Step ' + (idx + 1) + ' of ' + totalSteps);

        // Buttons
        $('#teamsGuidePrev').prop('disabled', idx === 0);
        if (idx === totalSteps - 1) {
            $('#teamsGuideNext').html('<i class="fa-solid fa-check"></i> Done');
        } else {
            $('#teamsGuideNext').html('Next <i class="fa-solid fa-chevron-right"></i>').prop('disabled', false);
        }

        updateNavLabel(idx);

        // Scroll the step content to top (not the whole modal)
        var $scrollArea = $('#teamsGuideSteps');
        if ($scrollArea.length) {
            $scrollArea[0].scrollTop = 0;
        }
    }

    // Initial label
    updateNavLabel(0);

    $('#teamsGuideNext').on('click', function() {
        if (currentStep === totalSteps - 1) {
            $('#giantModal').modal('hide');
            return;
        }
        goToStep(currentStep + 1);
    });

    $('#teamsGuidePrev').on('click', function() {
        goToStep(currentStep - 1);
    });

    // Keyboard navigation
    $(document).off('keydown.teamsGuide').on('keydown.teamsGuide', function(e) {
        if (!$('#giantModal').is(':visible')) return;
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); goToStep(currentStep + 1); }
        if (e.key === 'ArrowLeft'  || e.key === 'ArrowUp')   { e.preventDefault(); goToStep(currentStep - 1); }
    });

    // Cleanup keyboard listener when modal closes
    $('#giantModal').off('hidden.bs.modal.teamsGuide').on('hidden.bs.modal.teamsGuide', function() {
        $(document).off('keydown.teamsGuide');
    });

    // Hide add button
    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').find('.giant-empty-state').remove();

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}
