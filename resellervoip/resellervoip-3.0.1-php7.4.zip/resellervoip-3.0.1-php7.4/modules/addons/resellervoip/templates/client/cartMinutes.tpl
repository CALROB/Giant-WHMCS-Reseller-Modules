<script>window.rvMinutesCfg = {ldelim}"groups": {$groups}, "seatsOptionId": {$seatsOptionId}, "numbersOptionId": {$numbersOptionId}{rdelim};</script>
{literal}
<style>
.rv-minutes { margin-top:16px; border:1px solid #e5e7eb; border-radius:12px; background:#fff; overflow:hidden; }
.rv-minutes-head { padding:12px 16px; border-bottom:1px solid #f3f4f6; font-weight:700; font-size:14px; display:flex; align-items:center; gap:8px; }
.rv-minutes-body { padding:12px 16px; display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:10px; }
.rv-minutes-card { border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px; }
.rv-minutes-card .l { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; color:#6b7280; }
.rv-minutes-card .v { font-size:20px; font-weight:800; color:#111827; }
.rv-minutes-card .d { font-size:11px; color:#6b7280; margin-top:2px; }
.rv-minutes-note { padding:0 16px 12px; font-size:12px; color:#6b7280; }
html.dark .rv-minutes, html.dark .rv-minutes-card { background:rgb(var(--surface-2, 30 41 59)); border-color:rgb(var(--border, 51 65 85)); color:rgb(var(--text, 226 232 240)); }
html.dark .rv-minutes-card .v { color:rgb(var(--text, 226 232 240)); }
</style>
<script>
(function () {
    if (typeof jQuery === 'undefined' || !window.rvMinutesCfg) { return; }
    var cfg = window.rvMinutesCfg;
    var groups = cfg.groups || [];
    if (!groups.length) { return; }

    function esc(s) { return jQuery('<i>').text(s == null ? '' : s).html(); }

    function units(basis) {
        var id = basis === 'numbers' ? cfg.numbersOptionId : (basis === 'none' ? 0 : cfg.seatsOptionId);
        if (!id) { return 1; }
        var $el = jQuery('[name="configoption[' + id + ']"]');
        if (!$el.length) { return 1; }
        var v = $el.is('select') ? ($el.find('option:selected').text().match(/\d+/) || [1])[0] : $el.val();
        v = parseInt(v, 10);
        return isNaN(v) || v < 1 ? 1 : v;
    }

    function render() {
        var html = '';
        groups.forEach(function (g) {
            var u = units(g.basis);
            var total = g.perUnit * u;
            var per = g.basis === 'none' ? '' : (g.perUnit + ' min per ' + (g.basis === 'numbers' ? 'number' : 'user') + (u > 1 ? ' × ' + u : ''));
            html += '<div class="rv-minutes-card"><div class="l">' + esc(g.label) + '</div>' +
                    '<div class="v">' + total.toLocaleString() + ' min</div>' +
                    '<div class="d">' + per + (g.prefixes ? (per ? ' · ' : '') + 'to ' + esc(g.prefixes) : '') + '</div></div>';
        });
        jQuery('#rvMinutesBody').html(html);
    }

    function place() {
        if (jQuery('#rvMinutes').length) { return true; }
        var $anchor = jQuery('#productConfigurableOptions');
        if (!$anchor.length) { return false; }
        $anchor.after('<div class="rv-minutes" id="rvMinutes"><div class="rv-minutes-head"><i class="fa fa-phone"></i> Inclusive minutes with this plan</div>' +
            '<div class="rv-minutes-body" id="rvMinutesBody"></div><div class="rv-minutes-note">Per billing period. Calls beyond the allowance are charged at standard rates.</div></div>');
        render();
        return true;
    }

    jQuery(function () {
        if (!place()) {
            var n = 0, t = setInterval(function () { if (place() || ++n > 20) { clearInterval(t); } }, 150);
        }
        jQuery(document).on('change keyup', '[name^="configoption["]', render);
    });
})();
</script>
{/literal}
