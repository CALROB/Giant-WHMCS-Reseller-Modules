$('#giantModalAddForm').off('submit');
$('#giantModalAddForm').on('submit', function (event) {

    $('.giantModalPanel').hide();
    $('#giantModalSpinnerDiv').show();

    event.preventDefault();
    $.ajax({
        type: 'post',
        data: $(this).serialize(),
        success: function (responseJson) {
            var response = jQuery.parseJSON(responseJson);

            if (response.error) {
                $('#giantModalAlertDiv').show();
                $('#giantModalAlert').html(response.error);
            }
            refreshList("voiceCloud");

            // Offer the new main user's login QR immediately (create → scan). The
            // password was stored on create, so the QR renders without a reset.
            if (!response.error && response.primaryUserId && typeof openVcQrOverlay === 'function') {
                openVcQrOverlay(response.primaryUserId, response.userName || 'this user');
            }
        }
    });
});

// Live "X selected" badge on the extensions section.
function giantVcUpdateExtCount() {
    var n = $('#giantModalAddForm .extensionsInput:checked').length;
    $('#giantVcExtCount').text(n + ' selected').toggleClass('is-active', n > 0);
}

// Exactly one selected extension is the "main app user"; the rest are attached
// to it. Keep #primaryExtensionInput pointing at a currently-checked tile
// (defaulting to the first checked) and reflect main/attached state on the tiles.
function giantVcSyncMain() {
    var ids = $('#giantModalAddForm .extensionsInput:checked').map(function () {
        return String($(this).val());
    }).get();

    var current = String($('#primaryExtensionInput').val() || '');
    if (ids.indexOf(current) === -1) {
        current = ids.length ? ids[0] : '';
        $('#primaryExtensionInput').val(current);
    }

    $('#giantModalAddForm .giant-vc-ext-tile').each(function () {
        var $tile   = $(this);
        var id      = String($tile.find('.extensionsInput').val());
        var checked = $tile.find('.extensionsInput').is(':checked');
        var isMain  = checked && id === current;
        $tile.toggleClass('is-main', isMain);
        $tile.toggleClass('is-attached', checked && !isMain);
        $tile.find('.giant-vc-ext-main-btn').attr('title', isMain ? 'Main app user' : 'Make this the main app user');
        $tile.find('.giant-vc-ext-main-txt').text(isMain ? 'Main' : 'Make main');
    });
}

$(document).off('change.giantVcExtCount', '#giantModalAddForm .extensionsInput');
$(document).on('change.giantVcExtCount', '#giantModalAddForm .extensionsInput', function () {
    if ($(this).is(':checked')) $('#extensionsError').hide();
    giantVcUpdateExtCount();
    giantVcSyncMain();
});

// Star a tile as the main user. The click must NOT bubble to the <label> (that
// would toggle the checkbox off), and starring a tile auto-includes it.
$(document).off('click.giantVcMain', '#giantModalAddForm .giant-vc-ext-main-btn');
$(document).on('click.giantVcMain', '#giantModalAddForm .giant-vc-ext-main-btn', function (event) {
    event.preventDefault();
    event.stopPropagation();
    var id  = String($(this).data('ex-id'));
    var $cb = $('#extensionsInput' + id);
    if (!$cb.prop('checked')) { $cb.prop('checked', true); }
    $('#primaryExtensionInput').val(id);
    $('#extensionsError').hide();
    giantVcUpdateExtCount();
    giantVcSyncMain();
});

giantVcUpdateExtCount();
giantVcSyncMain();

$('#nextButton').on('click', function (event) {
    event.preventDefault();

    var ok = true;

    if (!$('#fullNameInput').val().trim()) { $('#fullNameInput').addClass('is-invalid'); ok = false; }
    else { $('#fullNameInput').removeClass('is-invalid'); }

    var emailVal = $('#emailInput').val().trim();
    if (!emailVal || emailVal.indexOf('@') === -1) { $('#emailInput').addClass('is-invalid'); ok = false; }
    else { $('#emailInput').removeClass('is-invalid'); }

    if (!$('#mobileInput').val().trim()) { $('#mobileInput').addClass('is-invalid'); ok = false; }
    else { $('#mobileInput').removeClass('is-invalid'); }

    if (!$('.extensionsInput:checked').length) {
        $('#extensionsError').show();
        ok = false;
    } else {
        $('#extensionsError').hide();
    }

    if (!ok) return false;

    $('#summaryName').text($('#fullNameInput').val());
    $('#summaryEmail').text($('#emailInput').val());

    var primaryId = String($('#primaryExtensionInput').val() || '');
    var $sx = $('#summaryExtensions').empty();
    // Main user first, then the attached extensions.
    var $checked = $('.extensionsInput:checked').toArray().sort(function (a, b) {
        return (String($(a).val()) === primaryId ? -1 : 0) - (String($(b).val()) === primaryId ? -1 : 0);
    });
    $checked.forEach(function (el) {
        var $el = $(el);
        var id = String($el.val());
        var label = String($el.data('number') || '');
        var isMain = id === primaryId;
        var $chip = $('<span class="giant-vc-summary-chip"></span>');
        if (isMain) $chip.addClass('is-main');
        $chip.append('<i class="fa-solid ' + (isMain ? 'fa-star' : 'fa-link') + '"></i>');
        $chip.append(document.createTextNode(' ' + label + (isMain ? ' — main user' : '')));
        $sx.append($chip);
    });

    $('#page1').hide();
    $('#page2').show();
});

$('#prevButton').on('click', function (event) {
    event.preventDefault();
    $('#page2').hide();
    $('#page1').show();
});
