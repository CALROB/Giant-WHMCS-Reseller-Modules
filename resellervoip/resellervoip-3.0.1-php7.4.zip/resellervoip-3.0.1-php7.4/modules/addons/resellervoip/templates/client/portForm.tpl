<style>
    /* Branded port-date picker (flatpickr), scoped to this form's instance. */
    .flatpickr-calendar.giant-port-fp {
        border-radius: 12px;
        box-shadow: 0 22px 48px -22px rgba(5, 59, 48, .4);
        border: 1px solid #d9efe6;
    }
    .flatpickr-calendar.giant-port-fp .flatpickr-months .flatpickr-month,
    .flatpickr-calendar.giant-port-fp .flatpickr-current-month,
    .flatpickr-calendar.giant-port-fp .flatpickr-current-month input.cur-year,
    .flatpickr-calendar.giant-port-fp .flatpickr-monthDropdown-months { color: #053b30; font-weight: 700; }
    .flatpickr-calendar.giant-port-fp .flatpickr-months .flatpickr-prev-month svg,
    .flatpickr-calendar.giant-port-fp .flatpickr-months .flatpickr-next-month svg { fill: #0a7d63; }
    .flatpickr-calendar.giant-port-fp .flatpickr-months .flatpickr-prev-month:hover svg,
    .flatpickr-calendar.giant-port-fp .flatpickr-months .flatpickr-next-month:hover svg { fill: #00d9a7; }
    .flatpickr-calendar.giant-port-fp span.flatpickr-weekday { color: #0a7d63; font-weight: 600; }
    .flatpickr-calendar.giant-port-fp .flatpickr-day {
        border-radius: 9px; color: #0f172a; font-weight: 500;
    }
    .flatpickr-calendar.giant-port-fp .flatpickr-day:hover,
    .flatpickr-calendar.giant-port-fp .flatpickr-day:focus { background: #eafaf5; border-color: #eafaf5; }
    .flatpickr-calendar.giant-port-fp .flatpickr-day.today { border-color: #00d9a7; }
    .flatpickr-calendar.giant-port-fp .flatpickr-day.today:hover { background: #00d9a7; color: #04231c; }
    .flatpickr-calendar.giant-port-fp .flatpickr-day.selected,
    .flatpickr-calendar.giant-port-fp .flatpickr-day.selected:hover,
    .flatpickr-calendar.giant-port-fp .flatpickr-day.selected:focus {
        background: #00d9a7; border-color: #00d9a7; color: #04231c; font-weight: 700;
    }
    .flatpickr-calendar.giant-port-fp .flatpickr-day.flatpickr-disabled,
    .flatpickr-calendar.giant-port-fp .flatpickr-day.flatpickr-disabled:hover {
        color: #cbd5e1; text-decoration: line-through; background: transparent; cursor: not-allowed;
    }
    .flatpickr-calendar.giant-port-fp .flatpickr-day.prevMonthDay,
    .flatpickr-calendar.giant-port-fp .flatpickr-day.nextMonthDay { color: #b8c4c0; }

    /* CUPID pill shown beside each losing-provider name in the LCP picker. */
    .giant-lcp-opt { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
    .giant-lcp-opt .giant-lcp-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .giant-cupid-pill {
        flex: 0 0 auto;
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
        font-size: 11px; font-weight: 700; line-height: 1; letter-spacing: .02em;
        color: #0a7d63; background: rgba(0, 217, 167, .12);
        border: 1px solid rgba(0, 217, 167, .35);
        border-radius: 999px; padding: 3px 8px;
    }

    /* ===== Guided multi-step port form ===== */
    .giant-port-form { max-width: 720px; margin: 0 auto; }

    /* Progress stepper */
    .giant-stepper { display: flex; align-items: flex-start; margin: 2px 0 28px; }
    .giant-step { flex: 1 1 0; position: relative; text-align: center; min-width: 0; cursor: default; }
    .giant-step::before {
        content: ""; position: absolute; top: 17px; right: 50%; width: 100%; height: 2px;
        background: #dbe7e2; z-index: 0;
    }
    .giant-step:first-child::before { display: none; }
    .giant-step.is-active::before, .giant-step.is-done::before { background: #00d9a7; }
    .giant-step-num {
        position: relative; z-index: 1; display: flex; align-items: center; justify-content: center;
        width: 36px; height: 36px; margin: 0 auto 8px; border-radius: 50%;
        background: #fff; border: 2px solid #dbe7e2; color: #7c918b;
        font-weight: 700; font-size: 14px; transition: all .2s ease;
    }
    .giant-step-label { font-size: 12px; font-weight: 600; color: #7c918b; padding: 0 4px; }
    .giant-step.is-active .giant-step-num { border-color: #00d9a7; color: #053b30; box-shadow: 0 0 0 4px rgba(0,217,167,.15); }
    .giant-step.is-active .giant-step-label { color: #053b30; }
    .giant-step.is-done { cursor: pointer; }
    .giant-step.is-done .giant-step-num { background: #00d9a7; border-color: #00d9a7; color: #04231c; }
    .giant-step.is-done .giant-step-label { color: #0a7d63; }

    /* Panel fade between steps */
    .giant-port-form .formPage { animation: giantPortFade .25s ease; }
    @keyframes giantPortFade { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }

    /* Headings + fields */
    .giant-port-form h4 { font-size: 17px; font-weight: 700; color: #053b30; margin: 0 0 4px; }
    .giant-port-form .col-form-label {
        display: block; text-transform: none; letter-spacing: 0; font-family: inherit;
        font-size: 13px; font-weight: 600; color: #26433b; margin: 14px 0 6px;
    }
    .giant-port-form .form-control {
        border-radius: 10px; border: 1.5px solid #dbe7e2; padding: 10px 13px; height: auto;
        font-size: 14px; color: #0f172a; box-shadow: none;
        transition: border-color .15s ease, box-shadow .15s ease;
    }
    .giant-port-form .form-control:focus {
        border-color: #00d9a7; box-shadow: 0 0 0 3px rgba(0,217,167,.18); outline: none;
    }
    .giant-port-form .form-text { font-size: 12px; color: #7c918b; margin-top: 5px; line-height: 1.5; }
    .giant-port-form .form-control.is-invalid { border-color: #e5484d; box-shadow: 0 0 0 3px rgba(229,72,77,.15); }

    /* +44 prefix + input-group corners — seamless join (no gap, no double radius) */
    .giant-port-form .input-group { flex-wrap: nowrap; align-items: stretch; }
    .giant-port-form .input-group-prepend { margin: 0; }
    .giant-port-form .input-group-text {
        display: flex; align-items: center;
        border: 1.5px solid #dbe7e2 !important; border-right: 0 !important;
        border-radius: 10px 0 0 10px !important;
        background: #f2f8f6; color: #0a7d63; font-weight: 700; font-size: 14px;
        padding: 10px 14px; margin: 0;
    }
    /* input sitting AFTER the +44 prefix: no left border, square left, rounded right */
    .giant-port-form .input-group-prepend + .form-control {
        border-left: 0 !important; margin-left: 0 !important;
        border-radius: 0 10px 10px 0 !important;
    }
    /* input sitting BEFORE an append button (e.g. port date): rounded left, square right */
    .giant-port-form .input-group > .form-control:first-child {
        border-radius: 10px 0 0 10px !important;
    }
    .giant-port-form .input-group-append { margin: 0; }
    .giant-port-form .input-group-append .btn { border-radius: 0 10px 10px 0 !important; border-left: 0; }

    /* Signature pad — responsive */
    .giant-port-form #signatureDiv { width: 100% !important; max-width: 100%; border-radius: 10px; border-color: #dbe7e2 !important; }

    /* Nav bar */
    .giant-port-form .giant-port-nav {
        display: flex; justify-content: space-between; align-items: center; gap: 10px;
        margin-top: 26px; padding-top: 18px; border-top: 1px solid #eef4f1;
    }
    .giant-port-form .giant-port-nav .btn { margin: 0; }
    .giant-port-form .giant-port-nav-right { display: flex; gap: 8px; margin-left: auto; }

    /* E-signature: Draw / Type modes */
    .giant-sig-tabs { display: inline-flex; margin-bottom: 10px; border: 1.5px solid #dbe7e2; border-radius: 9px; overflow: hidden; }
    .giant-sig-tab { background: #fff; border: 0; padding: 7px 16px; font-size: 13px; font-weight: 600; color: #26433b; cursor: pointer; }
    .giant-sig-tab + .giant-sig-tab { border-left: 1.5px solid #dbe7e2; }
    .giant-sig-tab.is-active { background: #00d9a7; color: #04231c; }
    .giant-sig-tab i { margin-right: 6px; }
    .giant-sig-preview {
        min-height: 84px; display: flex; align-items: center; justify-content: center;
        font-size: 46px; color: #0f172a; border: 1.5px dashed #dbe7e2; border-radius: 10px;
        margin-top: 10px; padding: 6px 14px; overflow: hidden; line-height: 1.1;
    }
    .giant-sig-preview:empty::before { content: "Your signature preview"; color: #b8c9c3; font-size: 15px; font-family: inherit; }
    .giant-sig-fonts { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 8px; }
    .giant-sig-font { background: #fff; border: 1.5px solid #dbe7e2; border-radius: 9px; padding: 4px 18px; font-size: 24px; line-height: 1.3; color: #26433b; cursor: pointer; }
    .giant-sig-font.is-active { border-color: #00d9a7; box-shadow: 0 0 0 3px rgba(0,217,167,.15); }

    /* Port cost badges (per-port hint on step 1, total on the final step) */
    .giant-cost-hint, .giant-cost-summary {
        margin-top: 14px; padding: 12px 16px; border-radius: 10px;
        background: rgba(0,217,167,.08); border: 1.5px solid rgba(0,217,167,.3);
        color: #0a5f4c; font-size: 14px; display: flex; align-items: center; gap: 10px;
    }
    .giant-cost-summary { font-size: 15px; margin-top: 20px; }
    .giant-cost-hint i, .giant-cost-summary i { color: #00d9a7; font-size: 16px; }
    .giant-cost-hint b, .giant-cost-summary b { color: #053b30; }

    /* The Letter of Authorisation declaration — the customer agrees to it before signing */
    .giant-cloa-box { margin-top: 8px; padding: 14px 16px; border-radius: 10px; background: #f6faf8; border: 1.5px solid #dbe7e2; }
    .giant-cloa-box p { margin: 0 0 8px; font-size: 13px; line-height: 1.55; color: #26433b; }
    .giant-cloa-box p:last-of-type { margin-bottom: 0; }
    .giant-cloa-agree { display: flex; align-items: flex-start; gap: 10px; margin-top: 12px; padding-top: 12px; border-top: 1px solid #dbe7e2; cursor: pointer; }
    .giant-cloa-agree input { margin: 3px 0 0; width: 16px; height: 16px; flex: 0 0 16px; accent-color: #00d9a7; cursor: pointer; }
    .giant-cloa-agree span { font-size: 13.5px; font-weight: 600; color: #053b30; line-height: 1.45; }
    .giant-cloa-box.is-invalid { border-color: #d9534f; box-shadow: 0 0 0 3px rgba(217,83,79,.12); }
    .giant-cloa-error { display: none; margin-top: 8px; font-size: 12.5px; font-weight: 600; color: #b4232a; }
    .giant-cloa-box.is-invalid .giant-cloa-error { display: block; }

    /* ===== Dark theme (the site theme's tokens; fallbacks are its dark values) =====
       This block lives with the form, not in index.css, so the stylesheet sweep
       (tools/dark-sweep.py) never sees it: keep its dark rules here, in step
       with the light ones above. */
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp {
        background: rgb(var(--surface-2, 30 41 59)); border-color: rgb(var(--border, 51 65 85));
        box-shadow: 0 22px 48px -22px rgba(0, 0, 0, .7);
    }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp.arrowTop::before,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp.arrowTop::after { border-bottom-color: rgb(var(--surface-2, 30 41 59)); }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp.arrowBottom::before,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp.arrowBottom::after { border-top-color: rgb(var(--surface-2, 30 41 59)); }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-months .flatpickr-month,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-current-month,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-current-month input.cur-year,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-monthDropdown-months { color: rgb(var(--text, 226 232 240)); background: transparent; }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-months .flatpickr-prev-month svg,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-months .flatpickr-next-month svg { fill: rgb(var(--accent, 0 217 167)); }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp span.flatpickr-weekday { color: rgb(var(--accent, 0 217 167)); }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day { color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day:hover,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day:focus { background-color: rgb(var(--accent, 0 217 167) / .18); border-color: transparent; }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day.today { border-color: rgb(var(--accent, 0 217 167)); }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day.flatpickr-disabled,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day.flatpickr-disabled:hover { color: rgb(var(--muted, 148 163 184) / .5); }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day.prevMonthDay,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day.nextMonthDay { color: rgb(var(--muted, 148 163 184) / .7); }
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day.today:hover,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day.selected,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day.selected:hover,
    html.dark body.gv-body .flatpickr-calendar.giant-port-fp .flatpickr-day.selected:focus { background-color: rgb(var(--accent, 0 217 167)); border-color: rgb(var(--accent, 0 217 167)); color: #04231c; }
    html.dark body.gv-body .giant-cupid-pill { color: rgb(var(--accent, 0 217 167)); }

    /* Stepper */
    html.dark body.gv-body .giant-step::before { background-color: rgb(var(--border, 51 65 85)); }
    html.dark body.gv-body .giant-step.is-active::before,
    html.dark body.gv-body .giant-step.is-done::before { background-color: rgb(var(--accent, 0 217 167)); }
    html.dark body.gv-body .giant-step-num { background-color: rgb(var(--surface-2, 30 41 59)); border-color: rgb(var(--border, 51 65 85)); color: rgb(var(--muted, 148 163 184)); }
    html.dark body.gv-body .giant-step-label { color: rgb(var(--muted, 148 163 184)); }
    html.dark body.gv-body .giant-step.is-active .giant-step-num { border-color: rgb(var(--accent, 0 217 167)); color: rgb(var(--accent, 0 217 167)); box-shadow: 0 0 0 4px rgb(var(--accent, 0 217 167) / .18); }
    html.dark body.gv-body .giant-step.is-active .giant-step-label { color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .giant-step.is-done .giant-step-label { color: rgb(var(--accent, 0 217 167)); }
    html.dark body.gv-body .giant-step.is-done .giant-step-num { background-color: rgb(var(--accent, 0 217 167)); border-color: rgb(var(--accent, 0 217 167)); color: #04231c; }

    /* Headings + fields */
    html.dark body.gv-body .giant-port-form h4 { color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .giant-port-form .col-form-label { color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .giant-port-form .form-control { background-color: rgb(var(--surface-2, 30 41 59)); border-color: rgb(var(--border, 51 65 85)); color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .giant-port-form .form-control:focus { border-color: rgb(var(--accent, 0 217 167)); box-shadow: 0 0 0 3px rgb(var(--accent, 0 217 167) / .22); }
    html.dark body.gv-body .giant-port-form .form-text { color: rgb(var(--muted, 148 163 184)); }
    html.dark body.gv-body .giant-port-form .input-group-text { background-color: rgb(var(--surface, 15 23 42)); border-color: rgb(var(--border, 51 65 85)) !important; color: rgb(var(--accent, 0 217 167)); }
    html.dark body.gv-body .giant-port-form .giant-port-nav { border-top-color: rgb(var(--border, 51 65 85)); }
    /* The drawn-signature pad stays white: the ink is black and ends up on a white letter. */
    html.dark body.gv-body .giant-port-form #signatureDiv { background: #fff; border-color: rgb(var(--border, 51 65 85)) !important; }

    /* E-signature modes (the typed preview is only a preview; the image is drawn with fixed ink) */
    html.dark body.gv-body .giant-sig-tabs { border-color: rgb(var(--border, 51 65 85)); }
    html.dark body.gv-body .giant-sig-tab { background-color: rgb(var(--surface-2, 30 41 59)); color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .giant-sig-tab + .giant-sig-tab { border-left-color: rgb(var(--border, 51 65 85)); }
    html.dark body.gv-body .giant-sig-tab.is-active { background-color: rgb(var(--accent, 0 217 167)); color: #04231c; }
    html.dark body.gv-body .giant-sig-preview { color: rgb(var(--text, 226 232 240)); border-color: rgb(var(--border, 51 65 85)); }
    html.dark body.gv-body .giant-sig-preview:empty::before { color: rgb(var(--muted, 148 163 184) / .7); }
    html.dark body.gv-body .giant-sig-font { background-color: rgb(var(--surface-2, 30 41 59)); border-color: rgb(var(--border, 51 65 85)); color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .giant-sig-font.is-active { border-color: rgb(var(--accent, 0 217 167)); }

    /* Cost badges */
    html.dark body.gv-body .giant-cost-hint,
    html.dark body.gv-body .giant-cost-summary { background-color: rgb(var(--accent, 0 217 167) / .1); border-color: rgb(var(--accent, 0 217 167) / .35); color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .giant-cost-hint b,
    html.dark body.gv-body .giant-cost-summary b { color: rgb(var(--accent, 0 217 167)); }

    /* Declaration */
    html.dark body.gv-body .giant-cloa-box { background-color: rgb(var(--surface-2, 30 41 59)); border-color: rgb(var(--border, 51 65 85)); }
    html.dark body.gv-body .giant-cloa-box p { color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .giant-cloa-agree { border-top-color: rgb(var(--border, 51 65 85)); }
    html.dark body.gv-body .giant-cloa-agree span { color: rgb(var(--text, 226 232 240)); }
    html.dark body.gv-body .giant-cloa-error { color: #f87171; }
</style>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@600&family=Dancing+Script:wght@600&family=Sacramento&display=swap" rel="stylesheet">

<form id="giantModalAddForm" class="modalForm giant-port-form" method="post" style="max-width: 752px;">
    <input type="hidden" class="form-control" name="pbxAction" value="addPort">
    <input type="hidden" id="currentRhInput" class="form-control" name="currentRh" value="">
    <input type="hidden" id="rhModeInput" class="form-control" name="rhMode" value="">

    {if $defaultValues}
        <input type="hidden" id="origRefInput" class="form-control" name="origRef" value="{$defaultValues.ref}">
    {/if}

    <!-- Progress stepper -->
    <div class="giant-stepper">
        <div class="giant-step is-active" data-step="1"><div class="giant-step-num">1</div><div class="giant-step-label">Number</div></div>
        <div class="giant-step" data-step="2"><div class="giant-step-num">2</div><div class="giant-step-label">Line details</div></div>
        <div class="giant-step" data-step="3"><div class="giant-step-num">3</div><div class="giant-step-label">Your details</div></div>
        <div class="giant-step" data-step="4"><div class="giant-step-num">4</div><div class="giant-step-label">Address &amp; sign</div></div>
    </div>


    <!-- PAGE 1 -->
    
    <div id="formPage1" class="formPage">
    <div class="row">
	<div class="col-md-12">
	<h4>Check Service Availability (MBN)</h4>
	<small class="form-text text-muted">This is usually the number that appears on the end-users phone bill. You will need to specify if the main billing number is to be ported or if it’s just to be used as a reference. If the main billing number is to be ported, it is essential that the end-user is aware that it will result in the termination of their existing service, including any associated services such as Broadband. If there are any associated numbers on the line, these must either be ported or ceased at the same time.</small>
	</div>
	</div> 
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="col-form-label">MBN:</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">+44</span>
                        </div>
                        <input type="text" class="form-control" id="mbnInput" name="mbn" value="{$defaultValues.mbn}">
                    </div>
                    <small class="form-text text-muted">Please enter your MBN (Main Billing Number)</small>
                </div>
            </div>        
        </div>  
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="col-form-label">LCP Account Number (e.g BT000001):</label>
                    <input type="text" class="form-control" id="accountNumberInput" name="account_number" value="{$defaultValues.account_number}">
                    <small class="form-text text-muted">This can usually be found on your phone bill from your current provider.</small>
                </div>
            </div>        
        </div>   

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <button id="checkPortabilityButton"  class="btn btn-primary">Check portability</button>
                    <div id="portCostHint" class="giant-cost-hint" style="display:none;"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div id = "lcpInfo0Div" class="lcpInfoDiv" style="display:none;">
                    <div class="alert alert-warning" role="alert">
                        The portability of this number cannot be determined.
                    </div>
                </div>
                <div id = "lcpInfo1Div" class="lcpInfoDiv" style="display:none;">
                    <p>The range holder for this number is <span class="currentLcpP"></span>. Is the Current Provider also <span class="currentLcpP"></span>?</p>
                </div>
                <div id = "lcpInfo2Div" class="lcpInfoDiv" style="display:none;">
                    <p>
                        The Range Holder (RH) for this number is <span class="currentLcpP"></span>, with whom we have no porting
                        agreement and therefore cannot on the face of it port it.<br>
                        It may be that <span class="currentLcpP"></span> has delegated porting to one of these and that we *might*
                        be able to port it. You can proceed by selecting the appropriate LCP below if you know
                        this to be case but as porting submissions are chargeable, we strongly recommend you
                        check with the current provider/reseller who the host network is and whether they will
                        accept a porting request from us for this number.
                        You should also consider whether the number is already ported away from <span class="currentLcpP"></span>
                        in which case we need an agreement as above *and* an agreement with the current LCP
                    </p>
                </div>
                <div id = "lcpDiv" style="display:none;">
                    <div id="lcpConfirmDiv" class="row">
                        <div class="col-md-6">
                            <button id="lcpCorrectButton" class="btn btn-primary">Yes, that’s correct.</button>
                        </div>
                        <div class="col-md-6">
                            <button id="lcpElseButton" class="btn btn-primary">No, it’s something else.</button>
                        </div>
                    </div>
                    <div id="lcpChosenDiv" style="display:none; margin-bottom:8px;">
                        <p id="lcpChosenText" style="margin:0 0 2px; font-size:14px;"></p>
                        <a href="#" id="lcpChangeLink" style="font-size:12px; font-weight:600; color:rgb(var(--accent));"><i class="fa-solid fa-rotate-left" style="margin-right:4px;"></i>Change answer</a>
                    </div>
                    <div id = "lcpSelectDiv" style="display:none;">
                        <div class="form-group">
                            <label class="col-form-label">Losing Communications Provider (e.g. “BT”):</label>
                            <select class="form-control" id="lcpCupidSelect" name="lcp_cupid" value="">
                                {foreach from=$lcpOptions key=value item=display}
                                    <option value="{$value}">{$display}</option>
                                {/foreach}
                            </select>
                            <small class="form-text text-muted">Start typing to search, then pick the provider your number is currently with &mdash; the number in the pill is their industry provider ID (CUPID). If your number was previously ported, choose the provider you pay today, not the original network.</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                            
    <!-- PAGE 2 -->
                            
    <div id="formPage2" class="formPage">
	<div class="row">
	<div class="col-md-12">
	<h4>Current Installation Verification</h4>
	<small class="form-text text-muted">Please specify what the current number installation looks like. Each port will be one of the following types, if unsure please contact the LCP before submission. Subsequent ports must be used where the number is already ported (i.e. the LCP is not the rangeholder)</small>
	</div>
	</div>
	{*
        <div class="row">
            <div class="col-md-4">
                <label class="col-form-label">Type:</label>
                <select class="form-control" id="typeSelect" name="type" value="">
                    <option {if $defaultValues.type eq "single"}selected{/if} value="single">Single</option>
                    <option {if $defaultValues.type eq "multi"}selected{/if} value="multi">Multi</option>
                    <option {if $defaultValues.type eq "sub_single"}selected{/if} value="sub_single">Sub Single</option>
                    <option {if $defaultValues.type eq "sub_multi"}selected{/if} value="sub_multi">Sub Multi</option>
                </select>
                <small class="form-text text-muted">Please select which port-type is to be used for this number port.</small>
            </div>
			
			*}
			
        <div class="row">
            <div class="col-md-12">
                <label class="col-form-label">Type:</label>
                <select class="form-control" id="typeSelect" name="type" value="">
                    <option {if $defaultValues.type eq "single"}selected{/if} value="single">
                        Single Line - 4 Working Days (14 if &gt; 10 lines porting in same installation/time)
                    </option>
                    <option {if $defaultValues.type eq "multi"}selected{/if} value="multi">
                        Multi Line - 7-17 Working Days (dependant on number of lines/numbers)
                    </option>
                    <option {if $defaultValues.type eq "sub_single"}selected{/if} value="sub_single">
                        Sub Single - Single Line - 7 Working Days (17 if &gt; 10 lines porting in same installation/time)
                    </option>
                    <option {if $defaultValues.type eq "sub_multi"}selected{/if} value="sub_multi">
                        Sub Multi - Multi Line - 10-25 Working Days (dependant on number of lines/numbers)
                    </option>
                </select>
                <small class="form-text text-muted">
                    Please select which port-type is to be used for this number port.
                </small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label class="col-form-label">Lines:</label>
                <input type="text" class="form-control" id="linesInput" name="lines" value="{if $defaultValues.lines}{$defaultValues.lines}{else}1{/if}">
                <small class="form-text text-muted">The total number of lines that the end-user currently has from the LCP.</small>
            </div>
            <div class="col-md-6">
                <label class="col-form-label">Channels:</label>
                <input type="text" class="form-control" id="channelsInput" name="channels" value="{if $defaultValues.channels}{$defaultValues.channels}{else}1{/if}">
                <small class="form-text text-muted">The total number of channels that the end-user currently has from the LCP. Minimum = 1.</small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="col-form-label">MBN:</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">+44</span>
                        </div>
                        <input type="text" class="form-control" id="mbnShowInput" name="mbnShow" value="" disabled="disabled">
                    </div>
                    <small class="form-text text-muted">This is your MBN (Main Billing Number) for this number port submission.</small>
                </div>
            </div>
        </div>

        {foreach from=$defaultValues.numberNumber key=index item=value}
            <div class="row align-items-end">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="col-form-label">Number:</label>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon1">+44</span>
                            </div>
                            <input type="text" class="form-control" name="numberNumber[]" value="{$value}"></div>
                    </div></div><div class="col-md-3">
                    <div class="form-group">
                        <label class="col-form-label">Action:</label>
                        <select type="text" class="form-control" name="numberAction[]">
                            <option {if $defaultValues.numberAction[$index] eq "port"}selected{/if} value="port">Port</option>
                            <option {if $defaultValues.numberAction[$index] eq "retain"}selected{/if} value="retain">Retain</option>
                            <option {if $defaultValues.numberAction[$index] eq "drop"}selected{/if} value="drop">Drop</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="col-form-label">Type:</label>
                        <select type="text" class="form-control" name="numberType[]">
                            <option {if $defaultValues.numberType[$index] eq "other"}selected{/if} value="other">Other</option>
                            <option {if $defaultValues.numberType[$index] eq "associated"}selected{/if} value="associated">Associated</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2 align-bottom">
                    <div class="form-group">
                        <button class="removeNumberButton btn btn-danger">-</button>
                    </div>
                </div>
            </div>
        {/foreach}
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <button id="addNumberButton" class="btn btn-success">Add Number</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- PAGE 3 -->
    
    <div id="formPage3" class="formPage">
	<div class="row">
	<div class="col-md-12">
	<div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-bottom:6px;">
	<h4 style="margin:0;">Personal Information</h4>
	{if $accountAddress && ($accountAddress.firstname || $accountAddress.lastname)}
	<button type="button" id="autofillPersonalBtn" class="btn btn-primary" style="padding:6px 14px; font-size:12px; margin:0;">
	<i class="fa-duotone fa-id-card" style="--fa-primary-color: rgb(var(--accent-contrast)); --fa-secondary-color: rgb(var(--accent-contrast)); margin-bottom:0;"></i> Use my account details
	</button>
	{/if}
	</div>
	<small class="form-text text-muted">Please provide the End-user's personal information.</small>
	{if $accountAddress}<script type="application/json" id="giantAccountAddressJson">{json_encode($accountAddress)}</script>{/if}
	</div>
	</div>
        <div class="row">
            <div class="col-md-6">
                <label class="col-form-label">Title:</label>
                <select class="form-control" id="titleSelect" name="title" value="">
                    <option {if $defaultValues.title eq "Mr"}selected{/if} value="Mr">Mr</option>
                    <option {if $defaultValues.title eq "Mrs"}selected{/if} value="Mrs">Mrs</option>
                    <option {if $defaultValues.title eq "Miss"}selected{/if} value="Miss">Miss</option>
                    <option {if $defaultValues.title eq "Ms"}selected{/if} value="Ms">Ms</option>
                    <option {if $defaultValues.title eq "Doctor"}selected{/if} value="Doctor">Doctor</option>
                    <option {if $defaultValues.title eq "Dr"}selected{/if} value="Dr">Dr</option>
                    <option {if $defaultValues.title eq "Dr."}selected{/if} value="Dr.">Dr.</option>
                    <option {if $defaultValues.title eq "Doc"}selected{/if} value="Doc">Doc</option>
                    <option {if $defaultValues.title eq "Professor"}selected{/if} value="Professor">Professor</option>
                    <option {if $defaultValues.title eq "Prof"}selected{/if} value="Prof">Prof</option>
                    <option {if $defaultValues.title eq "Prof."}selected{/if} value="Prof.">Prof.</option>
                </select>
                <small class="form-text text-muted">Please slect the end-users Title.</small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label class="col-form-label">First Name:</label>
                <input type="text" id="forenameInput" class="form-control" name="forename" value="{$defaultValues.forename}">
                <small class="form-text text-muted">Please enter the end-user's first name.</small>
            </div>
            <div class="col-md-6">
                <label class="col-form-label">Surname:</label>
                <input type="text" id="nameInput" class="form-control" name="name" value="{$defaultValues.name}">
                <small class="form-text text-muted">Please enter the end-user's last name.</small>
            </div>
        </div>
    </div>
    
    <!-- PAGE 4 -->
    
    <div id="formPage4" class="formPage">
	<div class="row">
	<div class="col-md-12">
	<div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-bottom:6px;">
	<h4 style="margin:0;">Installation address</h4>
	{if $accountAddress && $accountAddress.address1}
	<button type="button" id="autofillAddressBtn" class="btn btn-primary" style="padding:6px 14px; font-size:12px; margin:0;">
	<i class="fa-duotone fa-user" style="--fa-primary-color: rgb(var(--accent-contrast)); --fa-secondary-color: rgb(var(--accent-contrast)); margin-bottom:0;"></i> Use my account address
	</button>
	{/if}
	</div>
	<small class="form-text text-muted">When porting numbers on behalf of a company, the first name and last name provided above must match those on the Letter of Authority.</small>
	</div>
	</div>
        <div class="row">
            <div class="col-md-12">
                <label class="col-form-label">Company Name:</label>
                <input type="text" id="companyInput" class="form-control" name="company" value="{$defaultValues.company}">
                <small class="form-text text-muted">Please enter the Company name for this port.</small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <label class="col-form-label">Property Number / Name:</label>
                <input type="text" id="premisesInput" class="form-control" name="premises" value="{$defaultValues.premises}">
                <small class="form-text text-muted">Please enter the property number for this address. e.g. '63' or 'Old Cottage'.</small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <label class="col-form-label">Street Name (Address Line1):</label>
                <input type="text" id="thoroughfareInput" class="form-control" name="thoroughfare" value="{$defaultValues.thoroughfare}">
                <small class="form-text text-muted">Please enter the Street name for this port.</small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label class="col-form-label">Town/City:</label>
                <input type="text" id="localityInput" class="form-control" name="locality" value="{$defaultValues.locality}">
                <small class="form-text text-muted">Please enter the Town or City for this port.</small>
            </div>
            <div class="col-md-6">
                <label class="col-form-label">Post Code:</label>
                <input type="text" id="postcodeInput" class="form-control" name="postcode" value="{$defaultValues.postcode}">
                <small class="form-text text-muted">Please enter the associated Post Code for this port. <b>NOTE:</b> Please use spacing.</small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <label class="col-form-label">Port Date</label>
                <div class="input-group">
                    <input type="text" id="portDateInput" class="form-control" name="portDate" value="{$defaultValues.portDate}" placeholder="Choose a date&hellip;">
                    <div class="input-group-append">
                        <button type="button" id="portDateEarliestBtn" class="btn btn-primary" style="padding:6px 14px; font-size:12px; margin:0; white-space:nowrap;">
                            <i class="fa-duotone fa-bolt" style="--fa-primary-color: rgb(var(--accent-contrast)); --fa-secondary-color: rgb(var(--accent-contrast)); margin-bottom:0;"></i> Earliest date
                        </button>
                    </div>
                </div>
                <small class="form-text text-muted">Pick the date you'd like the number(s) to move &mdash; or tap <b>Earliest date</b> for the soonest we can do it. Weekends and bank holidays can't be selected.</small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <label class="col-form-label">Route incoming calls to <span style="color:rgb(var(--muted)); font-weight:600;">&mdash; optional</span></label>
                <select class="form-control" id="portDestinationInput" name="portDestination">
                    <option value="">&mdash; Set up later &mdash;</option>
                    {foreach from=$destinationOptions key=groupLabel item=groupOpts}
                        <optgroup label="{$groupLabel}">
                            {foreach from=$groupOpts key=destValue item=destLabel}
                                <option value="{$destValue}"{if $defaultValues.portDestination eq $destValue} selected{/if}>{$destLabel}</option>
                            {/foreach}
                        </optgroup>
                    {/foreach}
                </select>
                <small class="form-text text-muted">Pick where these number(s) should ring &mdash; we'll point them there as soon as they're on your account, so there's nothing to set up afterwards. Leave as &ldquo;Set up later&rdquo; to route them yourself.</small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <label class="col-form-label">Letter of Authorisation:</label>
                <div id="cloaDeclaration" class="giant-cloa-box">
                    <p><strong>F.A.O my current provider &mdash; this CLoA is to notify you that I (representing the customer shown below) have taken the decision to move my Telephony services to a new Provider and require the numbers associated with those services to be ported across to my chosen new Provider, your provider Ltd.</strong></p>
                    <p><strong>My new Provider is authorised to act on my behalf in this matter &amp; you have my authority to disclose to my new Provider (at their request) any other service or site-specific details they might need to allow this port to proceed (e.g. Site/Billing address post code, DDI number range, Main Billing Number (MBN), etc.).</strong></p>
                    <p>I recognise that it is my responsibility to arrange the cessation of, or changes to, any other services provided by my current Provider.</p>
                    <label class="giant-cloa-agree" for="cloaAgreeInput">
                        <input type="checkbox" id="cloaAgreeInput" name="cloa_agree" value="1">
                        <span>I have read and agree to this declaration. It forms my signed Letter of Authorisation to my current provider.</span>
                    </label>
                    <div class="giant-cloa-error"><i class="fa-solid fa-circle-exclamation" style="margin-right:5px;"></i>Please tick to agree to the declaration before submitting.</div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <label class="col-form-label">E-Signature:</label>

                <div class="giant-sig-tabs">
                    <button type="button" class="giant-sig-tab is-active" data-sigmode="draw"><i class="fa-solid fa-pen-nib"></i>Draw</button>
                    <button type="button" class="giant-sig-tab" data-sigmode="type"><i class="fa-solid fa-keyboard"></i>Type</button>
                </div>

                <!-- Draw mode -->
                <div id="sigDrawWrap">
                    <div id="signatureDiv" style="height:200px; border-style: solid; border-width: 1px; border-color: rgb(var(--border))"></div>
                </div>

                <!-- Type mode -->
                <div id="sigTypeWrap" style="display:none;">
                    <input type="text" id="sigTypeInput" class="form-control" placeholder="Type your full name" autocomplete="off">
                    <div id="sigTypePreview" class="giant-sig-preview"></div>
                    <small class="form-text text-muted">Pick a style:</small>
                    <div class="giant-sig-fonts">
                        <button type="button" class="giant-sig-font is-active" data-font="'Dancing Script', cursive" style="font-family:'Dancing Script', cursive;">Signature</button>
                        <button type="button" class="giant-sig-font" data-font="'Caveat', cursive" style="font-family:'Caveat', cursive;">Signature</button>
                        <button type="button" class="giant-sig-font" data-font="'Sacramento', cursive" style="font-family:'Sacramento', cursive;">Signature</button>
                    </div>
                </div>

                <textarea id="sigpad" name="signature" style="display: none"></textarea>
                <small class="form-text text-muted">By signing you confirm you're authorised to request this port on behalf of the account holder.</small>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <button id="clearSignatureButton" class="btn btn-secondary" type="button"><i class="fa-solid fa-eraser" style="margin-right:6px;"></i>Clear signature</button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div id="portCostSummary" class="giant-cost-summary"><i class="fa-solid fa-receipt"></i><span>The port charge is invoiced when you submit.</span></div>
            </div>
        </div>
    </div>

    <div class="giant-port-nav">
        <button id="prevButton" class="btn btn-secondary"><i class="fa-solid fa-arrow-left" style="margin-right:6px;"></i>Back</button>
        <div class="giant-port-nav-right">
            <button id="nextButton" class="btn btn-primary">Next<i class="fa-solid fa-arrow-right" style="margin-left:6px;"></i></button>
            <button id="submitButton" class="btn btn-primary"><i class="fa-solid fa-paper-plane" style="margin-right:6px;"></i>Submit port request</button>
        </div>
    </div>
    <script src="modules/addons/resellervoip/templates/client/js/portForm.js?cahebaypas={$smarty.now}"></script>
</form>
