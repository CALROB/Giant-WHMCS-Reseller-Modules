// ─────────────────────────────────────────────────────────────────────
//  giantConfirm — the one in-page confirmation dialog. Returns a
//  Promise<boolean> and also honours callbacks, so both call styles work:
//
//    if (!(await giantConfirm('Delete this?'))) return;
//    giantConfirm({ title, message, warning, confirmText, cancelText, danger })
//    giantConfirm({ title, body, icon, variant, confirmLabel, cancelLabel,
//                   checkboxes: [{ id, label, checked }], onConfirm(checks), onCancel })
//
//  A plain string is the message. A message split on a blank line renders
//  its tail as a warning block. Destructive wording auto-selects the red
//  danger styling. `body` is trusted HTML; `message` is escaped text.
//  Styled by .giant-confirm* in index.css — nothing is injected here.
// ─────────────────────────────────────────────────────────────────────
function giantConfirm(opts) {
    if (typeof opts === 'string') { opts = { message: opts }; }
    opts = opts || {};

    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    var rawMsg   = opts.message != null ? String(opts.message) : '';
    var parts    = rawMsg.split('\n\n');
    var mainText = parts.shift();
    var warnText = (opts.warning != null) ? String(opts.warning) : parts.join(' ').trim();

    // Destructive wording picks the red styling unless the caller said otherwise.
    var probe = rawMsg + ' ' + (opts.title || '') + ' ' + (opts.confirmLabel || opts.confirmText || '');
    var destructive = /\b(delete|remov|permanent|cannot be undone|can't be undone|disconnect|log ?out|sign ?out|disable|clear|reset|wipe|erase|deactivat|unregister)/i.test(probe);
    var variant = opts.variant || (opts.danger === true ? 'danger' : opts.danger === false ? 'primary' : (destructive ? 'danger' : 'primary'));

    var iconMap = {
        'trash':    'fa-duotone fa-trash',
        'unlink':   'fa-duotone fa-link-slash',
        'cloud-up': 'fa-duotone fa-cloud-arrow-up',
        'warn':     'fa-duotone fa-triangle-exclamation',
        'power':    'fa-duotone fa-power-off',
        'question': 'fa-duotone fa-circle-question'
    };
    var iconKey   = opts.icon || (variant === 'danger' ? (destructive ? 'trash' : 'warn') : variant === 'warn' ? 'warn' : 'question');
    var iconClass = iconMap[iconKey] || iconMap.question;

    var title       = opts.title || (rawMsg ? 'Please confirm' : 'Are you sure?');
    var confirmText = opts.confirmLabel || opts.confirmText || 'Confirm';
    var cancelText  = opts.cancelLabel  || opts.cancelText  || 'Cancel';

    var bodyHtml = '';
    if (opts.body) bodyHtml += '<div class="giant-confirm-text">' + opts.body + '</div>';
    else if (mainText) bodyHtml += '<p class="giant-confirm-text">' + esc(mainText).replace(/\n/g, '<br>') + '</p>';
    if (warnText) bodyHtml += '<p class="giant-confirm-warn"><i class="fa-solid fa-triangle-exclamation"></i> ' + esc(warnText) + '</p>';
    (opts.checkboxes || []).forEach(function (c, i) {
        var cid = 'giantConfirmCheck_' + (c.id || i);
        bodyHtml += '<label class="giant-confirm-check">' +
            '<input type="checkbox" id="' + cid + '" data-cid="' + (c.id || ('check_' + i)) + '"' + (c.checked ? ' checked' : '') + '>' +
            '<span>' + c.label + '</span></label>';
    });

    // One dialog at a time: a dialog still up is answered "cancel" for its caller.
    if (typeof window._giantConfirmFinish === 'function') window._giantConfirmFinish(false);
    $('#giantConfirmDialog').remove();
    $(document).off('keydown.giantConfirm');

    var $dlg = $(
        '<div id="giantConfirmDialog" class="giant-confirm-overlay">' +
          '<div class="giant-confirm" role="alertdialog" aria-modal="true" data-variant="' + variant + '">' +
            '<div class="giant-confirm-head">' +
              '<div class="giant-confirm-icon"><i class="' + iconClass + '"></i></div>' +
              '<div class="giant-confirm-title">' + esc(title) + '</div>' +
            '</div>' +
            (bodyHtml ? '<div class="giant-confirm-body">' + bodyHtml + '</div>' : '') +
            '<div class="giant-confirm-actions">' +
              '<button type="button" class="giant-confirm-cancel">' + esc(cancelText) + '</button>' +
              '<button type="button" class="giant-confirm-ok">' + esc(confirmText) + '</button>' +
            '</div>' +
          '</div>' +
        '</div>'
    );

    // Mounted inside whatever is on top. The addon's own full-screen overlays
    // (login QR, the app user, devices, summary, CDR tags…) are body children
    // stacked ABOVE the Bootstrap modal, and the modal is its own stacking
    // context — a confirm mounted in the modal can never rise above them, no
    // matter its z-index. So: the newest overlay if one is open; else the open
    // Bootstrap modal, so its focus trap leaves the dialog alone; else body.
    var $top  = $('.giant-cdr-tag-overlay').last();
    var $host = $top.length ? $top : $('.modal.in, .modal.show').first();
    ($host.length ? $host : $('body')).append($dlg);

    return new Promise(function (resolve) {
        var settled = false;
        var finish = function (ok) {
            if (settled) return;
            settled = true;
            if (window._giantConfirmFinish === finish) window._giantConfirmFinish = null;
            document.removeEventListener('keydown', onKey, true);
            var checks = {};
            $dlg.find('.giant-confirm-check input[type="checkbox"]').each(function () {
                checks[$(this).data('cid')] = $(this).is(':checked');
            });
            $dlg.remove();
            try {
                if (ok && typeof opts.onConfirm === 'function') opts.onConfirm(checks);
                if (!ok && typeof opts.onCancel === 'function') opts.onCancel();
            } catch (e) { console.error('giantConfirm: callback failed', e); }
            resolve(!!ok);
        };
        window._giantConfirmFinish = finish;
        $dlg.on('click', function (e) { if (e.target === this) finish(false); });
        $dlg.find('.giant-confirm-cancel').on('click', function () { finish(false); });
        $dlg.find('.giant-confirm-ok').on('click', function () { finish(true); });
        // Keys are taken in the capture phase and stopped there: the overlay or
        // modal behind the dialog listens for Escape on the document too, and
        // must not close along with the confirm.
        var onKey = function (e) {
            var typing = e.target && /^(input|textarea|select)$/i.test(e.target.tagName);
            if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(false); }
            else if (e.key === 'Enter' && !typing) { e.preventDefault(); e.stopPropagation(); finish(true); }
        };
        document.addEventListener('keydown', onKey, true);
        setTimeout(function () { $dlg.find('.giant-confirm-ok').trigger('focus'); }, 50);
    });
}

// ─────────────────────────────────────────────────────────────────────
//  Universal remove-form gate. Every delete "remove" form in the client
//  area (queues, extensions, media, voicemail, feature codes, phones, …)
//  is a <form class="giantModalRemoveForm">. This single capture-phase
//  listener on document intercepts the submit BEFORE the browser's native
//  submission and before any per-tile handler can run, so nothing can ever
//  delete before the confirmation is answered — regardless of when/whether
//  a per-tile handler happened to be bound. It stops propagation, so the
//  older per-tile submit handlers never double-fire.
// ─────────────────────────────────────────────────────────────────────
if (!window.__giantRemoveGateInstalled) {
    window.__giantRemoveGateInstalled = true;

    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (!form || !form.classList || !form.classList.contains('giantModalRemoveForm')) { return; }

        // We own this submit entirely — block the native post and any
        // per-tile bubble-phase handler.
        e.preventDefault();
        e.stopImmediatePropagation();

        var $form  = $(form);
        var action = ($form.find('input[name="pbxAction"]').val()) || '';

        // Which list to refresh after the delete. Derive it from the action
        // ("removeQueue" -> "queue") — this is the exact inverse of how the
        // remove form is built (remove + Ucfirst(tile)) — and fall back to the
        // last-shown tile. Relying on a global alone left the modal stuck.
        var refreshTile = window.__giantTile || '';
        if (action.indexOf('remove') === 0 && action.length > 6) {
            var t = action.slice(6);
            refreshTile = t.charAt(0).toLowerCase() + t.slice(1);
        }

        var proceed = function () {
            $('#giantModalAlertDiv').hide();
            $('#giantModalSpinnerDiv').show();

            $.ajax({
                type: 'post',
                data: $form.serialize(),
                success: function (responseJson) {
                    var response;
                    try { response = jQuery.parseJSON(responseJson); } catch (er) { response = {}; }

                    if (response && response.error) {
                        $('#giantModalSpinnerDiv').hide();
                        $('#giantModalAlertDiv').show();
                        $('#giantModalAlert').html(response.error);
                        return;
                    }

                    if (response && response.rps && typeof showRpsToast === 'function') {
                        showRpsToast(response.rps);
                    }

                    if (typeof refreshList === 'function' && refreshTile) {
                        refreshList(refreshTile);
                    } else {
                        $('#giantModalSpinnerDiv').hide();
                    }
                },
                error: function () {
                    $('#giantModalSpinnerDiv').hide();
                    $('#giantModalAlertDiv').show();
                    $('#giantModalAlert').html('Could not remove this item — please try again.');
                }
            });
        };

        // Phone removal keeps its richer dialog (with the "unregister from
        // RPS" toggle); everything else gets a standard confirmation.
        if (action === 'removePhone' && typeof showPhoneRemoveDialog === 'function') {
            showPhoneRemoveDialog($form, proceed);
            return;
        }

        var messages = {
            removeQueue:       'Delete this queue? Its agents and settings will be removed.',
            removeMedia:       'Delete this media file?',
            removeVoicemail:   'Remove this voicemail box?',
            removeFeatureCode: 'Remove this feature code?'
        };

        giantConfirm(messages[action] || 'Are you sure you want to remove this?').then(function (ok) {
            if (ok) { proceed(); }
        });
    }, true); // capture phase — runs before native submit + bubble handlers
}

// ─────────────────────────────────────────────────────────────────────
//  gvColor — resolve a gv-system token to a usable CSS colour string
//  at runtime. Canvas APIs (Chart.js) can't evaluate `var(--accent)`,
//  so any chart that wants theme-aware colour has to ask for it via
//  this helper. Returns `rgb(R G B)` or `rgb(R G B / A)` based on the
//  optional `alpha` argument.
//
//  gvColor('accent')         → "rgb(0 217 167)"
//  gvColor('accent', .15)    → "rgb(0 217 167 / 0.15)"
//  gvColor('text', .65)      → light: "rgb(26 26 46 / 0.65)"
//                              dark:  "rgb(240 244 250 / 0.65)"
//
//  Charts also need to re-paint when html.dark toggles. Pages with
//  active charts should keep a reference list and call
//  window.gvRefreshCharts() inside the MutationObserver wired below.
// ─────────────────────────────────────────────────────────────────────
window.gvColor = function (token, alpha) {
    try {
        var raw = getComputedStyle(document.documentElement)
            .getPropertyValue('--' + token).trim();
        if (!raw) {
            // Fallback table — keeps charts visible if a page somehow
            // loads before gv-system.css does.
            var fb = {
                accent:        '0 217 167',
                'accent-2':   '11 132 87',
                'accent-ink':  '0 217 167',
                'accent-contrast': '26 26 46',
                text:         '26 26 46',
                muted:       '105 114 125',
                bg:          '255 255 255',
                surface:     '247 249 242',
                'surface-2': '240 244 236',
                border:      '232 236 240',
                warn:        '217 119 6',
                danger:      '220 38 38',
                success:      '89 186 65'
            };
            raw = fb[token] || '0 217 167';
        }
        // gv-system stores tokens as space-separated triplets.
        // Normalise any comma-separated legacy variants so the output
        // always uses the modern `rgb(R G B / A)` syntax.
        raw = raw.replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
        if (alpha != null && alpha !== 1) {
            return 'rgb(' + raw + ' / ' + alpha + ')';
        }
        return 'rgb(' + raw + ')';
    } catch (e) {
        return 'rgb(0 217 167)';
    }
};

// Chart.js theme bootstrap — pages that import Chart.js call this
// after page load (and again whenever dark mode toggles) to get the
// shared defaults right. The defaults cover legend label colour,
// tooltip background, scale tick / grid colour. Anything chart-
// specific (dataset colours) still has to use gvColor() inline.
window.gvApplyChartDefaults = function () {
    if (typeof Chart === 'undefined' || !Chart.defaults) { return; }
    Chart.defaults.color = window.gvColor('muted');
    Chart.defaults.borderColor = window.gvColor('border');
    if (Chart.defaults.plugins) {
        if (Chart.defaults.plugins.legend && Chart.defaults.plugins.legend.labels) {
            Chart.defaults.plugins.legend.labels.color = window.gvColor('text');
        }
        if (Chart.defaults.plugins.tooltip) {
            Chart.defaults.plugins.tooltip.backgroundColor = window.gvColor('text', .92);
            Chart.defaults.plugins.tooltip.titleColor = window.gvColor('bg');
            Chart.defaults.plugins.tooltip.bodyColor  = window.gvColor('bg');
            Chart.defaults.plugins.tooltip.borderColor = window.gvColor('border');
            Chart.defaults.plugins.tooltip.borderWidth = 1;
        }
    }
};

// Iterate every live Chart.js instance and re-render. Pages keep
// their own chart references; this helper is the universal fallback.
window.gvRefreshCharts = function () {
    window.gvApplyChartDefaults();
    if (typeof Chart === 'undefined' || !Chart.instances) { return; }
    var insts = Chart.instances;
    // Chart.js 3.x stores instances on an iterable map-like object.
    if (typeof insts.forEach === 'function') {
        insts.forEach(function (c) { try { c.update('none'); } catch (e) {} });
    } else {
        Object.keys(insts).forEach(function (k) {
            try { insts[k].update('none'); } catch (e) {}
        });
    }
};

// Watch for dark-mode toggles on <html> and re-paint every chart.
// Pages that mount their own per-chart colour state should also
// listen on the `gv:themechange` custom event we dispatch here.
(function () {
    if (typeof MutationObserver === 'undefined') { return; }
    var prev = document.documentElement.classList.contains('dark');
    new MutationObserver(function () {
        var now = document.documentElement.classList.contains('dark');
        if (now === prev) { return; }
        prev = now;
        window.gvRefreshCharts();
        document.dispatchEvent(new CustomEvent('gv:themechange', { detail: { dark: now } }));
    }).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
})();

// Build a GET URL to the addon image-serving endpoint, reusing current query params (tenant / hosting id).
function buildPhoneModelImageUrl(pmId, version) {
    return pbxApi.url('getPhoneModelImage', { pm_id: pmId, v: version || 0 });
}

// Compact call-log datetime cell: "2026-08-26 11:27:49" → a date pill above the
// time, so the Started/Ended columns are narrow and scannable. The <td> carries
// the raw string in data-order so DataTables still sorts chronologically. Falls
// back to the raw (escaped) text if it doesn't parse.
function fmtCdrWhen(raw) {
    var escOne = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/.exec(String(raw || ''));
    if (!m) { return escOne(raw); }
    var mons = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var day  = parseInt(m[3], 10);
    var mon  = mons[parseInt(m[2], 10) - 1] || m[2];
    var time = m[4] + ':' + m[5] + (m[6] ? ':' + m[6] : '');
    return '<div class="giant-cdr-when">' +
             '<span class="giant-cdr-when-date">' + day + ' ' + mon + ' ' + m[1] + '</span>' +
             '<span class="giant-cdr-when-time">' + time + '</span>' +
           '</div>';
}

// Seconds → compact "1h 02m 05s" / "3m 41s" / "9s" for the call-log Duration.
function fmtCdrDur(s) {
    s = Math.max(0, parseInt(s, 10) || 0);
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var out;
    if (h > 0)      { out = h + 'h ' + pad(m) + 'm ' + pad(sec) + 's'; }
    else if (m > 0) { out = m + 'm ' + pad(sec) + 's'; }
    else            { out = sec + 's'; }
    return '<span class="giant-cdr-dur">' + out + '</span>';
}

// Call-log toolbar: a filter bar (Direction / Outcome / Location) + a column
// picker (hide/show columns; Ref. and Ended hidden by default). Column hiding is
// done with a scoped <style> (display:none by nth-child) rather than DataTables'
// column().visible() — that keeps every <td> in the DOM, so the position-based
// giantCallInfoFromRow (and the leg child-rows) stay correct. Choices persist
// per-viewer in localStorage. Rules are scoped under .giant-modal-cdr so they
// only apply while the call-log modal is open (never bleed into other tiles that
// reuse #giantModalList).
function setupCallLogTools(dt) {
    var $box = $('#giantModalListDiv');
    $box.find('.giant-cdr-tools').remove();
    $('#giantCdrColHide').remove();

    var COLS = [
        { i: 1,  label: 'Started' },  { i: 2,  label: 'Ref.' },        { i: 3,  label: 'Dir.' },
        { i: 4,  label: 'Caller' },   { i: 5,  label: 'Outcome' },     { i: 6,  label: 'Ex.' },
        { i: 7,  label: 'Callee' },   { i: 8,  label: 'Location' },    { i: 9,  label: 'Duration' },
        { i: 10, label: 'Ended' },    { i: 11, label: 'Cost' },        { i: 12, label: 'Tags / Notes' },
        { i: 13, label: 'Sentiment' },{ i: 14, label: 'AI Summary' },  { i: 15, label: 'Recording' }
    ];
    var DEFAULT_HIDDEN = [2, 10, 12]; // Ref. + Ended + Tags / Notes

    // Bumped storage key (…_v2) so the new defaults take effect for everyone.
    var hidden;
    try {
        var saved = window.localStorage.getItem('giantCdrHiddenCols_v2');
        hidden = saved ? JSON.parse(saved) : DEFAULT_HIDDEN.slice();
        if (!Array.isArray(hidden)) { hidden = DEFAULT_HIDDEN.slice(); }
    } catch (e) { hidden = DEFAULT_HIDDEN.slice(); }

    var applyHidden = function () {
        var css = hidden.map(function (i) {
            var k = i + 1;
            return '.giant-modal-cdr #giantModalList>thead>tr>th:nth-child(' + k + '),' +
                   '.giant-modal-cdr #giantModalList>tbody>tr>td:nth-child(' + k + '){display:none;}';
        }).join('');
        $('#giantCdrColHide').remove();
        $('<style id="giantCdrColHide">' + css + '</style>').appendTo('head');
        try { window.localStorage.setItem('giantCdrHiddenCols_v2', JSON.stringify(hidden)); } catch (e) {}
    };

    var htmlEsc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var regexEsc = function (s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); };
    var uniqueVals = function (colIdx) {
        var set = {};
        dt.column(colIdx).data().each(function (v) {
            var t = $('<div>').html(v == null ? '' : String(v)).text().trim();
            if (t) { set[t] = true; }
        });
        return Object.keys(set).sort();
    };

    // Build our OWN controls (the native DataTables "Show entries" + "Search" are
    // hidden via CSS) so we control the layout — one clean row: filters · search ·
    // show · columns.
    var field = function (label, inner, extra) {
        return '<label class="giant-cdr-field' + (extra ? ' ' + extra : '') + '"><span>' + label + '</span>' + inner + '</label>';
    };
    var filterDefs = [{ i: 3, label: 'Direction' }, { i: 5, label: 'Outcome' }, { i: 8, label: 'Location' }];

    var html = '<div class="giant-cdr-tools">';
    // Date range picker (replaces the separate From/To bar) — first field, styled
    // like the rest. Auto-runs the search when a range is picked.
    html += field('Date range', '<input type="text" id="giantCdrRange" class="giant-cdr-input giant-cdr-rangeinput" placeholder="Pick a date range" readonly>', 'giant-cdr-wide');
    filterDefs.forEach(function (f) {
        var opts = '<option value="">All</option>';
        uniqueVals(f.i).forEach(function (v) { opts += '<option value="' + htmlEsc(v) + '">' + htmlEsc(v) + '</option>'; });
        html += field(f.label, '<select class="giant-cdr-input" data-col="' + f.i + '">' + opts + '</select>');
    });
    // Sentiment filter — col 13 is HTML, so parse the tier label out of each cell
    // for the options (the custom search below matches on data-sentiment).
    var sentOrder = { 'Very Bad': 0, 'Bad': 1, 'Neutral': 2, 'Good': 3, 'Very Good': 4 };
    var sentSet = {};
    try {
        dt.column(13).data().each(function (h) {
            var m = /data-sentiment="([^"]+)"/.exec(h == null ? '' : String(h));
            if (m) { sentSet[m[1]] = true; }
        });
    } catch (e) {}
    var sentVals = Object.keys(sentSet).sort(function (a, b) {
        var oa = sentOrder[a] === undefined ? 99 : sentOrder[a];
        var ob = sentOrder[b] === undefined ? 99 : sentOrder[b];
        return oa - ob;
    });
    if (sentVals.length) {
        var sentOpts = '<option value="">All</option>';
        sentVals.forEach(function (v) { sentOpts += '<option value="' + htmlEsc(v) + '">' + htmlEsc(v) + '</option>'; });
        html += field('Sentiment', '<select class="giant-cdr-input" id="giantCdrSentFilter">' + sentOpts + '</select>');
    }
    html += field('Search', '<input type="text" class="giant-cdr-input giant-cdr-search" placeholder="Filter table…">', 'giant-cdr-grow');
    var curLen = dt.page.len();
    var lenOpts = [10, 25, 50, 100].map(function (n) { return '<option value="' + n + '"' + (n === curLen ? ' selected' : '') + '>' + n + '</option>'; }).join('');
    html += field('Show', '<select class="giant-cdr-input giant-cdr-pagelen">' + lenOpts + '</select>', 'giant-cdr-narrow');
    html += '<div class="giant-cdr-colpick"><button type="button" class="btn btn-default giant-cdr-colbtn"><i class="fa-solid fa-table-columns"></i> Columns</button>';
    html += '<div class="giant-cdr-colmenu" style="display:none;">';
    COLS.forEach(function (c) {
        html += '<label><input type="checkbox" data-col="' + c.i + '"' + (hidden.indexOf(c.i) === -1 ? ' checked' : '') + '> ' + htmlEsc(c.label) + '</label>';
    });
    html += '</div></div></div>';

    $('#giantModalListTableDiv').before(html);
    applyHidden();

    // Filters → per-column search.
    $box.find('.giant-cdr-tools select[data-col]').on('change', function () {
        var col = parseInt($(this).data('col'), 10);
        var val = $(this).val();
        dt.column(col).search(val ? '^' + regexEsc(val) + '$' : '', true, false).draw();
    });
    // Our quick search → global table search.
    $box.find('.giant-cdr-search').on('keyup', function () { dt.search($(this).val()).draw(); });
    // Our page-length → DataTables page length.
    $box.find('.giant-cdr-pagelen').on('change', function () { dt.page.len(parseInt($(this).val(), 10)).draw(); });

    // Sentiment filter — its cell is HTML, so a plain column search won't match;
    // use a self-gating custom search plug-in that reads the cell's data-sentiment.
    var sExt = $.fn.dataTable.ext.search;
    for (var si = sExt.length - 1; si >= 0; si--) { if (sExt[si]._giantCdrSent) { sExt.splice(si, 1); } }
    var sentFn = function (settings, dataArr, idx) {
        if (settings.nTable.id !== 'giantModalList') { return true; }
        var $sel = $('#giantCdrSentFilter');
        var want = $sel.length ? $sel.val() : '';
        if (!want) { return true; }
        var tr = settings.aoData[idx] && settings.aoData[idx].nTr;
        if (!tr) { return true; }
        var lbl = $(tr).children('td').eq(13).find('[data-sentiment]').attr('data-sentiment') || '';
        return lbl === want;
    };
    sentFn._giantCdrSent = true;
    sExt.push(sentFn);
    $box.find('#giantCdrSentFilter').on('change', function () { dt.draw(); });

    $box.find('.giant-cdr-colbtn').on('click', function (e) {
        e.stopPropagation();
        $box.find('.giant-cdr-colmenu').toggle();
    });
    $box.find('.giant-cdr-colmenu').on('click', function (e) { e.stopPropagation(); });
    $(document).off('click.cdrcol').on('click.cdrcol', function () { $('.giant-cdr-colmenu').hide(); });
    $box.find('.giant-cdr-colmenu input').on('change', function () {
        var col = parseInt($(this).data('col'), 10);
        var idx = hidden.indexOf(col);
        if ($(this).is(':checked')) { if (idx > -1) { hidden.splice(idx, 1); } }
        else                        { if (idx === -1) { hidden.push(col); } }
        applyHidden();
    });

    // Date-range picker → feeds the (now hidden) generic #from/#to + fires the
    // existing Search button, so the search path is unchanged.
    if (window.flatpickr) {
        var f0 = $('#from').val(), t0 = $('#to').val();
        flatpickr('#giantCdrRange', {
            mode: 'range',
            dateFormat: 'Y-m-d',
            disableMobile: true,
            defaultDate: (f0 && t0) ? [f0, t0] : null,
            onClose: function (selectedDates, dateStr, inst) {
                if (selectedDates.length === 2) {
                    $('#from').val(inst.formatDate(selectedDates[0], 'Y-m-d'));
                    $('#to').val(inst.formatDate(selectedDates[1], 'Y-m-d'));
                    $('#giantDateApply').trigger('click');
                }
            }
        });
    }

    // Assemble ONE cohesive panel: the toolbar (date range + filters) on top, the
    // "search what was said" transcript bar BELOW it. The old From/To date bar is
    // kept in the DOM (hidden via CSS) purely to hold #from/#to/#giantDateApply.
    $box.find('.giant-cdr-controls').children().unwrap();
    var $tools = $box.find('.giant-cdr-tools').first();
    if ($tools.length) {
        var $wrap = $('<div class="giant-cdr-controls"></div>');
        $tools.before($wrap);
        $wrap.append($tools);
        $wrap.append($box.find('.giant-tsearch-bar').first());
        $wrap.after($box.find('#giantTranscriptResults').first());
    }
}

// Resolve the best src for a phone-model image: inline data URI if the server sent one,
// otherwise fall back to the cached endpoint URL.
function resolvePhoneModelSrc(inlineSrc, pmId, version) {
    if (inlineSrc) return inlineSrc;
    if (version) return buildPhoneModelImageUrl(pmId, version);
    return '';
}

// Render a phone model name: replace " (ZeroTouch+)" suffix with the ZeroTouch badge.
// Optional opts.stripManufacturer strips a leading "<Mfg> - " prefix (used when the
// manufacturer logo is shown separately, to avoid redundancy).
var ZEROTOUCH_LOGO_URL = 'modules/addons/resellervoip/templates/client/img/Giant-Zerotouch_provisioning_Colour_1.svg';
function formatPhoneModelName(rawName, opts) {
    opts = opts || {};
    var escape = function (s) { return $('<div>').text(s == null ? '' : s).html(); };
    var escapeRe = function (s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); };

    var name = String(rawName || '');
    var hasZeroTouch = /\(\s*ZeroTouch\s*\+\s*\)/i.test(name);
    var clean = name
        .replace(/[-\u2013\u2014\s]*\(\s*ZeroTouch\s*\+\s*\)[-\u2013\u2014\s]*/ig, ' ')
        .replace(/\s*[-\u2013\u2014]\s*$/g, '')
        .replace(/^\s*[-\u2013\u2014]\s*/g, '')
        .replace(/\s{2,}/g, ' ')
        .trim();

    if (opts.stripManufacturer) {
        var re = new RegExp('^\\s*' + escapeRe(opts.stripManufacturer) + '\\s*[-\u2013\u2014]\\s*', 'i');
        clean = clean.replace(re, '').trim();
    }

    var safe = escape(clean);
    if (hasZeroTouch) {
        safe += ' <img src="' + ZEROTOUCH_LOGO_URL + '" class="giant-zerotouch-badge" alt="ZeroTouch" title="ZeroTouch provisioning supported">';
    }
    return safe;
}

// Build a <img> tag for a manufacturer logo, or an empty string when no logo is uploaded.
function manufacturerLogoTag(src, name, extraClass) {
    if (!src) return '';
    var cls = 'giant-mfg-logo' + (extraClass ? ' ' + extraClass : '');
    var alt = name ? name : '';
    return '<img src="' + src + '" class="' + cls + '" alt="' + alt + '" title="' + alt + '" decoding="async">';
}

// ===== Toast notifications =====
// Small, unobtrusive feedback that doesn't push layout around like #giantModalAlertDiv does.
// Usage: giantToast('Call started', 'success'); giantToast('Failed', 'error'); giantToast('…');
function giantToast(message, type, opts) {
    opts = opts || {};
    var kind = (type || 'info').toLowerCase();
    var timeoutMs = opts.timeout == null ? (kind === 'error' ? 5000 : 3000) : opts.timeout;

    var $container = $('#giantToastContainer');
    if ($container.length === 0) {
        $('body').append('<div id="giantToastContainer" class="giant-toast-container"></div>');
        $container = $('#giantToastContainer');
    }

    var icons = {
        success: 'fa-circle-check',
        error:   'fa-circle-exclamation',
        warn:    'fa-triangle-exclamation',
        info:    'fa-circle-info',
    };
    var icon = icons[kind] || icons.info;

    var $t = $('<div class="giant-toast giant-toast-' + kind + '">' +
        '<i class="fa-solid ' + icon + ' giant-toast-icon"></i>' +
        '<span class="giant-toast-msg"></span>' +
        '<button class="giant-toast-close" aria-label="Close">&times;</button>' +
        '</div>');
    $t.find('.giant-toast-msg').text(message);
    $container.append($t);

    // Trigger slide-in
    requestAnimationFrame(function () { $t.addClass('is-visible'); });

    var dismiss = function () {
        $t.removeClass('is-visible');
        setTimeout(function () { $t.remove(); }, 200);
    };
    $t.find('.giant-toast-close').on('click', dismiss);
    if (timeoutMs > 0) setTimeout(dismiss, timeoutMs);

    return $t;
}

// Port charges come from the addon config (window.giantPortPricing), so the
// modal descriptions reflect whatever pricing is set — geographic, non-geo and
// mobile can differ.
var giantPP = window.giantPortPricing || {};
function giantFmtPrice(v) {
    var n = parseFloat(v);
    return isNaN(n) ? ('£' + (v || '12')) : ('£' + n.toFixed(2));
}
var gpGeo = giantFmtPrice(giantPP.geographic);
var gpNonGeo = giantFmtPrice(giantPP.nonGeographic);
var gpMobile = giantFmtPrice(giantPP.mobile);
var gpPortPriceText = (gpGeo === gpNonGeo)
    ? ('<b>Ports are charged at ' + gpGeo + ' ex. VAT per number.</b>')
    : ('<b>Ports are charged at ' + gpGeo + ' ex. VAT per number — ' + gpNonGeo + ' for non-geographic (03/05/08/09) numbers.</b>');

var modalDescriptions = window.modalDescriptions = {
    callFlow: "Visually build and edit the call routing for each phone number. Add steps like IVRs, queues, extensions, and voicemail to control how incoming calls are handled.",
    teamsRouting: "Connect Microsoft Teams to the app with Direct Routing. Follow the step-by-step guide to configure your SBC and start making calls from Teams.",
    extension: "Manage your phone extensions — create, edit, or remove them anytime. Each extension has its own caller ID, username, and password for SIP registration.",
    callLog: "Browse your call history with detailed records. Use the date pickers or search bar to find specific calls, and download call recordings where enabled.",
    destination: "Manage your telephone numbers — change destinations, add labels, and enable or disable call recording on each number.",
    port: "Submit a number port request to transfer your existing telephone number. <b>Note:</b> ADSL/FTTC broadband on this number will cease when porting completes. " + gpPortPriceText,
    mobilePort: "Port an existing mobile number onto our network. You'll need the <b>PAC</b> (Porting Authorisation Code) from your current mobile provider — text <b>PAC</b> to 65075 to get it. The earliest port date is 2 working days from today. <b>Mobile ports are charged at " + gpMobile + " ex. VAT per number.</b>",
    ivr: "Set up your Interactive Voice Response menus. Route callers based on key presses — for example, \"Press 1 for Sales\" can route to a queue or extension.",
    voicemail: "Create and manage voicemail boxes. Enable voicemail-to-email so you never miss a message, and customise your greeting recordings.",
    phone: "Auto-provision your desk phones and devices. Register new hardware with a single click for rapid deployment.",
    condition: "Create time-based call routing rules. Route calls to different destinations based on time of day, day of week, or holidays.",
    huntList: "Set up ring groups so multiple phones ring at once. Perfect for teams where any member can take the call.",
    media: "Upload and manage your audio files for hold music, welcome messages, and announcements. Drag & drop to upload new files.",
    musicOnHold: "Choose which audio files play when callers are on hold. Build a playlist with multiple tracks for a better caller experience.",
    queue: "Manage your call queues — assign agents, set announcements, and configure how calls are distributed to your team.",
    conference: "Create and manage conference rooms. Participants dial the conference number to join, with an optional PIN for privacy.",
    customDestination: "Create additional destinations for routing calls to external numbers — useful for mobile diversions and external transfers. Shared services such as call screening are listed underneath, ready to route to.",
    featureCode: "Configure feature codes for quick access to phone system functions directly from your handset.",
    shortNumber: "Set up short dial codes for fast one-touch calling to your most-used destinations.",
    phoneBook: "Manage your shared cloud phone book. Contacts sync across all registered handsets automatically.",
    smsLog: "Send SMS messages to any UK number. View your message history and manage SMS campaigns.",
    apiAccess: "Manage your API keys for programmatic access to the VoIP platform. Use these keys to build custom integrations.",
    voiceCloud: "Set up the the app softphone app for yourself and your team. Take calls from anywhere on any device.",
    appDevices: "See where the softphone app is signed in across your team's extensions, and log out a lost or unrecognised device. Desk phones aren't shown here — this is the app only.",
    aiAgentLog: "Review every conversation an AI agent has had with a caller. Filter by date and click any row to see the full transcript.",
    integration: "Connect third-party services to your VoIP system. Turn integrations on or off and configure each one without leaving this page.",
    tenantSettings: "Account-wide settings for your phone system — call handling, recording and web/app calling. Changes apply across your whole account.",
    callerIdBlacklist: "Block nuisance callers tenant-wide. Paste a list of numbers in one go, give each entry a reason, and the PBX rejects matches before they hit your phones.",
    disa: "Dial-in access. Ring a designated number, enter your PIN, and you get a dial tone to make outbound calls presenting your office caller ID — useful for on-call staff.",
    campaign: "Run an outbound calling campaign — appointment reminders, customer call-outs, or any planned dial list. Numbers are dialled from a queue, with live state and per-number disposition reporting.",
};

// Render the gov.uk bank holidays response into a target element.
// Used by the USEGLOBAL condition dialog to show customers exactly which
// dates count as "bank holidays" for their auto-managed routing rule.
function renderUkBankHolidays($target, resp) {
    if (!resp || !resp.ok) {
        $target.html('<div class="text-muted" style="font-size:13px;">' + (resp && resp.error ? String(resp.error) : 'Could not load bank holidays.') + '</div>');
        return;
    }
    var dates = resp.dates || [];
    if (!dates.length) {
        $target.html('<div class="text-muted" style="font-size:13px;">No upcoming bank holidays found.</div>');
        return;
    }

    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var groupByYear = {};
    dates.forEach(function (d) {
        var year = String(d.date).substring(0, 4);
        if (!groupByYear[year]) groupByYear[year] = [];
        groupByYear[year].push(d);
    });
    var years = Object.keys(groupByYear).sort();

    var html = '<div style="font-size:13px;">';
    html += '<div style="font-weight:600; color:#1e293b; margin-bottom:6px;">Upcoming UK bank holidays <small style="color:#6b7280; font-weight:400;">— from gov.uk</small></div>';
    years.forEach(function (year) {
        html += '<div style="margin-top:8px; font-weight:600; color:#475569; font-size:12px;">' + year + '</div>';
        html += '<table style="width:100%; border-collapse:collapse; margin-top:2px;">';
        groupByYear[year].forEach(function (d) {
            var date = new Date(d.date);
            var dayMonth = (isNaN(date.getTime())
                ? d.date
                : date.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }));
            var regions = (d.regions || []).map(function (r) {
                return '<span style="display:inline-block; padding:1px 6px; border-radius:8px; background:#e0e7ff; color:#3730a3; font-size:10.5px; font-weight:600; margin-right:3px;">' + esc(r) + '</span>';
            }).join('');
            html += '<tr style="border-bottom:1px solid #f1f5f9;">';
            html += '  <td style="padding:5px 8px 5px 0; white-space:nowrap; font-family:monospace; color:#475569; font-size:12px;">' + esc(dayMonth) + '</td>';
            html += '  <td style="padding:5px 8px;">' + esc(d.title) + (d.notes ? ' <small style="color:#92400e;">' + esc(d.notes) + '</small>' : '') + '</td>';
            html += '  <td style="padding:5px 0; text-align:right;">' + regions + '</td>';
            html += '</tr>';
        });
        html += '</table>';
    });
    if (resp.fetchedAt) {
        var fetched = new Date(resp.fetchedAt);
        html += '<div style="margin-top:8px; color:#9ca3af; font-size:11px;">Last refreshed ' +
                (isNaN(fetched.getTime()) ? esc(resp.fetchedAt) : fetched.toLocaleString('en-GB')) + '</div>';
    }
    html += '</div>';

    $target.html(html);
}

// The dates of a shared list a condition follows, read-only: every active day
// grouped by year, past days dimmed, and a warning when none are left.
function renderSharedConditionDates($target, resp) {
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var shared = (resp && resp.shared) || {};
    var ranges = (resp && resp.ranges) || [];
    var head = '<div style="font-weight:600; color:#1e293b; margin-bottom:6px;">' + (shared.name ? esc(shared.name) : 'Shared list') + ' <small style="color:#6b7280; font-weight:400;">— managed for you</small></div>';
    if (shared.available === false) {
        $target.html('<div style="font-size:13px;">' + head + '<div class="text-muted">Couldn\'t load the dates just now. The condition still works.</div></div>');
        return;
    }
    if (!ranges.length) {
        $target.html('<div style="font-size:13px;">' + head + '<div class="text-muted">No dates on this list yet.</div></div>');
        return;
    }
    if (shared.type === 'WEEKTIME') {
        $target.html('<div style="font-size:13px;">' + head + '<div>' + esc((shared.summary && shared.summary.scheduleFull) || '') + '</div></div>');
        return;
    }
    // Every active day: an entry is a single day, or a span the PBX ends at
    // the following midnight.
    var parse = function (s) {
        var m = String(s || '').match(/(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})(?:\D+(\d{1,2}):(\d{2}))?/);
        return m ? { d: new Date(+m[1], +m[2] - 1, +m[3]), midnight: !m[4] || (+m[4] === 0 && +m[5] === 0) } : null;
    };
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var days = {};
    ranges.forEach(function (r) {
        var a = parse(r && r.param1); if (!a) return;
        var b = parse(r && r.param2);
        var end = a.d;
        if (b && b.d > a.d) {
            end = b.midnight ? new Date(b.d.getFullYear(), b.d.getMonth(), b.d.getDate() - 1) : b.d;
            if (end < a.d) end = a.d;
        }
        for (var d = new Date(a.d), i = 0; d <= end && i < 400; d.setDate(d.getDate() + 1), i++) {
            days[d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())] = true;
        }
    });
    var keys = Object.keys(days).sort();
    var today = new Date(); today.setHours(0, 0, 0, 0);
    var byYear = {};
    keys.forEach(function (k) { var y = k.substring(0, 4); (byYear[y] = byYear[y] || []).push(k); });
    var pastCount = 0;
    var html = '<div style="font-size:13px;">' + head;
    Object.keys(byYear).sort().forEach(function (y) {
        html += '<div style="margin-top:8px; font-weight:600; color:#475569; font-size:12px;">' + esc(y) + '</div>';
        html += '<div style="display:flex; flex-wrap:wrap; gap:4px; margin-top:4px;">';
        byYear[y].forEach(function (k) {
            var dt = new Date(k + 'T00:00:00');
            var past = dt < today;
            if (past) pastCount++;
            html += '<span style="display:inline-block; padding:2px 8px; border-radius:8px; font-size:12px; background:' + (past ? '#f1f5f9' : '#e6fbf5') + '; color:' + (past ? '#94a3b8' : '#04705c') + ';"' + (past ? ' title="Already passed"' : '') + '>'
                  + esc(dt.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })) + '</span>';
        });
        html += '</div>';
    });
    if (keys.length && pastCount === keys.length) {
        html += '<div style="margin-top:8px; color:#b45309; font-size:12px;"><i class="fa fa-triangle-exclamation"></i> All these dates have passed — this condition won\'t match again until the list is updated.</div>';
    }
    html += '</div>';
    $target.html(html);
}

var addFormData = {
//extension=====================================================================        
    extension: [
        {
            name: "ex_info",
            display: "Info",
            type: "info",
            value: "dynamic",
        },
        {
            name: "ex_name",
            display: "Name",
            description: "Extension name e.g. 'Jon Doe' or 'Jon Doe - Director'.",
        },
        {
            name: "ex_number",
            display: "Extension Number",
            description: "A unique number for internal dialling, e.g. '501' or '5000'. Avoid numbers that match emergency services (999, 112, 101).",
        },
        {
            name: "ex_cidnum",
            display: "Telephone Number for outbound presentation",
            description: "Please select one of your provided telephone numbers to be presented to the callee when you call them.",
            options: "dynamic",
        },
        {
            name: "ex_mailbox",
            display: "Voicemail",
            description: "If you would like voicemail to be accessable to this extension, please select it from the dropdown above.",
            options: "dynamic",
        },
        {
            name: "ex_mu_id",
            display: "Hold music",
            description: "What a caller hears when this extension puts them on hold. Leave on the account default unless this extension needs its own.",
            options: "dynamic",
        },
        /*
        {
            name:       "ex_tech",
            display:    "Tech",
            options: {
                SIP:    "SIP",
                PJSIP:  "PJSIP"
            }
        },
        * 
        */
        {
            name: "ex_alertemail",
            display: "Alert notification email",
            description: "If you would like extension related emails to be sent to an email address, please enter it here.",
        },
        {
            name: "ex_alertwhenoffline",
            display: "Extension online/offline alerts",
            description: "This enables email notifications for the availibility status of this extension e.g 'Extension Offline' or 'Extension online'.",
            options: {
                off: "Disabled",
                on: "Enabled",
            }
        },
        {
            name: "password",
            display: "Password",
            description: "The password for this extension user, either enter your own or click the generate button to create a secure password for this extension.",
            type: "password"
        },
    ],

//customDestination=============================================================
    customDestination: [
        {
            name: "cu_name",
            display: "Label",
            description: "A friendly name for this destination, e.g. 'Jon's Mobile' or 'Office Overflow'.",
        },
        {
            name: "cu_ct_id",
            display: "Destination Type",
            description: "The type of custom destination. 'Forwarding' forwards calls to an external number.",
            options: "dynamic",
        },
        {
            name: "cu_param1",
            display: "Phone Number",
            description: "The UK landline (01/02), 03 or UK mobile (07) number to forward calls to, e.g. 020 7946 0000, 0333 000 0000 or 07700 900123. Spaces and +44 are fine; premium-rate, 08 and international numbers aren't allowed.",
        },
        {
            name: "cu_param2",
            display: "Caller ID Presentation",
            description: "What caller ID the recipient sees when the call is forwarded.",
            options: {
                "ORIGINAL": "Show original caller's number",
                "INCOMINGDID": "Show the DID that was dialled",
            }
        },
        {
            name: "cu_param3",
            display: "Ring Timeout (seconds)",
            description: "How long to ring before giving up. Leave blank for default (30 seconds).",
        },
    ],

//phone(autoprovisioning)=======================================================   
    phone: [
        {
            name: "ph_name",
            display: "Name",
            description: "Unique label for your provisioned device e.g 'Jon Doe's Yealink T46S' or 'Main Office Phone'.",
        },
        {
            name: "ph_mac",
            display: "MAC",
            description: "Please enter the MAC Address for this device, you can usually find this on the back or underside of your hardware.",
            mask: {regex: "([0-9A-Fa-f]{2}:){5}([0-9A-Fa-f]{2})"},
        },
        {
            name: "ph_pm_id",
            display: "Phone Model",
            description: "Please select from the list of supported autoprovisionable devices, Yealink is currently the only manufacturarer that we are able to deploy with 'Zero-touch'.",
            options: "dynamic",
            onChange: function (event) {

                var linesCount = $(this).find('option:selected').data("pm_endline");
                $('[name^="ph_line"]').prop('disabled', false);
                for (var i = linesCount; i < 10; i++) {
                    $('[name="ph_line' + (i + 1) + '_ex_id"]').prop('disabled', true);
                }
            }
        },
        {
            name: "ph_line0_ex_id",
            display: "Line 1 Extension",
            description: "Please select your 1st phone line for this device. e.g '101 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line1_ex_id",
            display: "Line 2 Extension",
            description: "Please select your 2nd phone line for this device. e.g '102 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line2_ex_id",
            display: "Line 3 Extension",
            description: "Please select your 3rd phone line for this device. e.g '103 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line3_ex_id",
            display: "Line 4 Extension",
            description: "Please select your 4th phone line for this device. e.g '104 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line4_ex_id",
            display: "Line 5 Extension",
            description: "Please select your 5th phone line for this device. e.g '105 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line5_ex_id",
            display: "Line 6 Extension",
            description: "Please select your 6th phone line for this device. e.g '106 - Jon Doe'",
            options: "dynamic",
        },

    ],
//huntList======================================================================
    huntList: [
        {
            name: "hu_name",
            display: "Name",
            description: "Please label your new Hunt List e.g 'Sales Team' or 'Support Team' etc.",
        },
        {
            name: "hu_number",
            display: "Number",
            description: "Optional internal number for this hunt list (e.g. '759'). Leave blank to auto-assign.",
        },
        {
            name: "hu_type",
            display: "Type",
            description: "Ring All = ring all destinations simultaneously. Sequence = ring in listed order. Cycle = ring each in turn, looping.",
            options: {RINGALL: "Ring All", "RINGALL-LOOP": "Ring All (Loop)", SEQUENCE: "Sequence", CYCLE: "Cycle"},
        },
        {
            name: "hu_ringtime",
            display: "Ring Time (seconds)",
            description: "How long to ring each destination before moving on.",
            default: "30",
        },
        {
            name: "hu_dialtimeout",
            display: "Overall Dial Timeout (seconds)",
            description: "Total time to keep attempting destinations before giving up.",
            default: "3600",
        },
        {
            name: "hu_confirmmessage_id",
            display: "Confirmation message",
            description: "Played to whoever answers, before they press a key to accept the call. Leave on Default for the standard prompt. Only used when Request Confirmation is on.",
            options: "dynamic",
        },
        {
            name: "hu_checkinuse",
            display: "Skip Busy Destinations",
            description: "Skip destinations that are currently on a call.",
            type: "toggle",
        },
        {
            name: "hu_checkoffline",
            display: "Skip Offline Destinations",
            description: "Skip destinations that are not registered / offline.",
            type: "toggle",
        },
        {
            name: "hu_requestconfirm",
            display: "Request Confirmation",
            description: "Require the answerer to press a key to accept the call.",
            type: "toggle",
        },
        {
            name: "hu_usemoh",
            display: "Music on Hold",
            description: "Play music on hold to the caller while ringing.",
            type: "toggle",
        },
        {
            name: "hu_allowredirect",
            display: "Allow Redirect",
            description: "Allow destinations to redirect the call.",
            type: "toggle",
        },
        {
            name: "hu_allowadditionaldestinations",
            display: "Allow Additional Destinations",
            description: "Allow extra destinations to be added at runtime.",
            type: "toggle",
        },
        {
            name: "hu_allowfmfm",
            display: "Allow Follow-Me",
            description: "Allow Follow-Me (find-me-follow-me) for destinations.",
            type: "toggle",
        },
        {
            name: "hu_fastdialing",
            display: "Fast Dialing",
            description: "Skip delays between dial attempts.",
            type: "toggle",
        },
        {
            name: "hu_usecustomdetails",
            display: "Use Custom Caller Details",
            description: "Override default caller-id details for this hunt list.",
            type: "toggle",
        },
        {
            name: "hu_extensions",
            display: "Destinations",
            description: "Please add which extensions or custom destinations you would like to be called when callers are diverted to your Hunt List.",
            options: "dynamic",
            type: "checkbox"
        },
        {
            name: "hu_on_timeout",
            display: "If nobody answers",
            description: "Where to send the caller once every destination in the hunt list has been tried without an answer.",
            options: "dynamic",
            type: "multipleSelect",
        },
    ],
//shortNumber===================================================================
    shortNumber: [
        {
            name: "sn_number",
            display: "Number",
            description: "Please enter your new short number code, after this new short number has been created, you can dial the short number code to dial your real destination.",
        },
        {
            name: "sn_destnumber",
            display: "Destination Number",
            description: "Please enter the destination number e.g '03330000000' or '07900000000'.",
        },
        {
            name: "sn_comment",
            display: "Comment",
            description: "Please name your new short number e.g 'Jon Doe Mobile Speed Dial' etc.",
        },

    ],
//featureCode==============================================================================
    featureCode: [
        {
            name: "fe_code",
            display: "Code",
            description: "Please enter your new feature code number e.g '659*'",
        },
        {
            name: "fe_comment",
            display: "Comment",
            description: "Please name your new Feature code e.g 'Withheld dial",
        },
    ],

//ivr===========================================================================
    ivr: [
        {
            name: "iv_name",
            display: "Name",
            description: "Please name your new IVR e.g 'Main Welcome IVR'.",
        },
        {
            name: "iv_me_id",
            display: "Welcome message",
            description: "Please select your IVR welcome message here, this is the media file your caller will hear first before selecting an option.",
            options: "dynamic",
        },
        {
            name: "iv_options_me",
            display: "Options message",
            description: "Played after the welcome message to read out the menu options. Leave blank if the welcome message already covers them.",
            options: "dynamic",
        },
        {
            name: "iv_timeout",
            display: "Timeout",
            description: "Enter the number of seconds your caller has to make their IVR number selection.",
        },
        {
            name: "iv_maxloops",
            display: "Max Loops",
            description: "Enter the maximum number of IVR loops given to the caller before the caller is disconnected for either not selecting an option or trying to select an invalid option.",
        },
        {
            name: "iv_ivr_1",
            display: "Pressing 1",
            description: "Enter the destination to route your caller to when they press <b>'1'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_2",
            display: "Pressing 2",
            description: "Enter the destination to route your caller to when they press <b>'2'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_3",
            display: "Pressing 3",
            description: "Enter the destination to route your caller to when they press <b>'3'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_4",
            display: "Pressing 4",
            description: "Enter the destination to route your caller to when they press <b>'4'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_5",
            display: "Pressing 5",
            description: "Enter the destination to route your caller to when they press <b>'5'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_6",
            display: "Pressing 6",
            description: "Enter the destination to route your caller to when they press <b>'6'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_7",
            display: "Pressing 7",
            description: "Enter the destination to route your caller to when they press <b>'7'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_8",
            display: "Pressing 8",
            description: "Enter the destination to route your caller to when they press <b>'8'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_9",
            display: "Pressing 9",
            description: "Enter the destination to route your caller to when they press <b>'9'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_0",
            display: "Pressing 0",
            description: "Enter the destination to route your caller to when they press <b>'0'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_star",
            display: "Pressing Star",
            description: "Enter the destination to route your caller to when they press <b>'*'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_sharp",
            display: "Pressing Sharp",
            description: "Enter the destination to route your caller to when they press <b>'#'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_timeout",
            display: "On timeout",
            description: "Where to send the caller if they don't press anything before the menu times out.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_wrong",
            display: "On invalid key",
            description: "Where to send the caller after they press a key that isn't one of the options.",
            options: "dynamic",
            type: "multipleSelect",
        },
    ],
//voicemail
    voicemail: [
        {
            type: "section",
            display: "The box",
        },
        {
            name: "fullname",
            display: "Name",
            description: "Whose box this is, e.g. 'Reception' or 'Jon Doe'. Shown in lists and read out in the dial-by-name directory.",
        },
        {
            name: "mailbox",
            display: "Mailbox number",
            description: "The number callers and phones use to reach it, usually the same as the extension, e.g. 5000.",
        },
        {
            name: "password",
            display: "PIN",
            description: "Four digits, needed to listen from a handset. Leave blank for 0000.",
        },
        {
            name: "welcomeoption",
            display: "Greeting",
            description: "What callers hear before the beep. 'Automatic' reads the name or number; 'instructions' adds how to leave a message.",
            options: {
                "Auto": "Automatic, no instructions",
                "AutoInst": "Automatic, with instructions",
                "Inst": "Instructions only",
                "Silent": "Nothing, just the beep",
            }
        },
        {
            name: "language",
            display: "Language",
            description: "The voice used for prompts in this box.",
            options: {
                "": "Account default",
                "en_GB": "English (UK)",
            }
        },
        {
            name: "timezone",
            display: "Time zone",
            description: "Used when a message's date and time is read out or emailed.",
            options: {
                "": "Account default",
                "Europe/London": "Europe/London (GMT) London",
                "Europe/Belfast": "Europe/Belfast (GMT) Belfast",
                "Europe/Dublin": "Europe/Dublin (GMT) Dublin",
                "Europe/Lisbon": "Europe/Lisbon (GMT) Lisbon",
                "Europe/Amsterdam": "Europe/Amsterdam (GMT+01:00) Amsterdam, Berlin, Rome, Stockholm, Vienna",
                "Europe/Brussels": "Europe/Brussels (GMT+01:00) Brussels, Copenhagen, Madrid, Paris",
                "Europe/Belgrade": "Europe/Belgrade (GMT+01:00) Belgrade, Budapest, Prague",
                "Europe/Minsk": "Europe/Minsk (GMT+02:00) Minsk",
                "Europe/Moscow": "Europe/Moscow (GMT+03:00) Moscow, St. Petersburg",
                "Africa/Abidjan": "Africa/Abidjan (GMT) Monrovia, Reykjavik",
                "Africa/Algiers": "Africa/Algiers (GMT+01:00) West Central Africa",
                "Africa/Windhoek": "Africa/Windhoek (GMT+01:00) Windhoek",
                "Africa/Cairo": "Africa/Cairo (GMT+02:00) Cairo",
                "Africa/Blantyre": "Africa/Blantyre (GMT+02:00) Harare, Pretoria",
                "Africa/Addis_Ababa": "Africa/Addis_Ababa (GMT+03:00) Nairobi",
                "Asia/Beirut": "Asia/Beirut (GMT+02:00) Beirut",
                "Asia/Damascus": "Asia/Damascus (GMT+02:00) Syria",
                "Asia/Gaza": "Asia/Gaza (GMT+02:00) Gaza",
                "Asia/Jerusalem": "Asia/Jerusalem (GMT+02:00) Jerusalem",
                "Asia/Tehran": "Asia/Tehran (GMT+03:30) Tehran",
                "Asia/Dubai": "Asia/Dubai (GMT+04:00) Abu Dhabi, Muscat",
                "Asia/Yerevan": "Asia/Yerevan (GMT+04:00) Yerevan",
                "Asia/Kabul": "Asia/Kabul (GMT+04:30) Kabul",
                "Asia/Tashkent": "Asia/Tashkent (GMT+05:00) Tashkent",
                "Asia/Yekaterinburg": "Asia/Yekaterinburg (GMT+05:00) Ekaterinburg",
                "Asia/Kolkata": "Asia/Kolkata (GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi",
                "Asia/Katmandu": "Asia/Katmandu (GMT+05:45) Kathmandu",
                "Asia/Dhaka": "Asia/Dhaka (GMT+06:00) Astana, Dhaka",
                "Asia/Novosibirsk": "Asia/Novosibirsk (GMT+06:00) Novosibirsk",
                "Asia/Rangoon": "Asia/Rangoon (GMT+06:30) Yangon",
                "Asia/Bangkok": "Asia/Bangkok (GMT+07:00) Bangkok, Hanoi, Jakarta",
                "Asia/Krasnoyarsk": "Asia/Krasnoyarsk (GMT+07:00) Krasnoyarsk",
                "Asia/Hong_Kong": "Asia/Hong_Kong (GMT+08:00) Beijing, Hong Kong, Manila",
                "Asia/Irkutsk": "Asia/Irkutsk (GMT+08:00) Irkutsk, Ulaan Bataar",
                "Asia/Seoul": "Asia/Seoul (GMT+09:00) Seoul",
                "Asia/Tokyo": "Asia/Tokyo (GMT+09:00) Osaka, Sapporo, Tokyo",
                "Asia/Yakutsk": "Asia/Yakutsk (GMT+09:00) Yakutsk",
                "Asia/Vladivostok": "Asia/Vladivostok (GMT+10:00) Vladivostok",
                "Asia/Magadan": "Asia/Magadan (GMT+11:00) Magadan",
                "Asia/Anadyr": "Asia/Anadyr (GMT+12:00) Anadyr, Kamchatka",
                "Australia/Perth": "Australia/Perth (GMT+08:00) Perth",
                "Australia/Eucla": "Australia/Eucla (GMT+08:45) Eucla",
                "Australia/Adelaide": "Australia/Adelaide (GMT+09:30) Adelaide",
                "Australia/Darwin": "Australia/Darwin (GMT+09:30) Darwin",
                "Australia/Brisbane": "Australia/Brisbane (GMT+10:00) Brisbane",
                "Australia/Hobart": "Australia/Hobart (GMT+10:00) Hobart",
                "Australia/Sydney": "Australia/Sydney (GMT+10:00) Sydney",
                "Australia/Lord_Howe": "Australia/Lord_Howe (GMT+10:30) Lord Howe Island",
                "Pacific/Auckland": "Pacific/Auckland (GMT+12:00) Auckland, Wellington",
                "Pacific/Chatham": "Pacific/Chatham (GMT+12:45) Chatham Islands",
                "Pacific/Tongatapu": "Pacific/Tongatapu (GMT+13:00) Nuku'alofa",
                "Pacific/Kiritimati": "Pacific/Kiritimati (GMT+14:00) Kiritimati",
                "Pacific/Norfolk": "Pacific/Norfolk (GMT+11:30) Norfolk Island",
                "Pacific/Midway": "Pacific/Midway (GMT-11:00) Midway Island, Samoa",
                "Pacific/Gambier": "Pacific/Gambier (GMT-09:00) Gambier Islands",
                "Pacific/Marquesas": "Pacific/Marquesas (GMT-09:30) Marquesas Islands",
                "Etc/GMT-12": "Etc/GMT-12 (GMT+12:00) Fiji, Marshall Is.",
                "Etc/GMT+11": "Etc/GMT+11 (GMT+11:00) Solomon Is., New Caledonia",
                "Etc/GMT+10": "Etc/GMT+10 (GMT-10:00) Hawaii",
                "Etc/GMT+8": "Etc/GMT+8 (GMT-08:00) Pitcairn Islands",
                "Atlantic/Azores": "Atlantic/Azores (GMT-01:00) Azores",
                "Atlantic/Cape_Verde": "Atlantic/Cape_Verde (GMT-01:00) Cape Verde Is.",
                "Atlantic/Stanley": "Atlantic/Stanley (GMT-04:00) Falkland Islands",
                "America/Noronha": "America/Noronha (GMT-02:00) Mid-Atlantic",
                "America/Godthab": "America/Godthab (GMT-03:00) Greenland",
                "America/Miquelon": "America/Miquelon (GMT-03:00) Miquelon, St. Pierre",
                "America/Montevideo": "America/Montevideo (GMT-03:00) Montevideo",
                "America/Araguaina": "America/Araguaina (GMT-03:00) UTC-3",
                "America/Argentina/Buenos_Aires": "America/Argentina/Buenos_Aires (GMT-03:00) Buenos Aires",
                "America/Sao_Paulo": "America/Sao_Paulo (GMT-03:00) Brasilia",
                "America/St_Johns": "America/St_Johns (GMT-03:30) Newfoundland",
                "America/Campo_Grande": "America/Campo_Grande (GMT-04:00) Brazil",
                "America/Caracas": "America/Caracas (GMT-04:30) Caracas",
                "America/Glace_Bay": "America/Glace_Bay (GMT-04:00) Atlantic Time (Canada)",
                "America/Goose_Bay": "America/Goose_Bay (GMT-04:00) Atlantic Time (Goose Bay)",
                "America/La_Paz": "America/La_Paz (GMT-04:00) La Paz",
                "America/Santiago": "America/Santiago (GMT-04:00) Santiago",
                "America/Bogota": "America/Bogota (GMT-05:00) Bogota, Lima, Quito, Rio Branco",
                "America/Havana": "America/Havana (GMT-05:00) Cuba",
                "America/New_York": "America/New_York (GMT-05:00) Eastern Time (US & Canada)",
                "America/Belize": "America/Belize (GMT-06:00) Saskatchewan, Central America",
                "America/Cancun": "America/Cancun (GMT-06:00) Guadalajara, Mexico City, Monterrey",
                "America/Chicago": "America/Chicago (GMT-06:00) Central Time (US & Canada)",
                "Chile/EasterIsland": "Chile/EasterIsland (GMT-06:00) Easter Island",
                "America/Chihuahua": "America/Chihuahua (GMT-07:00) Chihuahua, La Paz, Mazatlan",
                "America/Dawson_Creek": "America/Dawson_Creek (GMT-07:00) Arizona",
                "America/Denver": "America/Denver (GMT-07:00) Mountain Time (US & Canada)",
                "America/Ensenada": "America/Ensenada (GMT-08:00) Tijuana, Baja California",
                "America/Los_Angeles": "America/Los_Angeles (GMT-08:00) Pacific Time (US & Canada)",
                "America/Anchorage": "America/Anchorage (GMT-09:00) Alaska",
                "America/Adak": "America/Adak (GMT-10:00) Hawaii-Aleutian",
            }
        },
        {
            type: "section",
            display: "Email",
        },
        {
            name: "email",
            display: "Send new messages to",
            description: "Every new message is emailed here. Separate several addresses with commas.",
        },
        {
            name: "attach",
            display: "Attach the recording",
            description: "Include the audio file in the email.",
            type: "toggle",
            default: "on",
        },
        {
            name: "deletevoicemail",
            display: "Delete after emailing",
            description: "Remove the message from the box once the email has gone, so the email is the only copy.",
            type: "toggle",
        },
        {
            name: "pager",
            display: "Short notification to",
            description: "A second address that gets a brief alert without the recording, for example an SMS gateway. Optional.",
        },
        {
            type: "section",
            display: "Transcripts & summaries",
        },
        {
            name: "transcript_store",
            display: "Store transcript & summary",
            description: "Keep the text of each message alongside the recording, so you can read a voicemail instead of listening to it.",
            type: "toggle",
            default: "on",
        },
        {
            name: "ai_transcript",
            display: "Generate transcript",
            description: "Turn each voicemail into text you can read. Automatic transcribes new messages whenever transcripts are stored or your notification email includes them.",
            options: {
                auto: "Automatically",
                no: "Never",
            }
        },
        {
            name: "ai_summary",
            display: "Generate summary",
            description: "A short AI-written note of what the caller wanted, shown with the message and in the email. Needs a transcript.",
            options: {
                auto: "Automatically",
                no: "Never",
            }
        },
        {
            type: "section",
            display: "When listening from a phone",
        },
        {
            name: "envelope",
            display: "Read out the date and time",
            description: "Before each message.",
            type: "toggle",
            default: "on",
        },
        {
            name: "saycid",
            display: "Read out the caller's number",
            description: "Before each message.",
            type: "toggle",
            default: "on",
        },
        {
            name: "nextaftercmd",
            display: "Play messages back to back",
            description: "Go straight to the next message instead of returning to the menu.",
            type: "toggle",
        },
        {
            name: "autodeleteolder",
            display: "Make room automatically",
            description: "Delete the oldest messages when the box is over 90% full, so new callers can always leave one.",
            type: "toggle",
        },
        {
            type: "section",
            display: "For callers",
        },
        {
            name: "review",
            display: "Let callers review their message",
            description: "Callers can listen back and re-record before leaving it.",
            type: "toggle",
        },
        {
            name: "includeindbn",
            display: "List in the dial-by-name directory",
            description: "Callers can reach this box by spelling the name.",
            type: "toggle",
        },
        {
            name: "vm_on_operator",
            display: "Operator (press 0)",
            description: "Where to send a caller who presses 0 during the greeting instead of leaving a message.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            type: "section",
            display: "Advanced",
        },
        {
            name: "callback",
            display: "Call the caller back",
            description: "From the message menu on a phone, the box owner can ring the caller straight back.",
            options: {
                "": "Not allowed",
                "authenticated": "Allowed",
            }
        },
        {
            name: "dialout",
            display: "Dial out from the box",
            description: "From the message menu on a phone, the box owner can make an outside call.",
            options: {
                "": "Not allowed",
                "authenticated": "Allowed",
            }
        },
    ],
//queue
    queue: [
        //config
        {
            name: "qu_info_config",
            display: "Info",
            type: "info",
            value: "Configuration",
        },
        {
            name: "qu_name",
            display: "Name",
            description: "Please enter a name for the Queue e.g 'Failover Sales Queue' etc.",
        },
        /*    {
                name:       "xxx1",
                display:    "Play to the caller",
                options: {
                    1:     "Music on Hold",
                    2:     "Ringing",
                    3:     "Music on hold and then ringing once an agent is ringing",
                }
            },*/
        {
            name: "qu_ringinuse",
            display: "Ring when in use/offline",
            description: "Would you like this queue to attempt to dial agent extensions while they're offline or currently on a call wioth another caller?",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "qu_timeout",
            display: "Timeout",
            description: "Please enter a queue maximum duration, this means the maximum time any caller can stay in th your queue until they are disconnected or diverted to your 'On Timeout' destination below.",
        },
        {
            name: "musiconhold",
            display: "Hold music",
            description: "What callers hear while they wait for an agent. Leave on the account default unless this queue needs its own.",
            options: "dynamic",
        },
        {
            name: "qu_on_timeout",
            display: "On timeout",
            description: "Select where to divert timed out callers in your queue.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_exitkey",
            display: "On exit key",
            description: "Where to send a caller who presses the exit key while waiting.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_nobodyhome",
            display: "When nobody is logged in",
            description: "Where to send the caller when no agents are logged in to take calls.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_nofreemember",
            display: "When no agent is free",
            description: "Where to send the caller when every logged-in agent is busy.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_oncallback",
            display: "On callback",
            description: "Where to send the caller after they've requested a callback.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_full",
            display: "When the queue is full",
            description: "Where to send the caller when the queue has reached its maximum number of waiting callers.",
            options: "dynamic",
            type: "multipleSelect",
        },
        //agents
        {
            name: "qu_info_agents",
            display: "Info",
            description: "description pending",
            type: "info",
            value: "Agents",
        },
        {
            name: "strategy",
            display: "Strategy",
            description: "<b>Ring All:</b> rings all available extensions until one answers<br><b>Round Robin:</b> rings one extension at time, remembering which one was last ring<br><b>Random:</b> rings a random extension<br><b>Weighted Random:</b> rings a random extension but uses the agent's penalty as a weight<br><b>Least Recent:</b> ring the extension which was least recently called by this queue<br><b>Fewest Calls:</b> rings the extension with fewest completed calls from this queue",
            options: {
                RINGALL: "Ring all",
                RRMEMORY: "Roundrobin",
                RANDOM: "Random",
                WRANDOM: "Weighted Random",
                LEASTRECENT: "Least Recent",
                FEWESTCALLS: "Fewest Calls",
            }
        },
        {
            name: "agents",
            display: "Agents",
            description: "description pending",
            options: "dynamic",
            type: "multipleSelect",
            description: "Please select which agents you would like to be members of this Queue.",
        },
        {
            name: "qu_parameters",
            display: "Available Agent ringing",
            description: "Select the number of times you would like each agent to be called by the queue.",
            options: {
                tr: "Multiple Times",
                ntr: "Only Once",
            }
        },
        {
            name: "timeout",//q
            display: "Agent timeout",
            description: "How many seconds to ring an agent's phone before moving on or dial it again if the queue timeout is longer",
            'default': 30,
        },
        {
            name: "retry",//q
            display: "Wait time for retry",
            description: "After an agent has been dialed, how many seconds to wait before dialing it again",
            'default': 15,
        },
        //Periodic Announce
        {
            name: "qu_info_periodic_announce",
            display: "Info",
            type: "info",
            value: "Periodic Announce",
        },
        {
            name: "periodic_announce", //q
            display: "Periodic Announce",
            description: "Select the announces to be played. If you don't want announces, set to 0 (zero) the above Announce Frequency",
            options: "dynamic",
            type: "multipleSelect",
        },
        //Position/Time Announce
        {
            name: "qu_info_position",
            display: "Info",
            description: "description pending",
            type: "info",
            value: "Position/Time Announce",
        },
        {
            name: "announce_frequency", //q
            display: "Announce Frequency",
            description: "Number of seconds between announcements, set to 0 to completely disable any announcement of these messages",
        },
        {
            name: "announce_holdtime",//q
            display: "Announce holdtime",
            description: "Choose to announce the calculated hold time before being connected",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "announce_round_seconds",//q
            display: "Announce Round Seconds",
            description: "Rounding level for wait-time announcements. If 0, only minutes, not seconds, are announced. (For example, when set to 30, a wait time of 2:34 will be rounded to 2:30.)",
            options: {
                "0": "No rounding",
                "60": "Only minutes",
                "1": "1",
                "5": "5",
            }
        },
        {
            name: "announce_position",//q
            display: "Announce position",
            description: "Choose to announce the position of the caller in the queue",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "qu_youarenext_me_id",
            display: '"You are the next" message',
            description: "Please choose the media file to use for this announcement.",
            options: "dynamic"
        },
        {
            name: "qu_thereare_me_id",
            display: '"There are" message',
            description: "Please choose the media file to use for this announcement.",
            options: "dynamic"
        },
        {
            name: "qu_callswaiting_me_id",
            display: '"Calls waiting" message',
            description: "Please choose the media file to use for this announcement.",
            options: "dynamic"
        },
        {
            name: "qu_thankyou_me_id",
            display: '"Thank you" message',
            description: "Please choose the media file to use for this announcement.",
            options: "dynamic"
        },
        {
            name: "qu_holdtime_me_id",
            display: '"The current est. holdtime is" message',
            description: "Please choose the media file to use for this announcement.",
            options: "dynamic"
        },
    ],
    //port
    port: "dynamic",
    //mobilePort (MNP)
    mobilePort: [
        {
            name: "msisdn",
            display: "Mobile number",
            description: "The UK mobile number you want to port in, e.g. '07700900123'.",
        },
        {
            name: "pac",
            display: "PAC code",
            maxlength: 11,
            description: "The Porting Authorisation Code from your current mobile provider. Text 'PAC' to 65075 to get it — it usually arrives within minutes.",
        },
        {
            name: "port_date",
            display: "Port date",
            type: "date",
            minWorkingDaysFromToday: 2,
            defaultToMin: true,
            workingDaysOnly: true,
            description: "The date you want the number to move to us. Ports complete on working days only \u2014 not weekends or bank holidays. Earliest (and default) is 2 working days from today.",
        },
    ],
    //smsLog
    smsLog: [
        {
            name: "smsFrom",
            display: "From",
            options: "dynamic",
            description: "Choose one of your numbers or your company name for this SMS — or set a custom sender ID below.",
        },
        {
            name: "smsCustomFrom",
            display: "Custom sender ID (optional)",
            maxlength: 11,
            description: "Optional — overrides 'From' with a custom sender name, max 11 letters/numbers (e.g. 'GiantComms'). Note: recipients can't reply to a name, only to a number.",
        },
        {
            name: "smsTo",
            display: "To",
            description: "Please enter the recipients' telephone number to send this SMS to e.g '07900000000' or '+447900000000'",
        },
        {
            name: "smsMessage",
            display: "Message",
            type: "textarea",
            description: "Please enter your SMS content, limited to 165 characters.",
        },
    ],
    voiceCloud: "dynamic",
    appDevices: "dynamic",
//media=====================================================================
    media: [
        {
            name: "me_name",
            display: "Name",
            description: "Enter a name for this media file e.g. 'Welcome Message' or 'On Hold Music'.",
        },
        {
            name: "me_file",
            display: "Audio File",
            type: "file",
            description: "Please select an audio file to upload (WAV, MP3, OGG or GSM).",
        },
    ],
//condition====================================================================
    condition: [
        {
            name: "co_name",
            display: "Name",
            description: "A friendly label for this condition e.g. 'Office Hours' or 'Holidays'.",
        },
        {
            name: "co_type",
            display: "Type",
            description: "Week-time = active on certain days/hours of the week. Calendar = active on specific dates picked on a calendar. Specific dates = a short list of dates, optionally repeating every year. Caller ID = matches who is calling. UK Bank Holidays = a shared list we keep up to date for you — pick the region that matches where your business observes holidays.",
            options: {
                "WEEKTIME": "Week-time",
                "CALENDAR": "Calendar",
                "DATE":     "Specific dates",
                "CALLERID": "Caller ID",
                "BH_EW":    "UK Bank Holidays: England & Wales",
                "BH_SC":    "UK Bank Holidays: Scotland",
                "BH_NI":    "UK Bank Holidays: Northern Ireland",
                "BH_ALL":   "UK Bank Holidays: All combined"
            },
        },
    ],
    //conference=================================================================
    conference: [
        {
            name: "cr_name",
            display: "Name",
            description: "A friendly label e.g. 'Boardroom' or 'Sales Standup'.",
        },
        {
            name: "cr_number",
            display: "Conference number",
            description: "Internal extension that participants dial to enter the room. 2–8 digits (e.g. 887).",
        },
        {
            name: "pin",
            display: "Participant PIN (optional)",
            description: "If set, joiners must enter this PIN. Leave blank for an open room.",
        },
        {
            name: "adminpin",
            display: "Admin PIN (optional)",
            description: "Whoever joins with this PIN gets admin controls (mute others, end the call). Must differ from the participant PIN.",
        },
        {
            name: "starttime",
            display: "Available from (optional)",
            description: "Don't allow joins before this date/time. Leave blank for always-available.",
            type: "datetime",
        },
        {
            name: "endtime",
            display: "Available until (optional)",
            description: "Don't allow joins after this date/time. Leave blank for no expiry.",
            type: "datetime",
        },
        {
            name: "maxusers",
            display: "Max participants (optional)",
            description: "Cap how many people can be in the room at once. Leave blank for no limit.",
            type: "number",
            min: 2,
            max: 200,
        },
    ],
//callerIdBlacklist=============================================================
    callerIdBlacklist: [
        {
            name: "cb_callerid",
            display: "Number",
            description: "The caller ID to block. Use the number exactly as it would appear to your phones (e.g. +447700900123 or 07700900123)."
        },
        {
            name: "cb_reason",
            display: "Reason",
            description: "Optional note so future you remembers why this number was added."
        },
    ],
//END addFormData=========================================================================
};

//==============================================================================
var editFormData = {
//extension=====================================================================        
    extension: [
        {
            name: "ex_id",
        },
        {
            name: "ex_name",
            display: "Name",
            description: "Extension name e.g. 'Jon Doe' or 'Jon Doe - Director'.",
        },
        {
            name: "ex_cidnum",
            display: "Telephone Number for outbound presentation",
            options: "dynamic",
            description: "Telephone Number for outbound presentation",
        },
        // Additional destinations — the PBX's per-extension exits. Each exit is
        // only used while its switch is on (mirrors the PBX's "Active if checked").
        {
            name: "ex_onnoanswerstatus",
            display: "On no answer — active",
            description: "Use the \"On no answer\" destination below when this extension doesn't pick up.",
            type: "toggle",
        },
        {
            name: "ex_dest_noanswer",
            display: "On no answer",
            description: "Where the call goes when nobody answers, e.g. a voicemail box.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "ex_onbusystatus",
            display: "On busy — active",
            description: "Use the \"On busy\" destination below when this extension is already on a call.",
            type: "toggle",
        },
        {
            name: "ex_dest_busy",
            display: "On busy",
            description: "Where the call goes when the extension is busy.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "ex_onofflinestatus",
            display: "On offline — active",
            description: "Use the \"On offline\" destination below when this extension is not registered.",
            type: "toggle",
        },
        {
            name: "ex_dest_offline",
            display: "On offline",
            description: "Where the call goes when the extension is offline.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "ex_unconditionalstatus",
            display: "Unconditional forward — active",
            description: "Always send calls to the destination below instead of ringing this extension.",
            type: "toggle",
        },
        {
            name: "ex_dest_unconditional",
            display: "Unconditional forward to",
            description: "Where every call to this extension is sent while the switch above is on.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "ex_mailbox",
            display: "Voicemail",
            description: "If you would like voicemail to be accessable to this extension, please select it from the dropdown above.",
            options: "dynamic",
        },
        {
            name: "ex_mu_id",
            display: "Hold music",
            description: "What a caller hears when this extension puts them on hold. Leave on the account default unless this extension needs its own.",
            options: "dynamic",
        },
        {
            name: "ex_alertemail",
            display: "Alert notification email",
            description: "If you would like extension related emails to be sent to an email address, please enter it here.",
        },
        {
            name: "ex_alertwhenoffline",
            display: "Extension online/offline alerts",
            description: "This enables email notifications for the availibility status of this extension e.g 'Extension Offline' or 'Extension online'.",
            options: {
                off: "Disabled",
                on: "Enabled",
            }
        },
        {
            name: "password",
            display: "Password",
            description: "The password for this extension user, either enter your own or click the generate button to create a secure password for this extension.",
            type: "password"
        },
    ],
//customDestination=============================================================
    customDestination: [
        {
            name: "cu_id",
        },
        {
            name: "cu_name",
            display: "Label",
            description: "A friendly name for this destination.",
        },
        {
            name: "cu_ct_id",
            display: "Destination Type",
            description: "The type of custom destination.",
            options: "dynamic",
        },
        {
            name: "cu_param1",
            display: "Phone Number",
            description: "The UK landline (01/02), 03 or UK mobile (07) number to forward calls to. Spaces and +44 are fine; premium-rate, 08 and international numbers aren't allowed.",
        },
        {
            name: "cu_param2",
            display: "Caller ID Presentation",
            description: "What caller ID the recipient sees.",
            options: {
                "ORIGINAL": "Show original caller's number",
                "INCOMINGDID": "Show the DID that was dialled",
            }
        },
        {
            name: "cu_param3",
            display: "Ring Timeout (seconds)",
            description: "How long to ring before giving up.",
        },
    ],

//huntList=============================================================        
    huntList: [
        {
            name: "hu_id",
        },
        {
            name: "hu_name",
            display: "Name",
            description: "Please label your new Hunt List e.g 'Sales Team' or 'Support Team' etc.",
        },
        {
            name: "hu_number",
            display: "Number",
            description: "Optional internal number for this hunt list.",
        },
        {
            name: "hu_type",
            display: "Type",
            description: "Ring All = ring all destinations simultaneously. Sequence = ring in listed order. Cycle = ring each in turn, looping.",
            options: {RINGALL: "Ring All", "RINGALL-LOOP": "Ring All (Loop)", SEQUENCE: "Sequence", CYCLE: "Cycle"},
        },
        {
            name: "hu_ringtime",
            display: "Ring Time (seconds)",
            description: "How long to ring each destination before moving on.",
            default: "30",
        },
        {
            name: "hu_dialtimeout",
            display: "Overall Dial Timeout (seconds)",
            description: "Total time to keep attempting destinations before giving up.",
            default: "3600",
        },
        {
            name: "hu_confirmmessage_id",
            display: "Confirmation message",
            description: "Played to whoever answers, before they press a key to accept the call. Leave on Default for the standard prompt. Only used when Request Confirmation is on.",
            options: "dynamic",
        },
        {
            name: "hu_checkinuse",
            display: "Skip Busy Destinations",
            description: "Skip destinations that are currently on a call.",
            type: "toggle",
        },
        {
            name: "hu_checkoffline",
            display: "Skip Offline Destinations",
            description: "Skip destinations that are not registered / offline.",
            type: "toggle",
        },
        {
            name: "hu_requestconfirm",
            display: "Request Confirmation",
            description: "Require the answerer to press a key to accept the call.",
            type: "toggle",
        },
        {
            name: "hu_usemoh",
            display: "Music on Hold",
            description: "Play music on hold to the caller while ringing.",
            type: "toggle",
        },
        {
            name: "hu_allowredirect",
            display: "Allow Redirect",
            description: "Allow destinations to redirect the call.",
            type: "toggle",
        },
        {
            name: "hu_allowadditionaldestinations",
            display: "Allow Additional Destinations",
            description: "Allow extra destinations to be added at runtime.",
            type: "toggle",
        },
        {
            name: "hu_allowfmfm",
            display: "Allow Follow-Me",
            description: "Allow Follow-Me (find-me-follow-me) for destinations.",
            type: "toggle",
        },
        {
            name: "hu_fastdialing",
            display: "Fast Dialing",
            description: "Skip delays between dial attempts.",
            type: "toggle",
        },
        {
            name: "hu_usecustomdetails",
            display: "Use Custom Caller Details",
            description: "Override default caller-id details for this hunt list.",
            type: "toggle",
        },
        {
            name: "hu_extensions",
            display: "Destinations",
            description: "Please add which extensions or custom destinations you would like to be called when callers are diverted to your Hunt List.",
            options: "dynamic",
            type: "checkbox"
        },
        {
            name: "hu_on_timeout",
            display: "If nobody answers",
            description: "Where to send the caller once every destination in the hunt list has been tried without an answer.",
            options: "dynamic",
            type: "multipleSelect",
        },

    ],
//destination===================================================================
    destination: [
        {
            name: "di_id",
        },
        {
            name: "di_comment",
            display: "Label",
            description: "Enter a label for this telephone number e.g 'Main Company Line'",

        },
        {
            type: "section",
            display: "Recording & AI",
        },
        {
            name: "di_recording",
            display: "Call recording",
            description: "Record inbound calls to this number.",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "di_transcript",
            display: "Transcription",
            description: "Automatically transcribe recorded calls so they're searchable and readable.",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "di_aisummary",
            display: "AI call summary",
            description: "Generate a short AI summary of each recorded call.",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "di_aisentiment",
            display: "AI sentiment",
            description: "Tag each recorded call with an AI sentiment read (positive / neutral / negative).",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "di_emailrecording",
            display: "Email recordings to",
            description: "Email a copy of each recording to this address. Leave blank to disable.",
        },
        {
            name: "di_minemailrecording",
            display: "Minimum length to email (seconds)",
            description: "Skip emailing very short calls — recordings shorter than this many seconds won't be sent. 0 emails everything.",
        },
        {
            type: "section",
            display: "Fax to email",
        },
        {
            name: "di_fax",
            display: "Fax to email",
            description: "Receive inbound faxes on this number as emailed PDFs.",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "di_fax_email",
            display: "Fax email address",
            description: "Where inbound faxes for this number should be delivered.",
        },
        {
            type: "section",
            display: "SMS",
            showIf: isMobileDid,
        },
        {
            name: "di_sms_store",
            display: "Store SMS messages",
            description: "Keep a record of SMS messages received on this number.",
            showIf: isMobileDid,
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "di_smsemail",
            display: "SMS to email",
            description: "Email inbound SMS messages for this number to this address.",
            showIf: isMobileDid,
        },
        {
            name: "di_smsprotocol",
            display: "SMS delivery protocol",
            description: "Advanced: delivery method for inbound SMS (e.g. an HTTP webhook). Leave as-is unless you're wiring SMS into another system.",
            showIf: isMobileDid,
        },
        {
            name: "di_smsfromfield",
            display: "SMS ‘from’ field",
            description: "Advanced: the field name your SMS webhook expects for the sender.",
            showIf: isMobileDid,
        },
        {
            name: "di_smstofield",
            display: "SMS ‘to’ field",
            description: "Advanced: the field name your SMS webhook expects for the recipient.",
            showIf: isMobileDid,
        },
        {
            name: "di_smsbodyfield",
            display: "SMS body field",
            description: "Advanced: the field name your SMS webhook expects for the message text.",
            showIf: isMobileDid,
        },
        {
            type: "section",
            display: "Call routing",
        },
        {
            name: "di_destination",
            display: "Destination",
            description: "Please select a destination for this telephone number, you can select from created extensions, hunt lists, IVR(s), Queues and much more.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "di_unconditionalstatus",
            display: "Unconditional divert — active",
            description: "While active, every call to this number goes to the unconditional destination below instead of the normal destination.",
            type: "toggle",
        },
        {
            name: "di_unconditional",
            display: "Unconditional destination",
            description: "Where every call to this number goes while the unconditional divert is active.",
            options: "dynamic",
            type: "multipleSelect",
        },
    ],
//phone
    phone: [
        {
            name: "ph_id",
        },
        {
            name: "ph_name",
            display: "Name",
            description: "Unique label for your provisioned device e.g 'Jon Doe's Yealink T46S' or 'Main Office Phone'.",
        },
        {
            name: "ph_mac",
            display: "MAC",
            description: "Please enter the MAC Address for this device, you can usually find this on the back or underside of your hardware.",
            mask: {regex: "([0-9A-Fa-f]{2}:){5}([0-9A-Fa-f]{2})"},
        },
        {
            name: "ph_pm_id",
            display: "Phone Model",
            description: "Please select from the list of supported autoprovisionable devices, Yealink is currently the only manufacturarer that we are able to deploy with 'Zero-touch'.",
            options: "dynamic",
            onChange: function (event) {
                var linesCount = $(this).find('option:selected').data("pm_endline");
                $('[name^="ph_line"]').prop('disabled', false);
                for (var i = linesCount; i < 10; i++) {
                    $('[name="ph_line' + (i + 1) + '_ex_id"]').prop('disabled', true);
                }
            }
        },
        {
            name: "ph_line0_ex_id",
            display: "Line 1 Extension",
            description: "Please select your 1st phone line for this device. e.g '101 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line1_ex_id",
            display: "Line 2 Extension",
            description: "Please select your 1st phone line for this device. e.g '102 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line2_ex_id",
            display: "Line 3 Extension",
            description: "Please select your 1st phone line for this device. e.g '103 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line3_ex_id",
            display: "Line 4 Extension",
            description: "Please select your 1st phone line for this device. e.g '104 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line4_ex_id",
            display: "Line 5 Extension",
            description: "Please select your 1st phone line for this device. e.g '105 - Jon Doe'",
            options: "dynamic",
        },
        {
            name: "ph_line5_ex_id",
            display: "Line 6 Extension",
            description: "Please select your 1st phone line for this device. e.g '106 - Jon Doe'",
            options: "dynamic",
        },
    ],
    shortNumber: [
        {
            name: "sn_id",
        },
        {
            name: "sn_number",
            display: "Number",
            description: "Please enter your new short number code, after this new short number has been created, you can dial the short number code to dial your real destination.",
        },
        {
            name: "sn_destnumber",
            display: "Destination Number",
            description: "Please enter the destination number e.g '03330000000' or '07900000000'.",
        },
        {
            name: "sn_comment",
            display: "Comment",
            description: "Please name your new short number e.g 'Jon Doe Mobile Speed Dial' etc.",
        },

    ],
//featureCode==============================================================================
    featureCode: [
        {
            name: "fe_id",
        },
        {
            name: "fe_code",
            display: "Code",
            description: "Please enter your new feature code number e.g '659*'",
        },
        {
            name: "fe_comment",
            display: "Comment",
            description: "Please name your new Feature code e.g 'Withheld dial",
        },
    ],

//ivr
    ivr: [
        {
            name: "iv_id",
        },
        {
            name: "iv_name",
            display: "Name",
            description: "Please name your new IVR e.g 'Main Welcome IVR'.",
        },
        {
            name: "iv_me_id",
            display: "Welcome message",
            description: "Please select your IVR welcome message here, this is the media file your caller will hear first before selecting an option.",
            options: "dynamic",
        },
        {
            name: "iv_options_me",
            display: "Options message",
            description: "Played after the welcome message to read out the menu options. Leave blank if the welcome message already covers them.",
            options: "dynamic",
        },
        {
            name: "iv_timeout",
            display: "Timeout",
            description: "Enter the number of seconds your caller has to make their IVR number selection.",
        },
        {
            name: "iv_maxloops",
            display: "Max Loops",
            description: "Enter the maximum number of IVR loops given to the caller before the caller is disconnected for either not selecting an option or trying to select an invalid option.",
        },
        {
            name: "iv_ivr_1",
            display: "Pressing 1",
            description: "Enter the destination to route your caller to when they press <b>'1'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_2",
            display: "Pressing 2",
            description: "Enter the destination to route your caller to when they press <b>'2'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_3",
            display: "Pressing 3",
            description: "Enter the destination to route your caller to when they press <b>'3'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_4",
            display: "Pressing 4",
            description: "Enter the destination to route your caller to when they press <b>'4'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_5",
            display: "Pressing 5",
            description: "Enter the destination to route your caller to when they press <b>'5'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_6",
            display: "Pressing 6",
            description: "Enter the destination to route your caller to when they press <b>'6'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_7",
            display: "Pressing 7",
            description: "Enter the destination to route your caller to when they press <b>'7'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_8",
            display: "Pressing 8",
            description: "Enter the destination to route your caller to when they press <b>'8'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_9",
            display: "Pressing 9",
            description: "Enter the destination to route your caller to when they press <b>'9'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_0",
            display: "Pressing 0",
            description: "Enter the destination to route your caller to when they press <b>'0'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_star",
            display: "Pressing Star",
            description: "Enter the destination to route your caller to when they press <b>'*'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_sharp",
            display: "Pressing Sharp",
            description: "Enter the destination to route your caller to when they press <b>'#'</b> when presented with options on their keypad.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_timeout",
            display: "On timeout",
            description: "Where to send the caller if they don't press anything before the menu times out.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "iv_ivr_wrong",
            display: "On invalid key",
            description: "Where to send the caller after they press a key that isn't one of the options.",
            options: "dynamic",
            type: "multipleSelect",
        },
    ],

//voicemail
    voicemail: [
        {
            name: "uniqueid",
        },
        {
            type: "section",
            display: "The box",
        },
        {
            name: "fullname",
            display: "Name",
            description: "Whose box this is, e.g. 'Reception' or 'Jon Doe'. Shown in lists and read out in the dial-by-name directory.",
        },
        {
            name: "mailbox",
            display: "Mailbox number",
            description: "The number callers and phones use to reach it, usually the same as the extension, e.g. 5000.",
        },
        {
            name: "password",
            display: "PIN",
            description: "Four digits, needed to listen from a handset. Leave blank for 0000.",
        },
        {
            name: "welcomeoption",
            display: "Greeting",
            description: "What callers hear before the beep. 'Automatic' reads the name or number; 'instructions' adds how to leave a message.",
            options: {
                "Auto": "Automatic, no instructions",
                "AutoInst": "Automatic, with instructions",
                "Inst": "Instructions only",
                "Silent": "Nothing, just the beep",
            }
        },
        {
            name: "language",
            display: "Language",
            description: "The voice used for prompts in this box.",
            options: {
                "": "Account default",
                "en_GB": "English (UK)",
            }
        },
        {
            name: "timezone",
            display: "Time zone",
            description: "Used when a message's date and time is read out or emailed.",
            options: {
                "": "Account default",
                "Europe/London": "Europe/London (GMT) London",
                "Europe/Belfast": "Europe/Belfast (GMT) Belfast",
                "Europe/Dublin": "Europe/Dublin (GMT) Dublin",
                "Europe/Lisbon": "Europe/Lisbon (GMT) Lisbon",
                "Europe/Amsterdam": "Europe/Amsterdam (GMT+01:00) Amsterdam, Berlin, Rome, Stockholm, Vienna",
                "Europe/Brussels": "Europe/Brussels (GMT+01:00) Brussels, Copenhagen, Madrid, Paris",
                "Europe/Belgrade": "Europe/Belgrade (GMT+01:00) Belgrade, Budapest, Prague",
                "Europe/Minsk": "Europe/Minsk (GMT+02:00) Minsk",
                "Europe/Moscow": "Europe/Moscow (GMT+03:00) Moscow, St. Petersburg",
                "Africa/Abidjan": "Africa/Abidjan (GMT) Monrovia, Reykjavik",
                "Africa/Algiers": "Africa/Algiers (GMT+01:00) West Central Africa",
                "Africa/Windhoek": "Africa/Windhoek (GMT+01:00) Windhoek",
                "Africa/Cairo": "Africa/Cairo (GMT+02:00) Cairo",
                "Africa/Blantyre": "Africa/Blantyre (GMT+02:00) Harare, Pretoria",
                "Africa/Addis_Ababa": "Africa/Addis_Ababa (GMT+03:00) Nairobi",
                "Asia/Beirut": "Asia/Beirut (GMT+02:00) Beirut",
                "Asia/Damascus": "Asia/Damascus (GMT+02:00) Syria",
                "Asia/Gaza": "Asia/Gaza (GMT+02:00) Gaza",
                "Asia/Jerusalem": "Asia/Jerusalem (GMT+02:00) Jerusalem",
                "Asia/Tehran": "Asia/Tehran (GMT+03:30) Tehran",
                "Asia/Dubai": "Asia/Dubai (GMT+04:00) Abu Dhabi, Muscat",
                "Asia/Yerevan": "Asia/Yerevan (GMT+04:00) Yerevan",
                "Asia/Kabul": "Asia/Kabul (GMT+04:30) Kabul",
                "Asia/Tashkent": "Asia/Tashkent (GMT+05:00) Tashkent",
                "Asia/Yekaterinburg": "Asia/Yekaterinburg (GMT+05:00) Ekaterinburg",
                "Asia/Kolkata": "Asia/Kolkata (GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi",
                "Asia/Katmandu": "Asia/Katmandu (GMT+05:45) Kathmandu",
                "Asia/Dhaka": "Asia/Dhaka (GMT+06:00) Astana, Dhaka",
                "Asia/Novosibirsk": "Asia/Novosibirsk (GMT+06:00) Novosibirsk",
                "Asia/Rangoon": "Asia/Rangoon (GMT+06:30) Yangon",
                "Asia/Bangkok": "Asia/Bangkok (GMT+07:00) Bangkok, Hanoi, Jakarta",
                "Asia/Krasnoyarsk": "Asia/Krasnoyarsk (GMT+07:00) Krasnoyarsk",
                "Asia/Hong_Kong": "Asia/Hong_Kong (GMT+08:00) Beijing, Hong Kong, Manila",
                "Asia/Irkutsk": "Asia/Irkutsk (GMT+08:00) Irkutsk, Ulaan Bataar",
                "Asia/Seoul": "Asia/Seoul (GMT+09:00) Seoul",
                "Asia/Tokyo": "Asia/Tokyo (GMT+09:00) Osaka, Sapporo, Tokyo",
                "Asia/Yakutsk": "Asia/Yakutsk (GMT+09:00) Yakutsk",
                "Asia/Vladivostok": "Asia/Vladivostok (GMT+10:00) Vladivostok",
                "Asia/Magadan": "Asia/Magadan (GMT+11:00) Magadan",
                "Asia/Anadyr": "Asia/Anadyr (GMT+12:00) Anadyr, Kamchatka",
                "Australia/Perth": "Australia/Perth (GMT+08:00) Perth",
                "Australia/Eucla": "Australia/Eucla (GMT+08:45) Eucla",
                "Australia/Adelaide": "Australia/Adelaide (GMT+09:30) Adelaide",
                "Australia/Darwin": "Australia/Darwin (GMT+09:30) Darwin",
                "Australia/Brisbane": "Australia/Brisbane (GMT+10:00) Brisbane",
                "Australia/Hobart": "Australia/Hobart (GMT+10:00) Hobart",
                "Australia/Sydney": "Australia/Sydney (GMT+10:00) Sydney",
                "Australia/Lord_Howe": "Australia/Lord_Howe (GMT+10:30) Lord Howe Island",
                "Pacific/Auckland": "Pacific/Auckland (GMT+12:00) Auckland, Wellington",
                "Pacific/Chatham": "Pacific/Chatham (GMT+12:45) Chatham Islands",
                "Pacific/Tongatapu": "Pacific/Tongatapu (GMT+13:00) Nuku'alofa",
                "Pacific/Kiritimati": "Pacific/Kiritimati (GMT+14:00) Kiritimati",
                "Pacific/Norfolk": "Pacific/Norfolk (GMT+11:30) Norfolk Island",
                "Pacific/Midway": "Pacific/Midway (GMT-11:00) Midway Island, Samoa",
                "Pacific/Gambier": "Pacific/Gambier (GMT-09:00) Gambier Islands",
                "Pacific/Marquesas": "Pacific/Marquesas (GMT-09:30) Marquesas Islands",
                "Etc/GMT-12": "Etc/GMT-12 (GMT+12:00) Fiji, Marshall Is.",
                "Etc/GMT+11": "Etc/GMT+11 (GMT+11:00) Solomon Is., New Caledonia",
                "Etc/GMT+10": "Etc/GMT+10 (GMT-10:00) Hawaii",
                "Etc/GMT+8": "Etc/GMT+8 (GMT-08:00) Pitcairn Islands",
                "Atlantic/Azores": "Atlantic/Azores (GMT-01:00) Azores",
                "Atlantic/Cape_Verde": "Atlantic/Cape_Verde (GMT-01:00) Cape Verde Is.",
                "Atlantic/Stanley": "Atlantic/Stanley (GMT-04:00) Falkland Islands",
                "America/Noronha": "America/Noronha (GMT-02:00) Mid-Atlantic",
                "America/Godthab": "America/Godthab (GMT-03:00) Greenland",
                "America/Miquelon": "America/Miquelon (GMT-03:00) Miquelon, St. Pierre",
                "America/Montevideo": "America/Montevideo (GMT-03:00) Montevideo",
                "America/Araguaina": "America/Araguaina (GMT-03:00) UTC-3",
                "America/Argentina/Buenos_Aires": "America/Argentina/Buenos_Aires (GMT-03:00) Buenos Aires",
                "America/Sao_Paulo": "America/Sao_Paulo (GMT-03:00) Brasilia",
                "America/St_Johns": "America/St_Johns (GMT-03:30) Newfoundland",
                "America/Campo_Grande": "America/Campo_Grande (GMT-04:00) Brazil",
                "America/Caracas": "America/Caracas (GMT-04:30) Caracas",
                "America/Glace_Bay": "America/Glace_Bay (GMT-04:00) Atlantic Time (Canada)",
                "America/Goose_Bay": "America/Goose_Bay (GMT-04:00) Atlantic Time (Goose Bay)",
                "America/La_Paz": "America/La_Paz (GMT-04:00) La Paz",
                "America/Santiago": "America/Santiago (GMT-04:00) Santiago",
                "America/Bogota": "America/Bogota (GMT-05:00) Bogota, Lima, Quito, Rio Branco",
                "America/Havana": "America/Havana (GMT-05:00) Cuba",
                "America/New_York": "America/New_York (GMT-05:00) Eastern Time (US & Canada)",
                "America/Belize": "America/Belize (GMT-06:00) Saskatchewan, Central America",
                "America/Cancun": "America/Cancun (GMT-06:00) Guadalajara, Mexico City, Monterrey",
                "America/Chicago": "America/Chicago (GMT-06:00) Central Time (US & Canada)",
                "Chile/EasterIsland": "Chile/EasterIsland (GMT-06:00) Easter Island",
                "America/Chihuahua": "America/Chihuahua (GMT-07:00) Chihuahua, La Paz, Mazatlan",
                "America/Dawson_Creek": "America/Dawson_Creek (GMT-07:00) Arizona",
                "America/Denver": "America/Denver (GMT-07:00) Mountain Time (US & Canada)",
                "America/Ensenada": "America/Ensenada (GMT-08:00) Tijuana, Baja California",
                "America/Los_Angeles": "America/Los_Angeles (GMT-08:00) Pacific Time (US & Canada)",
                "America/Anchorage": "America/Anchorage (GMT-09:00) Alaska",
                "America/Adak": "America/Adak (GMT-10:00) Hawaii-Aleutian",
            }
        },
        {
            type: "section",
            display: "Email",
        },
        {
            name: "email",
            display: "Send new messages to",
            description: "Every new message is emailed here. Separate several addresses with commas.",
        },
        {
            name: "attach",
            display: "Attach the recording",
            description: "Include the audio file in the email.",
            type: "toggle",
            default: "on",
        },
        {
            name: "deletevoicemail",
            display: "Delete after emailing",
            description: "Remove the message from the box once the email has gone, so the email is the only copy.",
            type: "toggle",
        },
        {
            name: "pager",
            display: "Short notification to",
            description: "A second address that gets a brief alert without the recording, for example an SMS gateway. Optional.",
        },
        {
            type: "section",
            display: "Transcripts & summaries",
        },
        {
            name: "transcript_store",
            display: "Store transcript & summary",
            description: "Keep the text of each message alongside the recording, so you can read a voicemail instead of listening to it.",
            type: "toggle",
            default: "on",
        },
        {
            name: "ai_transcript",
            display: "Generate transcript",
            description: "Turn each voicemail into text you can read. Automatic transcribes new messages whenever transcripts are stored or your notification email includes them.",
            options: {
                auto: "Automatically",
                no: "Never",
            }
        },
        {
            name: "ai_summary",
            display: "Generate summary",
            description: "A short AI-written note of what the caller wanted, shown with the message and in the email. Needs a transcript.",
            options: {
                auto: "Automatically",
                no: "Never",
            }
        },
        {
            type: "section",
            display: "When listening from a phone",
        },
        {
            name: "envelope",
            display: "Read out the date and time",
            description: "Before each message.",
            type: "toggle",
            default: "on",
        },
        {
            name: "saycid",
            display: "Read out the caller's number",
            description: "Before each message.",
            type: "toggle",
            default: "on",
        },
        {
            name: "nextaftercmd",
            display: "Play messages back to back",
            description: "Go straight to the next message instead of returning to the menu.",
            type: "toggle",
        },
        {
            name: "autodeleteolder",
            display: "Make room automatically",
            description: "Delete the oldest messages when the box is over 90% full, so new callers can always leave one.",
            type: "toggle",
        },
        {
            type: "section",
            display: "For callers",
        },
        {
            name: "review",
            display: "Let callers review their message",
            description: "Callers can listen back and re-record before leaving it.",
            type: "toggle",
        },
        {
            name: "includeindbn",
            display: "List in the dial-by-name directory",
            description: "Callers can reach this box by spelling the name.",
            type: "toggle",
        },
        {
            name: "vm_on_operator",
            display: "Operator (press 0)",
            description: "Where to send a caller who presses 0 during the greeting instead of leaving a message.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            type: "section",
            display: "Advanced",
        },
        {
            name: "callback",
            display: "Call the caller back",
            description: "From the message menu on a phone, the box owner can ring the caller straight back.",
            options: {
                "": "Not allowed",
                "authenticated": "Allowed",
            }
        },
        {
            name: "dialout",
            display: "Dial out from the box",
            description: "From the message menu on a phone, the box owner can make an outside call.",
            options: {
                "": "Not allowed",
                "authenticated": "Allowed",
            }
        },
    ],
//queue
    queue: [
        {
            name: "qu_id",
        },
        //config
        {
            name: "qu_info_config",
            display: "Info",
            type: "info",
            value: "Configuration",
        },
        {
            name: "qu_name",
            display: "Name",
        },
        /*    {
                name:       "xxx1",
                display:    "Play to the caller",
                options: {
                    1:     "Music on Hold",
                    2:     "Ringing",
                    3:     "Music on hold and then ringing once an agent is ringing",
                }
            },*/
        {
            name: "qu_ringinuse",
            display: "Ring when in use/offline",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "qu_timeout",
            display: "Timeout",
        },
        {
            name: "musiconhold",
            display: "Hold music",
            description: "What callers hear while they wait for an agent. Leave on the account default unless this queue needs its own.",
            options: "dynamic",
        },
        {
            name: "qu_on_timeout",
            display: "On timeout",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_exitkey",
            display: "On exit key",
            description: "Where to send a caller who presses the exit key while waiting.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_nobodyhome",
            display: "When nobody is logged in",
            description: "Where to send the caller when no agents are logged in to take calls.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_nofreemember",
            display: "When no agent is free",
            description: "Where to send the caller when every logged-in agent is busy.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_oncallback",
            display: "On callback",
            description: "Where to send the caller after they've requested a callback.",
            options: "dynamic",
            type: "multipleSelect",
        },
        {
            name: "qu_on_full",
            display: "When the queue is full",
            description: "Where to send the caller when the queue has reached its maximum number of waiting callers.",
            options: "dynamic",
            type: "multipleSelect",
        },
        //agents
        {
            name: "qu_info_agents",
            display: "Info",
            type: "info",
            value: "Agents",
        },
        {
            name: "strategy",
            display: "Strategy",
            options: {
                RINGALL: "Ring all",
                RRMEMORY: "Roundrobin",
                RANDOM: "Random",
                WRANDOM: "Weighted random",
                LEASTRECENT: "Least Recent",
                FEWESTCALLS: "Fewest Calls",
            }
        },
        {
            name: "agents",
            display: "Agents",
            options: "dynamic",
            type: "multipleSelect",
            description: "test agents description",
        },
        {
            name: "qu_parameters",
            display: "Available Agent ringing",
            options: {
                tr: "Multiple Times",
                ntr: "Only Once",
            }
        },
        {
            name: "timeout",//q
            display: "Agent timeout",
            'default': 30,
        },
        {
            name: "retry",//q
            display: "Wait time for retry",
            'default': 15,
        },
        //Periodic Announce
        {
            name: "qu_info_periodic_announce",
            display: "Info",
            type: "info",
            value: "Periodic Announce",
        },
        {
            name: "periodic_announce", //q
            display: "Periodic Announce",
            options: "dynamic",
            type: "multipleSelect",
        },
        //Position/Time Announce
        {
            name: "qu_info_position",
            display: "Info",
            type: "info",
            value: "Position/Time Announce",
        },
        {
            name: "announce_frequency", //q
            display: "Announce Frequency",
        },
        {
            name: "announce_holdtime",//q
            display: "Announce holdtime",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "announce_round_seconds",//q
            display: "Announce Round Seconds",
            options: {
                "0": "No rounding",
                "60": "Only minutes",
                "1": "1",
                "5": "5",
            }
        },
        {
            name: "announce_position",//q
            display: "Announce position",
            options: {
                no: "Disabled",
                yes: "Enabled",
            }
        },
        {
            name: "qu_youarenext_me_id",
            display: '"You are the next" message',
            options: "dynamic"
        },
        {
            name: "qu_thereare_me_id",
            display: '"There are" message',
            options: "dynamic"
        },
        {
            name: "qu_callswaiting_me_id",
            display: '"Calls waiting" message',
            options: "dynamic"
        },
        {
            name: "qu_thankyou_me_id",
            display: '"Thank you" message',
            options: "dynamic"
        },
        {
            name: "qu_holdtime_me_id",
            display: '"The current est. holdtime is" message',
            options: "dynamic"
        },
    ],
    apiAccess: [
        {
            name: "se_id",
        },
        {
            name: "se_code",
        },
        {
            name: "se_value",
            display: "API Key",
            type: "password",
        }
    ],

    //port
    port: "dynamic",
//media=====================================================================
    media: [
        {
            name: "me_id",
        },
        {
            name: "me_name",
            display: "Name",
            description: "Enter a name for this media file.",
        },
        {
            name: "me_file",
            display: "Replace Audio File",
            type: "file",
            description: "Optionally select a new audio file to replace the existing one (WAV, MP3, OGG or GSM).",
        },
    ],
//condition====================================================================
    condition: [
        {
            name: "co_id",
        },
        {
            name: "co_extendedinfos",
            display: "Time Ranges",
            description: "Each row defines a day of the week and the active hours. Times are 24-hour (e.g. 08:00, 17:30).",
            type: "timeRanges",
        },
        {
            name: "co_dest_true",
            display: "If it matches",
            description: "Chain of destinations followed when the current time falls inside one of the ranges above. Add a step for each destination.",
            type: "destinationChain",
            branch: "true",
        },
        {
            name: "co_dest_false",
            display: "Otherwise",
            description: "Chain of destinations followed at all other times.",
            type: "destinationChain",
            branch: "false",
        },
    ],
//conference====================================================================
    conference: [
        { name: "cr_id" },
        {
            name: "cr_name",
            display: "Name",
            description: "A friendly label e.g. 'Boardroom' or 'Sales Standup'.",
        },
        {
            name: "cr_number",
            display: "Conference number",
            description: "Internal extension that participants dial to enter the room.",
        },
        {
            name: "pin",
            display: "Participant PIN (optional)",
            description: "If set, joiners must enter this PIN. Leave blank for an open room.",
        },
        {
            name: "adminpin",
            display: "Admin PIN (optional)",
            description: "Whoever joins with this PIN gets admin controls (mute others, end the call).",
        },
        {
            name: "starttime",
            display: "Available from (optional)",
            description: "Don't allow joins before this date/time. Blank = always available.",
            type: "datetime",
        },
        {
            name: "endtime",
            display: "Available until (optional)",
            description: "Don't allow joins after this date/time. Blank = no expiry.",
            type: "datetime",
        },
        {
            name: "maxusers",
            display: "Max participants (optional)",
            description: "Cap how many people can be in the room at once. Leave blank for no limit.",
            type: "number",
            min: 2,
            max: 200,
        },
    ],
//callerIdBlacklist=============================================================
    callerIdBlacklist: [
        { name: "cb_id", type: "hidden" },
        {
            name: "cb_callerid",
            display: "Number",
            description: "The caller ID to block."
        },
        {
            name: "cb_reason",
            display: "Reason",
            description: "Optional note."
        },
    ],
//END editFormData=========================================================================
};

var waitingFor = {};
var requestSend = {};
var cacheKeys = {
    "ph_line0_ex_id": "ph_lineX_ex_id",
    "ph_line1_ex_id": "ph_lineX_ex_id",
    "ph_line2_ex_id": "ph_lineX_ex_id",
    "ph_line3_ex_id": "ph_lineX_ex_id",
    "ph_line4_ex_id": "ph_lineX_ex_id",
    "ph_line5_ex_id": "ph_lineX_ex_id",

    "iv_ivr_1": "iv_ivr_X",
    "iv_ivr_2": "iv_ivr_X",
    "iv_ivr_3": "iv_ivr_X",
    "iv_ivr_4": "iv_ivr_X",
    "iv_ivr_5": "iv_ivr_X",
    "iv_ivr_6": "iv_ivr_X",
    "iv_ivr_7": "iv_ivr_X",
    "iv_ivr_8": "iv_ivr_X",
    "iv_ivr_9": "iv_ivr_X",
    "iv_ivr_0": "iv_ivr_X",
    "iv_ivr_star": "iv_ivr_X",
    "iv_ivr_sharp": "iv_ivr_X",

    qu_youarenext_me_id: "qu_media",
    qu_thereare_me_id: "qu_media",
    qu_callswaiting_me_id: "qu_media",
    qu_thankyou_me_id: "qu_media",
    qu_holdtime_me_id: "qu_media",
    periodic_announce: "qu_media_1",

};
var cache = {};

$(document).ready(function () {

    // Move modal to body so it's not trapped inside a WHMCS container
    // that creates a stacking context above the backdrop
    $('#giantModal').appendTo('body');

    // Stop any inline media-card audio when the modal is dismissed (close
    // button, click-outside, Esc) — otherwise the audio keeps playing in the
    // background even though the customer can no longer see/control it.
    $('#giantModal').on('hide.bs.modal', function () {
        (window._giantMwaveAudios || []).forEach(function (a) {
            try { a.pause(); a.currentTime = 0; } catch (e) {}
        });
        window._giantMwaveAudios = [];
    });

    $('#giantModal').on('show.bs.modal', function (event) {

        var button = $(event.relatedTarget);

        if (!button.hasClass("tile")) {
            return;
        }

        var tileName = button.data('name');
        // Title = the tile's icon + label, not its state line.
        var $ico = button.find('i').first(), $lbl = button.find('.tile-label').first();
        var title = ($ico.length && $lbl.length) ? ($ico[0].outerHTML + ' ' + $lbl[0].outerHTML) : button.html();
        var modal = $(this);
        modal.find("#giantModalTitle").html(title);
        if (tileName === 'teamsRouting' || tileName === 'callFlow') {
            modal.find("#giantModalTitle").append(' <span class="modal-beta-pill">Beta</span>');
        }
        modal.find("#giantModalDescription").html(modalDescriptions[tileName]);
        $('#giantModalAlertDiv').hide();

        // Reset width — will be set to wide in the AJAX success if needed
        modal.find('.modal-dialog').removeClass('giant-modal-wide giant-modal-cdr giant-modal-flow');
        modal.removeClass('flow-embedded-edit');
        window._flowEmbeddedEdit = null;
        $('#giantFlowDrawerHead').remove();
        if (typeof flowStopMedia === 'function') flowStopMedia();
        if (typeof flowLiveStop === 'function') flowLiveStop();
        if (typeof flowLoaderStop === 'function') flowLoaderStop();

        refreshList(tileName);
    });
	$(document).off('click', '.giantResetVoiceCloudPassword');
$(document).on('click', '.giantResetVoiceCloudPassword', async function (event) {
    event.preventDefault();

    if (!(await giantConfirm("Reset this the app user's password? They'll be emailed the new sign-in QR and details."))) return;

    var resetUserId = String($(this).data('ringoteluserid') || '');

    $('#giantModalAlertDiv').hide();
    $('.giantModalPanel').hide();
    $('#giantModalSpinnerDiv').show();

    $.ajax({
        type: 'post',
        data: {
            pbxAction: 'resetVoiceCloudPassword',
            appUserId: resetUserId,
            // noemail:0 → the app platform sends its built-in email with the new password + QR.
            noemail: 0
        },
        success: function (responseJson) {
            var response = jQuery.parseJSON(responseJson);

            $('.giantModalPanel').hide();
            $('#giantModalListDiv').show();

            if (response.error) {
                $('#giantModalAlertDiv').show();
                $('#giantModalAlert').html(response.error);
                return;
            }

            $('#giantModalAlertDiv').show();
            $('#giantModalAlert').html('New the app password: <b>' + response.password + '</b><br>The new sign-in QR &amp; details have been emailed to the user.');

            // The reset now stores the new password server-side, so if this user's
            // login QR is on screen, rebuild it to match the freshly-minted one.
            var $qr = $('.giant-vc-qr-overlay .giant-vc-qr-regen, .giant-vc-qr-overlay .giant-vc-qr-generate').first();
            if ($qr.length && String($qr.data('user-id')) === resetUserId && typeof loadVcQr === 'function') {
                loadVcQr(resetUserId, String($qr.data('user-name') || 'this user'), false);
            }

            refreshList("voiceCloud");
        }
    });
});

// ─────────────────────────────────────────────────────────────────────
//  the app — edit user / add linked extension / remove linked
// ─────────────────────────────────────────────────────────────────────

// Edit a the app user — display name, email, extension, mobile,
// phone, company, position. Modal is appended INSIDE #giantModal so
// Bootstrap's focus enforcement doesn't yank focus away from our
// inputs (which would block typing). The same pattern fixes any
// future overlay-on-top-of-bootstrap dialog.
$(document).off('click', '.giant-vc-edit');
$(document).on('click', '.giant-vc-edit', function (event) {
    event.preventDefault();
    event.stopPropagation();
    var $btn = $(this);
    var userId       = String($btn.data('user-id')        || '');
    var userName     = String($btn.data('user-name')      || '');
    var userEmail    = String($btn.data('user-email')     || '');
    var userExt      = String($btn.data('user-extension') || '');
    var userMobile   = String($btn.data('user-mobile')    || '');
    var userPhone    = String($btn.data('user-phone')     || '');
    var userCompany  = String($btn.data('user-company')   || '');
    var userPosition = String($btn.data('user-position')  || '');
    if (!userId) return;

    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    var initial = (userName || '?').trim().charAt(0).toUpperCase();

    $('.giant-vc-modal-overlay').remove();
    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay">' +
          '<div class="giant-cdr-tag-dialog giant-vc-edit-dialog giant-vc-modal-fancy">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar">' + esc(initial) + '</div>' +
              '<div class="giant-vc-modal-title">' +
                '<h4>Edit user</h4>' +
                '<div class="giant-vc-modal-sub">' + esc(userName || 'the app user') + '</div>' +
              '</div>' +
              '<button type="button" class="giant-vc-modal-close giant-vc-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body">' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-regular fa-id-badge"></i> Basic info</div>' +
                '<div class="giant-vc-grid">' +
                  '<div class="giant-vc-col giant-vc-col-full"><label>Display name <span class="req">*</span></label>' +
                    '<input type="text" class="giant-vc-name" maxlength="60" value="' + esc(userName) + '"></div>' +
                  '<div class="giant-vc-col"><label>Extension</label>' +
                    '<input type="text" class="giant-vc-ext" maxlength="8" pattern="\\d+" value="' + esc(userExt) + '"></div>' +
                  '<div class="giant-vc-col"><label>Email</label>' +
                    '<input type="email" class="giant-vc-email" maxlength="120" value="' + esc(userEmail) + '"></div>' +
                '</div>' +
              '</div>' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-regular fa-address-book"></i> Contact</div>' +
                '<div class="giant-vc-grid">' +
                  '<div class="giant-vc-col"><label>Mobile</label>' +
                    '<input type="text" class="giant-vc-mobile" maxlength="32" value="' + esc(userMobile) + '"></div>' +
                  '<div class="giant-vc-col"><label>Direct phone</label>' +
                    '<input type="text" class="giant-vc-phone" maxlength="32" value="' + esc(userPhone) + '"></div>' +
                '</div>' +
              '</div>' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-regular fa-building"></i> Profile</div>' +
                '<div class="giant-vc-grid">' +
                  '<div class="giant-vc-col"><label>Company</label>' +
                    '<input type="text" class="giant-vc-company" maxlength="60" value="' + esc(userCompany) + '"></div>' +
                  '<div class="giant-vc-col"><label>Position</label>' +
                    '<input type="text" class="giant-vc-position" maxlength="60" value="' + esc(userPosition) + '"></div>' +
                '</div>' +
              '</div>' +
              '<div class="giant-vc-modal-note"><i class="fa-regular fa-circle-info"></i> Updates the live user record. Chat history and the app session are preserved.</div>' +
            '</div>' +
            '<div class="giant-vc-modal-foot">' +
              '<button type="button" class="btn giant-vc-btn-ghost giant-vc-close">Cancel</button>' +
              '<button type="button" class="btn giant-vc-btn-primary giant-vc-save"><i class="fa-regular fa-floppy-disk"></i> <span>Save changes</span></button>' +
            '</div>' +
          '</div>' +
        '</div>'
    ).appendTo('#giantModal'); // INSIDE the bootstrap modal — fixes focus trap

    // Stop clicks INSIDE the dialog from reaching the overlay backdrop.
    // Close handlers are bound DIRECTLY (not delegated through $ov) because
    // delegated handlers rely on bubbling, which the dialog's stopPropagation
    // would kill — that's why Cancel / × silently did nothing before.
    $ov.find('.giant-cdr-tag-dialog').on('click mousedown', function (e) { e.stopPropagation(); });
    var closeEdit = function () { $ov.remove(); $(document).off('keydown.giantVcEdit'); };
    $ov.find('.giant-vc-close').on('click', closeEdit);
    $ov.on('click', function (e) { if (e.target === $ov[0]) closeEdit(); });
    $(document).on('keydown.giantVcEdit', function (e) {
        if (e.key === 'Escape') closeEdit();
    });

    setTimeout(function () { $ov.find('.giant-vc-name').focus().select(); }, 50);

    $ov.find('.giant-vc-save').on('click', function () {
        var $b = $(this);
        var savedHtml = $b.html();
        $b.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> <span>Saving&hellip;</span>');
        $.ajax({
            type: 'post',
            data: {
                pbxAction:    'editVoiceCloudUser',
                appUserId: userId,
                name:           $ov.find('.giant-vc-name').val(),
                email:          $ov.find('.giant-vc-email').val(),
                extension:      $ov.find('.giant-vc-ext').val(),
                mobile:         $ov.find('.giant-vc-mobile').val(),
                phone:          $ov.find('.giant-vc-phone').val(),
                company:        $ov.find('.giant-vc-company').val(),
                position:       $ov.find('.giant-vc-position').val()
            },
            dataType: 'json'
        }).done(function (resp) {
            if (resp && resp.success) {
                if (typeof giantToast === 'function') giantToast('User updated.', 'success');
                $ov.remove();
                refreshList('voiceCloud');
            } else {
                if (typeof giantToast === 'function') giantToast((resp && resp.error) || 'Update failed.', 'error');
                else alert((resp && resp.error) || 'Update failed.');
                $b.prop('disabled', false).html(savedHtml);
            }
        }).fail(function () {
            if (typeof giantToast === 'function') giantToast('Network error.', 'error');
            else alert('Network error.');
            $b.prop('disabled', false).html(savedHtml);
        });
    });
});

// + Add a linked extension (status=2 user).
$(document).off('click', '.giant-vc-link-add');
$(document).on('click', '.giant-vc-link-add', function (event) {
    event.preventDefault();
    event.stopPropagation();
    var $btn = $(this);
    var primaryId   = String($btn.data('primary-id')   || '');
    var primaryName = String($btn.data('primary-name') || 'User');
    if (!primaryId) return;

    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var initial = (primaryName || '?').trim().charAt(0).toUpperCase();

    $('.giant-vc-modal-overlay').remove();
    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay">' +
          '<div class="giant-cdr-tag-dialog giant-vc-link-dialog giant-vc-modal-fancy">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar"><i class="fa-solid fa-link"></i></div>' +
              '<div class="giant-vc-modal-title">' +
                '<h4>Link an extension</h4>' +
                '<div class="giant-vc-modal-sub">to ' + esc(primaryName) + '</div>' +
              '</div>' +
              '<button type="button" class="giant-vc-modal-close giant-vc-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body">' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-grid">' +
                  '<div class="giant-vc-col"><label>Extension number <span class="req">*</span></label>' +
                    '<input type="text" class="giant-vc-link-ext" maxlength="8" pattern="\\d+" placeholder="e.g. 6001">' +
                    '<small>2&ndash;8 digits. Must not conflict with an existing extension.</small></div>' +
                  '<div class="giant-vc-col"><label>Label</label>' +
                    '<input type="text" class="giant-vc-link-name" maxlength="60" placeholder="' + esc(primaryName + ' Linked') + '">' +
                    '<small>e.g. &ldquo;Mobile&rdquo;, &ldquo;Desktop&rdquo;, &ldquo;Reception&rdquo;. Optional.</small></div>' +
                '</div>' +
              '</div>' +
            '</div>' +
            '<div class="giant-vc-modal-foot">' +
              '<button type="button" class="btn giant-vc-btn-ghost giant-vc-close">Cancel</button>' +
              '<button type="button" class="btn giant-vc-btn-primary giant-vc-link-create"><i class="fa-solid fa-link"></i> <span>Link extension</span></button>' +
            '</div>' +
          '</div>' +
        '</div>'
    ).appendTo('#giantModal'); // INSIDE bootstrap modal — fixes focus trap

    $ov.find('.giant-cdr-tag-dialog').on('click mousedown', function (e) { e.stopPropagation(); });
    var closeLink = function () { $ov.remove(); $(document).off('keydown.giantVcLink'); };
    $ov.find('.giant-vc-close').on('click', closeLink);
    $ov.on('click', function (e) { if (e.target === $ov[0]) closeLink(); });
    $(document).on('keydown.giantVcLink', function (e) {
        if (e.key === 'Escape') closeLink();
    });

    $ov.find('.giant-vc-link-create').on('click', function () {
        var ext = String($ov.find('.giant-vc-link-ext').val() || '').trim();
        if (!/^\d{2,8}$/.test(ext)) {
            if (typeof giantToast === 'function') giantToast('Extension must be 2-8 digits.', 'warn');
            else alert('Extension must be 2-8 digits.');
            $ov.find('.giant-vc-link-ext').focus().select();
            return;
        }
        var $b = $(this);
        var savedHtml = $b.html();
        $b.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> <span>Linking&hellip;</span>');
        $.ajax({
            type: 'post',
            data: {
                pbxAction:   'addVoiceCloudExtension',
                primaryUserId: primaryId,
                extension:     ext,
                name:          String($ov.find('.giant-vc-link-name').val() || '').trim()
            },
            dataType: 'json'
        }).done(function (resp) {
            if (resp && resp.success) {
                if (typeof giantToast === 'function') giantToast('Extension linked.', 'success');
                $ov.remove();
                refreshList('voiceCloud');
            } else {
                if (typeof giantToast === 'function') giantToast((resp && resp.error) || 'Could not link extension.', 'error');
                else alert((resp && resp.error) || 'Could not link extension.');
                $b.prop('disabled', false).html(savedHtml);
            }
        }).fail(function () {
            if (typeof giantToast === 'function') giantToast('Network error.', 'error');
            else alert('Network error.');
            $b.prop('disabled', false).html(savedHtml);
        });
    });

    setTimeout(function () { $ov.find('.giant-vc-link-ext').focus(); }, 50);
});

// × Remove a linked extension (with confirm).
$(document).off('click', '.giant-vc-link-remove');
$(document).on('click', '.giant-vc-link-remove', async function (event) {
    event.preventDefault();
    event.stopPropagation();
    var $btn = $(this);
    var linkId    = String($btn.data('link-id')    || '');
    var linkLabel = String($btn.data('link-label') || 'this extension');
    if (!linkId) return;
    if (!(await giantConfirm('Remove ' + linkLabel + '?'))) return;

    $btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i>');
    $.ajax({
        type: 'post',
        data: { pbxAction: 'removeVoiceCloudExtension', linkUserId: linkId },
        dataType: 'json'
    }).done(function (resp) {
        if (resp && resp.success) {
            if (typeof giantToast === 'function') giantToast('Extension removed.', 'success');
            refreshList('voiceCloud');
        } else {
            alert((resp && resp.error) || 'Could not remove extension.');
            $btn.prop('disabled', false).html('×');
        }
    }).fail(function () {
        alert('Network error.');
        $btn.prop('disabled', false).html('×');
    });
});

// ─────────────────────────────────────────────────────────────────────
//  the app — per-user signed-in app devices (inside the the app modal)
// ─────────────────────────────────────────────────────────────────────
function loadVcDevices(userId) {
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var $body = $('.giant-vc-dev-body');
    if (!$body.length) return;
    $body.html('<div style="padding:18px;text-align:center;color:#5b8577;"><i class="fa fa-spinner fa-spin"></i> Loading devices…</div>');

    $.ajax({ type: 'post', data: { pbxAction: 'getVoiceCloudUserDevices', userId: userId }, dataType: 'json' })
      .done(function (resp) {
          if (!resp || !resp.success) {
              $body.html('<div style="padding:18px;text-align:center;color:#b91c1c;">' + esc((resp && resp.message) || 'Could not load devices.') + '</div>');
              return;
          }
          var devs = resp.devices || [];
          if (!devs.length) {
              $body.html('<div style="padding:24px;text-align:center;color:#5b8577;"><i class="fa-regular fa-circle-check" style="font-size:22px;color:#00b08a;"></i><div style="margin-top:8px;">No devices are currently signed in.</div></div>');
              return;
          }
          var html = '';
          devs.forEach(function (d) {
              html += '<div class="giant-vc-dev-row" style="display:flex;align-items:center;gap:12px;padding:11px 4px;border-bottom:1px solid #eef2f1;">' +
                        '<i class="' + esc(d.icon || 'fa-solid fa-display') + '" style="font-size:20px;color:#00b08a;width:24px;text-align:center;"></i>' +
                        '<div style="flex:1 1 auto;min-width:0;">' +
                          '<div style="font-weight:600;color:#0f172a;">' + esc(d.ua) + '</div>' +
                          '<div style="font-size:12px;color:#5b8577;">' + esc(d.ip) + (d.lastSeen ? ' · last seen ' + esc(d.lastSeen) : '') + '</div>' +
                        '</div>' +
                        '<button type="button" class="btn btn-sm giant-appdev-logout" style="background:#fff;border:1px solid #f0b4b4;color:#b91c1c;border-radius:8px;white-space:nowrap;"' +
                          ' data-user-id="' + esc(userId) + '" data-term-id="' + esc(d.termId) + '" data-device-label="' + esc(d.ua) + '">' +
                          '<i class="fa-solid fa-right-from-bracket"></i> Log out</button>' +
                      '</div>';
          });
          $body.html(html);
      })
      .fail(function () { $body.html('<div style="padding:18px;text-align:center;color:#b91c1c;">Network error.</div>'); });
}

$(document).off('click', '.giant-vc-devices');
$(document).on('click', '.giant-vc-devices', function (event) {
    event.preventDefault();
    event.stopPropagation();
    var $btn     = $(this);
    var userId   = String($btn.data('user-id')   || '');
    var userName = String($btn.data('user-name') || 'the app user');
    if (!userId) return;
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    $('.giant-vc-modal-overlay').remove();
    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay giant-vc-devices-overlay">' +
          '<div class="giant-cdr-tag-dialog giant-vc-modal-fancy">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar"><i class="fa-solid fa-mobile-signal-out"></i></div>' +
              '<div class="giant-vc-modal-title"><h4>Signed-in devices</h4>' +
                '<div class="giant-vc-modal-sub">' + esc(userName) + '</div></div>' +
              '<button type="button" class="giant-vc-modal-close giant-vc-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body giant-vc-dev-body" data-user-id="' + esc(userId) + '"></div>' +
          '</div>' +
        '</div>');
    $('body').append($ov);
    $ov.on('click', function (e) { if (e.target === this) $ov.remove(); });
    $ov.find('.giant-vc-close').on('click', function () { $ov.remove(); });

    loadVcDevices(userId);
});

// the app login QR — scannable {domain, username, password}. getUser doesn't
// return the password, so the first view mints + stores one; repeat views reuse
// it (no re-issue). "Regenerate" forces a fresh one.
function loadVcQr(userId, userName, regen) {
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var $body = $('.giant-vc-qr-body');
    if (!$body.length) return;
    $body.html('<div style="padding:24px;color:#5b8577;"><i class="fa fa-spinner fa-spin"></i> Generating…</div>');
    var payload = { pbxAction: 'getVoiceCloudLoginQr', userId: userId };
    if (regen) payload.regen = 1;
    $.ajax({ type: 'post', data: payload, dataType: 'json' })
      .done(function (resp) {
          if (!resp || !resp.success) {
              $body.html('<div style="padding:18px;color:#b91c1c;">' + esc((resp && resp.message) || 'Could not generate QR.') + '</div>');
              return;
          }
          if (resp.needsGenerate) {
              // No login on file — require an explicit click; nothing is reset yet.
              $body.html(
                  '<div style="text-align:left;padding:6px 4px;font-size:13px;color:#0f172a;">No login QR has been created for <strong>' + esc(userName) + '</strong> yet.</div>' +
                  '<div style="text-align:left;margin:8px 4px 16px;font-size:12px;color:#5b8577;line-height:1.6;">Generating one sets a fresh app password (required for the QR). <strong>Any existing app sessions for this user will be signed out</strong> and must scan the new QR to sign back in.</div>' +
                  '<button type="button" class="btn btn-primary giant-vc-qr-generate" data-user-id="' + esc(userId) + '" data-user-name="' + esc(userName) + '"><i class="fa-solid fa-qrcode"></i> Generate login QR</button>'
              );
              return;
          }
          var warn = resp.reset
              ? '<div style="margin-top:10px;font-size:11px;color:#b45309;"><i class="fa-solid fa-triangle-exclamation"></i> A fresh login was issued — existing app sessions for this user were signed out and must scan this QR.</div>'
              : '';
          $body.html(
              '<div id="giantVcQrCanvas" style="display:inline-block;padding:8px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;line-height:0;"></div>' +
              '<div style="margin-top:12px;font-size:13px;color:#0f172a;">Scan with the <strong>softphone app</strong> to sign in.</div>' +
              '<div style="margin-top:12px;text-align:left;font-size:12px;color:#5b8577;background:#f6faf9;border:1px solid #d8efe7;border-radius:8px;padding:10px 12px;line-height:1.7;">' +
                'Domain: <code>' + esc(resp.domain) + '</code><br>' +
                'Username: <code>' + esc(resp.username) + '</code><br>' +
                'Password: <code>' + esc(resp.password) + '</code>' +
              '</div>' + warn +
              '<button type="button" class="btn btn-sm giant-vc-qr-regen" data-user-id="' + esc(userId) + '" data-user-name="' + esc(userName) + '" style="margin-top:12px;background:#fff;border:1px solid #cbd5e1;border-radius:8px;"><i class="fa-solid fa-rotate"></i> Regenerate QR</button>'
          );
          // Render the QR client-side — the credentials never leave the browser.
          try {
              var qcEl = document.getElementById('giantVcQrCanvas');
              if (qcEl && typeof QRCode !== 'undefined') {
                  new QRCode(qcEl, { text: resp.qr, width: 200, height: 200, correctLevel: QRCode.CorrectLevel.M });
              } else if (qcEl) {
                  qcEl.innerHTML = '<div style="padding:40px 20px;color:#b91c1c;font-size:12px;">QR renderer not loaded — hard-refresh the page.</div>';
              }
          } catch (e) {}
      })
      .fail(function () { $('.giant-vc-qr-body').html('<div style="padding:18px;color:#b91c1c;">Network error.</div>'); });
}

// Open the login-QR overlay for a user. Reused by the row's QR button AND by
// the add-user flow (show the QR right after creating someone).
function openVcQrOverlay(userId, userName) {
    userId   = String(userId   || '');
    userName = String(userName || 'this user');
    if (!userId) return;
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    $('.giant-vc-modal-overlay').remove();
    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay giant-vc-qr-overlay">' +
          '<div class="giant-cdr-tag-dialog giant-vc-modal-fancy">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar"><i class="fa-solid fa-qrcode"></i></div>' +
              '<div class="giant-vc-modal-title"><h4>the app login QR</h4>' +
                '<div class="giant-vc-modal-sub">' + esc(userName) + '</div></div>' +
              '<button type="button" class="giant-vc-modal-close giant-vc-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body giant-vc-qr-body" style="text-align:center;"></div>' +
          '</div>' +
        '</div>');
    $('body').append($ov);
    $ov.on('click', function (e) { if (e.target === this) $ov.remove(); });
    $ov.find('.giant-vc-close').on('click', function () { $ov.remove(); });

    loadVcQr(userId, userName, false);
}
window.openVcQrOverlay = openVcQrOverlay;   // so voiceCloudForm.js can call it

$(document).off('click', '.giant-vc-qr');
$(document).on('click', '.giant-vc-qr', function (event) {
    event.preventDefault();
    event.stopPropagation();
    openVcQrOverlay($(this).data('user-id'), $(this).data('user-name') || 'this user');
});

// First-time create — the click on this button IS the confirmation, so no
// password is ever reset until the user deliberately asks for it.
$(document).off('click', '.giant-vc-qr-generate');
$(document).on('click', '.giant-vc-qr-generate', function (event) {
    event.preventDefault();
    var $b       = $(this);
    var userId   = String($b.data('user-id')   || '');
    var userName = String($b.data('user-name') || 'this user');
    if (!userId) return;
    $b.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Generating…');
    loadVcQr(userId, userName, true);
});

$(document).off('click', '.giant-vc-qr-regen');
$(document).on('click', '.giant-vc-qr-regen', async function (event) {
    event.preventDefault();
    var $b       = $(this);
    var userId   = String($b.data('user-id')   || '');
    var userName = String($b.data('user-name') || 'this user');
    if (!userId) return;
    if (!(await giantConfirm('Regenerate a fresh login QR for ' + userName + '?\n\nThis re-issues their login — existing app sign-ins will be signed out and must scan the new QR. They\'ll also be emailed the new QR and sign-in details.'))) return;
    loadVcQr(userId, userName, true);
});

$(document).off('click', '.giant-appdev-logout');
$(document).on('click', '.giant-appdev-logout', async function (event) {
    event.preventDefault();
    event.stopPropagation();
    var $btn   = $(this);
    var userId = String($btn.data('user-id')      || '');
    var termId = String($btn.data('term-id')      || '');
    var label  = String($btn.data('device-label') || 'this device');
    if (!userId || !termId) return;
    if (!(await giantConfirm('Log out ' + label + '? The softphone app on that device will be signed out and must sign in again.'))) return;

    $btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i>');
    $.ajax({ type: 'post', data: { pbxAction: 'logoutAppDevice', userId: userId, termId: termId }, dataType: 'json' })
      .done(function (resp) {
          if (resp && resp.success) {
              if (typeof giantToast === 'function') giantToast('Device logged out.', 'success');
              var $ovBody = $btn.closest('.giant-vc-dev-body');
              if ($ovBody.length) { loadVcDevices(String($ovBody.data('user-id'))); }  // the app modal overlay
              else { refreshList('phone'); }                                            // unified Devices list
          } else {
              alert((resp && resp.message) || 'Could not log out device.');
              $btn.prop('disabled', false).html('<i class="fa-solid fa-right-from-bracket"></i> Log out');
          }
      })
      .fail(function () {
          alert('Network error.');
          $btn.prop('disabled', false).html('<i class="fa-solid fa-right-from-bracket"></i> Log out');
      });
});

// ─────────────────────────────────────────────────────────────────────
//  the app — per-user "Calls & privacy" (call history + GDPR erase)
// ─────────────────────────────────────────────────────────────────────

// softphone app call history for one user (last 90 days), each flagged for a
// recording / transcript, plus the GDPR "erase all recordings/transcripts"
// self-service. Delete wipes EVERYTHING for the user, not just the shown window.
function loadVcCalls(userId, userName) {
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var $body = $('.giant-vc-priv-body');
    if (!$body.length) return;
    $body.html('<div style="padding:18px;text-align:center;color:#5b8577;"><i class="fa fa-spinner fa-spin"></i> Loading calls…</div>');

    $.ajax({ type: 'post', data: { pbxAction: 'getVoiceCloudUserCalls', userId: userId }, dataType: 'json' })
      .done(function (resp) {
          if (!resp || !resp.success) {
              $body.html('<div style="padding:18px;text-align:center;color:#b91c1c;">' + esc((resp && resp.message) || 'Could not load calls.') + '</div>');
              return;
          }
          var calls  = resp.calls  || [];
          var counts = resp.counts || { total: 0, recordings: 0, transcripts: 0 };

          var actions =
            '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-start;padding:12px;background:#f6faf9;border:1px solid #d8efe7;border-radius:10px;margin-bottom:14px;">' +
              '<div style="flex:1 1 auto;min-width:180px;font-size:12px;color:#5b8577;line-height:1.6;">' +
                '<div style="font-weight:600;color:#0f172a;margin-bottom:2px;">Privacy &amp; data (GDPR)</div>' +
                'Erase this user’s stored call media. Permanent, and removes <strong>all</strong> of it — not only the calls listed below.' +
              '</div>' +
              '<button type="button" class="btn btn-sm giant-vc-del-recordings" data-user-id="' + esc(userId) + '" data-user-name="' + esc(userName) + '" style="background:#fff;border:1px solid #f0b4b4;color:#b91c1c;border-radius:8px;white-space:nowrap;">' +
                '<i class="fa-solid fa-microphone-slash"></i> Delete all recordings' + (counts.recordings ? ' (' + esc(counts.recordings) + ')' : '') + '</button>' +
              '<button type="button" class="btn btn-sm giant-vc-del-transcripts" data-user-id="' + esc(userId) + '" data-user-name="' + esc(userName) + '" style="background:#fff;border:1px solid #f0b4b4;color:#b91c1c;border-radius:8px;white-space:nowrap;">' +
                '<i class="fa-solid fa-file-circle-xmark"></i> Delete all transcripts' + (counts.transcripts ? ' (' + esc(counts.transcripts) + ')' : '') + '</button>' +
            '</div>';

          if (!calls.length) {
              $body.html(actions + '<div style="padding:24px;text-align:center;color:#5b8577;"><i class="fa-regular fa-comment-dots" style="font-size:22px;color:#00b08a;"></i><div style="margin-top:8px;">No the app calls in the last 90 days.</div></div>');
              return;
          }

          var rowsHtml = '';
          calls.forEach(function (c) {
              var dirIcon = c.outbound
                  ? '<i class="fa-solid fa-arrow-up-right-from-square" title="Outbound" style="color:#0ea5a0;"></i>'
                  : '<i class="fa-solid fa-arrow-down-left" title="Inbound" style="color:#64748b;"></i>';
              var recBadge = c.rec ? '<span title="Call recorded" style="color:#00b08a;cursor:default;"><i class="fa-solid fa-microphone"></i></span>' : '';
              var trBadge  = c.tr
                  ? '<button type="button" class="giant-vc-summary" data-user-id="' + esc(userId) + '" data-t="' + esc(c.t) + '" data-label="' + esc(String(c.from) + ' → ' + String(c.to)) + '" title="View AI summary" style="border:1px solid #e2d5fb;background:#f5f0ff;color:#7c3aed;border-radius:7px;padding:2px 8px;cursor:pointer;line-height:1;font-size:13px;"><i class="fa-solid fa-wand-magic-sparkles"></i></button>'
                  : '';
              var search = (String(c.from) + ' ' + String(c.to) + ' ' + String(c.outcome) + ' ' + String(c.time)).toLowerCase();
              rowsHtml +=
                '<div class="giant-vc-call-row" data-search="' + esc(search) + '" style="display:flex;align-items:center;gap:12px;padding:9px 4px;border-bottom:1px solid #eef2f1;font-size:13px;">' +
                  '<div style="width:20px;text-align:center;">' + dirIcon + '</div>' +
                  '<div style="flex:1 1 auto;min-width:0;">' +
                    '<div style="font-weight:600;color:#0f172a;">' + esc(c.from) + ' &rarr; ' + esc(c.to) + '</div>' +
                    '<div style="font-size:12px;color:#5b8577;">' + esc(c.time) + ' &middot; ' + esc(c.outcome) + ' &middot; ' + esc(c.duration) + '</div>' +
                  '</div>' +
                  '<div style="display:flex;gap:8px;align-items:center;min-width:40px;justify-content:flex-end;">' + recBadge + trBadge + '</div>' +
                '</div>';
          });

          var toolbar =
            '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">' +
              '<div style="position:relative;flex:1 1 auto;">' +
                '<i class="fa-solid fa-magnifying-glass" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:12px;"></i>' +
                '<input type="text" class="giant-vc-call-search" placeholder="Search number, outcome or date…" style="width:100%;padding:7px 10px 7px 28px;border:1px solid #d8efe7;border-radius:8px;font-size:13px;">' +
              '</div>' +
              '<span class="giant-vc-call-count" style="font-size:11px;color:#94a3b8;white-space:nowrap;">' + esc(calls.length) + ' call' + (calls.length === 1 ? '' : 's') + '</span>' +
            '</div>';

          var capNote = resp.capped
              ? '<div style="padding:8px 4px;font-size:11px;color:#94a3b8;text-align:center;">Showing the 1000 most recent of ' + esc(counts.total) + ' calls.</div>'
              : '';

          $body.html(actions + toolbar + '<div class="giant-vc-calls-list">' + rowsHtml + '</div>' + capNote);
      })
      .fail(function () { $body.html('<div style="padding:18px;text-align:center;color:#b91c1c;">Network error.</div>'); });
}

$(document).off('click', '.giant-vc-privacy');
$(document).on('click', '.giant-vc-privacy', function (event) {
    event.preventDefault();
    event.stopPropagation();
    var $btn     = $(this);
    var userId   = String($btn.data('user-id')   || '');
    var userName = String($btn.data('user-name') || 'the app user');
    if (!userId) return;
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    $('.giant-vc-modal-overlay').remove();
    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay giant-vc-privacy-overlay">' +
          '<div class="giant-cdr-tag-dialog giant-vc-modal-fancy">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar"><i class="fa-solid fa-shield-halved"></i></div>' +
              '<div class="giant-vc-modal-title"><h4>Calls &amp; privacy</h4>' +
                '<div class="giant-vc-modal-sub">' + esc(userName) + '</div></div>' +
              '<button type="button" class="giant-vc-modal-close giant-vc-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body giant-vc-priv-body" data-user-id="' + esc(userId) + '" data-user-name="' + esc(userName) + '"></div>' +
          '</div>' +
        '</div>');
    $('body').append($ov);
    $ov.on('click', function (e) { if (e.target === this) $ov.remove(); });
    $ov.find('.giant-vc-close').on('click', function () { $ov.remove(); });

    loadVcCalls(userId, userName);
});

async function giantVcDelete(kind, $btn) {
    var userId   = String($btn.data('user-id')   || '');
    var userName = String($btn.data('user-name') || 'this user');
    if (!userId) return;
    var noun   = (kind === 'transcripts') ? 'transcripts' : 'recordings';
    var action = (kind === 'transcripts') ? 'deleteVoiceCloudTranscriptions' : 'deleteVoiceCloudRecordings';
    if (!(await giantConfirm('Permanently delete ALL the app call ' + noun + ' for ' + userName + '?\n\nThis cannot be undone.'))) return;

    var original = $btn.html();
    $btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Deleting…');
    $.ajax({ type: 'post', data: { pbxAction: action, userId: userId }, dataType: 'json' })
      .done(function (resp) {
          if (resp && resp.success) {
              if (typeof giantToast === 'function') giantToast('Deleted ' + (resp.files || 0) + ' ' + noun + ' file(s).', 'success');
              loadVcCalls(userId, userName);   // refresh the counts + list
          } else {
              alert((resp && resp.message) || ('Could not delete ' + noun + '.'));
              $btn.prop('disabled', false).html(original);
          }
      })
      .fail(function () {
          alert('Network error.');
          $btn.prop('disabled', false).html(original);
      });
}

$(document).off('click', '.giant-vc-del-recordings');
$(document).on('click', '.giant-vc-del-recordings', function (e) { e.preventDefault(); giantVcDelete('recordings', $(this)); });

$(document).off('click', '.giant-vc-del-transcripts');
$(document).on('click', '.giant-vc-del-transcripts', function (e) { e.preventDefault(); giantVcDelete('transcripts', $(this)); });

// the app access state. Two SEPARATE concepts, four ops:
//   Block / Unblock       — deny / restore sign-in; the user stays activated.
//   Deactivate / Reactivate — unactivate (status -1) / re-activate the user.
async function giantVcState($btn, op) {
    var userId   = String($btn.data('user-id')   || '');
    var userName = String($btn.data('user-name') || 'this user');
    if (!userId) return;
    var prompts = {
        block:      'Block ' + userName + '?\n\nThey’ll be signed out and can’t sign in or make/receive calls, but they stay on the account. You can unblock them anytime.',
        unblock:    'Unblock ' + userName + '?\n\nThey’ll be able to sign in and make/receive calls again.',
        deactivate: 'Deactivate ' + userName + '?\n\nThe user becomes inactive (unactivated). You can reactivate them later.',
        reactivate: 'Reactivate ' + userName + '?\n\nThe user is activated again and issued a fresh app login.'
    };
    var done = { block: 'Blocked', unblock: 'Unblocked', deactivate: 'Deactivated', reactivate: 'Reactivated' };
    if (!(await giantConfirm(prompts[op] || 'Are you sure?'))) return;

    $btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i>');
    $.ajax({ type: 'post', data: { pbxAction: 'setVoiceCloudUserState', userId: userId, op: op }, dataType: 'json' })
      .done(function (resp) {
          if (resp && resp.success) {
              if (typeof giantToast === 'function') { giantToast((done[op] || 'Updated') + ' ' + userName + '.', 'success'); }
          } else {
              alert((resp && resp.message) || 'Could not update this user.');
          }
          refreshList('voiceCloud');
      })
      .fail(function () { alert('Network error.'); $btn.prop('disabled', false); });
}
[['block', '.giant-vc-block'], ['unblock', '.giant-vc-unblock'], ['deactivate', '.giant-vc-deactivate'], ['reactivate', '.giant-vc-reactivate']].forEach(function (pair) {
    $(document).off('click', pair[1]);
    $(document).on('click', pair[1], function (e) { e.preventDefault(); e.stopPropagation(); giantVcState($(this), pair[0]); });
});

// Live-filter the call list as the customer types.
$(document).off('input', '.giant-vc-call-search');
$(document).on('input', '.giant-vc-call-search', function () {
    var q = String($(this).val() || '').trim().toLowerCase();
    var $scope = $(this).closest('.giant-vc-modal-body');
    var shown = 0;
    $scope.find('.giant-vc-calls-list .giant-vc-call-row').each(function () {
        var match = !q || (String($(this).attr('data-search') || '').indexOf(q) !== -1);
        $(this).toggle(match);
        if (match) shown++;
    });
    $scope.find('.giant-vc-call-count').text(shown + ' call' + (shown === 1 ? '' : 's'));
});

// AI summary — opens a sub-overlay above the calls modal and pulls the per-call
// transcript/summary JSON off the the app platform file host (fetched server-side).
$(document).off('click', '.giant-vc-summary');
$(document).on('click', '.giant-vc-summary', function (event) {
    event.preventDefault();
    event.stopPropagation();
    var $btn   = $(this);
    var userId = String($btn.data('user-id') || '');
    var t      = String($btn.data('t') || '');
    var label  = String($btn.data('label') || 'Call');
    if (!userId || !t) return;
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    $('.giant-vc-summary-overlay').remove();
    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay giant-vc-summary-overlay" style="z-index:20050;">' +
          '<div class="giant-cdr-tag-dialog giant-vc-modal-fancy">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar"><i class="fa-solid fa-wand-magic-sparkles"></i></div>' +
              '<div class="giant-vc-modal-title"><h4>AI summary</h4>' +
                '<div class="giant-vc-modal-sub">' + esc(label) + '</div></div>' +
              '<button type="button" class="giant-vc-modal-close giant-vc-sum-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body giant-vc-sum-body" style="text-align:left;"></div>' +
          '</div>' +
        '</div>');
    $('body').append($ov);
    $ov.on('click', function (e) { if (e.target === this) $ov.remove(); });
    $ov.find('.giant-vc-sum-close').on('click', function () { $ov.remove(); });

    loadVcSummary(userId, t, label);
});

function loadVcSummary(userId, t, label) {
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var $body = $('.giant-vc-sum-body');
    if (!$body.length) return;
    $body.html('<div style="padding:24px;text-align:center;color:#5b8577;"><i class="fa fa-spinner fa-spin"></i> Loading summary…</div>');

    $.ajax({ type: 'post', data: { pbxAction: 'getVoiceCloudCallSummary', userId: userId, t: t }, dataType: 'json' })
      .done(function (resp) {
          if (!resp || !resp.success) {
              $body.html('<div style="padding:18px;color:#b91c1c;">' + esc((resp && resp.message) || 'Could not load summary.') + '</div>');
              return;
          }
          if (!resp.available || !resp.recognized) {
              // Either nothing stored, or the file wasn't a transcript we can
              // safely display (the server strips anything else — never raw).
              $body.html('<div style="padding:24px;text-align:center;color:#5b8577;"><i class="fa-regular fa-file-lines" style="font-size:22px;"></i><div style="margin-top:8px;">An AI summary for this call isn’t available to display.</div></div>');
              return;
          }
          $body.html(giantRenderSummary(resp, esc));
      })
      .fail(function () { $body.html('<div style="padding:18px;color:#b91c1c;">Network error.</div>'); });
}

// Renders ONLY the sanitised fields the server whitelisted (summary / sentiment
// / transcript). Never receives or prints the raw AI file.
function giantRenderSummary(r, esc) {
    function sec(title, body) {
        return '<div style="margin-bottom:14px;"><div style="font-weight:700;color:#0f172a;font-size:13px;margin-bottom:4px;">' + esc(title) + '</div>' + body + '</div>';
    }
    var html = '';
    if (r.summary) {
        html += sec('Summary', '<div style="font-size:13px;color:#334155;line-height:1.6;">' + esc(r.summary) + '</div>');
    }
    if (r.sentiment) {
        html += sec('Sentiment', '<span style="display:inline-block;padding:2px 10px;border-radius:999px;background:#f5f0ff;color:#7c3aed;font-size:12px;font-weight:600;">' + esc(r.sentiment) + '</span>');
    }
    if (r.transcript) {
        var tHtml = '';
        if (Array.isArray(r.transcript)) {
            r.transcript.forEach(function (seg) {
                if (!seg || !seg.text) return;
                var who = seg.who || '';
                tHtml += '<div style="margin-bottom:6px;">' + (who ? '<strong style="color:#0f172a;">' + esc(who) + ':</strong> ' : '') + '<span style="color:#334155;">' + esc(seg.text) + '</span></div>';
            });
        } else if (typeof r.transcript === 'string') {
            tHtml = '<div style="white-space:pre-wrap;color:#334155;">' + esc(r.transcript) + '</div>';
        }
        if (tHtml) html += sec('Transcript', '<div style="font-size:13px;line-height:1.6;max-height:320px;overflow:auto;">' + tHtml + '</div>');
    }
    if (!html) {
        html = '<div style="padding:24px;text-align:center;color:#5b8577;">An AI summary for this call isn’t available to display.</div>';
    }
    return html;
}

// ─────────────────────────────────────────────────────────────────────
//  CDR annotations — Tag / Notes / Disposition on call-log rows
// ─────────────────────────────────────────────────────────────────────

// AI Receptionist — connect an agent to one of the tenant's extensions. The
// agent then registers to the PBX as that extension, so normal call routing
// reaches it. Reuses the CDR-tag overlay chrome.
$(document).off('click', '.giant-va-connect-btn');
$(document).on('click', '.giant-va-connect-btn', function (event) {
    event.preventDefault();
    var agentId = String($(this).data('agent-id') || '');
    if (!agentId) return;

    $('.giant-va-overlay').remove();
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var btnLabel = '<i class="fa-solid fa-link"></i> <span>Connect</span>';

    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay giant-va-overlay">' +
          '<div class="giant-cdr-tag-dialog giant-vc-modal-fancy">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar"><i class="fa-solid fa-headset"></i></div>' +
              '<div class="giant-vc-modal-title">' +
                '<h4>Connect to an extension</h4>' +
                '<div class="giant-vc-modal-sub">The agent signs in as this extension and answers its calls</div>' +
              '</div>' +
              '<button type="button" class="giant-vc-modal-close giant-va-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body">' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-solid fa-phone"></i> Extension</div>' +
                '<select class="giant-va-ext giant-cdr-input"><option value="">Loading&hellip;</option></select>' +
                '<small>Pick an extension no desk phone is signed in to — otherwise the phone and the agent fight over the registration.</small>' +
              '</div>' +
              '<div class="giant-va-alert" style="display:none;"></div>' +
            '</div>' +
            '<div class="giant-vc-modal-foot">' +
              '<div class="giant-cdr-tag-foot-spacer"></div>' +
              '<button type="button" class="btn giant-vc-btn-ghost giant-va-close">Cancel</button>' +
              '<button type="button" class="btn giant-vc-btn-primary giant-va-save" disabled>' + btnLabel + '</button>' +
            '</div>' +
          '</div>' +
        '</div>'
    ).appendTo('#giantModal');

    $ov.find('.giant-cdr-tag-dialog').on('click mousedown', function (e) { e.stopPropagation(); });
    var close = function () { $ov.remove(); $(document).off('keydown.giantVa'); };
    $ov.find('.giant-va-close').on('click', close);
    $ov.on('click', function (e) { if (e.target === $ov[0]) close(); });
    $(document).on('keydown.giantVa', function (e) { if (e.key === 'Escape') close(); });

    // Populate the extension picker.
    $.ajax({
        type: 'post', dataType: 'json',
        data: { pbxAction: 'getVoiceAgentExtensions' },
        success: function (resp) {
            var $sel = $ov.find('.giant-va-ext');
            var list = (resp && resp.extensions) ? resp.extensions : [];
            if (!list.length) {
                $sel.html('<option value="">No extensions found</option>');
                return;
            }
            var html = '<option value="">— Select an extension —</option>';
            list.forEach(function (e) {
                html += '<option value="' + esc(e.ex_id) + '">' + esc(e.label) + '</option>';
            });
            $sel.html(html);
            giantIconSelect($sel, 'fa-user', $ov);
            $ov.find('.giant-va-save').prop('disabled', false);
        },
        error: function () {
            $ov.find('.giant-va-ext').html('<option value="">Could not load extensions</option>');
        }
    });

    $ov.find('.giant-va-save').on('click', function () {
        var $save  = $(this);
        var exId   = $ov.find('.giant-va-ext').val();
        var $alert = $ov.find('.giant-va-alert');
        $alert.hide().text('');
        if (!exId) { $alert.text('Please choose an extension.').show(); return; }

        $save.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> <span>Connecting&hellip;</span>');
        $.ajax({
            type: 'post', dataType: 'json',
            data: { pbxAction: 'connectVoiceAgent', agentId: agentId, exId: exId },
            success: function (resp) {
                if (resp && resp.success) { close(); refreshList('aiAgent'); }
                else {
                    $alert.text((resp && resp.error) ? resp.error : 'Could not connect the agent.').show();
                    $save.prop('disabled', false).html(btnLabel);
                }
            },
            error: function () {
                $alert.text('Something went wrong. Please try again.').show();
                $save.prop('disabled', false).html(btnLabel);
            }
        });
    });
});

$(document).off('click', '.giant-va-disconnect-btn');
$(document).on('click', '.giant-va-disconnect-btn', async function (event) {
    event.preventDefault();
    var agentId = String($(this).data('agent-id') || '');
    if (!agentId) return;
    if (!(await giantConfirm('Disconnect this agent? It will stop answering calls on that extension.'))) return;

    $.ajax({
        type: 'post', dataType: 'json',
        data: { pbxAction: 'disconnectVoiceAgent', agentId: agentId },
        success: function () { refreshList('aiAgent'); },
        error:   function () { refreshList('aiAgent'); }
    });
});

// "Link to app" button in the extensions modal — opens a small dialog to
// collect name/email/mobile, then creates a the app (the app platform) app user for
// that extension and fires the invite. Reuses the CDR-tag overlay chrome.
$(document).off('click', '.giant-vc-link-btn');
$(document).on('click', '.giant-vc-link-btn', function (event) {
    event.preventDefault();
    var $btn   = $(this);
    var exId   = String($btn.data('ex-id') || '');
    var exNum  = String($btn.data('ex-number') || '');
    var exName = String($btn.data('ex-name') || '');
    if (!exId) return;

    $('.giant-vc-link-overlay').remove();
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    var btnLabel = '<i class="fa-solid fa-paper-plane"></i> <span>Link &amp; invite</span>';

    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay giant-vc-link-overlay">' +
          '<div class="giant-cdr-tag-dialog giant-vc-modal-fancy">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar"><i class="fa-solid fa-link"></i></div>' +
              '<div class="giant-vc-modal-title">' +
                '<h4>Link to softphone app</h4>' +
                '<div class="giant-vc-modal-sub">Extension ' + esc(exNum) + ' &middot; sends an app-setup invite by email</div>' +
              '</div>' +
              '<button type="button" class="giant-vc-modal-close giant-vc-link-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body">' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-regular fa-user"></i> Name</div>' +
                '<input type="text" class="giant-vc-link-name giant-cdr-input" value="' + esc(exName) + '" placeholder="Full name">' +
              '</div>' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-regular fa-envelope"></i> Email</div>' +
                '<input type="email" class="giant-vc-link-email giant-cdr-input" placeholder="name@company.com">' +
                '<small>The app-setup invite is sent here.</small>' +
              '</div>' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-solid fa-mobile-screen"></i> Mobile <span style="font-weight:400;opacity:.7;">(optional)</span></div>' +
                '<input type="text" class="giant-vc-link-mobile giant-cdr-input" placeholder="07…">' +
                '<small>If given, we’ll also text them the invite.</small>' +
              '</div>' +
              '<div class="giant-vc-link-alert" style="display:none;"></div>' +
            '</div>' +
            '<div class="giant-vc-modal-foot">' +
              '<div class="giant-cdr-tag-foot-spacer"></div>' +
              '<button type="button" class="btn giant-vc-btn-ghost giant-vc-link-close">Cancel</button>' +
              '<button type="button" class="btn giant-vc-btn-primary giant-vc-link-save">' + btnLabel + '</button>' +
            '</div>' +
          '</div>' +
        '</div>'
    ).appendTo('#giantModal');

    $ov.find('.giant-cdr-tag-dialog').on('click mousedown', function (e) { e.stopPropagation(); });
    var close = function () { $ov.remove(); $(document).off('keydown.giantVcLink'); };
    $ov.find('.giant-vc-link-close').on('click', close);
    $ov.on('click', function (e) { if (e.target === $ov[0]) close(); });
    $(document).on('keydown.giantVcLink', function (e) { if (e.key === 'Escape') close(); });
    setTimeout(function () { $ov.find('.giant-vc-link-email').focus(); }, 50);

    $ov.find('.giant-vc-link-save').on('click', function () {
        var $save  = $(this);
        var name   = $.trim($ov.find('.giant-vc-link-name').val());
        var email  = $.trim($ov.find('.giant-vc-link-email').val());
        var mobile = $.trim($ov.find('.giant-vc-link-mobile').val());
        var $alert = $ov.find('.giant-vc-link-alert');
        $alert.hide().text('');

        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { $alert.text('Please enter a valid email address.').show(); return; }
        if (!name) { $alert.text('Please enter a name.').show(); return; }

        $save.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> <span>Linking&hellip;</span>');
        $.ajax({
            type: 'post',
            dataType: 'json',
            data: { pbxAction: 'linkExtensionToVoiceCloud', exId: exId, email: email, name: name, mobile: mobile },
            success: function (resp) {
                if (resp && resp.success) {
                    close();
                    if (typeof refreshList === 'function') refreshList('extension');
                } else {
                    $alert.text((resp && resp.error) ? resp.error : 'Could not link the extension.').show();
                    $save.prop('disabled', false).html(btnLabel);
                }
            },
            error: function () {
                $alert.text('Something went wrong. Please try again.').show();
                $save.prop('disabled', false).html(btnLabel);
            }
        });
    });
});

$(document).off('click', '.giant-cdr-tag-btn');
$(document).on('click', '.giant-cdr-tag-btn', function (event) {
    event.preventDefault();
    var $btn = $(this);
    var uniqueid  = String($btn.data('uniqueid')  || '');
    var direction = String($btn.data('direction') || '');
    var existing  = $btn.data('annotation') || {};
    if (typeof existing === 'string') {
        try { existing = JSON.parse(existing); } catch (e) { existing = {}; }
    }
    if (!uniqueid) return;

    $('.giant-cdr-tag-overlay').remove();

    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    var notes = existing.notes || '';
    var tags  = (existing.tags && existing.tags.length) ? existing.tags.join(', ') : '';
    var disp  = existing.disposition || '';

    var dispOpts = [
        ['',         '— None —'],
        ['answered', 'Answered'],
        ['missed',   'Missed'],
        ['callback', 'Callback'],
        ['won',      'Won'],
        ['lost',     'Lost'],
        ['spam',     'Spam'],
        ['other',    'Other']
    ];

    var dirIcon  = direction === 'in'  ? 'fa-phone-arrow-down-left'
                 : direction === 'out' ? 'fa-phone-arrow-up-right'
                 : 'fa-tag';
    var dirLabel = direction === 'in'  ? 'inbound call'
                 : direction === 'out' ? 'outbound call'
                 : 'call annotation';

    // Disposition pill picker — renders as a row of toggles instead of a select.
    var dispHtml = '<div class="giant-cdr-disp-pills">';
    dispOpts.forEach(function (o) {
        var isOn = (o[0] === disp);
        dispHtml += '<button type="button" class="giant-cdr-disp-pill' + (isOn ? ' is-on' : '') + '"' +
                    ' data-value="' + esc(o[0]) + '">' + esc(o[1]) + '</button>';
    });
    dispHtml += '</div>';

    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay">' +
          '<div class="giant-cdr-tag-dialog giant-vc-modal-fancy giant-cdr-tag-dialog-fancy">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar"><i class="fa-solid ' + dirIcon + '"></i></div>' +
              '<div class="giant-vc-modal-title">' +
                '<h4>Tag this call</h4>' +
                '<div class="giant-vc-modal-sub">Add disposition, tags &amp; notes &middot; ' + dirLabel + '</div>' +
              '</div>' +
              '<button type="button" class="giant-vc-modal-close giant-cdr-tag-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body">' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-regular fa-circle-check"></i> Disposition</div>' +
                dispHtml +
                '<input type="hidden" class="giant-cdr-disp-input" value="' + esc(disp) + '">' +
              '</div>' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-solid fa-tags"></i> Tags</div>' +
                '<input type="text" class="giant-cdr-tags-input giant-cdr-input" placeholder="comma-separated, e.g. sales, priority" value="' + esc(tags) + '">' +
                '<small>Comma-separated. Up to 8 tags, 30 characters each.</small>' +
              '</div>' +
              '<div class="giant-vc-section">' +
                '<div class="giant-vc-section-label"><i class="fa-regular fa-note-sticky"></i> Notes</div>' +
                '<textarea class="giant-cdr-notes-input giant-cdr-input giant-cdr-textarea" maxlength="500" placeholder="Anything worth remembering about this call&hellip;">' + esc(notes) + '</textarea>' +
                '<small>Up to 500 characters.</small>' +
              '</div>' +
            '</div>' +
            '<div class="giant-vc-modal-foot giant-cdr-tag-foot-fancy">' +
              '<button type="button" class="btn giant-vc-btn-danger giant-cdr-tag-clear"><i class="fa-regular fa-trash-can"></i> <span>Clear</span></button>' +
              '<div class="giant-cdr-tag-foot-spacer"></div>' +
              '<button type="button" class="btn giant-vc-btn-ghost giant-cdr-tag-close">Cancel</button>' +
              '<button type="button" class="btn giant-vc-btn-primary giant-cdr-tag-save"><i class="fa-regular fa-floppy-disk"></i> <span>Save</span></button>' +
            '</div>' +
          '</div>' +
        '</div>'
    ).appendTo('#giantModal'); // INSIDE the bootstrap modal — fixes focus trap

    // Clicks inside the dialog stop here so the backdrop-click handler doesn't fire.
    // Close handlers are bound DIRECTLY (not delegated) — delegated handlers
    // would never fire because the dialog kills the click bubble.
    $ov.find('.giant-cdr-tag-dialog').on('click mousedown', function (e) { e.stopPropagation(); });
    var closeCdr = function () { $ov.remove(); $(document).off('keydown.giantCdrTag'); };
    $ov.find('.giant-cdr-tag-close').on('click', closeCdr);
    $ov.on('click', function (e) { if (e.target === $ov[0]) closeCdr(); });
    $(document).on('keydown.giantCdrTag', function (e) {
        if (e.key === 'Escape') closeCdr();
    });

    // Disposition pill toggle.
    $ov.on('click', '.giant-cdr-disp-pill', function () {
        var $p = $(this);
        var val = String($p.data('value') || '');
        var alreadyOn = $p.hasClass('is-on');
        $ov.find('.giant-cdr-disp-pill').removeClass('is-on');
        if (!alreadyOn && val !== '') {
            $p.addClass('is-on');
            $ov.find('.giant-cdr-disp-input').val(val);
        } else {
            // Re-select "None" when toggling off the active one.
            $ov.find('.giant-cdr-disp-pill[data-value=""]').addClass('is-on');
            $ov.find('.giant-cdr-disp-input').val('');
        }
    });

    setTimeout(function () { $ov.find('.giant-cdr-tags-input').focus(); }, 50);

    function postAnnotation(payload, $saveBtn, savedHtml) {
        $saveBtn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> <span>Saving&hellip;</span>');
        $.ajax({
            type: 'post',
            data: $.extend({ pbxAction: 'saveCdrAnnotation', uniqueid: uniqueid, direction: direction }, payload),
            dataType: 'json'
        }).done(function (resp) {
            if (resp && resp.success) {
                if (typeof giantToast === 'function') giantToast('Saved.', 'success');
                closeCdr();
                refreshList('callLog');
            } else {
                if (typeof giantToast === 'function') giantToast((resp && resp.error) || 'Could not save annotation.', 'error');
                else alert((resp && resp.error) || 'Could not save annotation.');
                $saveBtn.prop('disabled', false).html(savedHtml);
            }
        }).fail(function () {
            if (typeof giantToast === 'function') giantToast('Network error.', 'error');
            else alert('Network error.');
            $saveBtn.prop('disabled', false).html(savedHtml);
        });
    }

    $ov.find('.giant-cdr-tag-save').on('click', function () {
        var $b = $(this);
        var savedHtml = $b.html();
        postAnnotation({
            notes:       $ov.find('.giant-cdr-notes-input').val(),
            tags:        $ov.find('.giant-cdr-tags-input').val(),
            disposition: $ov.find('.giant-cdr-disp-input').val()
        }, $b, savedHtml);
    });
    $ov.find('.giant-cdr-tag-clear').on('click', async function () {
        if (!(await giantConfirm('Clear all tags / notes / disposition on this call?'))) return;
        var $b = $(this);
        var savedHtml = $b.html();
        postAnnotation({ notes: '', tags: '', disposition: '' }, $b, savedHtml);
    });
});

// ─────────────────────────────────────────────────────────────────────
//  Per-phone directory bindings (phonephonebook). Click the book icon
//  on a phone row → modal showing which tenant phonebooks this handset
//  pulls, with add (from the available tenant phonebooks) + remove.
// ─────────────────────────────────────────────────────────────────────

$(document).off('click', '.giant-phone-pb-btn');
$(document).on('click', '.giant-phone-pb-btn', function (event) {
    event.preventDefault();
    var $btn = $(this);
    var phId   = String($btn.data('ph-id')   || '');
    var phName = String($btn.data('ph-name') || '');
    if (!phId) return;

    $('.giant-phone-pb-overlay').remove();
    var $ov = $(
        '<div class="giant-cdr-tag-overlay giant-vc-modal-overlay giant-phone-pb-overlay">' +
          '<div class="giant-cdr-tag-dialog giant-vc-modal-fancy giant-phone-pb-dialog">' +
            '<div class="giant-vc-modal-head">' +
              '<div class="giant-vc-modal-avatar"><i class="fa-solid fa-book"></i></div>' +
              '<div class="giant-vc-modal-title">' +
                '<h4>Phone books</h4>' +
                '<div class="giant-vc-modal-sub">' + $('<div>').text(phName || ('Phone #' + phId)).html() + '</div>' +
              '</div>' +
              '<button type="button" class="giant-vc-modal-close giant-phone-pb-close" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="giant-vc-modal-body">' +
              '<div class="giant-phone-pb-current"></div>' +
              '<div class="giant-pp-add-panel">' +
                '<div style="font-size:11.5px; color:#6b7280; text-transform:uppercase; letter-spacing:.04em; font-weight:600; margin-bottom:8px;">Push another book</div>' +
                '<div class="giant-pp-add-row">' +
                  '<select class="giant-phone-pb-select form-control"><option value="">— Loading available books —</option></select>' +
                  '<button type="button" class="btn giant-vc-btn-primary giant-phone-pb-add"><i class="fa fa-plus"></i> <span>Add</span></button>' +
                '</div>' +
                '<input type="text" class="giant-phone-pb-name form-control" placeholder="Optional label (shown on the handset)" style="margin-top:8px;">' +
              '</div>' +
            '</div>' +
            '<div class="giant-vc-modal-foot">' +
              '<button type="button" class="btn giant-vc-btn-ghost giant-phone-pb-close">Close</button>' +
            '</div>' +
          '</div>' +
        '</div>'
    ).appendTo('#giantModal'); // INSIDE the bootstrap modal — fixes focus trap

    $ov.find('.giant-cdr-tag-dialog').on('click mousedown', function (e) { e.stopPropagation(); });
    var closePhonePb = function () { $ov.remove(); $(document).off('keydown.giantPhonePb'); };
    $ov.find('.giant-phone-pb-close').on('click', closePhonePb);
    $ov.on('click', function (e) { if (e.target === $ov[0]) closePhonePb(); });
    $(document).on('keydown.giantPhonePb', function (e) {
        if (e.key === 'Escape') closePhonePb();
    });

    function loadCurrent() {
        var $cur = $ov.find('.giant-phone-pb-current');
        $cur.html('<div class="text-muted" style="font-size:13px; padding:6px 0;"><i class="fa fa-spinner fa-spin"></i> Loading…</div>');
        $.ajax({
            type: 'post',
            data: { pbxAction: 'getPhonePhoneBooks', ph_id: phId },
            dataType: 'json'
        }).done(function (resp) {
            if (!resp || !resp.ok) {
                $cur.html('<div class="alert alert-danger" style="font-size:13px;">' + ((resp && resp.error) || 'Could not load.') + '</div>');
                return;
            }
            var rows = resp.bindings || [];
            if (!rows.length) {
                $cur.html(
                    '<div style="text-align:center; padding:24px 12px; background:#f9fafb; border:1px dashed #cbd5e1; border-radius:6px; color:#6b7280; font-size:13px;">' +
                      '<i class="fa-duotone fa-address-book fa-2x" style="--fa-primary-color:#cbd5e1; --fa-secondary-color:#e5e7eb; margin-bottom:6px;"></i>' +
                      '<div>No phone books on this handset yet.</div>' +
                      '<div style="font-size:11.5px; color:#9ca3af; margin-top:2px;">Add one below to push it to the phone.</div>' +
                    '</div>'
                );
                return;
            }
            var html = '<div style="font-size:11.5px; color:#6b7280; text-transform:uppercase; letter-spacing:.04em; font-weight:600; margin-bottom:8px;">On this handset</div>';
            html += '<div class="giant-pp-list">';
            rows.forEach(function (r) {
                var label = r.__label || r.pp_name || r.name || ('Phone book #' + (r.pp_id || ''));
                var ppId  = r.pp_id || r.id || '';
                html +=
                    '<div class="giant-pp-row">' +
                      '<i class="fa-solid fa-book giant-pp-icon"></i>' +
                      '<span class="giant-pp-name">' + $('<div>').text(label).html() + '</span>' +
                      '<button type="button" class="giant-pp-remove giant-phone-pb-remove" title="Remove from this phone" data-pp-id="' + $('<div>').text(ppId).html() + '">' +
                        '<i class="fa-solid fa-trash"></i>' +
                      '</button>' +
                    '</div>';
            });
            html += '</div>';
            $cur.html(html);
        }).fail(function () {
            $cur.html('<div class="alert alert-danger" style="font-size:13px;">Network error.</div>');
        });
    }

    function loadAvailableBooks() {
        var $sel = $ov.find('.giant-phone-pb-select');
        $.ajax({
            type: 'post',
            data: { pbxAction: 'getPhoneBookList' },
            dataType: 'json'
        }).done(function (resp) {
            $sel.empty();
            var books = (resp && resp.books) || [];
            if (!books.length) {
                $sel.append('<option value="">No phone books available — create one in the Phone Books tile first</option>');
                $sel.prop('disabled', true);
                $ov.find('.giant-phone-pb-add').prop('disabled', true);
                return;
            }
            $sel.append('<option value="">— Select a book —</option>');
            books.forEach(function (b) {
                $sel.append('<option value="' + $('<div>').text(b.id).html() + '">' + $('<div>').text(b.name).html() + '</option>');
            });
            giantIconSelect($sel, 'fa-address-book', $ov);
        }).fail(function () {
            $sel.html('<option value="">Could not load available books</option>');
        });
    }

    $ov.on('click', '.giant-phone-pb-add', function () {
        var pbId = $ov.find('.giant-phone-pb-select').val();
        var name = $ov.find('.giant-phone-pb-name').val();
        if (!pbId) { alert('Pick a phone book to add.'); return; }
        var $b = $(this).prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i>');
        $.ajax({
            type: 'post',
            data: { pbxAction: 'addPhonePhoneBook', ph_id: phId, pb_id: pbId, pp_name: name },
            dataType: 'json'
        }).done(function (resp) {
            if (resp && resp.success) {
                if (typeof giantToast === 'function') giantToast('Added.', 'success');
                $ov.find('.giant-phone-pb-name').val('');
                loadCurrent();
            } else {
                alert((resp && resp.error) || 'Add failed.');
            }
        }).fail(function () {
            alert('Network error.');
        }).always(function () {
            $b.prop('disabled', false).html('<i class="fa fa-plus"></i> Add to phone');
        });
    });

    $ov.on('click', '.giant-phone-pb-remove', async function () {
        if (!(await giantConfirm('Remove this phone book from the handset?'))) return;
        var ppId = String($(this).data('pp-id') || '');
        var $btn = $(this).prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i>');
        $.ajax({
            type: 'post',
            data: { pbxAction: 'removePhonePhoneBook', pp_id: ppId },
            dataType: 'json'
        }).done(function (resp) {
            if (resp && resp.success) {
                if (typeof giantToast === 'function') giantToast('Removed.', 'success');
                loadCurrent();
            } else {
                alert((resp && resp.error) || 'Remove failed.');
                $btn.prop('disabled', false).html('<i class="fa fa-trash"></i>');
            }
        }).fail(function () {
            alert('Network error.');
            $btn.prop('disabled', false).html('<i class="fa fa-trash"></i>');
        });
    });

    loadCurrent();
    loadAvailableBooks();
});

$(document).off('click', '.giantDndToggle');
$(document).on('click', '.giantDndToggle', function (event) {
    event.preventDefault();

    var $btn = $(this);
    var current = $btn.data('dnd');
    var next = (current === 'on') ? 'off' : 'on';
    var exNumber = $btn.data('ex_number');

    $btn.prop('disabled', true);

    $.ajax({
        type: 'post',
        data: {
            pbxAction: 'setExtensionDnd',
            ex_number: exNumber,
            value: next,
        },
        success: function (responseJson) {
            var response = jQuery.parseJSON(responseJson);
            if (response.error) {
                $('#giantModalAlertDiv').show();
                $('#giantModalAlert').html(response.error);
                $btn.prop('disabled', false);
                return;
            }
            refreshList("extension");
        },
        error: function () {
            $btn.prop('disabled', false);
        }
    });
});

$(document).off('click', '.giantWebphoneLaunch');
$(document).on('click', '.giantWebphoneLaunch', function (event) {
    event.preventDefault();
    var $btn = $(this);
    var ext  = $btn.data('webphone_ext');
    var pass = $btn.data('webphone_pass');
    var name = $btn.data('webphone_name') || '';
    if (!ext || !pass) {
        if (typeof giantToast === 'function') giantToast('Missing WebPhone credentials for this extension.', 'error');
        return;
    }
    if (typeof giantToast === 'function') giantToast('The web phone is not available on this service.', 'warn');
    return;
    var w = null;
    if (!w && typeof giantToast === 'function') {
        giantToast('Your browser blocked the WebPhone popup. Allow popups for this site.', 'warn');
    }
});

$(document).off('click', '.giantClickToCallRow');
$(document).on('click', '.giantClickToCallRow', function (event) {
    event.preventDefault();
    var source = $(this).data('source');
    if (!source) return;
    if (typeof window.openDialModal === 'function') {
        window.openDialModal(source);
    }
});

});

//renderMediaLayout=============================================================
function renderMediaLayout(response, tileName) {

    var $container = $('#giantModalListTableDiv');
    $container.children().remove();

    var mediaCount = response.data ? Object.keys(response.data).length : 0;
    var html = '';

    if (mediaCount === 0) {
        html += '<div class="giant-empty-state" style="padding:40px 20px;">';
        html += '<i class="fa-duotone fa-compact-disc fa-3x" style="--fa-primary-color: #d1d5db; --fa-secondary-color: #e5e7eb; margin-bottom:16px !important;"></i>';
        html += '<p style="font-size:15px; font-weight:600; color:#1a1a2e; margin:0 0 6px;">No media files yet</p>';
        html += '<p style="font-size:13px; color:#6c757d; margin:0 0 4px;">Upload audio files for hold music, welcome messages, and announcements.</p>';
        html += '</div>';
    }

    html += '<div class="media-grid">';

    if (response.data) {
        Object.entries(response.data).forEach(function (entry) {
            var item = entry[1];
            var id = item.me_id;
            var name = item.me_name || 'Untitled';

            html += '<div class="media-card" data-id="' + id + '">';
            html += '  <div class="media-card-icon">';
            html += '    <i class="fa-duotone fa-waveform-lines fa-2x" style="--fa-primary-color: #00d9a7; --fa-secondary-color: #99e15f;"></i>';
            html += '  </div>';
            html += '  <div class="media-card-body">';
            html += '    <div class="media-card-name">' + name + '</div>';
            html += '    <div class="media-card-player giant-mwave" data-id="' + id + '">';
            html += '      <button class="media-play-btn giant-mwave-play" data-id="' + id + '" title="Play">';
            html += '        <i class="fa-solid fa-play"></i>';
            html += '      </button>';
            html += '      <div class="giant-mwave-track">';
            html += '        <canvas class="giant-mwave-canvas"></canvas>';
            html += '        <div class="giant-mwave-loading"><i class="fa-solid fa-spinner fa-spin-pulse"></i></div>';
            html += '      </div>';
            html += '      <span class="giant-mwave-time">0:00</span>';
            html += '    </div>';
            html += '  </div>';
            html += '  <div class="media-card-actions">';
            html += '    <button class="media-action-btn media-edit-btn" data-me_id="' + id + '" data-me_name="' + name.replace(/'/g, "&#39;") + '" title="Edit"><i class="fa-solid fa-pen"></i></button>';
            html += '    <form class="giantModalRemoveForm" style="display:inline;"><input type="hidden" name="pbxAction" value="removeMedia"><input type="hidden" name="me_id" value="' + id + '">';
            html += '      <button type="submit" class="media-action-btn media-delete-btn" title="Delete"><i class="fa-solid fa-trash"></i></button>';
            html += '    </form>';
            html += '  </div>';
            html += '</div>';
        });
    }

    html += '</div>';

    // The shared library: announcements and music the switch holds once for
    // everyone. Playable and pickable in menus and queues, never editable.
    // Behind an accordion so the tile stays as short as the customer's own files.
    var shared = Array.isArray(response.shared) ? response.shared : [];
    if (shared.length) {
        var esc = function (t) { return $('<div>').text(t == null ? '' : String(t)).html(); };
        var groups = [
            { title: 'Announcements', icon: 'fa-bullhorn', items: shared.filter(function (m) { return !m.music; }) },
            { title: 'Music',         icon: 'fa-music',    items: shared.filter(function (m) { return  m.music; }) }
        ];
        var body = '';
        groups.forEach(function (g) {
            if (!g.items.length) return;
            body += '<div class="giant-shared-sub"><i class="fa-solid ' + g.icon + '"></i> ' + g.title + ' <span class="giant-shared-acc-count">' + g.items.length + '</span></div>';
            body += '<div class="media-grid">';
            g.items.forEach(function (m) {
                body += '<div class="media-card is-shared" data-id="' + esc(m.id) + '">';
                body += '  <div class="media-card-icon"><i class="fa-duotone fa-waveform-lines fa-2x" style="--fa-primary-color: #00d9a7; --fa-secondary-color: #99e15f;"></i></div>';
                body += '  <div class="media-card-body">';
                body += '    <div class="media-card-name">' + esc(m.name) + (m.description ? '<div class="media-card-desc">' + esc(m.description) + '</div>' : '') + '</div>';
                body += '    <div class="media-card-player giant-mwave" data-id="' + esc(m.id) + '">';
                body += '      <button class="media-play-btn giant-mwave-play" data-id="' + esc(m.id) + '" title="Play"><i class="fa-solid fa-play"></i></button>';
                body += '      <div class="giant-mwave-track"><canvas class="giant-mwave-canvas"></canvas><div class="giant-mwave-loading"><i class="fa-solid fa-spinner fa-spin-pulse"></i></div></div>';
                body += '      <span class="giant-mwave-time">0:00</span>';
                body += '    </div>';
                body += '  </div>';
                body += '  <div class="media-card-actions"><span class="giant-shared-pill"><i class="fa-solid fa-people-group"></i> Shared</span></div>';
                body += '</div>';
            });
            body += '</div>';
        });
        html += giantSharedAccordion('media', {
            title: 'Shared library', icon: 'fa-people-group', count: shared.length,
            note: 'Ready to use in menus, queues and hold music. Shared with every account, so they can\'t be edited here.'
        }, body);
    }

    $container.append(html);

    // Draw a faint idle waveform in each track so it reads as a player rather
    // than a blank box before the audio is loaded on play.
    requestAnimationFrame(function () {
        $container.find('.giant-mwave-canvas').each(function () { drawMwaveIdle(this); });
    });

    // Add button
    $('#giantModalListDiv').find('#giantAddButton').remove();
    var btnWrap = mediaCount === 0 ? '<div style="text-align:center;">' : '<div>';
    $('#giantModalListDiv').append(btnWrap + '<button id="giantAddButton" class="btn btn-primary" style="margin-top:15px;"><i class="fa-duotone fa-cloud-arrow-up" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> Upload Media File</button></div>');

    $('#giantAddButton').off('click');
    $('#giantAddButton').on('click', function () {
        $('#giantModalAlertDiv').hide();
        showForm(tileName, "add", addFormData[tileName], {});
    });

    // Edit buttons
    $('.media-edit-btn').off('click');
    $('.media-edit-btn').on('click', function () {
        $('#giantModalAlertDiv').hide();
        showForm(tileName, "edit", editFormData[tileName], $(this).data());
    });

    // Remove forms
    $('.giantModalRemoveForm').off('submit');
    $('.giantModalRemoveForm').on('submit', async function (event) {
        event.preventDefault();
        if (!(await giantConfirm('Are you sure you want to delete this media file?'))) return;
        $('#giantModalAlertDiv').hide();
        $('.giantModalPanel').hide();
        $('#giantModalSpinnerDiv').show();
        $.ajax({
            type: 'post',
            data: $(this).serialize(),
            success: function (responseJson) {
                var resp = jQuery.parseJSON(responseJson);
                if (resp && resp.error) {
                    $('#giantModalAlertDiv').show();
                    $('#giantModalAlert').html(resp.error);
                }
                refreshList(tileName);
            }
        });
    });

    // Inline waveform player — same look-and-feel as the call-recording popup
    // but rendered directly in the card. State is kept on the host element
    // (not in singleton globals) so multiple media cards can have their own
    // waveform without colliding. Active Audio objects are also pushed to a
    // global registry so we can stop them on modal close / tile switch.
    window._giantMwaveAudios = window._giantMwaveAudios || [];
    $('.giant-mwave-play').off('click');
    $('.giant-mwave-play').on('click', function () {
        var $btn  = $(this);
        var id    = $btn.data('id');
        var $host = $btn.closest('.giant-mwave');
        if ($host.data('playing-loaded')) {
            // Already loaded — toggle play/pause.
            var audio = $host.data('audio');
            if (audio.paused) audio.play(); else audio.pause();
            return;
        }
        if ($host.data('loading')) return; // ignore double-click while fetching
        $host.data('loading', true);
        $host.find('.giant-mwave-loading').addClass('is-active').html('<i class="fa-solid fa-spinner fa-spin-pulse"></i>');

        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.pbxConfig.endpoint, true);
        xhr.responseType = 'arraybuffer';
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function () {
            $host.data('loading', false);
            if (xhr.status !== 200) {
                var msg, tip;
                if (xhr.status === 404) {
                    // The file record exists but the PBX has no stored audio for
                    // it — the upload never actually landed the binary. Re-upload
                    // the file to fix it.
                    msg = 'No audio stored';
                    tip = 'This file has no audio on the server (the upload didn\'t complete). Edit it and re-upload the audio file.';
                } else if (xhr.status === 502) {
                    msg = 'Preview unavailable';
                    tip = 'The audio service couldn\'t return this file. Please try again in a moment.';
                } else {
                    msg = 'Failed (' + xhr.status + ')';
                    tip = 'The audio service returned an error. Please try again in a moment.';
                }
                $host.find('.giant-mwave-loading')
                     .addClass('is-active')
                     .attr('title', tip)
                     .html('<span style="color:#dc2626; font-size:11px;"><i class="fa-solid fa-triangle-exclamation" style="margin-right:4px;"></i>' + msg + '</span>');
                return;
            }
            var arrayBuffer = xhr.response;

            // Sniff the first bytes — if it's not a recognisable audio
            // container the carrier probably returned an error page disguised
            // as 200. Surface a clearer message instead of trying to decode.
            var head = new Uint8Array(arrayBuffer.slice(0, 4));
            var isRiff = head[0] === 0x52 && head[1] === 0x49 && head[2] === 0x46 && head[3] === 0x46; // "RIFF"
            var isMpeg = (head[0] === 0xFF && (head[1] & 0xE0) === 0xE0) || (head[0] === 0x49 && head[1] === 0x44 && head[2] === 0x33); // MP3 frame or ID3
            var isOgg  = head[0] === 0x4F && head[1] === 0x67 && head[2] === 0x67 && head[3] === 0x53; // "OggS"
            if (!isRiff && !isMpeg && !isOgg) {
                $host.find('.giant-mwave-loading').addClass('is-active').html('<span style="color:#dc2626; font-size:11px;">No audio</span>');
                return;
            }

            // Pick a MIME for the blob based on what we sniffed so the
            // browser's HTML5 audio element decodes it correctly even when
            // the Web Audio API can't draw a waveform for it.
            var blobMime = isMpeg ? 'audio/mpeg' : (isOgg ? 'audio/ogg' : 'audio/wav');
            var blob     = new Blob([arrayBuffer], { type: blobMime });
            var blobUrl  = URL.createObjectURL(blob);

            var audio = new Audio();
            audio.src = blobUrl;
            $host.data('audio',   audio);
            $host.data('blobUrl', blobUrl);
            window._giantMwaveAudios.push(audio);

            // Decode for waveform and render once. decodeAudioData rejects
            // asynchronously on unsupported encodings (e.g. 8-bit μ-law WAV,
            // GSM-encoded WAV) — we treat that as non-fatal: the audio still
            // plays via the blob URL, we just skip the waveform render and
            // fall back to a flat track with the existing seek behaviour.
            var didRenderWave = false;
            try {
                var ctxAudio = new (window.AudioContext || window.webkitAudioContext)();
                ctxAudio.decodeAudioData(
                    arrayBuffer.slice(0),
                    function (buffer) {
                        didRenderWave = true;
                        drawInlineWaveform($host, buffer, 0);
                        $host.find('.giant-mwave-loading').removeClass('is-active');
                    },
                    function () {
                        // Decode failed — the file plays fine via HTML5 audio
                        // but we can't visualise it. Hide the spinner and let
                        // the seek-on-click-track behaviour still work.
                        $host.find('.giant-mwave-loading').removeClass('is-active');
                        $host.find('.giant-mwave-canvas').css('opacity', '0.4');
                    }
                );
            } catch (e) {
                $host.find('.giant-mwave-loading').hide();
                $host.find('.giant-mwave-canvas').css('opacity', '0.4');
            }

            audio.onloadedmetadata = function () {
                $host.find('.giant-mwave-time').text(fmtMSS(audio.duration || 0));
            };

            audio.ontimeupdate = function () {
                if (!audio.duration) return;
                var pct = audio.currentTime / audio.duration;
                drawInlineWaveform($host, null, pct);
                $host.find('.giant-mwave-time').text(fmtMSS(audio.currentTime));
            };

            audio.onended = function () {
                drawInlineWaveform($host, null, 0);
                $btn.html('<i class="fa-solid fa-play"></i>').removeClass('playing');
                $host.find('.giant-mwave-time').text('0:00');
            };

            audio.onplay  = function () { $btn.html('<i class="fa-solid fa-pause"></i>').addClass('playing'); };
            audio.onpause = function () {
                if (!audio.ended) $btn.html('<i class="fa-solid fa-play"></i>').removeClass('playing');
            };

            // Click on the waveform track to seek.
            $host.find('.giant-mwave-track').off('click').on('click', function (e) {
                if (!audio.duration) return;
                var rect = this.getBoundingClientRect();
                audio.currentTime = ((e.clientX - rect.left) / rect.width) * audio.duration;
            });

            $host.data('playing-loaded', true);
            audio.play();
        };
        xhr.onerror = function () {
            $host.data('loading', false);
            $host.find('.giant-mwave-loading').addClass('is-active').html('<span style="color:#dc2626; font-size:11px;">Failed</span>');
        };
        xhr.send(pbxApi.body('pbxAction=playMedia&itemId=' + encodeURIComponent(id)));
    });

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

//renderVoicemailLayout==========================================================
function renderVoicemailLayout(response, tileName) {

    var $container = $('#giantModalListTableDiv');
    $container.children().remove();

    var html = '';
    var dataCount = response.data ? Object.keys(response.data).length : 0;

    if (dataCount === 0) {
        html += '<div class="giant-empty-state" style="padding:40px 20px;">';
        html += '<i class="fa-duotone fa-voicemail fa-3x" style="--fa-primary-color: #d1d5db; --fa-secondary-color: #e5e7eb; margin-bottom:16px !important;"></i>';
        html += '<p style="font-size:15px; font-weight:600; color:#1a1a2e; margin:0 0 6px;">No voicemail boxes yet</p>';
        html += '<p style="font-size:13px; color:#6c757d; margin:0;">Create a voicemail box to start receiving messages.</p>';
        html += '</div>';
    } else {
        html += '<div class="giant-vm-grid">';
        Object.entries(response.data).forEach(function(entry) {
            var item = entry[1];
            var name = item.fullname || 'Mailbox';
            var mbox = item.mailbox_num || item.mailbox || '';
            var email = item.email || '';
            var newCount = item.new_count || 0;
            var totalCount = item.total_count || 0;

            html += '<div class="giant-vm-card" data-mailbox="' + mbox + '">';
            html += '  <div class="giant-vm-card-icon"><i class="fa-duotone fa-voicemail fa-lg" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f; margin-bottom:0;"></i></div>';
            html += '  <div class="giant-vm-card-body">';
            html += '    <div class="giant-vm-card-name">' + name + '</div>';
            html += '    <div class="giant-vm-card-meta">Mailbox ' + mbox;
            if (email) html += ' &middot; ' + email;
            html += '</div>';
            html += '  </div>';
            html += '  <div class="giant-vm-card-counts">';
            if (newCount > 0) {
                html += '<span class="giant-vm-badge-new">' + newCount + ' new</span>';
            }
            html += '<span class="giant-vm-badge-total">' + totalCount + ' total</span>';
            html += '  </div>';
            html += '  <div class="giant-vm-card-actions">';
            html += '    <button class="giant-vm-open giant-icon-btn giant-icon-edit" data-mailbox="' + mbox + '" data-name="' + name.replace(/"/g, '&quot;') + '" title="View Messages"><i class="fa-solid fa-inbox"></i></button>';
            // The whole row (every setting, decorated for the form) — the data-* attributes below only carry a few.
            window._giantVmRows = window._giantVmRows || {};
            window._giantVmRows[String(item.uniqueid || '')] = item;
            html += '    <button class="giantEditButton giant-icon-btn giant-icon-edit" title="Edit"';
            html += '      data-uniqueid="' + (item.uniqueid || '') + '" data-fullname="' + name.replace(/"/g, '&quot;') + '" data-mailbox="' + (item.mailbox || '') + '" data-email="' + email.replace(/"/g, '&quot;') + '"';
            html += '    ><i class="fa-solid fa-pen"></i></button>';
            html += '    <form class="giantModalRemoveForm" method="post" style="display:inline;"><input type="hidden" name="pbxAction" value="removeVoicemail"><input type="hidden" name="uniqueid" value="' + (item.uniqueid || '') + '">';
            html += '      <button type="submit" class="giant-icon-btn giant-icon-delete" title="Remove"><i class="fa-solid fa-trash"></i></button></form>';
            html += '  </div>';
            html += '</div>';
        });
        html += '</div>';
    }

    // Inbox view (hidden by default)
    html += '<div id="vmInboxView" style="display:none;">';
    html += '  <button id="vmBackToList" class="btn btn-secondary" style="margin-bottom:12px; margin-top:0;"><i class="fa-solid fa-arrow-left" style="margin-bottom:0;"></i> Back to mailboxes</button>';
    html += '  <h5 id="vmInboxTitle" style="font-weight:700; margin:0 0 12px;"></h5>';
    html += '  <div id="vmInboxMessages"></div>';
    html += '</div>';

    $container.html(html);

    // Add button
    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').find('.giant-empty-state').filter(function() { return !$(this).closest('#giantModalListTableDiv').length; }).remove();
    $('#giantModalListDiv').append('<div style="' + (dataCount === 0 ? 'text-align:center;' : '') + '"><button id="giantAddButton" class="btn btn-primary"><i class="fa-solid fa-plus" style="margin-bottom:0;"></i> Add Voicemail Box</button></div>');

    $('#giantAddButton').off('click').on('click', function() {
        $('#giantModalAlertDiv').hide();
        showForm(tileName, "add", addFormData[tileName], {});
    });

    // Edit buttons
    $('.giantEditButton').off('click').on('click', function() {
        $('#giantModalAlertDiv').hide();
        var vmRow = (window._giantVmRows || {})[String($(this).data('uniqueid') || '')];
        showForm(tileName, "edit", editFormData[tileName], vmRow ? $.extend({}, vmRow) : $(this).data());
    });

    // Remove forms
    $('.giantModalRemoveForm').off('submit').on('submit', async function (event) {
        event.preventDefault();
        if (!(await giantConfirm('Remove this voicemail box?'))) return;
        $.ajax({ type: 'post', data: $(this).serialize(), success: function() { refreshList(tileName); } });
    });

    // Open inbox
    $('.giant-vm-open').off('click').on('click', function() {
        var mailbox = $(this).data('mailbox');
        var name = $(this).data('name');
        openVoicemailInbox(mailbox, name, tileName);
    });

    // Also click on card to open
    $('.giant-vm-card').off('click').on('click', function(e) {
        if ($(e.target).closest('.giant-icon-btn, .giantModalRemoveForm, button, a').length) return;
        var mailbox = $(this).data('mailbox');
        var name = $(this).find('.giant-vm-card-name').text();
        openVoicemailInbox(mailbox, name, tileName);
    });

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

function openVoicemailInbox(mailbox, name, tileName) {
    $('.giant-vm-grid').hide();
    $('#giantAddButton').parent().hide();
    $('#vmInboxView').show();
    $('#vmInboxTitle').html('<i class="fa-duotone fa-inbox" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f; margin-bottom:0;"></i> ' + name + ' (Mailbox ' + mailbox + ')');
    $('#vmInboxMessages').html('<div class="giant-spinner" style="padding:20px;"><i class="fa-duotone fa-spinner fa-spin-pulse" style="--fa-primary-color: #00d9a7; --fa-secondary-color: #00d9a7;"></i></div>');

    $('#vmBackToList').off('click').on('click', function() {
        $('#vmInboxView').hide();
        $('.giant-vm-grid').show();
        $('#giantAddButton').parent().show();
    });

    $.ajax({
        type: 'post',
        data: { pbxAction: 'getVoicemailMessages', mailbox: mailbox },
        success: function(json) {
            var resp;
            try { resp = (typeof json === 'object') ? json : jQuery.parseJSON(json); } catch(e) { resp = {}; }

            if (resp.error) {
                $('#vmInboxMessages').html('<div class="giant-alert">' + resp.error + '</div>');
                return;
            }

            var msgs = resp.messages;
            if (!msgs || (Array.isArray(msgs) && msgs.length === 0) || Object.keys(msgs).length === 0) {
                $('#vmInboxMessages').html('<div class="giant-empty-state" style="padding:20px;"><i class="fa-duotone fa-inbox fa-2x" style="--fa-primary-color:#d1d5db; --fa-secondary-color:#e5e7eb;"></i><p>No messages in this mailbox.</p></div>');
                return;
            }

            var html = '<div class="giant-vm-msg-list">';
            var msgArr = Array.isArray(msgs) ? msgs : Object.values(msgs);

            // Debug: log first message to see structure
            if (msgArr.length > 0) console.log('[Voicemail] Sample message:', JSON.stringify(msgArr[0]).substring(0, 500));

            msgArr.forEach(function(msg, idx) {
                // The PBX's message id is msg_id ("1788535530-00001ae8"); newer
                // switch versions also return a database row id as `id`, which
                // the message / transcript / mark-read actions do NOT accept.
                var msgId = msg.msg_id || msg.msgid || msg.id || idx;
                // …while transcripts (INFO voicemailtranscript) want that row id.
                var rowId = (msg.id !== undefined && msg.id !== null && String(msg.id) !== String(msgId)) ? msg.id : '';
                var callerid = msg.callerid || msg.calleridnum || msg.origmailbox || msg.cid || 'Unknown';
                var duration = msg.duration || msg.dur || '0';
                var date = msg.origdate || msg.date || msg.origtime || msg.msg_date || '';
                var folder = (msg.folder || msg.dir || '').toString();

                // Detect unread: INBOX = new, Old/old/Family/etc = read
                // Also check if the dir path contains INBOX
                var isNew = false;
                var folderLower = folder.toLowerCase();
                if (folderLower === 'inbox' || folderLower === 'new') {
                    isNew = true;
                } else if (folder.indexOf('INBOX') > -1 && folder.indexOf('Old') === -1) {
                    isNew = true;
                }
                // If no folder info at all, check if msg has a 'read' or 'status' field
                if (!folder && msg.read !== undefined) {
                    isNew = !msg.read || msg.read === '0' || msg.read === 'no';
                }
                if (!folder && msg.status !== undefined) {
                    isNew = msg.status === 'unread' || msg.status === 'new';
                }

                var durMins = Math.floor(parseInt(duration) / 60);
                var durSecs = parseInt(duration) % 60;
                var durStr = durMins + ':' + (durSecs < 10 ? '0' : '') + durSecs;

                html += '<div class="giant-vm-msg' + (isNew ? ' giant-vm-msg-new' : ' giant-vm-msg-read') + '" data-msgid="' + msgId + '" data-mailbox="' + mailbox + '">';
                html += '  <div class="giant-vm-msg-status">' + (isNew ? '<span class="giant-vm-new-dot" title="Unread"></span>' : '<span class="giant-vm-read-dot" title="Read"></span>') + '</div>';
                html += '  <div class="giant-vm-msg-info">';
                html += '    <div class="giant-vm-msg-caller">' + (isNew ? '<strong>' : '') + callerid + (isNew ? '</strong>' : '') + '</div>';
                html += '    <div class="giant-vm-msg-meta">' + date + ' &middot; ' + durStr + (isNew ? ' &middot; <span class="giant-vm-unread-label">New</span>' : '') + '</div>';
                html += '  </div>';
                html += '  <div class="giant-vm-msg-actions">';
                html += '    <button class="giant-vm-play giant-icon-btn" data-mailbox="' + mailbox + '" data-msgid="' + msgId + '" data-rowid="' + rowId + '" title="Play"><i class="fa-solid fa-play"></i></button>';
                html += '    <button class="giant-vm-transcript giant-icon-btn" data-mailbox="' + mailbox + '" data-msgid="' + msgId + '" data-rowid="' + rowId + '" title="Transcript"><i class="fa-solid fa-quote-left"></i></button>';
                html += '    <button class="giant-vm-toggle-read giant-icon-btn" data-mailbox="' + mailbox + '" data-msgid="' + msgId + '" data-is-new="' + (isNew ? '1' : '0') + '" title="' + (isNew ? 'Mark as read' : 'Mark as unread') + '"><i class="fa-solid ' + (isNew ? 'fa-envelope-open' : 'fa-envelope') + '"></i></button>';
                html += '  </div>';
                html += '</div>';
            });
            html += '</div>';

            $('#vmInboxMessages').html(html);

            // Play buttons
            $('.giant-vm-play').off('click').on('click', function() {
                var $btn = $(this);
                var mb = $btn.data('mailbox');
                var mid = $btn.data('msgid');
                var caller = $btn.closest('.giant-vm-msg').find('.giant-vm-msg-caller').text();
                var meta = $btn.closest('.giant-vm-msg').find('.giant-vm-msg-meta').text();

                // Mark as read visually
                $btn.closest('.giant-vm-msg').removeClass('giant-vm-msg-new');
                $btn.closest('.giant-vm-msg').find('.giant-vm-new-dot').remove();

                // Mark as read on server
                $.ajax({ type: 'post', data: { pbxAction: 'markVoicemailRead', mailbox: mb, msgId: mid } });

                // Update UI
                var $msg = $btn.closest('.giant-vm-msg');
                $msg.removeClass('giant-vm-msg-new').addClass('giant-vm-msg-read');
                $msg.find('.giant-vm-new-dot').replaceWith('<span class="giant-vm-read-dot" title="Read"></span>');
                $msg.find('.giant-vm-unread-label').remove();
                $msg.find('.giant-vm-msg-caller strong').contents().unwrap();
                var $toggleBtn = $msg.find('.giant-vm-toggle-read');
                $toggleBtn.data('is-new', '0').attr('title', 'Mark as unread').html('<i class="fa-solid fa-envelope"></i>');

                // The same player the call log uses: waveform, transcript bubbles, AI summary.
                openVoicemailPopup(mb, mid, $btn.data('rowid') || '', caller, meta);
            });

            // Transcript buttons — open a dialog showing the carrier-generated
            // transcript for this voicemail. Transcripts come back from the
            // carrier already trimmed; we just render them in a scrollable
            // box. Empty/unavailable transcripts surface a friendly message
            // (the carrier sometimes takes a few minutes to process).
            // Transcript button: the same popup, so playback, transcript and
            // summary are always together — exactly like a call recording.
            $('.giant-vm-transcript').off('click').on('click', function() {
                var $btn = $(this);
                var mb   = $btn.data('mailbox');
                var mid  = $btn.data('msgid');
                var caller = $btn.closest('.giant-vm-msg').find('.giant-vm-msg-caller').text();
                var meta   = $btn.closest('.giant-vm-msg').find('.giant-vm-msg-meta').text();
                openVoicemailPopup(mb, mid, $btn.data('rowid') || '', caller, meta);
            });

            // Waveform player + transcript + AI summary for one voicemail.
            function openVoicemailPopup(mb, mid, rowId, caller, meta) {
                openRecordingPopup('vm_' + mb + '_' + mid, {
                    caller: caller,
                    started: meta,
                    direction: 'Voicemail'
                }, 'pbxAction=playVoicemailMessage&mailbox=' + encodeURIComponent(mb) + '&msgId=' + encodeURIComponent(mid) + '&rowId=' + encodeURIComponent(rowId),
                   { pbxAction: 'getVoicemailTranscript', mailbox: mb, msgId: mid, rowId: rowId });
            }

            // Toggle read/unread buttons
            $('.giant-vm-toggle-read').off('click').on('click', function() {
                var $btn = $(this);
                var mb = $btn.data('mailbox');
                var mid = $btn.data('msgid');
                var isNew = $btn.data('is-new') === '1' || $btn.data('is-new') === 1;
                var $msg = $btn.closest('.giant-vm-msg');

                if (isNew) {
                    // Mark as read
                    $.ajax({ type: 'post', data: { pbxAction: 'markVoicemailRead', mailbox: mb, msgId: mid } });
                    $msg.removeClass('giant-vm-msg-new').addClass('giant-vm-msg-read');
                    $msg.find('.giant-vm-new-dot').replaceWith('<span class="giant-vm-read-dot" title="Read"></span>');
                    $msg.find('.giant-vm-unread-label').remove();
                    $msg.find('.giant-vm-msg-caller strong').contents().unwrap();
                    $btn.data('is-new', '0').attr('title', 'Mark as unread').html('<i class="fa-solid fa-envelope"></i>');
                } else {
                    // Mark as unread
                    $.ajax({ type: 'post', data: { pbxAction: 'markVoicemailUnread', mailbox: mb, msgId: mid } });
                    $msg.removeClass('giant-vm-msg-read').addClass('giant-vm-msg-new');
                    $msg.find('.giant-vm-read-dot').replaceWith('<span class="giant-vm-new-dot" title="Unread"></span>');
                    $msg.find('.giant-vm-msg-caller').html('<strong>' + $msg.find('.giant-vm-msg-caller').text() + '</strong>');
                    var $meta = $msg.find('.giant-vm-msg-meta');
                    if (!$meta.find('.giant-vm-unread-label').length) {
                        $meta.append(' &middot; <span class="giant-vm-unread-label">New</span>');
                    }
                    $btn.data('is-new', '1').attr('title', 'Mark as read').html('<i class="fa-solid fa-envelope-open"></i>');
                }
            });
        }
    });
}

//renderFaxLayout================================================================
// Renders the fax inbox/outbox grid plus a "Send fax" entry point.
// Each row shows direction, from/to, date, status, pages and view/download
// buttons. The send-fax dialog is built lazily on click of the green action
// button at the bottom.
function renderFaxLayout(response, tileName) {

    var $container = $('#giantModalListTableDiv');
    $container.children().remove();

    var rows          = response.data || [];
    var sourceNumbers = response.sourceNumbers || [];
    var dataCount     = rows.length;

    var html = '';

    if (response.error) {
        html += '<div class="giant-alert">' + response.error + '</div>';
    }

    if (dataCount === 0 && !response.error) {
        html += '<div class="giant-empty-state" style="padding:40px 20px;">';
        html += '  <i class="fa-duotone fa-fax fa-3x" style="--fa-primary-color: #d1d5db; --fa-secondary-color: #e5e7eb; margin-bottom:16px !important;"></i>';
        html += '  <p style="font-size:15px; font-weight:600; color:#1a1a2e; margin:0 0 6px;">No faxes yet</p>';
        html += '  <p style="font-size:13px; color:#6c757d; margin:0;">Use the button below to send your first fax.</p>';
        html += '</div>';
    } else {
        html += '<div class="giant-fax-list">';
        rows.forEach(function (fax) {
            var isInbound = (fax.direction || '').toLowerCase() === 'in' || (fax.direction || '').toLowerCase() === 'inbound' || (fax.direction || '').toLowerCase() === 'received';
            var directionLabel = isInbound ? 'Received' : 'Sent';
            var directionIcon  = isInbound ? 'fa-arrow-down-to-bracket' : 'fa-arrow-up-from-bracket';
            var statusKey      = (fax.status || '').toLowerCase();
            var statusClass    = 'is-pending';
            if (statusKey.indexOf('success') !== -1 || statusKey === 'ok' || statusKey === 'sent' || statusKey === 'delivered' || statusKey === 'received') statusClass = 'is-ok';
            else if (statusKey.indexOf('fail') !== -1 || statusKey.indexOf('error') !== -1 || statusKey === 'rejected') statusClass = 'is-fail';

            html += '<div class="giant-fax-row" data-fax-id="' + fax.id + '">';
            html += '  <div class="giant-fax-direction"><i class="fa-solid ' + directionIcon + '"></i><span>' + directionLabel + '</span></div>';
            html += '  <div class="giant-fax-info">';
            html += '    <div class="giant-fax-numbers"><strong>' + (isInbound ? (fax.from || '—') : (fax.to || '—')) + '</strong>';
            if (isInbound && fax.to) html += ' <span class="giant-fax-meta">to ' + fax.to + '</span>';
            if (!isInbound && fax.from) html += ' <span class="giant-fax-meta">from ' + fax.from + '</span>';
            html += '</div>';
            html += '    <div class="giant-fax-meta">' + (fax.date || '—');
            if (fax.pages) html += ' &middot; ' + fax.pages + ' page' + (fax.pages === '1' ? '' : 's');
            html += '</div>';
            html += '  </div>';
            if (fax.status) {
                html += '  <div class="giant-fax-status ' + statusClass + '">' + fax.status + '</div>';
            } else {
                html += '  <div class="giant-fax-status"></div>';
            }
            html += '  <div class="giant-fax-actions">';
            if (fax.id) {
                html += '    <button type="button" class="giant-fax-view giant-icon-btn" data-fax-id="' + fax.id + '" title="View"><i class="fa-solid fa-eye"></i></button>';
                html += '    <button type="button" class="giant-fax-download giant-icon-btn" data-fax-id="' + fax.id + '" title="Download"><i class="fa-solid fa-download"></i></button>';
            }
            html += '  </div>';
            html += '</div>';
        });
        html += '</div>';
    }

    $container.html(html);

    // "Send fax" action button — reuses the standard #giantAddButton id so
    // refreshList's existing cleanup removes it cleanly when the customer
    // switches to another tile (otherwise the fax button persists on
    // Voicemail / Devices / etc.).
    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').append(
      '<div style="' + (dataCount === 0 ? 'text-align:center;' : 'text-align:right;') + ' margin-top: 12px;">' +
        '<button id="giantAddButton" class="btn btn-primary"><i class="fa-solid fa-paper-plane" style="margin-bottom:0;"></i> Send fax</button>' +
      '</div>'
    );

    $('#giantAddButton').off('click').on('click', function () {
        showSendFaxDialog(sourceNumbers, function () {
            // Re-fetch list after a successful send so the new outbound
            // entry shows up immediately.
            refreshList(tileName);
        });
    });

    // View buttons — open the carrier's PDF inline in a new tab.
    $('.giant-fax-view').off('click').on('click', function () {
        var id = $(this).data('fax-id');
        if (!id) return;
        window.open(pbxApi.url('downloadFax', { faxId: id }), '_blank');
    });

    // Download buttons — same endpoint with download=1 forces the PDF as
    // an attachment rather than inline preview.
    $('.giant-fax-download').off('click').on('click', function () {
        var id = $(this).data('fax-id');
        if (!id) return;
        window.open(pbxApi.url('downloadFax', { faxId: id, download: 1 }), '_blank');
    });

    // refreshList() hides every modal panel before dispatching to a custom
    // layout, so each renderer is responsible for un-hiding the list div.
    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

//renderPhoneBookLayout==========================================================
// Shared contact directory across the tenant. Layout: list of phone books on
// the left (or as a tab strip when there's only a few), contacts in the
// selected book on the right with quick add/delete. Most tenants only have
// one book so we collapse the picker when count === 1.
// Shared by both the empty-state form and the inline create form on
// the populated tab strip. Reads #giantPbNewName, posts to
// createPhoneBook, refreshes the tile + selects the new book.
function giantPbCreateBook(tileName) {
    var $inp = $('#giantPbNewName');
    var name = String($inp.val() || '').trim();
    if (!name) { $inp.focus(); return; }

    var $btn = $('#giantPbNewBtn').prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i>');
    $.ajax({
        type: 'post',
        data: { pbxAction: 'createPhoneBook', pb_name: name },
        dataType: 'json'
    }).done(function (resp) {
        if (resp && resp.success) {
            if (typeof giantToast === 'function') giantToast('Phone book created.', 'success');
            window._giantPbAutoSelectId = String(resp.pb_id || '');
            refreshList(tileName);
        } else {
            alert((resp && resp.error) || 'Could not create phone book.');
            $btn.prop('disabled', false).html('<i class="fa-solid fa-plus"></i> Create');
        }
    }).fail(function () {
        alert('Network error.');
        $btn.prop('disabled', false).html('<i class="fa-solid fa-plus"></i> Create');
    });
}

function renderPhoneBookLayout(response, tileName) {
    var $container = $('#giantModalListTableDiv');
    $container.children().remove();

    var books = response.books || [];

    var html = '';
    if (response.error) {
        html += '<div class="giant-alert">' + response.error + '</div>';
    }
    if (!books.length) {
        html += '<div class="giant-empty-state" style="padding:40px 20px;">';
        html += '  <i class="fa-duotone fa-address-book fa-3x" style="--fa-primary-color: #d1d5db; --fa-secondary-color: #e5e7eb; margin-bottom:16px !important;"></i>';
        html += '  <p style="font-size:15px; font-weight:600; color:#1a1a2e; margin:0 0 6px;">No phone books yet</p>';
        html += '  <p style="font-size:13px; color:#6c757d; margin:0 0 16px;">Create your first phone book and start adding contacts your team can dial.</p>';
        html += '  <div class="giant-pb-create" style="display:flex; gap:8px; justify-content:center; flex-wrap:wrap;">';
        html += '    <input type="text" id="giantPbNewName" maxlength="50" placeholder="Phone book name" style="padding:7px 11px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px; min-width:240px;">';
        html += '    <button type="button" id="giantPbNewBtn" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Create phone book</button>';
        html += '  </div>';
        html += '</div>';
        $container.html(html);
        $('#giantModalListDiv').find('#giantAddButton').remove();
        $('.giantModalPanel').hide();
        $('#giantModalListDiv').show();

        $('#giantPbNewBtn').off('click').on('click', function () { giantPbCreateBook(tileName); });
        $('#giantPbNewName').off('keydown').on('keydown', function (e) { if (e.key === 'Enter') giantPbCreateBook(tileName); });
        return;
    }

    // Tab strip across all books — even if only one, it gives a visible
    // header so the user knows what they're looking at. Trailing
    // "+ New" button opens an inline create form.
    html += '<div class="giant-pb-tabs" id="giantPbTabs">';
    books.forEach(function (b, i) {
        var active = i === 0 ? ' is-active' : '';
        html += '<button type="button" class="giant-pb-tab' + active + '" ' +
                'data-book-id="'   + (b.id   || '') + '" ' +
                'data-book-name="' + (b.name || '').replace(/"/g, '&quot;') + '">' +
                '<i class="fa-solid fa-address-book"></i> ' + (b.name || 'Phone book') +
                '</button>';
    });
    html += '<button type="button" class="giant-pb-tab giant-pb-tab-new" id="giantPbNewTab" title="Create a new phone book">' +
            '<i class="fa-solid fa-plus"></i> New' +
            '</button>';
    html += '</div>';
    html += '<div id="giantPbNewInline" style="display:none; margin:10px 0; padding:12px 14px; background:#f9fafb; border:1px solid #e5e7eb; border-radius:6px;">' +
            '  <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">' +
            '    <input type="text" id="giantPbNewName" maxlength="50" placeholder="Phone book name" style="flex:1; min-width:200px; padding:7px 11px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px;">' +
            '    <button type="button" id="giantPbNewBtn" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Create</button>' +
            '    <button type="button" id="giantPbNewCancel" class="btn btn-default btn-sm">Cancel</button>' +
            '  </div>' +
            '</div>';
    html += '<div id="giantPbContacts" class="giant-pb-contacts"><div class="giant-spinner" style="padding:20px;">' +
            '<i class="fa-duotone fa-spinner fa-spin-pulse" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i></div></div>';

    $container.html(html);

    // "Add contact" lives at the standard giantAddButton anchor so the
    // tile-switch cleanup picks it up when the customer leaves.
    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').append(
        '<div style="text-align:right; margin-top: 12px;">' +
        '  <button id="giantAddButton" class="btn btn-primary"><i class="fa-solid fa-plus" style="margin-bottom:0;"></i> Add contact</button>' +
        '</div>'
    );

    // Auto-select the just-created book if we have a pending pick.
    var preferredId = window._giantPbAutoSelectId || '';
    window._giantPbAutoSelectId = '';
    var currentBook = books[0];
    if (preferredId) {
        var match = books.filter(function (b) { return String(b.id) === preferredId; })[0];
        if (match) {
            currentBook = match;
            $('#giantPbTabs .giant-pb-tab').removeClass('is-active');
            $('#giantPbTabs .giant-pb-tab[data-book-id="' + preferredId + '"]').addClass('is-active');
        }
    }

    // Schema lives at the layout level (set on first load) so add/render
    // can both rely on it. It's an ordered list of {code, label} pairs:
    // code = pi_code (NAME / PHONE1 / …), label = pi_name (Name / Phone / …).
    var bookSchema = [];

    // Same allow-list as the Add form — Additional Phone 2-5, SIP Address,
    // XMPP Address, Company, Account Number etc. are kept out of both the
    // entry form AND the display so the table fits in the modal without
    // horizontal scroll. Customers who need those fields manage them in
    // the the app portal where the full schema is exposed.
    var visibleCodes = ['NAME', 'PHONE1', 'PHONE2', 'EMAIL'];
    function filterSchema(schema) {
        return (schema || []).filter(function (col) {
            return visibleCodes.indexOf(col.code) !== -1;
        });
    }

    function loadContacts(book) {
        var $area = $('#giantPbContacts');
        $area.html('<div class="giant-spinner" style="padding:20px;"><i class="fa-duotone fa-spinner fa-spin-pulse" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i></div>');
        $.ajax({
            type: 'post',
            data: { pbxAction: 'getPhoneBookContacts', phonebookId: book.id || '' },
            dataType: 'json'
        }).done(function (resp) {
            if (!resp || !resp.ok) {
                $area.html('<div class="giant-alert">' + ((resp && resp.error) || 'Could not load contacts.') + '</div>');
                return;
            }
            bookSchema = filterSchema(resp.schema || []);
            renderContactsTable($area, book, resp.contacts || [], bookSchema);
        }).fail(function () {
            $area.html('<div class="giant-alert">Could not reach the contacts service.</div>');
        });
    }

    function renderContactsTable($area, book, contacts, schema) {
        if (!contacts.length) {
            $area.html('<div class="giant-empty-state" style="padding:30px 20px;">' +
                '<i class="fa-duotone fa-address-book fa-2x" style="--fa-primary-color:#d1d5db; --fa-secondary-color:#e5e7eb;"></i>' +
                '<p style="font-size:14px; color:#6c757d; margin:8px 0 0;">No contacts in this book yet. Add one with the button below.</p>' +
                '</div>');
            return;
        }

        // Use the schema as the canonical column order. Fields come back
        // keyed by pi_code (NAME, PHONE1, …); the schema gives the
        // display label and the iteration order.
        var t = '<table class="table giant-pb-table"><thead><tr>';
        schema.forEach(function (col) {
            t += '<th>' + col.label + '</th>';
        });
        t += '<th style="width:80px;"></th></tr></thead><tbody>';
        contacts.forEach(function (c) {
            t += '<tr data-peid="' + (c.peid || '') + '">';
            schema.forEach(function (col) {
                var val = (c.fields && c.fields[col.code]) || '';
                // Treat any field whose code starts with PHONE as a phone
                // number (PHONE1 / PHONE2) — shows a click-to-call icon.
                var isPhoneCol = /^PHONE/i.test(col.code);
                if (val && isPhoneCol) {
                    t += '<td><span class="giant-pb-num">' + val + ' ' +
                         '<button type="button" class="giantClickToCallRow giant-icon-btn giant-pb-call" title="Click-to-call" data-source="' + val + '"><i class="fa-solid fa-phone"></i></button>' +
                         '</span></td>';
                } else {
                    t += '<td>' + (val || '') + '</td>';
                }
            });
            t += '<td><button type="button" class="giant-pb-delete giant-icon-btn giant-icon-delete" title="Remove" data-peid="' + (c.peid || '') + '"><i class="fa-solid fa-trash"></i></button></td>';
            t += '</tr>';
        });
        t += '</tbody></table>';
        $area.html(t);

        // Delete handlers (with confirm).
        $area.find('.giant-pb-delete').off('click').on('click', function () {
            var peid = $(this).data('peid');
            if (!peid) return;
            giantConfirm({
                title:        'Remove contact?',
                body:         '<p>This will permanently remove the contact from <strong>' + (book.name || 'this book') + '</strong>.</p>',
                icon:         'unlink',
                variant:      'danger',
                confirmLabel: 'Remove',
                onConfirm:    function () {
                    $.ajax({
                        type: 'post',
                        data: { pbxAction: 'deletePhoneBookContact', phonebookId: book.id || '', peid: peid },
                        dataType: 'json'
                    }).done(function (resp) {
                        if (resp && resp.ok) {
                            if (typeof giantToast === 'function') giantToast('Contact removed.', 'success');
                            loadContacts(book);
                        } else {
                            if (typeof giantToast === 'function') giantToast((resp && resp.error) || 'Could not remove contact.', 'error');
                        }
                    });
                }
            });
        });
    }

    // Tab switch — but the "+ New" tab opens the inline create form
    // instead of behaving like a real tab.
    $('#giantPbTabs').off('click', '.giant-pb-tab').on('click', '.giant-pb-tab', function () {
        var $t = $(this);
        if ($t.is('#giantPbNewTab')) {
            $('#giantPbNewInline').slideDown(120);
            setTimeout(function () { $('#giantPbNewName').focus(); }, 130);
            return;
        }
        $('#giantPbTabs .giant-pb-tab').removeClass('is-active');
        $t.addClass('is-active');
        currentBook = { id: $t.data('book-id'), name: $t.data('book-name') };
        loadContacts(currentBook);
    });

    // Inline create-book form on the populated tile.
    $('#giantPbNewBtn').off('click').on('click', function () { giantPbCreateBook(tileName); });
    $('#giantPbNewName').off('keydown').on('keydown', function (e) {
        if (e.key === 'Enter')  giantPbCreateBook(tileName);
        if (e.key === 'Escape') $('#giantPbNewInline').slideUp(120);
    });
    $('#giantPbNewCancel').off('click').on('click', function () {
        $('#giantPbNewInline').slideUp(120);
        $('#giantPbNewName').val('');
    });

    // Per-book delete — small × on each tab on hover.
    var deleteable = books.filter(function (b) { return b && b.id; });
    if (deleteable.length) {
        $('#giantPbTabs .giant-pb-tab').not('#giantPbNewTab').each(function () {
            var $tab = $(this);
            if (!$tab.find('.giant-pb-tab-del').length) {
                $tab.append(' <span class="giant-pb-tab-del" title="Delete this phone book">&times;</span>');
            }
        });
        $('#giantPbTabs').off('click', '.giant-pb-tab-del').on('click', '.giant-pb-tab-del', async function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $tab    = $(this).closest('.giant-pb-tab');
            var bookId  = String($tab.data('book-id') || '');
            var bookNm  = String($tab.data('book-name') || 'this book');
            if (!bookId) return;
            if (!(await giantConfirm('Delete "' + bookNm + '" and all its contacts?\n\nThis can\'t be undone.'))) return;
            $.ajax({
                type: 'post',
                data: { pbxAction: 'removePhoneBook', pb_id: bookId },
                dataType: 'json'
            }).done(function (resp) {
                if (resp && resp.success) {
                    if (typeof giantToast === 'function') giantToast('Phone book deleted.', 'success');
                    refreshList(tileName);
                } else {
                    alert((resp && resp.error) || 'Could not delete phone book.');
                }
            }).fail(function () { alert('Network error.'); });
        });
    }

    // Add contact — uses the schema we already loaded (no extra round-trip).
    // Falls back to fetching schema if the user clicks before the first
    // load has completed (rare but possible on a slow first paint).
    $('#giantAddButton').off('click').on('click', function () {
        if (bookSchema && bookSchema.length) {
            showAddContactDialog(currentBook, bookSchema);
            return;
        }
        $.ajax({
            type: 'post',
            data: { pbxAction: 'getPhoneBookContacts', phonebookId: currentBook.id || '' },
            dataType: 'json'
        }).done(function (resp) {
            bookSchema = (resp && resp.schema) || [];
            showAddContactDialog(currentBook, bookSchema);
        });
    });

    // Initial load
    loadContacts(currentBook);

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

function showAddContactDialog(book, schema) {
    jQuery('#giantPbAddDialog').remove();

    // The Add form only ever exposes the four essential fields — even if
    // the carrier's pi_phonebookitems table has more (Additional Phone 1-5,
    // SIP Address, Account Number etc.). Customers don't need them, and a
    // dozen fields would make this dialog scroll forever. The display
    // table still shows whatever's saved on existing contacts; it's just
    // the entry form that's opinionated about what we expose.
    //
    // We pull labels from the schema where available so any local-language
    // override of `pi_name` carries through to this form too.
    var fixedCodes = ['NAME', 'PHONE1', 'PHONE2', 'EMAIL'];
    var schemaByCode = {};
    (schema || []).forEach(function (s) { schemaByCode[s.code] = s.label; });
    var defaultLabels = { NAME: 'Name', PHONE1: 'Phone', PHONE2: 'Mobile Phone', EMAIL: 'Email' };
    var fields = fixedCodes.map(function (code) {
        return { code: code, label: schemaByCode[code] || defaultLabels[code] };
    });

    var rows = '';
    fields.forEach(function (col) {
        var inputType = col.code === 'EMAIL' ? 'email' :
                        /^PHONE/i.test(col.code) ? 'tel' : 'text';
        rows += '<div class="giant-fax-form-row">' +
                '  <label>' + col.label + '</label>' +
                '  <input type="' + inputType + '" data-key="' + col.code + '" autocomplete="off">' +
                '</div>';
    });

    var $dlg = jQuery(
      '<div id="giantPbAddDialog" class="giant-confirm-overlay">' +
        '<div class="giant-confirm" data-variant="primary" style="max-width: 480px;">' +
          '<div class="giant-confirm-head">' +
            '<div class="giant-confirm-icon"><i class="fa-duotone fa-address-book" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i></div>' +
            '<div class="giant-confirm-title">Add contact to ' + (book.name || 'phone book') + '</div>' +
          '</div>' +
          '<div class="giant-confirm-body">' +
            '<div class="giant-fax-form">' + rows + '<div class="giant-fax-alert" style="display:none;"></div></div>' +
          '</div>' +
          '<div class="giant-confirm-actions">' +
            '<button type="button" class="giant-confirm-cancel">Cancel</button>' +
            '<button type="button" class="giant-confirm-ok"><i class="fa-solid fa-plus"></i> Add</button>' +
          '</div>' +
        '</div>' +
      '</div>'
    );

    var $hostModal = jQuery('.modal.in, .modal.show').first();
    if ($hostModal.length) $hostModal.append($dlg); else jQuery('body').append($dlg);

    var close = function () {
        jQuery(document).off('keydown.giantPbAdd');
        $dlg.remove();
    };
    $dlg.on('click', function (e) { if (e.target === this) close(); });
    jQuery(document).on('keydown.giantPbAdd', function (e) { if (e.key === 'Escape') close(); });
    $dlg.find('.giant-confirm-cancel').on('click', close);

    setTimeout(function () { $dlg.find('input[data-key]').first().trigger('focus'); }, 60);

    $dlg.find('.giant-confirm-ok').on('click', function () {
        var $btn   = jQuery(this);
        var $alert = $dlg.find('.giant-fax-alert').hide();
        var values = {};
        $dlg.find('input[data-key]').each(function () {
            var v = jQuery(this).val();
            if (v && v.trim() !== '') values[jQuery(this).data('key')] = v.trim();
        });
        if (!Object.keys(values).length) {
            $alert.text('Please fill in at least one field.').show();
            return;
        }
        if (!values.NAME) {
            $alert.text('Please give the contact a name.').show();
            return;
        }

        var orig = $btn.html();
        $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin-pulse"></i> Adding…');

        // POST the values keyed by code (NAME / PHONE1 / …) as fields[CODE]
        // — the action forwards them to the carrier as a JSON-encoded
        // `values=` body, which is the exact contract the carrier expects.
        var data = { pbxAction: 'addPhoneBookContact', phonebookId: book.id || '' };
        Object.keys(values).forEach(function (k) { data['fields[' + k + ']'] = values[k]; });

        jQuery.ajax({ type: 'post', data: data, dataType: 'json' })
            .done(function (resp) {
                if (resp && resp.ok) {
                    close();
                    if (typeof giantToast === 'function') giantToast('Contact added.', 'success');
                    // Tell the active tab to reload its contacts.
                    jQuery('#giantPbTabs .giant-pb-tab.is-active').trigger('click');
                } else {
                    $alert.text((resp && resp.error) || 'Could not add contact.').show();
                    $btn.prop('disabled', false).html(orig);
                }
            })
            .fail(function () {
                $alert.text('Could not reach the contacts service.').show();
                $btn.prop('disabled', false).html(orig);
            });
    });
}

// =============================================================================
// Inline waveform helpers — used by the media-card player so each card has
// its own self-contained waveform/scrubber without colliding with the
// recording popup's singleton IDs. State (bars, max) is cached on the host
// jQuery element so multiple cards can play independently.
// =============================================================================
function fmtMSS(s) {
    s = Math.max(0, Math.floor(Number(s) || 0));
    var m = Math.floor(s / 60);
    var ss = s % 60;
    return m + ':' + (ss < 10 ? '0' : '') + ss;
}
// Faint static waveform silhouette shown in an idle track (before playback),
// so it reads as an audio player instead of a blank box. Overwritten by the
// real waveform once the file is decoded on play.
function drawMwaveIdle(canvas) {
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var dpr = window.devicePixelRatio || 1;
    var cssW = canvas.offsetWidth || 0;
    var cssH = canvas.offsetHeight || 0;
    if (!cssW || !cssH) return; // not laid out yet
    canvas.width  = cssW * dpr;
    canvas.height = cssH * dpr;
    var w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#e5e7eb';
    var barW = 3 * dpr, gap = 3 * dpr, x = 0, i = 0;
    while (x < w) {
        var v = 0.22 + 0.5 * Math.abs(Math.sin(i * 0.9) * Math.cos(i * 0.31));
        var barH = Math.max(2 * dpr, v * h * 0.62);
        ctx.fillRect(x, (h - barH) / 2, barW, barH);
        x += barW + gap; i++;
    }
}
function drawInlineWaveform($host, buffer, progress) {
    var canvas = $host.find('.giant-mwave-canvas')[0];
    if (!canvas) return;
    var ctx = canvas.getContext('2d');

    // Resize to host dimensions × devicePixelRatio for crisp bars.
    var dpr = window.devicePixelRatio || 1;
    var cssW = canvas.offsetWidth || 1;
    var cssH = canvas.offsetHeight || 1;
    if (canvas.width !== cssW * dpr || canvas.height !== cssH * dpr) {
        canvas.width  = cssW * dpr;
        canvas.height = cssH * dpr;
    }
    var w = canvas.width;
    var h = canvas.height;

    // First call (with buffer): compute bars and cache. Later calls reuse.
    var bars = $host.data('mwaveBars');
    var max  = $host.data('mwaveMax');
    if (buffer) {
        var data = new Float32Array(buffer.length);
        buffer.copyFromChannel(data, 0);
        if (buffer.numberOfChannels > 1) {
            var ch2 = new Float32Array(buffer.length);
            buffer.copyFromChannel(ch2, 1);
            for (var s = 0; s < data.length; s++) data[s] = (data[s] + ch2[s]) / 2;
        }
        var step = Math.ceil(data.length / (w / 3));
        bars = [];
        for (var i = 0; i < data.length; i += step) {
            var sum = 0;
            for (var j = 0; j < step && i + j < data.length; j++) sum += Math.abs(data[i + j]);
            bars.push(sum / step);
        }
        max = Math.max.apply(null, bars) || 1;
        $host.data('mwaveBars', bars);
        $host.data('mwaveMax',  max);
    }
    if (!bars || !bars.length) return;

    ctx.clearRect(0, 0, w, h);
    var barW = Math.max(2, w / bars.length);
    for (var k = 0; k < bars.length; k++) {
        var v = bars[k] / max;
        var barH = Math.max(2, v * h * 0.85);
        ctx.fillStyle = (k / bars.length) < (progress || 0) ? '#00d9a7' : '#d1d5db';
        ctx.fillRect(k * barW, (h - barH) / 2, barW - 1, barH);
    }
}

// =============================================================================
// Send-fax dialog. Lazy-built on first click; opens an overlay with a
// destination-number input, source-number dropdown (populated from the
// customer's allocated DIDs), and PDF file picker. Submits as multipart
// FormData so the file streams through to the carrier without any base64
// inflation.
// =============================================================================
function showSendFaxDialog(sourceNumbers, onSent) {
    jQuery('#giantSendFaxDialog').remove();

    var sourceOptions = '<option value="">Select a number…</option>';
    (sourceNumbers || []).forEach(function (n) {
        sourceOptions += '<option value="' + n.value + '">' + n.label + '</option>';
    });
    if (!sourceNumbers || sourceNumbers.length === 0) {
        sourceOptions = '<option value="">No numbers on this account</option>';
    }

    var $dlg = jQuery(
      '<div id="giantSendFaxDialog" class="giant-confirm-overlay">' +
        '<div class="giant-confirm" data-variant="primary" style="max-width: 560px;">' +
          '<div class="giant-confirm-head">' +
            '<div class="giant-confirm-icon"><i class="fa-duotone fa-fax" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i></div>' +
            '<div class="giant-confirm-title">Send a fax</div>' +
          '</div>' +
          '<div class="giant-confirm-body">' +
            '<div class="giant-fax-form">' +
              '<div class="giant-fax-form-row">' +
                '<label>Destination number</label>' +
                '<input type="text" class="giant-fax-dest" placeholder="e.g. 02012345678" autocomplete="off">' +
                '<div class="giant-fax-help">Include the area code. International numbers should start with 00 or +.</div>' +
              '</div>' +
              '<div class="giant-fax-form-row">' +
                '<label>Send from</label>' +
                '<select class="giant-fax-source">' + sourceOptions + '</select>' +
                '<div class="giant-fax-help">The number the recipient will see as the sender.</div>' +
              '</div>' +
              '<div class="giant-fax-form-row">' +
                '<label>Document</label>' +
                '<div class="drop-zone giant-fax-dropzone" id="giantFaxDropzone">' +
                  '<input type="file" class="giant-fax-file" accept="application/pdf,.pdf" style="display:none;">' +
                  '<div class="drop-zone-content">' +
                    '<i class="fa-duotone fa-cloud-arrow-up fa-2x" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i>' +
                    '<p class="drop-zone-text">Drag &amp; drop your PDF here</p>' +
                    '<p class="drop-zone-hint">or click to browse</p>' +
                    '<span class="drop-zone-formats">PDF · Max 25 MB</span>' +
                  '</div>' +
                  '<div class="drop-zone-file" style="display:none;">' +
                    '<i class="fa-duotone fa-file-pdf fa-lg" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i>' +
                    '<span class="drop-zone-filename"></span>' +
                    '<button type="button" class="drop-zone-remove" title="Remove">&times;</button>' +
                  '</div>' +
                '</div>' +
              '</div>' +
              '<div class="giant-fax-alert" style="display:none;"></div>' +
            '</div>' +
          '</div>' +
          '<div class="giant-confirm-actions">' +
            '<button type="button" class="giant-confirm-cancel">Cancel</button>' +
            '<button type="button" class="giant-confirm-ok"><i class="fa-solid fa-paper-plane"></i> Send fax</button>' +
          '</div>' +
        '</div>' +
      '</div>'
    );

    // Append inside the open Bootstrap modal so its focus trap doesn't steal
    // keyboard focus from our inputs (same fix as the 999 dialog). Falls back
    // to <body> when no modal is showing.
    var $hostModal = jQuery('.modal.in, .modal.show').first();
    if ($hostModal.length) {
        $hostModal.append($dlg);
    } else {
        jQuery('body').append($dlg);
    }

    var close = function () {
        jQuery(document).off('keydown.giantSendFax');
        $dlg.remove();
    };
    giantIconSelect($dlg.find('.giant-fax-source'), 'fa-hashtag', $dlg);
    $dlg.on('click', function (e) { if (e.target === this) close(); });
    jQuery(document).on('keydown.giantSendFax', function (e) { if (e.key === 'Escape') close(); });
    $dlg.find('.giant-confirm-cancel').on('click', close);

    // Drop-zone wiring — mirrors the audio-upload drop-zone in renderMediaLayout.
    var $dz    = $dlg.find('#giantFaxDropzone');
    var $input = $dlg.find('.giant-fax-file');
    $dz.on('click', function (e) {
        if (!jQuery(e.target).hasClass('drop-zone-remove')) $input.trigger('click');
    });
    $dz.on('dragover', function (e) {
        e.preventDefault();
        $dz.addClass('drop-zone-over');
    });
    $dz.on('dragleave drop', function (e) {
        e.preventDefault();
        $dz.removeClass('drop-zone-over');
    });
    $dz.on('drop', function (e) {
        var files = e.originalEvent.dataTransfer.files;
        if (files.length) {
            $input[0].files = files;
            $input.trigger('change');
        }
    });
    $input.on('change', function () {
        if (this.files && this.files[0]) {
            $dz.find('.drop-zone-content').hide();
            $dz.find('.drop-zone-filename').text(this.files[0].name);
            $dz.find('.drop-zone-file').show();
            $dz.addClass('drop-zone-has-file');
        }
    });
    $dz.find('.drop-zone-remove').on('click', function (e) {
        e.stopPropagation();
        $input.val('');
        $dz.find('.drop-zone-file').hide();
        $dz.find('.drop-zone-content').show();
        $dz.removeClass('drop-zone-has-file');
    });

    // Focus the destination number once the dialog is in the DOM. Defer with
    // a frame so Bootstrap's focus trap settles first.
    setTimeout(function () { $dlg.find('.giant-fax-dest').trigger('focus'); }, 60);

    $dlg.find('.giant-confirm-ok').on('click', function () {
        var $btn   = jQuery(this);
        var $alert = $dlg.find('.giant-fax-alert').hide();

        var dest   = $dlg.find('.giant-fax-dest').val().trim();
        var source = $dlg.find('.giant-fax-source').val();
        var fileEl = $dlg.find('.giant-fax-file')[0];
        var file   = fileEl && fileEl.files && fileEl.files[0];

        if (!dest)    { $alert.text('Please enter a destination number.').show(); return; }
        if (!source)  { $alert.text('Please choose which number to send from.').show(); return; }
        if (!file)    { $alert.text('Please select a PDF to send.').show(); return; }
        if (file.type && file.type !== 'application/pdf') {
            $alert.text('Only PDF files are supported.').show(); return;
        }
        if (file.size > 25 * 1024 * 1024) {
            $alert.text('File is too large. Please keep faxes under 25 MB.').show(); return;
        }

        var orig = $btn.html();
        $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin-pulse"></i> Sending…');

        var fd = new FormData();
        fd.append('pbxAction',  'sendFax');
        fd.append('destNumber',   dest);
        fd.append('sourceNumber', source);
        fd.append('fax',          file);

        jQuery.ajax({
            type: 'post',
            data: fd,
            processData: false,
            contentType: false,
            dataType: 'json'
        }).done(function (resp) {
            if (!resp || !resp.ok) {
                $alert.text((resp && resp.error) || 'Could not send fax.').show();
                $btn.prop('disabled', false).html(orig);
                return;
            }
            close();
            if (typeof onSent === 'function') onSent();
        }).fail(function () {
            $alert.text('Could not reach the fax service. Please try again.').show();
            $btn.prop('disabled', false).html(orig);
        });
    });
}

//renderIntegrationsLayout=======================================================
// One card per integration. The toggle in the card header is purely a
// derived state from the integration's `enabledField` — flipping it off
// blanks that field, flipping it on opens the card body so the user
// can populate it (we don't auto-write defaults; "on" without a URL
// makes no sense, so the Save button is the only thing that actually
// persists state).
// ===== Integrations =====
// A catalogue (connected summary, search, tiles by category) and a detail view
// per integration with Setup and Activity tabs. Caller Name Lookup's detail
// lists its name sources (Dentally, HubSpot, the public directory) in the
// order they're asked; each source has its own credentials and feature
// switches. Secrets never come back from the server: a saved one shows as
// "saved — leave blank to keep".
function renderIntegrationsLayout(response, tileName) {
    var items = (response && response.data) ? response.data : [];
    if (items && !Array.isArray(items) && typeof items === 'object') { items = Object.keys(items).map(function (k) { return items[k]; }); }
    var keep = window._giInt && window._giInt.tileName === tileName ? window._giInt.view : 'list';
    window._giInt = { items: items || [], categories: (response && response.categories) || {}, tileName: tileName, view: keep, error: response && response.error, notice: (response && response.notice) || '' };
    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').find('.giant-empty-state').remove();
    giIntDraw();
    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

function giIntEsc(s) { return $('<div>').text(s == null ? '' : String(s)).html(); }
function giIntItem(id) { return (window._giInt.items || []).filter(function (i) { return i.id === id; })[0] || null; }
function giIntParse(r) { if (r && typeof r === 'object') return r; try { return jQuery.parseJSON(r); } catch (e) { return { error: 'Unexpected response from the server.' }; } }
function giIntIsSource(item) { return item && item.kind === 'source'; }
// The integration's own logo (a file bundled under templates/Client/img/) when it has one, else its icon.
function giIntIcon(item, cls) {
    var logo = item && item.logo ? String(item.logo) : '';
    var url  = item && item.logoUrl ? String(item.logoUrl) : '';
    if (/^https:\/\/[a-z0-9.\-]+\/[^\s"'<>]+$/i.test(url)) {
        return '<span class="gi-int-tile-icon has-logo' + (cls ? ' ' + cls : '') + '"><img src="' + giIntEsc(url) + '" alt="" loading="lazy"></span>';
    }
    if (/^[a-z0-9_\-\/]+\.(svg|png|webp)$/i.test(logo) && logo.indexOf('..') < 0) {
        return '<span class="gi-int-tile-icon has-logo' + (cls ? ' ' + cls : '') + '"><img src="modules/addons/resellervoip/templates/client/img/' + giIntEsc(logo) + '" alt="" loading="lazy"></span>';
    }
    return '<span class="gi-int-tile-icon' + (cls ? ' ' + cls : '') + '"><i class="fa-duotone ' + giIntEsc(item.icon || 'fa-plug') + '"></i></span>';
}
function giIntStatus(item) {
    if (item.state && item.state.status === 'error') return { cls: 'is-warn', text: 'Needs attention' };
    return item.enabled ? { cls: 'is-on', text: 'Connected' } : { cls: 'is-off', text: 'Not connected' };
}
function giIntAlert(msg) { $('#giantModalAlertDiv').show(); $('#giantModalAlert').html(giIntEsc(msg)); }

function giIntDraw() {
    var st = window._giInt, $c = $('#giantModalListTableDiv');
    $('#giantModalAlertDiv').hide();
    if (st.view !== 'list' && giIntItem(st.view)) { $c.html(giIntDetailHtml(giIntItem(st.view))); giIntBindDetail(giIntItem(st.view)); return; }
    st.view = 'list';
    if (!st.items.length) {
        $c.html('<div class="giant-empty-state" style="padding:24px;"><p>No integrations are available for this service yet.</p>' + (st.error ? '<p>' + giIntEsc(st.error) + '</p>' : '') + '</div>');
        return;
    }
    $c.html(giIntListHtml());
    giIntBindList();
}

function giIntListHtml() {
    var st = window._giInt, esc = giIntEsc;
    var tiles = st.items.filter(function (i) { return !(giIntIsSource(i) && !i.category); });
    var on = tiles.filter(function (i) { return i.enabled; });
    var html = '<div class="gi-int">';
    if (st.notice) html += '<div class="gi-int-note is-warn"><i class="fa-solid fa-triangle-exclamation"></i> ' + esc(st.notice) + '</div>';
    html += '<div class="gi-int-top"><div class="gi-int-summary">';
    html += on.length
        ? '<span class="gi-int-summary-count">' + on.length + ' connected</span>' + on.map(function (i) { return '<button type="button" class="gi-int-chip" data-open="' + esc(i.id) + '">' + giIntIcon(i, 'is-xs') + esc(i.name) + '</button>'; }).join('')
        : '<span class="gi-int-summary-count">Nothing connected yet</span>';
    html += '</div><label class="gi-int-search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" placeholder="Search integrations" aria-label="Search integrations"></label></div>';

    var order = Object.keys(st.categories), groups = {};
    tiles.forEach(function (i) { var c = i.category || 'Other'; if (!groups[c]) { groups[c] = []; if (order.indexOf(c) < 0) order.push(c); } groups[c].push(i); });
    order.forEach(function (cat) {
        if (!groups[cat]) return;
        html += '<section class="gi-int-group"><h3 class="gi-int-group-name">' + esc(cat) + '</h3>' + (st.categories[cat] ? '<p class="gi-int-group-blurb">' + esc(st.categories[cat]) + '</p>' : '');
        html += '<div class="gi-int-grid">';
        groups[cat].forEach(function (i) {
            var s = giIntStatus(i);
            html += '<button type="button" class="gi-int-tile" data-open="' + esc(i.id) + '" data-search="' + esc((i.name + ' ' + (i.description || '') + ' ' + cat).toLowerCase()) + '">';
            html += giIntIcon(i);
            html += '<span class="gi-int-tile-body"><span class="gi-int-tile-name">' + esc(i.name) + '</span><span class="gi-int-tile-desc">' + esc(i.description || '') + '</span>';
            html += '<span class="gi-int-tile-meta"><span class="gi-int-pill ' + s.cls + '">' + s.text + '</span>' + (i.managed ? '<span class="gi-int-tag">Run by us</span>' : '') + (i.badge ? '<span class="gi-int-tag is-badge">' + esc(i.badge) + '</span>' : '') + '</span></span>';
            html += '<i class="fa-solid fa-chevron-right gi-int-tile-go"></i></button>';
        });
        html += '</div></section>';
    });
    html += '<p class="gi-int-empty-search" hidden>No integration matches that search.</p></div>';
    return html;
}

function giIntBindList() {
    var $c = $('#giantModalListTableDiv');
    $c.off('.giint');
    $c.on('click.giint', '[data-open]', function () { window._giInt.view = String($(this).data('open')); giIntDraw(); });
    $c.on('input.giint', '.gi-int-search input', function () {
        var q = $(this).val().toLowerCase().trim(), any = false;
        $c.find('.gi-int-tile').each(function () { var m = !q || String($(this).data('search')).indexOf(q) >= 0; $(this).prop('hidden', !m); if (m) any = true; });
        $c.find('.gi-int-group').each(function () { $(this).prop('hidden', !$(this).find('.gi-int-tile:not([hidden])').length); });
        $c.find('.gi-int-empty-search').prop('hidden', any);
    });
}

function giIntFieldHtml(item, f) {
    var esc = giIntEsc, id = 'gi_' + esc(item.id) + '_' + esc(f.code);
    var val = (item.values && item.values[f.code] != null) ? String(item.values[f.code]) : (f.default != null ? String(f.default) : '');
    var html = '<div class="gi-int-field"><label for="' + id + '">' + esc(f.label) + (f.required ? ' <span class="gi-int-req">*</span>' : '') + '</label>';
    if (f.type === 'select' && f.options) {
        html += '<select id="' + id + '" class="gi-int-input" data-code="' + esc(f.code) + '">';
        Object.keys(f.options).forEach(function (o) { html += '<option value="' + esc(o) + '"' + (val === o ? ' selected' : '') + '>' + esc(f.options[o]) + '</option>'; });
        html += '</select>';
    } else {
        var secret = f.type === 'secret', saved = secret && item.secretsSet && item.secretsSet[f.code];
        var type = secret ? 'password' : (f.type === 'number' ? 'number' : (f.type === 'url' ? 'url' : 'text'));
        var ph = saved ? 'Saved. Leave blank to keep it.' : (f.placeholder || '');
        html += '<input type="' + type + '" id="' + id + '" class="gi-int-input" data-code="' + esc(f.code) + '" autocomplete="off"' + (ph ? ' placeholder="' + esc(ph) + '"' : '') + ' value="' + (secret ? '' : esc(val)) + '">';
        if (saved) html += '<div class="gi-int-saved"><i class="fa-solid fa-lock"></i> A token is saved</div>';
    }
    if (f.help) html += '<div class="gi-int-help">' + esc(f.help) + '</div>';
    return html + '</div>';
}

function giIntDetailHtml(item) {
    var esc = giIntEsc, s = giIntStatus(item), src = giIntIsSource(item);
    var html = '<div class="gi-int gi-int-detail" data-id="' + esc(item.id) + '">';
    html += '<button type="button" class="gi-int-back"><i class="fa-solid fa-chevron-left"></i> All integrations</button>';
    html += '<header class="gi-int-head">' + giIntIcon(item, 'is-lg') + '<div class="gi-int-head-text">';
    html += '<h3>' + esc(item.name) + ' <span class="gi-int-pill ' + s.cls + '">' + s.text + '</span></h3><p>' + esc(item.description || '') + '</p></div>';
    if (!src && item.managed) html += '<label class="gi-int-switch" title="' + (item.enabled ? 'Switch off' : 'Switch on') + '"><input type="checkbox" class="gi-int-main-toggle"' + (item.enabled ? ' checked' : '') + '><span></span></label>';
    html += '</header>';
    if (item.state && item.state.status === 'error' && item.state.lastError) html += '<div class="gi-int-note is-warn"><i class="fa-solid fa-triangle-exclamation"></i> Last change failed: ' + esc(item.state.lastError) + '</div>';
    html += '<nav class="gi-int-tabs" role="tablist"><button type="button" role="tab" class="is-active" data-tab="setup">Setup</button>' + (item.guide ? '<button type="button" role="tab" data-tab="guide">Guide</button>' : '') + '<button type="button" role="tab" data-tab="activity">Activity</button></nav>';
    html += '<div class="gi-int-pane" data-pane="setup">' + (src ? giIntSourceSetup(item) : giIntSettingsSetup(item)) + '</div>';
    if (item.guide) html += '<div class="gi-int-pane" data-pane="guide" hidden>' + giIntGuideHtml(item.guide) + '</div>';
    html += '<div class="gi-int-pane" data-pane="activity" hidden><div class="gi-int-activity">Loading…</div></div>';
    return html + '</div>';
}

function giIntSettingsSetup(item) {
    var esc = giIntEsc, html = '';
    if (item.managed) {
        html += '<div class="gi-int-note"><i class="fa-solid fa-wand-magic-sparkles"></i> Run by us. Switch it on and it just works.</div>';
    } else {
        html += '<form class="gi-int-form" data-mode="settings">' + (item.fields || []).map(function (f) { return giIntFieldHtml(item, f); }).join('');
        html += '<div class="gi-int-actions">' + (item.enabled ? '<button type="button" class="btn btn-default gi-int-disable">Switch off</button>' : '') + (item.docUrl ? '<a href="' + esc(item.docUrl) + '" target="_blank" rel="noopener noreferrer" class="gi-int-doc">Provider help <i class="fa-solid fa-arrow-up-right-from-square"></i></a>' : '');
        html += '<button type="submit" class="btn btn-primary">' + (item.enabled ? 'Save' : 'Save and switch on') + '</button></div></form>';
    }
    if (item.id === 'cnam_giant') html += giIntSourcesPanel();
    return html;
}

function giIntSourcesPanel() {
    var esc = giIntEsc;
    var srcs = (window._giInt.items || []).filter(giIntIsSource).sort(function (a, b) { return (a.priority || 0) - (b.priority || 0); });
    var html = '<section class="gi-int-sources"><h4>Where names come from</h4><p class="gi-int-help">Each caller is looked up in these, top first; the first one that knows the number names the call. Reorder them to choose who wins.</p><ol class="gi-int-source-list">';
    srcs.forEach(function (s, i) {
        var stt = giIntStatus(s), names = s.features && s.features.names;
        html += '<li data-id="' + esc(s.id) + '"><span class="gi-int-source-rank">' + (i + 1) + '</span>' + giIntIcon(s, 'is-sm') + '';
        html += '<span class="gi-int-source-name">' + esc(s.name) + '<small>' + (s.enabled ? (names ? 'Names on' : 'Names off') : 'Not set up') + '</small></span><span class="gi-int-pill ' + stt.cls + '">' + stt.text + '</span>';
        html += '<span class="gi-int-source-move"><button type="button" class="gi-int-icon-btn" data-move="-1" aria-label="Move up"' + (i === 0 ? ' disabled' : '') + '><i class="fa-solid fa-arrow-up"></i></button><button type="button" class="gi-int-icon-btn" data-move="1" aria-label="Move down"' + (i === srcs.length - 1 ? ' disabled' : '') + '><i class="fa-solid fa-arrow-down"></i></button></span>';
        html += '<button type="button" class="btn btn-default btn-sm" data-open="' + esc(s.id) + '">' + (s.enabled ? 'Manage' : 'Set up') + '</button></li>';
    });
    html += '</ol><div class="gi-int-try"><label for="giTryNumber">Try a number</label><div class="gi-int-try-row"><input type="tel" id="giTryNumber" class="gi-int-input" placeholder="e.g. 01632 960123"><button type="button" class="btn btn-default gi-int-try-btn">Look up</button></div><div class="gi-int-try-out" aria-live="polite"></div></div></section>';
    return html;
}

// The sign-in window reports back here; a successful sign-in finishes connecting.
if (!window._giOauthListener) {
    window._giOauthListener = true;
    window.addEventListener('message', function (ev) {
        var d = ev.data || {};
        if (ev.origin !== window.location.origin || d.type !== 'giant-oauth') return;
        var id = window._giOauthPending; window._giOauthPending = null;
        if (!d.ok) { giIntAlert(d.message || 'Sign-in didn\'t complete.'); return; }
        var item = id ? giIntItem(id) : null;
        if (item) { item.signedIn = true; window._giInt.view = id; giIntDraw(); $('#giantModalListTableDiv .gi-int-form').trigger('submit'); }
        else if (window._giInt) refreshList(window._giInt.tileName);
    });
}

// The setup guide: intro, numbered steps, then things worth knowing.
function giIntGuideHtml(g) {
    var esc = giIntEsc, html = '<div class="gi-int-guide">';
    if (g.intro) html += '<p class="gi-int-guide-intro">' + esc(g.intro) + '</p>';
    if (g.steps && g.steps.length) html += '<ol class="gi-int-guide-steps">' + g.steps.map(function (st) { return '<li><b>' + esc(st[0]) + '</b><span>' + esc(st[1]) + '</span></li>'; }).join('') + '</ol>';
    if (g.notes && g.notes.length) html += '<div class="gi-int-guide-notes"><h5>Good to know</h5><ul>' + g.notes.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul></div>';
    return html + '</div>';
}

function giIntSourceSetup(item) {
    var esc = giIntEsc, html = '';
    if (item.guide) html += '<p class="gi-int-help">New to this? The <a href="#" class="gi-int-goto-guide">setup guide</a> walks you through it.</p>';
    if (item.setupHelp) html += '<div class="gi-int-note"><i class="fa-solid fa-circle-info"></i> ' + esc(item.setupHelp) + '</div>';
    if (item.managed) html += '<div class="gi-int-note"><i class="fa-solid fa-wand-magic-sparkles"></i> Run by us. Nothing to sign in to.</div>';
    html += '<form class="gi-int-form" data-mode="source">' + (item.fields || []).map(function (f) { return giIntFieldHtml(item, f); }).join('');
    if (item.auth === 'oauth') {
        html += '<div class="gi-int-signin">';
        if (!item.oauthReady) html += '<div class="gi-int-note is-warn"><i class="fa-solid fa-hourglass-half"></i> Sign-in with ' + esc(item.name) + ' isn\'t available yet. Contact us and we\'ll switch it on.</div>';
        else if (item.signedIn) html += '<span class="gi-int-saved"><i class="fa-solid fa-circle-check"></i> Signed in</span><button type="button" class="btn btn-default btn-sm gi-int-oauth">Sign in again</button>';
        else html += '<button type="button" class="btn btn-primary gi-int-oauth"><i class="fa-solid fa-right-to-bracket"></i> Sign in with ' + esc(item.name) + '</button>';
        html += '</div>';
    }
    var caps = item.capabilities || {}, feats = item.features || {};
    if (Object.keys(caps).length) {
        html += '<fieldset class="gi-int-features"><legend>What it does</legend>';
        Object.keys(caps).forEach(function (code) {
            var c = caps[code], need = c.requires, off = need && !feats[need];
            if ((code === 'log_calls' || need === 'log_calls') && !item.canLogCalls) return;
            html += '<label class="gi-int-feature' + (off ? ' is-disabled' : '') + '"' + (need ? ' data-requires="' + esc(need) + '"' : '') + '><input type="checkbox" data-feature="' + esc(code) + '"' + (feats[code] ? ' checked' : '') + (off ? ' disabled' : '') + '><span class="gi-int-feature-text">' + esc(c.label) + (c.help ? '<small>' + esc(c.help) + '</small>' : '') + '</span></label>';
        });
        html += '</fieldset>';
    }
    html += '<div class="gi-int-test-out" aria-live="polite"></div><div class="gi-int-actions">';
    if (item.enabled) html += '<button type="button" class="btn btn-default gi-int-disable">Disconnect</button>';
    var canSubmit = item.auth !== 'oauth' || item.signedIn;
    if (((item.fields || []).length || item.auth === 'oauth') && canSubmit) html += '<button type="button" class="btn btn-default gi-int-test">Test connection</button>';
    if (canSubmit) html += '<button type="submit" class="btn btn-primary">' + (item.enabled ? 'Save' : 'Connect') + '</button>';
    html += '</div></form>';
    html += '<p class="gi-int-help gi-int-parent-link"><a href="#" data-open="cnam_giant">Caller Name Lookup</a> decides the order sources are asked in.</p>';
    return html;
}

function giIntCollect($form) {
    var out = { fields: {}, features: {} };
    $form.find('.gi-int-input').each(function () { out.fields[$(this).data('code')] = $(this).val(); });
    $form.find('[data-feature]').each(function () { out.features[$(this).data('feature')] = $(this).is(':checked') ? 1 : 0; });
    return out;
}

function giIntPost(data, done) {
    $('#giantModalAlertDiv').hide();
    $.ajax({ type: 'post', data: data })
        .done(function (r) { done(giIntParse(r)); })
        .fail(function () { done({ error: 'The request didn\'t complete. Please try again.' }); });
}

function giIntBusy($btn, on) {
    if (on) { $btn.data('orig', $btn.html()).prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> ' + $btn.text()); }
    else { $btn.prop('disabled', false).html($btn.data('orig')); }
}

function giIntBindDetail(item) {
    var $c = $('#giantModalListTableDiv'), esc = giIntEsc, tile = window._giInt.tileName;
    var reload = function () { refreshList(tile); };
    $c.off('.giint');
    $c.on('click.giint', '.gi-int-back', function () { window._giInt.view = 'list'; giIntDraw(); });
    $c.on('click.giint', '[data-open]', function (e) { e.preventDefault(); window._giInt.view = String($(this).data('open')); giIntDraw(); });

    $c.on('click.giint', '.gi-int-goto-guide', function (e) { e.preventDefault(); $c.find('.gi-int-tabs [data-tab="guide"]').trigger('click'); });
    $c.on('click.giint', '.gi-int-oauth', function () {
        var $b = $(this), d = giIntCollect($b.closest('form'));
        // Open the window inside the click so pop-up blockers allow it, then point it at the sign-in page.
        var win = window.open('', 'giant-oauth', 'width=560,height=720');
        giIntBusy($b, true);
        giIntPost({ pbxAction: 'oauthStart', integrationId: item.id, fields: d.fields }, function (r) {
            giIntBusy($b, false);
            if (r.error || !r.url) {
                if (win) win.close();
                if (r.appNotRegistered) { item.oauthReady = false; giIntDraw(); }
                giIntAlert(r.error || 'Could not start sign-in.');
                return;
            }
            window._giOauthPending = item.id;
            if (win) win.location.href = r.url; else window.location.href = r.url;
        });
    });
    $c.on('click.giint', '.gi-int-tabs button', function () {
        var tab = $(this).data('tab');
        $c.find('.gi-int-tabs button').removeClass('is-active').filter(this).addClass('is-active');
        $c.find('.gi-int-pane').prop('hidden', true).filter('[data-pane="' + tab + '"]').prop('hidden', false);
        if (tab === 'activity') {
            var $a = $c.find('.gi-int-activity').text('Loading…');
            giIntPost({ pbxAction: 'getIntegrationActivity', integrationId: item.id }, function (r) {
                if (r.error) { $a.text(r.error); return; }
                var ev = r.events || [];
                var words = { match: 'Named a caller', saved: 'Settings saved', disconnected: 'Disconnected', tested: 'Connection tested', test_failed: 'Connection test failed', error: 'Lookup failed',
                              call_logged: 'Call logged', ticket_raised: 'Ticket raised', sync_error: 'Call logging failed', signed_in: 'Signed in', sign_in_failed: 'Sign-in failed',
                              needs_attention: 'Needs attention', paused: 'Paused', reordered: 'Order changed', key_rotated: 'Lookup key changed', created: 'Set up', imported: 'Moved over' };
                $a.html(ev.length ? '<ul class="gi-int-events">' + ev.map(function (x) {
                    return '<li class="' + (x.ok ? '' : 'is-bad') + '"><i class="fa-solid ' + (x.ok ? 'fa-circle-check' : 'fa-circle-exclamation') + '"></i><span><b>' + esc(words[x.event] || x.event) + '</b> ' + esc(x.detail) + '</span><time>' + esc(String(x.at).substring(0, 16)) + '</time></li>';
                }).join('') + '</ul>' : '<p class="gi-int-help">Nothing yet. Lookups, logged calls and errors will show here.</p>');
            });
        }
    });

    // Managed settings connector (Caller Name Lookup): the switch.
    $c.on('change.giint', '.gi-int-main-toggle', async function () {
        var $t = $(this), on = $t.is(':checked');
        if (!on && !(await giantConfirm({ message: 'Switch off ' + item.name + '? Callers will show as numbers only.', confirmLabel: 'Switch off' }))) { $t.prop('checked', true); return; }
        $t.prop('disabled', true);
        giIntPost({ pbxAction: 'saveIntegration', integrationId: item.id, enable: on ? 1 : 0, disable: on ? 0 : 1 }, function (r) {
            $t.prop('disabled', false);
            if (r.error) { $t.prop('checked', !on); giIntAlert(r.error); return; }
            reload();
        });
    });

    $c.on('change.giint', '[data-feature]', function () {
        var code = $(this).data('feature'), on = $(this).is(':checked');
        $c.find('[data-requires="' + code + '"]').toggleClass('is-disabled', !on).find('input').prop('disabled', !on);
    });

    $c.on('click.giint', '.gi-int-disable', async function () {
        if (!(await giantConfirm({ message: (giIntIsSource(item) ? 'Disconnect ' : 'Switch off ') + item.name + '?', confirmLabel: giIntIsSource(item) ? 'Disconnect' : 'Switch off' }))) return;
        var $b = $(this); giIntBusy($b, true);
        giIntPost({ pbxAction: 'saveIntegration', integrationId: item.id, disable: 1 }, function (r) { giIntBusy($b, false); if (r.error) { giIntAlert(r.error); return; } reload(); });
    });

    $c.on('click.giint', '.gi-int-test', function () {
        var $b = $(this), $out = $c.find('.gi-int-test-out'), d = giIntCollect($b.closest('form'));
        giIntBusy($b, true); $out.removeClass('is-ok is-bad').text('');
        giIntPost({ pbxAction: 'testIntegration', integrationId: item.id, fields: d.fields }, function (r) {
            giIntBusy($b, false);
            $out.addClass(r.error ? 'is-bad' : 'is-ok').html('<i class="fa-solid ' + (r.error ? 'fa-circle-exclamation' : 'fa-circle-check') + '"></i> ' + esc(r.error || r.message));
        });
    });

    $c.on('submit.giint', '.gi-int-form', function (e) {
        e.preventDefault();
        var $f = $(this), $b = $f.find('[type="submit"]'), d = giIntCollect($f);
        var send = function (force) {
            giIntBusy($b, true);
            var data = { pbxAction: 'saveIntegration', integrationId: item.id, fields: d.fields };
            if ($f.data('mode') === 'source') { data.features = d.features; if (force) data.force = 1; }
            giIntPost(data, async function (r) {
                giIntBusy($b, false);
                if (r.needsReplace) {
                    if (await giantConfirm({ message: r.error, confirmLabel: 'Switch to Caller Name Lookup', danger: false })) send(true);
                    return;
                }
                if (r.error) { giIntAlert(r.error); return; }
                reload();
                if (r.warning) setTimeout(function () { giIntAlert(r.warning); }, 400);
            });
        };
        send(false);
    });

    // Caller Name Lookup: source order + "try a number".
    $c.on('click.giint', '[data-move]', function () {
        var $li = $(this).closest('li'), dir = parseInt($(this).data('move'), 10);
        if (dir < 0) $li.prev().before($li); else $li.next().after($li);
        var $list = $c.find('.gi-int-source-list'), order = $list.children().map(function () { return String($(this).data('id')); }).get();
        $list.children().each(function (i) { $(this).find('.gi-int-source-rank').text(i + 1); $(this).find('[data-move="-1"]').prop('disabled', i === 0); $(this).find('[data-move="1"]').prop('disabled', i === order.length - 1); });
        order.forEach(function (id, i) { var s = giIntItem(id); if (s) s.priority = (i + 1) * 10; });
        giIntPost({ pbxAction: 'reorderIntegrationSources', order: order }, function (r) { if (r.error) giIntAlert(r.error); });
    });
    var tryIt = function () {
        var $b = $c.find('.gi-int-try-btn'), $out = $c.find('.gi-int-try-out'), num = $c.find('#giTryNumber').val();
        if (!String(num || '').trim()) return;
        giIntBusy($b, true); $out.text('');
        giIntPost({ pbxAction: 'testIntegration', integrationId: 'cnam_giant', number: num }, function (r) {
            giIntBusy($b, false);
            if (r.error) { $out.html('<p class="is-bad">' + esc(r.error) + '</p>'); return; }
            var said = { match: 'knows them', none: 'doesn\'t know this number', off: 'not set up or names off', error: 'couldn\'t be reached', skipped: 'not asked (out of time)' };
            var html = r.match ? '<p class="is-ok"><i class="fa-solid fa-circle-check"></i> Handsets would show <b>' + esc(r.match.name) + '</b> (from ' + esc(r.match.sourceName) + ')' + (r.match.url ? ' · <a href="' + esc(r.match.url) + '" target="_blank" rel="noopener noreferrer">Open record</a>' : '') + '</p>' : '<p>No source knows this number. Handsets would show the number' + ' (or the name the call arrives with).</p>';
            html += '<ul class="gi-int-trace">' + (r.trace || []).map(function (t) { return '<li class="is-' + esc(t.outcome) + '"><b>' + esc(t.name) + '</b> ' + esc(said[t.outcome] || t.outcome) + (t.result ? ': ' + esc(t.result) : '') + (t.error ? ': ' + esc(t.error) : '') + '</li>'; }).join('') + '</ul>';
            $out.html(html);
        });
    };
    $c.on('click.giint', '.gi-int-try-btn', tryIt);
    $c.on('keydown.giint', '#giTryNumber', function (e) { if (e.key === 'Enter') { e.preventDefault(); tryIt(); } });
}

//renderTenantSettingsLayout=====================================================
// Grouped, curated tenant SETTING codes (voicemail behaviour, etc.). Simpler
// than integrations — no per-item enable toggle; one form, one Save that writes
// every field. Reuses the .giant-int-* field styling.
function renderTenantSettingsLayout(response, tileName) {
    var $container = $('#giantModalListTableDiv');
    $container.children().remove();
    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').find('.giant-empty-state').remove();

    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    var groups = (response && response.data) ? response.data : [];
    if (groups && !Array.isArray(groups) && typeof groups === 'object') {
        groups = Object.keys(groups).map(function (k) { return groups[k]; });
    }

    if (response && response.error) {
        $container.html('<div class="giant-empty-state" style="padding:20px;"><p style="color:#dc2626;margin:0;">' + esc(response.error) + '</p></div>');
        $('.giantModalPanel').hide(); $('#giantModalListDiv').show();
        return;
    }
    if (!groups || !groups.length) {
        // No `data` came back. If the response is just the echoed request (no
        // customLayout), the server is running an older Actions.php without
        // getTenantSettingsList (redeploy), or this JS is a stale cache
        // (hard-refresh). Surface that rather than a bare blank.
        var looksLikeSettings = response && response.customLayout === 'tenantSettings';
        var msg = looksLikeSettings
            ? 'No settings to show. Add codes to TenantSettingsCatalog.'
            : 'Couldn\'t load settings. If this persists, hard-refresh (Ctrl/Cmd+Shift+R) and make sure the latest addon files are deployed. See the browser console for the raw response.';
        $container.html('<div class="giant-empty-state" style="padding:20px;"><p style="margin:0;">' + esc(msg) + '</p></div>');
        $('.giantModalPanel').hide(); $('#giantModalListDiv').show();
        return;
    }

    var html = '<form class="giant-tset-form">';
    groups.forEach(function (group) {
        html += '<div class="giant-tset-group">';
        html += '  <div class="giant-tset-group-head">' + esc(group.group || '');
        if (group.description) { html += '<span class="giant-tset-group-desc">' + esc(group.description) + '</span>'; }
        html += '  </div>';

        (group.settings || []).forEach(function (f) {
            var val = (f.value != null) ? String(f.value) : '';
            if (val === '' && f.default) { val = String(f.default); }
            var fid = 'tset_' + esc(f.code);

            html += '<div class="giant-int-field">';
            html += '  <label for="' + fid + '" class="giant-int-label">' + esc(f.label) + '</label>';

            if (f.type === 'select' && f.options) {
                html += '<select id="' + fid + '" class="giant-int-input" data-code="' + esc(f.code) + '">';
                Object.keys(f.options).forEach(function (optVal) {
                    html += '<option value="' + esc(optVal) + '"' + (val === optVal ? ' selected' : '') + '>' + esc(f.options[optVal]) + '</option>';
                });
                html += '</select>';
            } else {
                var inputType = (f.type === 'number') ? 'number' : (f.type === 'url') ? 'url' : 'text';
                html += '<input type="' + inputType + '" id="' + fid + '" class="giant-int-input" data-code="' + esc(f.code) + '"';
                if (f.placeholder) { html += ' placeholder="' + esc(f.placeholder) + '"'; }
                html += ' value="' + esc(val) + '">';
            }

            if (f.help) { html += '<div class="giant-int-help">' + esc(f.help) + '</div>'; }
            html += '</div>';
        });

        html += '</div>'; // /group
    });
    html += '  <div class="giant-int-actions"><button type="submit" class="btn btn-primary giant-int-save"><i class="fa-solid fa-floppy-disk" style="margin-bottom:0;"></i> Save settings</button></div>';
    html += '</form>';

    $container.html(html);

    $container.off('submit', '.giant-tset-form');
    $container.on('submit', '.giant-tset-form', function (event) {
        event.preventDefault();
        var $form = $(this);
        var $btn  = $form.find('.giant-int-save');
        var orig  = $btn.html();

        var fields = {};
        $form.find('.giant-int-input').each(function () {
            var $i = $(this);
            fields[$i.data('code')] = $i.val();
        });

        $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin-pulse"></i> Saving…');
        $('#giantModalAlertDiv').hide();

        $.ajax({
            type: 'post',
            data: { pbxAction: 'saveTenantSettings', fields: fields },
            success: function (responseJson) {
                var resp;
                try { resp = jQuery.parseJSON(responseJson); } catch (e) { resp = { error: 'Unexpected response' }; }
                $btn.prop('disabled', false).html(orig);
                if (resp && resp.error) {
                    $('#giantModalAlertDiv').show();
                    $('#giantModalAlert').html(resp.error);
                    return;
                }
                refreshList(tileName);
            },
            error: function () {
                $btn.prop('disabled', false).html(orig);
                $('#giantModalAlertDiv').show();
                $('#giantModalAlert').html('Could not save your settings. Please try again.');
            }
        });
    });

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

// One accordion for every "shared" section (media, hold music, additional
// destinations). Collapsed by default so a modal isn't lengthened by things
// the customer didn't create; the pickers still list the shared items. The
// open/closed choice is remembered per section in this browser.
function giantSharedAccordion(key, opts, bodyHtml) {
    var esc = function (t) { return $('<div>').text(t == null ? '' : String(t)).html(); };
    var open = false;
    try { open = window.localStorage.getItem('giantSharedOpen:' + key) === '1'; } catch (e) {}
    return '<div class="giant-shared-acc' + (open ? ' is-open' : '') + '" data-key="' + esc(key) + '">' +
        '<button type="button" class="giant-shared-acc-head" aria-expanded="' + (open ? 'true' : 'false') + '">' +
          '<i class="fa-duotone ' + esc(opts.icon || 'fa-people-group') + '" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f; margin-bottom:0;"></i> ' +
          '<span class="giant-shared-acc-title">' + esc(opts.title) + '</span>' +
          (opts.count != null ? ' <span class="giant-shared-acc-count">' + esc(opts.count) + '</span>' : '') +
          (opts.note ? ' <span class="giant-shared-note">' + esc(opts.note) + '</span>' : '') +
          '<i class="fa-solid fa-chevron-down giant-shared-acc-chev"></i>' +
        '</button>' +
        '<div class="giant-shared-acc-body">' + bodyHtml + '</div>' +
    '</div>';
}
$(document).off('click.giantSharedAcc').on('click.giantSharedAcc', '.giant-shared-acc-head', function () {
    var $acc = $(this).closest('.giant-shared-acc'), open = !$acc.hasClass('is-open');
    $acc.toggleClass('is-open', open);
    $(this).attr('aria-expanded', open ? 'true' : 'false');
    try { window.localStorage.setItem('giantSharedOpen:' + $acc.data('key'), open ? '1' : '0'); } catch (e) {}
    // Players inside were hidden while collapsed: draw their idle waveform now.
    if (open && typeof drawMwaveIdle === 'function') $acc.find('.giant-mwave-canvas').each(function () { drawMwaveIdle(this); });
});

// Shared services (Additional Destinations): destinations the switch holds
// once for every account — call screening, the Lenny chatbot … Each card says
// what the service does and where this account already routes to it.
function renderSharedDestinations(shared) {
    var esc = function (t) { return $('<div>').text(t == null ? '' : String(t)).html(); };
    $('#giantModalListDiv').find('.giant-shared-dest').remove();
    var body = '<div class="giant-moh-list">';
    shared.forEach(function (d) {
        var used = parseInt(d.used_by, 10) || 0;
        body += '<div class="giant-moh-card is-shared giant-shared-dest-card" data-cu_id="' + esc(d.cu_id) + '">';
        body += '  <div class="giant-moh-head"><div>';
        body += '    <div class="giant-moh-name">' + esc(d.cu_name) + '</div>';
        body += '    <div class="giant-moh-meta">';
        if (d.what) body += '<span class="giant-shared-what">' + esc(d.what) + '</span> ';
        body += '<span class="giant-moh-pill' + (used ? ' is-default' : '') + '"><i class="fa-solid ' + (used ? 'fa-route' : 'fa-circle-dashed') + '"></i> ' + (used ? ('Used by ' + used + ' route' + (used === 1 ? '' : 's')) : 'Not routed yet') + '</span>';
        body += '    </div>';
        body += '  </div><div class="giant-moh-card-actions"><span class="giant-shared-pill"><i class="fa-solid fa-people-group"></i> Shared</span></div></div>';
        body += '</div>';
    });
    body += '</div>';
    $('#giantModalListDiv').append('<div class="giant-shared-dest">' + giantSharedAccordion('customDestination', {
        title: 'Shared services', icon: 'fa-shield-halved', count: shared.length,
        note: 'Ready-made destinations you can route any number, menu or queue to. Shared with every account, so they can\'t be edited here.'
    }, body) + '</div>');
}

//renderFeatureCodesLayout=======================================================
function renderFeatureCodesLayout(response, tileName) {

    var $container = $('#giantModalListTableDiv');
    $container.children().remove();

    var html = '';

    // Custom feature codes section (if any)
    var customCount = response.data ? Object.keys(response.data).length : 0;
    if (customCount > 0) {
        html += '<div class="giant-fc-section">';
        html += '<h5 class="giant-fc-heading"><i class="fa-duotone fa-user-gear" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f; margin-bottom:0;"></i> Your Custom Feature Codes</h5>';
        html += '<div class="giant-fc-grid">';
        Object.entries(response.data).forEach(function(entry) {
            var item = entry[1];
            html += '<div class="giant-fc-item">';
            html += '<div class="giant-fc-code">' + (item.fe_code || '') + '</div>';
            html += '<div class="giant-fc-label">' + (item.fe_comment || '') + '</div>';
            html += '<div class="giant-fc-actions">';
            html += '<button class="giantEditButton giant-icon-btn giant-icon-edit" title="Edit"';
            html += ' data-fe_id="' + item.fe_id + '" data-fe_code="' + (item.fe_code || '') + '" data-fe_comment="' + (item.fe_comment || '').replace(/"/g, '&quot;') + '"';
            html += '><i class="fa-solid fa-pen"></i></button>';
            html += '<form class="giantModalRemoveForm" method="post" style="display:inline;"><input type="hidden" name="pbxAction" value="removeFeatureCode"><input type="hidden" name="fe_id" value="' + item.fe_id + '">';
            html += '<button type="submit" class="giant-icon-btn giant-icon-delete" title="Remove"><i class="fa-solid fa-trash"></i></button></form>';
            html += '</div></div>';
        });
        html += '</div></div>';
    }

    // Default feature codes
    if (response.defaults && response.defaults.length) {
        // Group by category
        var cats = {};
        response.defaults.forEach(function(d) {
            var c = d.category || 'Other';
            if (!cats[c]) cats[c] = [];
            cats[c].push(d);
        });

        var catIcons = {
            'DND': 'fa-ban', 'Voicemail': 'fa-voicemail', 'Recording': 'fa-circle-dot',
            'Calling': 'fa-phone', 'Forwarding': 'fa-phone-arrow-right', 'Pickup & Park': 'fa-parking',
            'Call Control': 'fa-sliders', 'Transfer': 'fa-arrow-right-arrow-left'
        };

        html += '<div class="giant-fc-section">';
        html += '<h5 class="giant-fc-heading"><i class="fa-duotone fa-list-check" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f; margin-bottom:0;"></i> Default System Codes</h5>';
        html += '<p class="giant-fc-intro">Dial these codes from your handset to quickly activate features. Codes with <code>[NUM]</code> or <code>[EXT]</code> require you to add a number after the code.</p>';

        // Search
        html += '<input type="text" class="form-control giant-fc-search" id="fcSearch" placeholder="Search feature codes...">';

        Object.entries(cats).forEach(function(catEntry) {
            var catName = catEntry[0];
            var items = catEntry[1];
            var icon = catIcons[catName] || 'fa-hashtag';

            html += '<div class="giant-fc-cat">';
            html += '<h6 class="giant-fc-cat-title"><i class="fa-duotone ' + icon + '" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f; margin-bottom:0;"></i> ' + catName + '</h6>';
            html += '<div class="giant-fc-grid">';
            items.forEach(function(d) {
                html += '<div class="giant-fc-item giant-fc-default">';
                html += '<div class="giant-fc-code">' + d.code + '</div>';
                html += '<div class="giant-fc-label">' + d.label + '</div>';
                html += '</div>';
            });
            html += '</div></div>';
        });

        html += '</div>';
    }

    $container.html(html);

    // Search handler
    $('#fcSearch').on('keyup', function() {
        var val = $(this).val().toLowerCase();
        $('.giant-fc-default').each(function() {
            var text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(val) > -1);
        });
        // Hide empty categories
        $('.giant-fc-cat').each(function() {
            var visible = $(this).find('.giant-fc-default:visible').length;
            $(this).toggle(visible > 0);
        });
    });

    // Add button
    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').find('.giant-empty-state').remove();
    $('#giantModalListDiv').append('<button id="giantAddButton" class="btn btn-primary"><i class="fa-solid fa-plus" style="margin-bottom:0;"></i> Add Custom Code</button>');

    $('#giantAddButton').off('click');
    $('#giantAddButton').on('click', function() {
        $('#giantModalAlertDiv').hide();
        showForm(tileName, "add", addFormData[tileName], {});
    });

    // Edit buttons
    $('.giantEditButton').off('click');
    $('.giantEditButton').on('click', function() {
        $('#giantModalAlertDiv').hide();
        showForm(tileName, "edit", editFormData[tileName], $(this).data());
    });

    // Remove forms
    $('.giantModalRemoveForm').off('submit');
    $('.giantModalRemoveForm').on('submit', async function (event) {
        event.preventDefault();
        if (!(await giantConfirm('Remove this feature code?'))) return;
        $.ajax({
            type: 'post',
            data: $(this).serialize(),
            success: function(responseJson) {
                var resp = jQuery.parseJSON(responseJson);
                if (resp && resp.error) {
                    $('#giantModalAlertDiv').show();
                    $('#giantModalAlert').html(resp.error);
                }
                refreshList(tileName);
            }
        });
    });

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

//refreshList===================================================================
function refreshList(tileName, extraParams) {

    // Remember the current list so the universal remove-form gate can refresh
    // the right tile after a delete.
    window.__giantTile = tileName;
    $('.giant-list-hint').remove();

    extraParams = extraParams || {};

    $('#giantModalListTableDiv').children().remove();
    $('#giantModalListTableDiv').append('<table id="giantModalList"><thead id="giantModalListHead"></thead><tbody id="giantModalListBody"></tbody></table>');
    $('.giantModalPanel').hide();
    $('#giantModalSpinnerDiv').show();
    $('#giantModalListDiv').find('#giantAddButton').parent().filter(':not(.giantModalPanel):not(#giantModalListDiv)').remove();
    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').find('.customAddDiv').remove();
    $('#giantModalListDiv').find('.giant-empty-state').remove();
    $('#giantModalListDiv').find('.giant-table-search').remove();
    // Optional summary banner some lists render above the table (e.g. the AI
    // conversations token totals) — clear any stale one on every refresh.
    $('#giantModalListDiv').find('.giant-list-header').remove();
    // Custom the app buttons (Settings / Rebuild) — re-added only for the
    // voiceCloud tile, so clear any stale ones left from a previous modal.
    $('#giantModalListDiv').find('#giantVcSettingsBtn, #giantRebuildVcBtn').remove();
    $('#giantModalListDiv').find('.giant-vc-download-bar').remove();
    var action = "get" + capitalizeFirstLetter(tileName) + "List";

    var ajaxData = $.extend({ pbxAction: action }, extraParams);

    $.ajax({
        type: 'post',
        data: ajaxData,
        error: function () {
            $('.giantModalPanel').hide();
            $('#giantModalAlertDiv').show();
            $('#giantModalAlert').html('An error occurred while loading data. Please try again.');
        },
        success: function (responseJson) {

            var response;
            try {
                response = (responseJson && typeof responseJson === 'object') ? responseJson : jQuery.parseJSON(responseJson);
            } catch (e) {
                $('.giantModalPanel').hide();
                $('#giantModalAlertDiv').show();
                $('#giantModalAlert').html('An error occurred while loading data. Please try again.');
                return;
            }

            if (response && response.customLayout === "media") {
                renderMediaLayout(response, tileName);
                return;
            }

            if (response && response.customLayout === "featureCodes") {
                renderFeatureCodesLayout(response, tileName);
                return;
            }

            if (response && response.customLayout === "teamsRouting") {
                renderTeamsRoutingGuide(response, tileName);
                return;
            }

            if (response && response.customLayout === "callFlow") {
                renderCallFlowList(response, tileName);
                return;
            }

            if (response && response.customLayout === "voicemail") {
                renderVoicemailLayout(response, tileName);
                return;
            }

            if (response && response.customLayout === "fax") {
                console.log('[us fax] dispatcher → renderFaxLayout', response);
                renderFaxLayout(response, tileName);
                return;
            }

            if (response && response.customLayout === "phoneBook") {
                renderPhoneBookLayout(response, tileName);
                return;
            }

            // Integrations tile — always route through the dedicated
            // renderer so any error path produces a visible diagnostic
            // (the generic fallback hides errors inside a hidden panel).
            if (tileName === 'integration') {
                console.log('[us integrations] raw response:', responseJson);
                renderIntegrationsLayout(response || {}, tileName);
                return;
            }

            if (response && response.customLayout === "integrations") {
                renderIntegrationsLayout(response, tileName);
                return;
            }

            // Tenant Settings tile — route through its renderer (like
            // integrations) so error paths stay visible.
            if (tileName === 'tenantSettings' || (response && response.customLayout === "tenantSettings")) {
                renderTenantSettingsLayout(response || {}, tileName);
                return;
            }

            if (response && response.customLayout === "disa") {
                renderDisaLayout(response, tileName);
                return;
            }

            if (response && response.customLayout === "campaign") {
                renderCampaignLayout(response, tileName);
                return;
            }

            if (response && response.customLayout === "musicOnHold") {
                renderMusicOnHoldLayout(response, tileName);
                return;
            }

            if (!response || !response.fields) {
                var $c = $('#giantModalListTableDiv');
                $c.children().remove();
                $c.append(`
                    <div style="text-align:center; padding:40px 20px;">
                        <i class="fa-duotone fa-circle-info fa-2x" style="--fa-primary-color: #00d9a7; --fa-secondary-color: #99e15f; margin-bottom:12px;"></i>
                        <p style="font-size:14px; color:#6c757d; margin:0 0 16px;">This feature is not available on this service. Please contact us if you need it.</p>
                    </div>
                `);

                $('.giantModalPanel').hide();
                $('#giantModalListDiv').show();
                return;
            }

            // Apply wide modal for DataTable views with data, or for wide list tiles
            var wideListTiles = ['callLog', 'smsLog', 'extension', 'phone', 'aiAgentLog'];
            if (response.asDataTable || wideListTiles.indexOf(tileName) > -1) {
                $('#giantModal .modal-dialog').addClass('giant-modal-wide');
            }
            // The call log is the widest table (16 columns) — give it a roomier
            // cap and let it scroll horizontally inside the modal rather than clip.
            $('#giantModal .modal-dialog').removeClass('giant-modal-cdr');
            if (tileName === 'callLog') {
                $('#giantModal .modal-dialog').addClass('giant-modal-cdr');
            }

            $('.datepicker').parent().parent().remove();
            // The transcript-search bar has no .datepicker, so the cleanup above
            // never removes it — clear it (and its results) explicitly. Without
            // this it duplicates on repeated call-log opens and lingers into
            // other modals that share this list container.
            $('.giant-tsearch-bar, .giant-tsearch-results').remove();
            // Call-log toolbar + its wrapper panel — clear any stale one so it
            // never lingers into another tile that reuses this list container.
            $('.giant-cdr-tools').remove();
            $('.giant-cdr-controls').remove();
            if (response.fromTo && response.asDataTable) {
                // Modern date filter bar
                var dateBar = '<div class="giant-date-bar">';
                dateBar += '<div class="giant-date-field"><label>From</label><input type="text" id="from" class="datepicker form-control" value="' + response.from + '"></div>';
                dateBar += '<div class="giant-date-field"><label>To</label><input type="text" id="to" class="datepicker form-control" value="' + response.to + '"></div>';
                dateBar += '<button id="giantDateApply" class="btn btn-primary" style="margin-top:0; padding:8px 16px; font-size:12px; align-self:flex-end;"><i class="fa-solid fa-magnifying-glass" style="margin-bottom:0;"></i> Search</button>';
                dateBar += '</div>';
                $('#giantModalAlertDiv').after(dateBar);

                // Transcript search — only the call log has recordings to search.
                if (tileName === 'callLog') {
                    var tBar = '<div class="giant-tsearch-bar">' +
                        '<div class="giant-tsearch-field"><i class="fa-solid fa-quote-left"></i>' +
                        '<input type="text" id="giantTranscriptSearch" class="form-control" placeholder="Search what was said on calls…">' +
                        '</div>' +
                        '<button id="giantTranscriptSearchBtn" class="btn btn-primary giant-tsearch-btn"><i class="fa-solid fa-magnifying-glass" style="margin-bottom:0;"></i> Search transcripts</button>' +
                        '</div>' +
                        '<div id="giantTranscriptResults" class="giant-tsearch-results" style="display:none;"></div>';
                    $('.giant-date-bar').after(tBar);

                    var runTranscriptSearch = function () {
                        var q = ($('#giantTranscriptSearch').val() || '').trim();
                        if (q.length < 2) { alert('Type at least 2 characters to search call transcripts.'); return; }
                        var $res = $('#giantTranscriptResults');
                        $('#giantModalListTableDiv').hide();
                        $res.show().html('<div class="giant-tsearch-status"><i class="fa-solid fa-spinner fa-spin"></i> Searching transcripts… the first search over a date range can take a few seconds.</div>');
                        $.ajax({
                            type: 'post', dataType: 'json',
                            data: { pbxAction: 'searchCallTranscripts', from: $('#from').val(), to: $('#to').val(), query: q }
                        }).done(function (resp) {
                            renderTranscriptSearchResults(resp, q);
                        }).fail(function () {
                            $res.html('<div class="giant-tsearch-status">Search failed. Please try again.</div>');
                        });
                    };
                    $('#giantTranscriptSearchBtn').on('click', runTranscriptSearch);
                    $('#giantTranscriptSearch').on('keypress', function (e) { if (e.which === 13) { e.preventDefault(); runTranscriptSearch(); } });
                }

                $('.datepicker').each(function() {
                    flatpickr(this, {
                        dateFormat: 'Y-m-d',
                        allowInput: true,
                        disableMobile: true,
                    });
                });

                function doDateSearch() {
                    // If a transcript search is open, restore the table view.
                    $('#giantTranscriptResults').hide().empty();
                    $('#giantModalListTableDiv').show();

                    // Call log: re-fetch through the unified list render rather than
                    // DataTables' rows.add(). The call log's Started/Ended/Duration/
                    // Cost cells carry orthogonal data-order attributes, which make
                    // DataTables treat those columns as object-sourced — plain array
                    // rows then throw "unknown parameter [object Object]". refreshList
                    // rebuilds the table HTML the same way as first load (correct
                    // pills/formatting + toolbar) AND shows the loading spinner.
                    if (tileName === 'callLog') {
                        refreshList(tileName, $.extend({}, extraParams, { from: $('#from').val(), to: $('#to').val() }));
                        return;
                    }

                    $.ajax({
                        type: 'post',
                        data: $.extend({}, extraParams, {
                            pbxAction: action,
                            from: $('#from').val(),
                            to: $('#to').val(),
                        }),
                        success: function (responseJson) {
                            var response = jQuery.parseJSON(responseJson);
                            var rows = [];
                            if (response.data) {
                                Object.entries(response.data).forEach(function (data, index) {
                                    data = data[1];
                                    var row = [];
                                    Object.entries(response.fields).forEach(function (fieldData, index) {

                                        fieldData = fieldData[1];

                                        if (fieldData.asRecording) {
                                            if (data[fieldData.name]) {
                                                var recHtml = '<div class="giant-rec-cell">';
                                                recHtml += '<button class="giant-rec-play giant-icon-btn" data-rec-id="' + data[fieldData.name] + '" data-action="playCallRecord" title="Play"><i class="fa-solid fa-play"></i></button>';
                                                recHtml += '<button class="giant-rec-transcript giant-icon-btn" data-rec-id="' + data[fieldData.name] + '" title="Transcript"><i class="fa-solid fa-quote-left"></i></button>';
                                                recHtml += '<form method="post" style="display:inline;" action="' + pbxApi.endpoint() + '"><input type="hidden" name="pbxAction" value="' + fieldData.action + '"><input type="hidden" name="download" value="1">' + pbxApi.hidden() + '<input type="hidden" name="itemId" value="' + data[fieldData.name] + '"><button class="giant-icon-btn" title="Download" type="submit"><i class="fa-solid fa-download"></i></button></form>';
                                                recHtml += '</div>';
                                                recHtml += '<audio class="giant-rec-audio" id="recAudio_' + data[fieldData.name].replace(/[^a-zA-Z0-9]/g, '_') + '" preload="none" style="display:none;"></audio>';
                                                row.push(recHtml);
                                            } else {
                                                row.push('');
                                            }
                                        } else if (fieldData.asDownload) {
                                            if (data[fieldData.name]) {
                                                var formHtml = '<form method="post" action="' + pbxApi.endpoint() + '"><input type="hidden" name="pbxAction" value="' + fieldData.action + '"><input type="hidden" name="download" value="1">' + pbxApi.hidden() + '<input type="hidden" name="itemId" value="' + data[fieldData.name] + '"><button class="btn btn-primary">Download</button> </form>';
                                            } else {
                                                formHtml = "";
                                            }
                                            row.push(formHtml);
                                        } else {
                                            row.push(data[fieldData.name]);
                                        }
                                    });
                                    rows.push(row);
                                });
                            }
                            var datatable = $('#giantModalList').DataTable();
                            datatable.clear();
                            datatable.rows.add(rows);
                            datatable.draw();

                            // Refresh the optional summary banner for the new range.
                            $('#giantModalListDiv').find('.giant-list-header').remove();
                            if (response.headerHtml) {
                                $('#giantModalListTableDiv').before('<div class="giant-list-header">' + response.headerHtml + '</div>');
                            }
                        }
                    });
                }

                $('#giantDateApply').on('click', function() { doDateSearch(); });
                // Also search on Enter key in date fields
                $('.datepicker').on('keypress', function(e) { if (e.which === 13) doDateSearch(); });
            }

            // Add search bar for non-DataTable lists with 3+ items
            if (!response.asDataTable && response.data && Object.keys(response.data).length >= 3) {
                $('#giantModalListTableDiv').prepend('<div class="giant-table-search"><input type="text" id="giantTableSearch" class="form-control" placeholder="Search..."></div>');
                $('#giantTableSearch').on('keyup', function() {
                    var val = $(this).val().toLowerCase();
                    $('#giantModalListBody tr').each(function() {
                        var text = $(this).text().toLowerCase();
                        $(this).toggle(text.indexOf(val) > -1);
                    });
                });
            }

            // A pick from the landing page's find box opens the list already
            // narrowed to it. Rows are appended below, so filter on the next tick.
            var pend = window._giantPendingListSearch;
            window._giantPendingListSearch = null;
            if (pend && pend.tile === tileName && pend.term && $('#giantTableSearch').length) {
                setTimeout(function () { $('#giantTableSearch').val(pend.term).trigger('keyup'); }, 0);
            }

            // Optional summary banner rendered above the table (e.g. the AI
            // conversations token totals + per-agent breakdown). Injected as a
            // sibling above the table container; cleared on every refreshList.
            $('#giantModalListDiv').find('.giant-list-header').remove();
            if (response.headerHtml) {
                $('#giantModalListTableDiv').before('<div class="giant-list-header">' + response.headerHtml + '</div>');
            }

            var tableHead = "<tr>";
            Object.entries(response.fields).forEach(function (fieldData, index) {
                fieldData = fieldData[1];
                tableHead += '<th>' + fieldData.display + '</th>';
            });
            if (!response.noActions) {
                tableHead += '<th>' + "Actions" + '</th>';
            }

            $('#giantModalListHead').append(tableHead);
            /*
            if(response.asDataTable) {
                $('#giantModalList').DataTable().clear().draw();
            }
            */
            if (response.data) {
                Object.entries(response.data).forEach(function (data, index) {
                    data = data[1];
                    var tableRow = "<tr>";
                    Object.entries(response.fields).forEach(function (fieldData, index) {
                        fieldData = fieldData[1];

                        if (tileName === "phone" && fieldData.name === "ph_status") {
                            var s = (data.ph_status || '').toLowerCase();
                            if (s === 'active') {
                                tableRow += '<td><span class="giant-phone-status giant-phone-status-on"><i class="fa-solid fa-circle"></i> Active</span></td>';
                            } else if (s === 'inactive') {
                                tableRow += '<td><span class="giant-phone-status giant-phone-status-off"><i class="fa-solid fa-circle"></i> Inactive</span></td>';
                            } else {
                                tableRow += '<td><span class="giant-phone-status giant-phone-status-unknown">—</span></td>';
                            }
                        } else if (tileName === "phone" && fieldData.name === "ph_extensions") {
                            if (data.ph_extensions) {
                                var parts = String(data.ph_extensions).split(',').map(function (p) { return p.trim(); }).filter(Boolean);
                                var pills = parts.map(function (p) { return '<span class="giant-ext-pill">' + $('<div>').text(p).html() + '</span>'; }).join(' ');
                                tableRow += '<td><div class="giant-ext-cell">' + pills + '</div></td>';
                            } else {
                                tableRow += '<td><span class="text-muted">—</span></td>';
                            }
                        } else if (fieldData.asDateTime) {
                            // Compact date-pill + time; raw value in data-order keeps DataTables sorting chronologically.
                            var _rawWhen = data[fieldData.name] == null ? '' : String(data[fieldData.name]);
                            tableRow += '<td data-order="' + _rawWhen.replace(/"/g, '&quot;') + '">' + fmtCdrWhen(_rawWhen) + '</td>';
                        } else if (fieldData.asDuration) {
                            var _secs = parseInt(data[fieldData.name], 10); if (isNaN(_secs)) { _secs = 0; }
                            tableRow += '<td data-order="' + _secs + '">' + fmtCdrDur(_secs) + '</td>';
                        } else if (fieldData.asMoney) {
                            var _amt = parseFloat(String(data[fieldData.name]).replace(/[^0-9.\-]/g, '')); if (isNaN(_amt)) { _amt = 0; }
                            // A pre-rendered cell (e.g. "Included" when inclusive minutes
                            // covered the call) keeps the numeric sort.
                            var _amtHtml = data[fieldData.name + '_html'];
                            tableRow += '<td data-order="' + _amt + '">' + (_amtHtml ? _amtHtml : '£' + _amt.toFixed(2)) + '</td>';
                        } else if (data[fieldData.name]) {
                            if (tileName === "phone" && fieldData.name === "ph_pm_name") {
                                var pmSrc = resolvePhoneModelSrc(data.pm_image_src, data.ph_pm_id, data.pm_image_ver);
                                var pmThumb = pmSrc
                                    ? '<img src="' + pmSrc + '" class="giant-pm-thumb" alt="" decoding="async" loading="eager">'
                                    : '<span class="giant-pm-thumb giant-pm-thumb-empty"><i class="fa-solid fa-mobile"></i></span>';
                                var mfgTag = manufacturerLogoTag(data.pm_mfg_src, data.pm_mfg_name);
                                var modelFmtOpts = data.pm_mfg_src ? { stripManufacturer: data.pm_mfg_name } : null;
                                tableRow += '<td><div class="giant-pm-cell">' + pmThumb + '<div class="giant-pm-cell-text">' + mfgTag + '<span>' + formatPhoneModelName(data[fieldData.name], modelFmtOpts) + '</span></div></div></td>';
                            } else if (fieldData.asButton) {

                                var copyButtonHtml = '<button class="giantCopyButton btn btn-primary" data-to-copy="' + data[fieldData.name] + '">Copy</button>';
                                tableRow += '<td>' + copyButtonHtml + '</td>'
                            } else if (fieldData.asQr) {

                                var qrButtonHtml = '<button class="giantQrButton btn btn-primary" data-qr-data="' + data[fieldData.name] + '">Show</button>';
                                tableRow += '<td>' + qrButtonHtml + '</td>'
                            } else if (fieldData.asRecording) {
                                if (data[fieldData.name]) {
                                    var recHtml = '<div class="giant-rec-cell">';
                                    recHtml += '<button class="giant-rec-play giant-icon-btn" data-rec-id="' + data[fieldData.name] + '" data-action="playCallRecord" title="Play"><i class="fa-solid fa-play"></i></button>';
                                    recHtml += '<button class="giant-rec-transcript giant-icon-btn" data-rec-id="' + data[fieldData.name] + '" title="Transcript"><i class="fa-solid fa-quote-left"></i></button>';
                                    recHtml += '<form method="post" style="display:inline;" action="' + pbxApi.endpoint() + '"><input type="hidden" name="pbxAction" value="' + fieldData.action + '"><input type="hidden" name="download" value="1">' + pbxApi.hidden() + '<input type="hidden" name="itemId" value="' + data[fieldData.name] + '"><button class="giant-icon-btn" title="Download" type="submit"><i class="fa-solid fa-download"></i></button></form>';
                                    recHtml += '</div>';
                                    recHtml += '<audio class="giant-rec-audio" id="recAudio_' + data[fieldData.name].replace(/[^a-zA-Z0-9]/g, '_') + '" preload="none" style="display:none;"></audio>';
                                    tableRow += '<td>' + recHtml + '</td>';
                                } else {
                                    tableRow += '<td></td>';
                                }
                            } else if (fieldData.asDownload) {
                                if (data[fieldData.name]) {
                                    var formHtml = '<form method="post" action="' + pbxApi.endpoint() + '"><input type="hidden" name="pbxAction" value="' + fieldData.action + '"><input type="hidden" name="download" value="1">' + pbxApi.hidden() + '<input type="hidden" name="itemId" value="' + data[fieldData.name] + '"><button class="btn btn-primary"><i class="fa-duotone fa-download" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i>Download</button> </form>';

                                } else {
                                    formHtml = "";
                                }
                                tableRow += '<td>' + formHtml + '</td>';
                            } else {
                                tableRow += '<td>' + data[fieldData.name] + '</td>';
                            }
                        } else {
                            tableRow += '<td></td>';
                        }
                    });
                    if (response.idName && !response.noActions) {
                        var editButton = '';
                        if (tileName == "port" || tileName == "mobilePort") {
                            // Geographic ports (port) can be resubmitted on
                            // rejection via their edit form; mobile ports
                            // (mobilePort) have no edit form, so no resubmit.
                            var rejected = (data.status_code == "reject" || data.status_code == "reject_lcp");
                            if (editFormData[tileName] && rejected && data.supersededBy) {
                                // The number has since ported (or is porting) with the
                                // same carrier under a later request: nothing to resubmit.
                                editButton = '<span class="giant-port-superseded" title="This number went through under a later request, so there is nothing to resubmit" style="display:inline-block;font-size:12px;color:#6b7d77;margin-right:8px;white-space:nowrap;">Superseded by <b>' + data.supersededBy + '</b></span>';
                            } else if (editFormData[tileName] && rejected) {
                                editButton = '<button class="giantEditButton btn btn-primary"';
                                editButton += ' data-ref=' + data.ref;
                                editButton += ">Resubmit</button> ";
                            }

                            var additionalDataButton = '';
                            if (data.detailsHtml) {
                                additionalDataButton = '<button class="giantAdditionalDataButton btn btn-primary"';
                                additionalDataButton += ' data-html=' + '"' + data.detailsHtml + '"';
                                additionalDataButton += ">Details</button> ";
                            }
                            tableRow += '<td style="text-align: right">' + editButton + additionalDataButton + '</td>';
                        } else {
    var actionBtns = '<div class="giant-row-actions">';

    if (editFormData[tileName] && !data._noActions) {
        actionBtns += '<button class="giantEditButton giant-icon-btn giant-icon-edit" title="Edit"';
        var skipDataAttrs = { pm_image_src: 1, pm_mfg_src: 1 };
        // jQuery's .data() reader auto-parses arrays/objects (anything
        // matching `[...]` / `{...}`) as JSON, but treats every other
        // attribute value as a literal string. So:
        //   - arrays/objects must go in as JSON.stringify output
        //   - strings/numbers must go in as their raw value (no JSON
        //     wrapping), HTML-escaped so quotes/newlines survive the
        //     round-trip through the data-* attribute
        var giantAttrEscape = function (s) {
            return String(s == null ? '' : s)
                .replace(/&/g, '&amp;')
                .replace(/"/g, '&quot;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/\r/g, '&#13;')
                .replace(/\n/g, '&#10;');
        };
        Object.entries(data).forEach(function (entry) {
            if (skipDataAttrs[entry[0]]) return;
            // Convention: server-rendered display HTML is suffixed with
            // _display and is for the list cell only — skipping it here
            // keeps the data-* attribute string from blowing up on quotes.
            if (/_display$/.test(entry[0])) return;
            var raw = (entry[1] !== null && typeof entry[1] === 'object')
                ? JSON.stringify(entry[1])
                : entry[1];
            // HTML lowercases attribute names — `data-systemContent` would
            // be stored as `data-systemcontent` and jQuery's .data() then
            // hands back the key as lowercase, breaking lookups by the
            // camelCase field name. Convert camelCase → kebab-case here so
            // jQuery's reverse transform restores the original field name.
            var attrName = entry[0].replace(/([A-Z])/g, '-$1').toLowerCase();
            actionBtns += ' data-' + attrName + '="' + giantAttrEscape(raw) + '"';
        });
        actionBtns += '><i class="fa-solid fa-pen"></i></button>';
    }

    // Call Flow button for telephone numbers
    if (tileName === "destination" && data.di_id) {
        var flowLabel = (data.di_area || '') + (data.di_number || '');
        actionBtns += '<button class="giant-flow-btn giant-icon-btn" title="View Call Flow"' +
            ' data-typesrc="DID" data-typeidsrc="' + data.di_id + '" data-name="' + flowLabel + '">' +
            '<i class="fa-solid fa-diagram-project"></i></button>';

        // 999 status pill — auto-checks on list render, click to edit
        actionBtns += '<span class="giant-999-status is-checking" data-di-id="' + data.di_id + '" title="Checking 999 record…">' +
            '<i class="fa-solid fa-spinner fa-spin"></i> 999' +
          '</span>';
    }

    if (tileName === "extension" && data.ex_number) {
        var dndOn = (data.dnd === "on");
        var dndTitle = dndOn ? "DND: ON (click to disable)" : "DND: OFF (click to enable)";
        var dndClass = dndOn ? "giant-icon-btn giant-icon-dnd-on" : "giant-icon-btn";
        actionBtns += '<button class="giantDndToggle ' + dndClass + '" title="' + dndTitle + '"' +
            ' data-ex_number="' + data.ex_number + '" data-dnd="' + (dndOn ? "on" : "off") + '">' +
            '<i class="fa-solid fa-moon"></i></button>';

        // Launch WebPhone in a new tab — bakes in the extension's SIP credentials.
        if (data.username_combined && data.password) {
            actionBtns += '<button class="giantWebphoneLaunch giant-icon-btn" title="Open WebPhone for this extension"' +
                ' data-webphone_ext="' + data.username_combined + '"' +
                ' data-webphone_pass="' + data.password + '"' +
                ' data-webphone_name="' + (data.ex_name || '').replace(/"/g, '&quot;') + '">' +
                '<i class="fa-solid fa-headset"></i></button>';
        }

        // Click-to-call — small inline button next to DND/WebPhone for quick dial.
        actionBtns += '<button class="giantClickToCallRow giant-icon-btn" title="Click-to-call from this extension"' +
            ' data-source="' + data.ex_number + '">' +
            '<i class="fa-solid fa-phone"></i></button>';
    }

    if (tileName === "voiceCloud" && data.appUserId) {
        actionBtns += '<button class="giantResetVoiceCloudPassword giant-icon-btn giant-icon-warn" title="Reset Password"' +
            ' data-appuserid="' + data.appUserId + '">' +
            '<i class="fa-solid fa-key"></i></button>';
    }

    // Reboot / re-register dropdown — same dropdown pattern as the RPS
    // menu. Sends the request via the carrier's REBOOT/UNREGISTER reqtype;
    // the phone goes offline for ~30s on a full reboot, near-instant on a
    // re-register. Tenant ownership is enforced server-side before the
    // request leaves our backend.
    if (tileName === "phone" && data.ph_id) {
        var phId = String(data.ph_id).replace(/"/g, '&quot;');
        var phName = String(data.ph_name || '').replace(/"/g, '&quot;');
        actionBtns += '<div class="giant-device-rps">' +
            '<button type="button" class="giant-device-rps-btn giant-icon-btn" title="Reboot or re-register this phone" data-ph-id="' + phId + '">' +
              '<i class="fa-solid fa-power-off"></i>' +
            '</button>' +
            '<div class="giant-device-rps-menu">' +
              '<div class="giant-device-rps-menu-h">Phone controls</div>' +
              '<button type="button" data-phone-action="unregister" data-ph-id="' + phId + '"><i class="fa-solid fa-rotate"></i> Force re-register</button>' +
              '<button type="button" data-phone-action="reboot"     data-ph-id="' + phId + '" class="is-danger"><i class="fa-solid fa-power-off"></i> Reboot phone</button>' +
            '</div>' +
          '</div>';

        // Per-phone directory bindings (phonephonebook). Opens a dialog
        // listing the books pushed to this handset, with add/remove.
        actionBtns += '<button type="button" class="giant-icon-btn giant-phone-pb-btn" title="Phone Books on this handset"' +
            ' data-ph-id="' + phId + '" data-ph-name="' + phName + '">' +
            '<i class="fa-solid fa-book"></i></button>';
    }

    // RPS status pill + management dropdown
    if (tileName === "phone" && data.ph_mac) {
        var rpsSupported = {
            auerswald: 1, gigaset: 1, panasonic: 1, snom: 1, yealink: 1,
            grandstream: 1, fanvil: 1, giant: 1, poly: 1, polycom: 1
        };
        var rpsMfgKey   = String(data.pm_mfg_name || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
        var rpsMac      = String(data.ph_mac).replace(/"/g, '&quot;');
        var rpsMfgLabel = String(data.pm_mfg_name || '').replace(/"/g, '&quot;');

        if (rpsSupported[rpsMfgKey]) {
            actionBtns += '<span class="giant-rps-status is-checking" data-mac="' + rpsMac + '" title="Checking RPS status…">' +
                '<i class="fa-solid fa-spinner fa-spin"></i> Checking' +
              '</span>';
            actionBtns += '<div class="giant-device-rps">' +
                '<button type="button" class="giant-device-rps-btn giant-icon-btn" title="Manage RPS registration" data-mac="' + rpsMac + '">' +
                  '<i class="fa-solid fa-cloud"></i>' +
                '</button>' +
                '<div class="giant-device-rps-menu">' +
                  '<div class="giant-device-rps-menu-h">RPS &middot; ' + rpsMfgLabel + '</div>' +
                  '<button type="button" data-rps-action="check"  data-mac="' + rpsMac + '"><i class="fa-solid fa-magnifying-glass"></i> Check status</button>' +
                  '<button type="button" data-rps-action="add"    data-mac="' + rpsMac + '"><i class="fa-solid fa-cloud-arrow-up"></i> Register</button>' +
                  '<button type="button" data-rps-action="remove" data-mac="' + rpsMac + '" class="is-danger"><i class="fa-solid fa-link-slash"></i> Unregister</button>' +
                '</div>' +
              '</div>';
        } else {
            actionBtns += '<span class="giant-rps-status is-unsupported" title="RPS not supported for ' + (rpsMfgLabel || 'this manufacturer') + '">' +
                '<i class="fa-solid fa-minus"></i> Not supported' +
              '</span>';
        }
    }

    if (addFormData[tileName] && !data._noActions) {
        actionBtns += '<form class="giantModalRemoveForm" method="post" style="display:inline;">' +
            '<input type="hidden" name="pbxAction" value="remove' + capitalizeFirstLetter(tileName) + '">' +
            '<input type="hidden" name="' + response.idName + '" value="' + data[response.idName] + '">' +
            '<button type="submit" class="giant-icon-btn giant-icon-delete" title="Remove"><i class="fa-solid fa-trash"></i></button>' +
            '</form>';
    }

    // Per-tile custom row actions registered by feature files (e.g.
    // aiAgent.js adds a "View conversations" button on AI Agent rows).
    // Keeps tile-specific buttons out of this generic engine path.
    if (window.giantRowActions && typeof window.giantRowActions[tileName] === 'function') {
        actionBtns += window.giantRowActions[tileName](data, response);
    }

    actionBtns += '</div>';
    tableRow += '<td>' + actionBtns + '</td>';
}

                    }

                    tableRow += "</tr>";

                    $('#giantModalListBody').append(tableRow);
                });

                // Kick off parallel RPS adoption checks for the newly rendered device rows.
                // Browser will cap concurrency to ~6 per origin; each call goes via our backend
                // proxy which enforces tenant ownership before hitting dm-voip.
                if (tileName === "phone") { giantKickRpsChecks(); }

                // Same pattern for 999 emergency data on telephone numbers.
                if (tileName === "destination" && typeof giantKick999Checks === 'function') {
                    giantKick999Checks();
                }

               if (response.numberAddonUrl) {
    $('#giantModalListDiv').append(
        '<a id="giantAddButton" href="' + response.numberAddonUrl + '" class="btn btn-primary" style="margin-top: 15px; display: inline-block;">' +
        '<i class="fa-duotone fa-phone-plus" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> Add New Numbers</a>'
    );
}

            }

            // Check if data is empty
            var dataCount = response.data ? Object.keys(response.data).length : 0;

            if (addFormData[tileName]) {

                // Nice empty state when no data exists
                if (dataCount === 0) {
                    $('#giantModalList').hide();

                    var friendlyNames = {
                        extension: "extensions", customDestination: "additional destinations", phone: "devices",
                        huntList: "hunt lists", voicemail: "voicemail boxes", ivr: "IVR menus",
                        queue: "queues", media: "media files", shortNumber: "short numbers",
                        featureCode: "feature codes", smsLog: "messages", voiceCloud: "the app users",
                        appDevices: "signed-in app devices", aiAgent: "AI agents", aiAgentLog: "AI conversations"
                    };
                    var friendly = friendlyNames[tileName] || tileName;

                    var emptyIcons = {
                        extension: "fa-user-plus", customDestination: "fa-phone-arrow-right", phone: "fa-phone-office",
                        huntList: "fa-users-rays", voicemail: "fa-voicemail", ivr: "fa-list-tree",
                        queue: "fa-arrows-turn-to-dots", media: "fa-compact-disc", shortNumber: "fa-forward",
                        featureCode: "fa-lightbulb-gear", smsLog: "fa-messages", voiceCloud: "fa-mobile-button",
                        appDevices: "fa-mobile-signal-out", aiAgent: "fa-microchip-ai", aiAgentLog: "fa-comments"
                    };
                    var emptyIcon = emptyIcons[tileName] || "fa-folder-open";

                    $('#giantModalListDiv').append(
                        '<div class="giant-empty-state" style="padding:40px 20px;">' +
                        '<i class="fa-duotone ' + emptyIcon + ' fa-3x" style="--fa-primary-color: #d1d5db; --fa-secondary-color: #e5e7eb; margin-bottom:16px !important;"></i>' +
                        '<p style="font-size:15px; font-weight:600; color:#1a1a2e; margin:0 0 6px;">No ' + friendly + ' yet</p>' +
                        '<p style="font-size:13px; color:#6c757d; margin:0 0 20px;">Get started by creating your first one.</p>' +
                        '</div>'
                    );
                }

                if (tileName == "smsLog") {
                    $('#giantModalListDiv').append('<div style="text-align:center;"><button id="giantAddButton" class="btn btn-primary"><i class="fa-duotone fa-paper-plane" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> Send New SMS</button></div>');
                } else if (tileName == "voiceCloud" && dataCount === 0) {
                    $('#giantModalListDiv').append('<div class="customAddDiv" style="text-align:center;"><button id="giantAddButton" class="btn btn-primary"><i class="fa-duotone fa-wand-magic-sparkles" style="--fa-primary-color:#fff; --fa-secondary-color:#fff;"></i> Begin Set Up</button></div>');
                } else if (dataCount === 0) {
                    $('#giantModalListDiv').append('<div style="text-align:center;"><button id="giantAddButton" class="btn btn-primary"><i class="fa-solid fa-plus" style="margin-bottom:0;"></i> Add New</button></div>');
                } else {
                    $('#giantModalListDiv').append('<button id="giantAddButton" class="btn btn-primary"><i class="fa-solid fa-plus" style="margin-bottom:0;"></i> Add New</button>');
                }

                $('#giantAddButton').off('click');
                $('#giantAddButton').on('click', function (event) {
                    $('#giantModalAlertDiv').hide();
                    showForm(tileName, "add", addFormData[tileName], {});
                });

                // Additional Destinations: the shared services sit under the
                // account's own, as cards of their own — routable, not editable.
                if (tileName === 'customDestination' && Array.isArray(response.shared) && response.shared.length) {
                    renderSharedDestinations(response.shared);
                }
            }

            // the app: a "Download the app" badge bar above the users list so
            // customers can grab the app for any platform. Badges are shipped in
            // the module (templates/Client/img/appbadges); links are us's own
            // stable store/download URLs. Shown for the tile whether or not any
            // users exist yet.
            if (tileName == 'voiceCloud') {
                var _vcBase  = 'modules/addons/resellervoip/templates/client/img/appbadges/';
                var _vcBadge = function (href, img, alt) {
                    return '<a href="' + href + '" target="_blank" rel="noopener"><img src="' + _vcBase + img + '" alt="' + alt + '" style="height:42px;width:auto;display:block;border:0;"></a>';
                };
                var _vcBar =
                    '<div class="giant-vc-download-bar" style="background:#f1faf6;border:1px solid #d9efe6;border-radius:12px;padding:14px 16px;margin-bottom:16px;">' +
                      '<div style="font-size:13px;font-weight:700;color:#053b30;margin-bottom:10px;"><i class="fa-duotone fa-cloud-arrow-down" style="--fa-primary-color:#00d9a7;--fa-secondary-color:#00d9a7;margin-right:6px;"></i>Download the softphone app</div>' +
                      '<div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">' +
                        (function () {
                            var L = (window.pbxConfig && window.pbxConfig.brand && window.pbxConfig.brand.links) || {};
                            return (L.ios ? _vcBadge(L.ios, 'appstore.png', 'Download on the App Store') : '') +
                                   (L.android ? _vcBadge(L.android, 'googleplay.png', 'Get it on Google Play') : '') +
                                   (L.desktop ? _vcBadge(L.desktop, 'windows.png', 'Download for desktop') : '') ||
                                   '<span style="font-size:12px;color:#6b7d77;">Ask us for the app download links.</span>';
                        })() +
                      '</div>' +
                    '</div>';
                $('#giantModalListDiv').find('.giant-vc-download-bar').remove();
                $('#giantModalListTableDiv').before(_vcBar);
            }

            if (tileName == "apiAccess") {
                /* API documentation: the reseller's own, if any. */
            }

            // the app: a "Rebuild connection" button re-pushes the branch
            // settings (resync) to fix sync issues without touching users/logins.
            // Only shown when a connection already exists (there are users).
            if (tileName == "voiceCloud" && dataCount > 0) {
                $('#giantModalListDiv').append('<button id="giantVcSettingsBtn" class="btn btn-default" style="margin-left:8px;" title="AI transcription, recording &amp; other the app settings"><i class="fa-duotone fa-sliders" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#00d9a7;"></i> Settings</button>');
                $('#giantVcSettingsBtn').off('click').on('click', function () {
                    if (window.GiantVcSettings && typeof window.GiantVcSettings.open === 'function') window.GiantVcSettings.open();
                });
                $('#giantModalListDiv').append('<button id="giantRebuildVcBtn" class="btn btn-default" style="margin-left:8px;" title="Re-applies your the app connection settings to fix sync issues. Does not affect your users or logins."><i class="fa-duotone fa-rotate" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#00d9a7;"></i> Rebuild connection</button>');
                $('#giantRebuildVcBtn').off('click').on('click', async function () {
                    if (!(await giantConfirm('Rebuild the the app connection?\n\nThis re-applies your connection settings. Your users and logins are NOT affected.'))) return;
                    var $b = $(this);
                    var label = '<i class="fa-duotone fa-rotate" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#00d9a7;"></i> Rebuild connection';
                    $b.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> Rebuilding…');
                    $.ajax({
                        type: 'post',
                        data: { pbxAction: 'rebuildVoiceCloudConnection' },
                        dataType: 'json',
                        success: function (resp) {
                            var ok  = resp && resp.success;
                            var msg = ok ? 'the app connection rebuilt.' : ('Rebuild failed: ' + ((resp && resp.error) || 'Unknown error'));
                            if (typeof giantToast === 'function') giantToast(msg, ok ? 'success' : 'error'); else alert(msg);
                        },
                        error: function () {
                            if (typeof giantToast === 'function') giantToast('Could not rebuild connection.', 'error'); else alert('Could not rebuild connection.');
                        },
                        complete: function () { $b.prop('disabled', false).html(label); }
                    });
                });
            }


            // Recording play buttons — open popup
            // Call info comes from the row cells by position. Cell 0 is the
            // group-expander column, so the data columns start at 1:
            //   1 Started · 3 In/Out · 4 Caller · 9 Duration
            var giantCallInfoFromRow = function ($btn) {
                var cells = $btn.closest('tr').find('td');
                return {
                    started:   cells.eq(1).attr('data-order') || cells.eq(1).text() || '',
                    direction: cells.eq(3).text() || '',
                    caller:    cells.eq(4).text() || '',
                    duration:  cells.eq(9).text() || '',
                };
            };

            $(document).off('click', '.giant-rec-play');
            $(document).on('click', '.giant-rec-play', function (event) {
                event.preventDefault();
                openRecordingPopup($(this).data('rec-id'), giantCallInfoFromRow($(this)));
            });

            // Recording transcript buttons — open the same rich playback popup
            // as the play button so the transcript shows as synced chat bubbles
            // alongside the audio (highlight + scrub), rather than a flat text
            // dialog.
            $(document).off('click', '.giant-rec-transcript');
            $(document).on('click', '.giant-rec-transcript', function (event) {
                event.preventDefault();
                openRecordingPopup($(this).data('rec-id'), giantCallInfoFromRow($(this)));
            });

            // Expand/collapse a grouped call's legs as a DataTables child row.
            $(document).off('click', '.giant-cdr-group-toggle');
            $(document).on('click', '.giant-cdr-group-toggle', function (event) {
                event.preventDefault();
                event.stopPropagation();
                var $btn = $(this);
                var $tr  = $btn.closest('tr');
                if (!($.fn.dataTable && $.fn.dataTable.isDataTable('#giantModalList'))) { return; }
                var row = $('#giantModalList').DataTable().row($tr);
                if (row.child && row.child.isShown()) {
                    row.child.hide();
                    $tr.removeClass('giant-group-open');
                } else {
                    var legs = $btn.siblings('.giant-cdr-group-legs').html() || '';
                    row.child('<div class="giant-cdr-legs-wrap">' + legs + '</div>').show();
                    $tr.addClass('giant-group-open');
                }
            });

            $('.giantCopyButton').off('click');
            $('.giantCopyButton').on('click', function (event) {
                event.preventDefault();

                var toCopy = $(this).data('to-copy');
                $(this).before("<input id='temp'>");
                var $temp = $("#temp");
                $temp.val(toCopy).select();
                document.execCommand("copy");
                $temp.remove();
            });

            $('.giantQrButton').off('click');
            $('.giantQrButton').on('click', function (event) {
                event.preventDefault();
                var qrData = $(this).data('qr-data');
                showQr(qrData);
            });

            $('.giantEditButton').off('click');
            $('.giantEditButton').on('click', function (event) {
                event.preventDefault();
                $('#giantModalAlertDiv').hide();
                showForm(tileName, "edit", editFormData[tileName], $(this).data());
            });

            // Call flow buttons
            $('.giant-flow-btn').off('click');
            $('.giant-flow-btn').on('click', function(event) {
                event.preventDefault();
                var typeSrc = $(this).data('typesrc');
                var typeIdSrc = $(this).data('typeidsrc');
                var name = $(this).data('name') || (typeSrc + ' ' + typeIdSrc);
                openCallFlowBuilder(typeSrc, typeIdSrc, name);
            });

            $('.giantAdditionalDataButton').off('click');
            $('.giantAdditionalDataButton').on('click', function (event) {
                event.preventDefault();
                $('#giantModalAlertDiv').hide();
                showAdditionalData($(this).data("html"))
            });


            $('.giantModalRemoveForm').off('submit');
            $('.giantModalRemoveForm').on('submit', async function (event) {

                event.preventDefault();

                var $form = $(this);
                var action = $form.find('input[name="pbxAction"]').val();

                var submitForm = function () {
                    $('#giantModalAlertDiv').hide();
                    $('.giantModalPanel').hide();
                    $('#giantModalSpinnerDiv').show();

                    $.ajax({
                        type: 'post',
                        data: $form.serialize(),
                        success: function (responseJson) {
                            var response;
                            try { response = jQuery.parseJSON(responseJson); } catch (e) { response = {}; }
                            if (response && response.error) {
                                $('#giantModalAlertDiv').show();
                                $('#giantModalAlert').html(response.error);
                            }
                            if (response && response.rps && typeof showRpsToast === 'function') {
                                showRpsToast(response.rps);
                            }
                            refreshList(tileName);
                        }
                    });
                };

                // Phone removal gets a proper dialog with an "Also unregister from RPS" toggle.
                if (action === 'removePhone' && typeof showPhoneRemoveDialog === 'function') {
                    showPhoneRemoveDialog($form, submitForm);
                    return;
                }

                if (!(await giantConfirm('Are you sure?'))) return;
                submitForm();
            });
			
			
			
			

            if (response.asDataTable) {
                // Call log: disable DataTables' autoWidth so it never re-measures
                // columns to content on filter/search/redraw (that's what shrank
                // the table to "skinny"). With autoWidth off, the width:100% CSS
                // keeps it full-width on every draw.
                var giantDt = $('#giantModalList').DataTable(tileName === 'callLog' ? { autoWidth: false } : undefined);
                // Call log col 0 is the group-expander; sort by Started (col 1)
                // instead of that empty column.
                if (tileName === 'callLog') { try { giantDt.order([1, 'asc']); } catch (e) {} }
                giantDt.draw();
                // Call-log toolbar (filters + column picker + default hidden cols).
                if (tileName === 'callLog') { try { setupCallLogTools(giantDt); } catch (e) {} }
            }
			
			

            $('.giantModalPanel').hide();
            $('#giantModalListDiv').show();
        }
    });
}

// True for UK mobile DIDs (07…/+447…) — used to show SMS settings only on
// numbers that can actually receive texts. Works off the DID's country/area/
// number parts already present in the row data.
function isMobileDid(dv) {
    if (!dv) return false;
    var country  = String(dv.di_country == null ? '' : dv.di_country);
    var area     = String(dv.di_area == null ? '' : dv.di_area);
    var number   = String(dv.di_number == null ? '' : dv.di_number);
    var national = '0' + area + number;        // e.g. 07914118475
    var intl     = country + area + number;    // e.g. 447914118475
    return /^07/.test(national) || /^447/.test(intl);
}

// UK landline (01 / 02), 03 number or UK mobile (071–075, 077–079): the only
// numbers a forwarding destination may point at. Same rule as Helpers/UkNumber
// on the server. Input is normalised first — "(0)", spaces, dashes and brackets
// dropped, +44 / 0044 / 44 turned into the leading 0 — so "+44 (0)20 …" is fine.
var GIANT_UK_FORWARD_RE = /^(?:(?:01\d{8,9})|(?:02\d{9})|(?:03\d{9})|(?:07[1-5]\d{8})|(?:077\d{8})|(?:078\d{8})|(?:079\d{8}))$/;
function giantNormaliseUkNumber(raw) {
    var s = String(raw == null ? '' : raw).replace(/\(0\)/g, '').replace(/[\s().-]/g, '');
    if (/^\+44/.test(s)) s = '0' + s.slice(3);
    else if (/^0044/.test(s)) s = '0' + s.slice(4);
    else if (/^44\d{9,10}$/.test(s)) s = '0' + s.slice(2);
    return s;
}
function giantIsUkForwardNumber(raw) { return GIANT_UK_FORWARD_RE.test(giantNormaliseUkNumber(raw)); }
var GIANT_UK_FORWARD_ERROR = "Enter a UK landline (01/02), 03 or UK mobile (07) number, e.g. 020 7946 0000, 0333 000 0000 or 07700 900123. Premium-rate, 08 and international numbers can't be used as a forwarding destination.";

// Live check on the forwarding-number field: the verdict appears under the
// input as soon as they pause typing or leave it — the same rule the submit
// guard applies. Returns true when the field holds an allowed number.
// (The AI receptionist form reuses the cu_param1 name for its provider, hence
// the action check.)
function giantForwardFieldCheck($in, normalise) {
    var action = String($in.closest('form').find('input[name="pbxAction"]').val() || '');
    if (action !== 'addCustomDestination' && action !== 'editCustomDestination') return true;
    var raw = String($in.val() || '');
    $in.next('.giant-fwd-error, .giant-fwd-ok').remove();
    if (raw.trim() === '') { $in.removeClass('is-invalid'); return false; }
    var norm = giantNormaliseUkNumber(raw);
    if (!GIANT_UK_FORWARD_RE.test(norm)) {
        $in.addClass('is-invalid').after('<div class="giant-fwd-error" style="color:#b4232a;font-size:12px;font-weight:600;margin-top:4px;">' + GIANT_UK_FORWARD_ERROR + '</div>');
        return false;
    }
    $in.removeClass('is-invalid');
    if (normalise && norm !== raw) $in.val(norm);
    var kind = norm.slice(0, 2) === '07' ? 'UK mobile' : (norm.slice(0, 2) === '03' ? 'UK 03 number' : 'UK landline');
    $in.after('<div class="giant-fwd-ok" style="color:#0a7d63;font-size:12px;font-weight:600;margin-top:4px;"><i class="fa-solid fa-circle-check"></i> ' + kind + ' · ' + norm + '</div>');
    return true;
}
var giantFwdTimer = null;
$(document).off('input.giantFwd blur.giantFwd', 'input[name="cu_param1"]')
    .on('input.giantFwd', 'input[name="cu_param1"]', function () {
        var $in = $(this);
        $in.removeClass('is-invalid').next('.giant-fwd-error, .giant-fwd-ok').remove();
        clearTimeout(giantFwdTimer);
        giantFwdTimer = setTimeout(function () { giantForwardFieldCheck($in, false); }, 700);
    })
    .on('blur.giantFwd', 'input[name="cu_param1"]', function () {
        clearTimeout(giantFwdTimer);
        giantForwardFieldCheck($(this), true);
    });

// Return the ISO date (YYYY-MM-DD) that is `n` working days (Mon–Fri) from
// today, skipping weekends. Used for the mobile-port earliest date (today + 2
// working days). Bank holidays aren't accounted for — the external provider validates the
// exact date on submit; this just keeps the picker from offering same-day.
function workingDaysFromTodayISO(n) {
    var d = new Date();
    var added = 0;
    while (added < n) {
        d.setDate(d.getDate() + 1);
        var day = d.getDay();
        if (day !== 0 && day !== 6) { added++; }
    }
    var mm = ('0' + (d.getMonth() + 1)).slice(-2);
    var dd = ('0' + d.getDate()).slice(-2);
    return d.getFullYear() + '-' + mm + '-' + dd;
}

function showForm(tileName, type, formData, defaultValues) {

    var form = $("#giantModalAddForm");
    window._giantFormValues = defaultValues || {};   // the row being edited, for render hooks

    // Reset tile-specific styling — `#giantModalAddForm` is reused across
    // every tile, and any class a previous tile bolted on (e.g. aiAgent.js
    // adds `aiAgent-form` for its 2-column grid layout) would otherwise
    // leak into the next form. The base markup only carries `modalForm`
    // and `giant-form`, so put it back to that.
    form.attr('class', 'modalForm giant-form');

    // Destroy Select2 instances before clearing
    form.find('select.form-control').each(function() {
        if ($(this).data('select2')) {
            $(this).select2('destroy');
        }
    });

    form.children().remove();

    cache = {};
    requestSend = {};

    if (!formData) {
        return;
    }

    $('.giantModalPanel').hide();
    $('#giantModalSpinnerDiv').show();

    if (formData == "dynamic") {
        $.ajax({
            type: 'post',
            data: {
                pbxAction: "getForm",
                formName: tileName,
                formType: type,
                defaultValues: defaultValues,
            },
            success: function (responseJson) {
                var response = jQuery.parseJSON(responseJson);

                if (response.error) {
                    $('#giantModalAlertDiv').show();
                    $('#giantModalAlert').html(response.error);
                    refreshList("voiceCloud");
                }
                else
                {
                    $("#giantModalAddForm").replaceWith(response.formHtml);
                    $('.giantModalPanel').hide();
                    $('#giantModal .modal-dialog').removeClass('giant-modal-wide giant-modal-cdr giant-modal-flow');
                    $('#giantModalAddFormDiv').show();
                    giantFormAfterRender($('#giantModalAddForm'));   // keypad, media preview, member ordering, create-new pickers
                }
            }
        });
        return;
    }

    var toTrigger = [];
    var toggleRow = null;
    var closeToggleRow = function () { toggleRow = null; };

    formData.forEach(function (fieldData) {

        // Conditional fields: skip anything whose showIf() returns false for
        // this record (e.g. SMS settings only apply to mobile numbers).
        if (typeof fieldData.showIf === "function" && !fieldData.showIf(defaultValues)) {
            return;
        }

        // Lightweight visual divider to group long forms into sections.
        if (fieldData.type == "section") {
            closeToggleRow();
            form.append('<div class="giant-form-section">' + (fieldData.display || '') + '</div>');
            return;
        }

        var defaultValue = defaultValues[fieldData.name];

        if (!defaultValue) {
            defaultValue = fieldData.default || '';
        }

        if (fieldData.type != "toggle") {
            closeToggleRow();
        }

        if (fieldData.display) {

            var label = '<label class="col-form-label">' + fieldData.display + ':</label>';
            var description = "";

            if (fieldData.description) {
                description = '<small class="form-text text-muted">' + fieldData.description + '</small>';
            }
            if (fieldData.type == "signature") {

                var elementHtml = '<div id="signature" style="width: 600px; height:200px; border-style: solid; border-width: 1px"></div> <br><br>';
                elementHtml += '<button id="clear">Clear Signature</button>';
                elementHtml += '<textarea id="sigpad" name="signature" style="display: none"></textarea>';

                form.append('<div class="form-group">' + label + elementHtml + description + '</div>');
                var signature = $('#signature').signature({syncField: '#sigpad', syncFormat: 'PNG'});
                $('#clear').click(function (e) {
                    e.preventDefault();
                    signature.signature('clear');
                    $("#sigpad").val('');
                });

            } else if (fieldData.type == "info") {

                var elementHtml = '<div id = "' + fieldData.name + 'Info" class="alert alert-primary" role="alert" name="' + fieldData.name + '">test</div>';

                form.append(elementHtml);

                if (fieldData.value == "dynamic") {
                    addDynamicText($('#' + fieldData.name + 'Info'));
                } else {
                    addText($('#' + fieldData.name + 'Info'), fieldData.value);
                }

            } else if (fieldData.type == "checkbox") {

                var fieldGroup = '<div class="form-group"><label class="col-form-label">' + fieldData.display + ':</label><div class="giant-toggle-box"><div id="' + fieldData.name + 'Group" class="row"></div></div></div>';
                form.append(fieldGroup);
                if (fieldData.options) {
                    if (fieldData.options == "dynamic") {

                        waitingFor[fieldData.name] = true;

                        $.ajax({
                            type: 'post',
                            data: {
                                pbxAction: "getOptions",
                                fieldName: fieldData.name,
                            },
                            success: function (responseJson) {
                                var response = jQuery.parseJSON(responseJson)

                                var renderOption = function (optionValue, optionDisplay) {
                                    var checked = "";
                                    if (jQuery.inArray(optionValue, defaultValue) !== -1) {
                                        checked = "checked";
                                    }
                                    var inputId = fieldData.name + '_' + optionValue.replace(/[^A-Za-z0-9_-]/g, '_') + 'Toggle';
                                    // Prepend the per-type destination icon when the value is a
                                    // "TYPE-id" tag (matches the select dropdowns). Plain-valued
                                    // checkbox fields have no dash, so they stay icon-free.
                                    var iconHtml = '';
                                    var dashPos = String(optionValue).indexOf('-');
                                    if (dashPos !== -1 && typeof flowTypeIcons !== 'undefined') {
                                        var optType = String(optionValue).slice(0, dashPos).toUpperCase();
                                        var optIcon = flowTypeIcons[optType] || 'fa-arrow-right-to-bracket';
                                        iconHtml = '<i class="fa-solid ' + optIcon + ' giant-dest-opt-ico" style="margin-right:6px;"></i>';
                                    }
                                    var fieldHtml = '';
                                    fieldHtml += '<div class="col-md-6"><div class="form-check">';
                                    fieldHtml += '  <input type="checkbox" id="' + inputId + '" name="' + fieldData.name + '[]" value="' + optionValue + '" ' + checked + '>';
                                    fieldHtml += '  <label class="form-check-label" for="' + inputId + '">' + iconHtml + optionDisplay + '</label>';
                                    fieldHtml += '</div></div>';
                                    $('#' + fieldData.name + 'Group').append(fieldHtml);
                                };

                                var isGrouped = false;
                                var entries = Object.entries(response.options);
                                if (entries.length > 0 && typeof entries[0][1] === "object" && entries[0][1] !== null) {
                                    isGrouped = true;
                                }

                                if (isGrouped) {
                                    entries.forEach(function (group) {
                                        var groupLabel = group[0];
                                        var groupOptions = group[1];
                                        $('#' + fieldData.name + 'Group').append('<div class="col-12 mt-2 mb-1"><strong>' + groupLabel + '</strong></div>');
                                        if (Object.keys(groupOptions).length === 0) {
                                            $('#' + fieldData.name + 'Group').append('<div class="col-12 text-muted"><em>None available</em></div>');
                                        } else {
                                            Object.entries(groupOptions).forEach(function (data) {
                                                renderOption(data[0], data[1]);
                                            });
                                        }
                                    });
                                } else {
                                    entries.forEach(function (data) {
                                        renderOption(data[0], data[1]);
                                    });
                                }
                                waitingFor[fieldData.name] = false;
                            }
                        });
                    }
                }

            } else if (fieldData.type == "toggle") {

                if (!toggleRow) {
                    var rowId = 'toggleRow_' + Math.random().toString(36).substr(2, 8);
                    form.append('<div class="giant-toggle-box"><div id="' + rowId + '" class="row toggle-row"></div></div>');
                    toggleRow = $('#' + rowId);
                }

                var isOn = (defaultValue === "on" || defaultValue === true || defaultValue === 1 || defaultValue === "1");
                var checked = isOn ? "checked" : "";
                var inputId = fieldData.name + 'Input';
                var descHtml = fieldData.description ? '<small class="form-text text-muted giant-toggle-desc">' + fieldData.description + '</small>' : '';

                var toggleHtml = '';
                toggleHtml += '<div class="col-md-6">';
                toggleHtml += '  <div class="form-check">';
                toggleHtml += '    <input type="hidden" name="' + fieldData.name + '" value="">';
                toggleHtml += '    <input type="checkbox" id="' + inputId + '" name="' + fieldData.name + '" value="on" ' + checked + '>';
                toggleHtml += '    <label class="form-check-label" for="' + inputId + '">' + fieldData.display + '</label>';
                toggleHtml += '  </div>';
                toggleHtml += descHtml;
                toggleHtml += '</div>';

                toggleRow.append(toggleHtml);
                return;

            } else if (fieldData.type == "destinationChain") {

                var chainRowsId = fieldData.name + 'ChainRows';
                var chainAddId  = fieldData.name + 'ChainAdd';
                var fieldName   = fieldData.name;

                var chainHtml = '';
                chainHtml += '<div class="form-group">';
                chainHtml += label;
                chainHtml += '<div class="giant-toggle-box">';
                chainHtml += '  <div id="' + chainRowsId + '" class="destination-chain-rows"></div>';
                chainHtml += '  <button type="button" id="' + chainAddId + '" class="btn btn-sm btn-primary mt-2">+ Add Step</button>';
                chainHtml += '</div>';
                chainHtml += description;
                chainHtml += '</div>';
                form.append(chainHtml);

                var renderChainRow = function (value) {
                    var rowHtml = '';
                    rowHtml += '<div class="row destination-chain-row align-items-center mb-2">';
                    rowHtml += '  <div class="col-md-10"><select class="form-control chain-select" name="' + fieldName + '[]"></select></div>';
                    rowHtml += '  <div class="col-md-2 text-right"><button type="button" class="btn btn-sm btn-outline-danger chain-remove" title="Remove"><i class="fa-solid fa-trash"></i></button></div>';
                    rowHtml += '</div>';
                    $('#' + chainRowsId).append(rowHtml);
                    var $sel = $('#' + chainRowsId + ' .destination-chain-row:last-child select');
                    addDynamicOptions($sel, value || '');
                };

                $('#' + chainAddId).off('click').on('click', function (e) {
                    e.preventDefault();
                    renderChainRow('');
                });

                $(document).off('click', '#' + chainRowsId + ' .chain-remove');
                $(document).on('click', '#' + chainRowsId + ' .chain-remove', function (e) {
                    e.preventDefault();
                    $(this).closest('.destination-chain-row').remove();
                });

                // Fetch existing chain via the shared condition AJAX endpoint
                if (defaultValues && defaultValues.co_id) {
                    waitingFor[fieldName] = true;
                    $.ajax({
                        type: 'post',
                        data: { pbxAction: 'getConditionExtendedInfos', co_id: defaultValues.co_id },
                        success: function (responseJson) {
                            try {
                                var response = jQuery.parseJSON(responseJson);
                                var chain = (fieldData.branch === 'false') ? (response.destFalseList || []) : (response.destTrueList || []);
                                if (chain.length === 0) {
                                    renderChainRow('');
                                } else {
                                    chain.forEach(function (val) { renderChainRow(val); });
                                }
                            } catch (e) {
                                renderChainRow('');
                            }
                            waitingFor[fieldName] = false;
                        },
                        error: function () {
                            renderChainRow('');
                            waitingFor[fieldName] = false;
                        }
                    });
                } else {
                    renderChainRow('');
                }

                return;

            } else if (fieldData.type == "timeRanges") {

                var containerId = fieldData.name + 'Container';
                var rowsId = fieldData.name + 'Rows';
                var addBtnId = fieldData.name + 'AddBtn';
                var quickBtnsId = fieldData.name + 'QuickBtns';
                var calendarId = fieldData.name + 'Calendar';
                var hiddenInputsId = fieldData.name + 'HiddenInputs';

                var coName = (defaultValues && defaultValues.co_name) || '';
                var coType = ((defaultValues && defaultValues.co_type) || '').toString().toUpperCase();
                var coRegion = ((defaultValues && defaultValues.co_region) || '').toString().toUpperCase();
                var isCalendar  = (coType === 'CALENDAR');
                var isUseGlobal = (coType === 'USEGLOBAL');
                var isDates     = (coType === 'DATE');
                var isCallerId  = (coType === 'CALLERID');

                var regionFullName = {EW:'England & Wales', SC:'Scotland', NI:'Northern Ireland', ALL:'All combined'};

                var headerHtml = '';
                if (coName || coType) {
                    var typeBadge = coType;
                    if (coType === 'USEGLOBAL') {
                        typeBadge = regionFullName[coRegion]
                            ? 'UK Bank Holidays: ' + regionFullName[coRegion]
                            : 'UK Bank Holidays';
                    }
                    else if (coType === 'WEEKTIME') typeBadge = 'Week-time';
                    else if (coType === 'CALENDAR') typeBadge = 'Calendar';
                    else if (coType === 'DATE')     typeBadge = 'Specific dates';
                    else if (coType === 'CALLERID') typeBadge = 'Caller ID';
                    headerHtml += '<div class="giant-condition-header">';
                    if (coName) headerHtml += '<strong>' + coName + '</strong>';
                    if (coType) headerHtml += '<span class="badge badge-secondary ml-2">' + typeBadge + '</span>';
                    headerHtml += '</div>';
                }

                var typeDescription = isUseGlobal
                    ? 'Auto-managed — the dates on this condition are kept up to date for you. Only the destination chains below are configurable here.'
                    : (isCalendar
                        ? 'Calendar condition — click dates on the calendar below to mark them as active. Each active day counts as a full 24-hour match.'
                        : (isDates
                            ? 'Specific dates — the condition matches all day on each date listed. Tick "Every year" for a date that repeats, such as a fixed holiday.'
                            : (isCallerId
                                ? 'Caller ID — matches when the caller\'s number is one of these. Enter numbers as they arrive (07700900123 and 447700900123 are different); a pattern like ^0161 also works.'
                                : 'Week-time condition — each row defines a day of the week and the active hours.')));

                var containerHtml = '';
                containerHtml += '<div class="form-group">';
                containerHtml += headerHtml;
                if (!isUseGlobal) {
                    containerHtml += (isDates || isCallerId) ? String(label).replace(/Time Ranges/i, isDates ? 'Dates' : 'Caller numbers') : label;
                }
                containerHtml += '<small class="form-text text-muted mb-2">' + typeDescription + '</small>';
                var knownRegion = (coRegion === 'EW' || coRegion === 'SC' || coRegion === 'NI' || coRegion === 'ALL');
                var sharedName  = (defaultValues && defaultValues.co_master_name) ? $('<div>').text(String(defaultValues.co_master_name)).html() : '';
                if (isUseGlobal) {
                    containerHtml += '<div class="giant-condition-readonly" style="background:#f0fdf4; border:1px solid #86efac; padding:12px 14px; border-radius:6px; color:#166534; font-size:13px;">' +
                                       '<i class="fa fa-circle-info" style="margin-right:6px;"></i>' +
                                       (knownRegion
                                           ? 'This condition uses our shared <strong>UK Bank Holidays</strong> list. The dates can\'t be edited here — they\'re refreshed automatically. Configure where calls should go on bank holidays using the chains below.'
                                           : 'This condition follows the shared <strong>' + (sharedName || 'list') + '</strong>. The dates can\'t be edited here — they\'re managed for you. Configure where calls should go on those dates using the chains below.') +
                                     '</div>';
                    // The dates that count: the live gov.uk list for one of our
                    // UK regions, else the master list's own entries.
                    containerHtml += '<div id="' + containerId + 'BHList" class="giant-bh-list" style="margin-top:12px;">' +
                                       '<div class="text-muted" style="font-size:13px;"><i class="fa fa-spinner fa-spin"></i> Loading the dates…</div>' +
                                     '</div>';
                } else {
                    containerHtml += '<div id="' + containerId + '" class="giant-toggle-box">';
                    if (isDates || isCallerId) {
                        containerHtml += '  <div id="' + rowsId + '"></div>';
                        containerHtml += '  <div class="mt-2"><button type="button" id="' + addBtnId + '" class="btn btn-sm btn-primary">+ ' + (isDates ? 'Add a date' : 'Add a number') + '</button></div>';
                    } else if (isCalendar) {
                        containerHtml += '  <div id="' + calendarId + '" class="giant-cal-inline"></div>';
                        containerHtml += '  <div class="giant-cal-summary text-muted small mt-2"></div>';
                        containerHtml += '  <div id="' + hiddenInputsId + '" style="display:none;"></div>';
                    } else {
                        containerHtml += '  <div id="' + rowsId + '"></div>';
                        containerHtml += '  <div class="d-flex align-items-center flex-wrap mt-2" style="gap:6px;">';
                        containerHtml += '    <button type="button" id="' + addBtnId + '" class="btn btn-sm btn-primary">+ Add Time Range</button>';
                        containerHtml += '    <div id="' + quickBtnsId + '" class="ml-auto">';
                        containerHtml += '      <button type="button" class="btn btn-sm btn-outline-secondary giant-quick-tpl" data-tpl="weekdays">Weekdays 9–5</button>';
                        containerHtml += '      <button type="button" class="btn btn-sm btn-outline-secondary giant-quick-tpl" data-tpl="alldays">All week 9–5</button>';
                        containerHtml += '      <button type="button" class="btn btn-sm btn-outline-danger giant-quick-tpl" data-tpl="clear">Clear</button>';
                        containerHtml += '    </div>';
                        containerHtml += '  </div>';
                    }
                    containerHtml += '</div>';
                }
                if (!isUseGlobal && !isDates && !isCallerId) containerHtml += description;
                containerHtml += '</div>';
                form.append(containerHtml);

                if (isUseGlobal) {
                    // Auto-managed — no time-range editing on this side. One of
                    // our UK regions shows the live gov.uk list (we pass both
                    // the region and co_param1, the master id, so the server
                    // can resolve either); any other shared master shows its
                    // own dates, read-only, from the extended-infos loader.
                    var $bhTarget = $('#' + containerId + 'BHList');
                    var coParam1  = (defaultValues && defaultValues.co_param1) ? String(defaultValues.co_param1) : '';
                    if (!knownRegion) {
                        $.ajax({
                            type: 'post',
                            data: { pbxAction: 'getConditionExtendedInfos', co_id: (defaultValues && defaultValues.co_id) || '' },
                            success: function (responseJson) {
                                var resp;
                                try { resp = (typeof responseJson === 'object') ? responseJson : jQuery.parseJSON(responseJson); }
                                catch (e) { resp = {}; }
                                renderSharedConditionDates($bhTarget, resp);
                            },
                            error: function () {
                                $bhTarget.html('<div class="text-muted" style="font-size:13px;">Couldn\'t load the dates. The condition still works.</div>');
                            }
                        });
                        return;
                    }
                    $.ajax({
                        type: 'post',
                        data: { pbxAction: 'getUkBankHolidays', region: coRegion, co_param1: coParam1 },
                        success: function (responseJson) {
                            var resp;
                            try { resp = (typeof responseJson === 'object') ? responseJson : jQuery.parseJSON(responseJson); }
                            catch (e) { resp = {}; }
                            renderUkBankHolidays($bhTarget, resp);
                        },
                        error: function () {
                            $bhTarget.html('<div class="text-muted" style="font-size:13px;">Couldn\'t load the upcoming list. The condition still works.</div>');
                        }
                    });
                    return;
                }

                if (isCalendar) {
                    // the phone system calendar format: param1="YYYY/MM/DD 00:00", param2="(next day) 00:00", param3/param4 empty.
                    var pad2 = function (n) { return (n < 10 ? '0' : '') + n; };
                    var toMirta = function (d) { return d.getFullYear() + '/' + pad2(d.getMonth() + 1) + '/' + pad2(d.getDate()) + ' 00:00'; };
                    var nextDayMirta = function (d) {
                        var n = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1);
                        return toMirta(n);
                    };
                    var parseMirtaDate = function (s) {
                        if (!s) return null;
                        var m = String(s).match(/(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/);
                        if (!m) return null;
                        return new Date(parseInt(m[1], 10), parseInt(m[2], 10) - 1, parseInt(m[3], 10));
                    };

                    var rebuildCalendarInputs = function (dates) {
                        var $h = $('#' + hiddenInputsId);
                        $h.empty();
                        (dates || []).forEach(function (d, i) {
                            $h.append('<input type="hidden" name="' + fieldData.name + '[' + i + '][param1]" value="' + toMirta(d) + '">');
                            $h.append('<input type="hidden" name="' + fieldData.name + '[' + i + '][param2]" value="' + nextDayMirta(d) + '">');
                            $h.append('<input type="hidden" name="' + fieldData.name + '[' + i + '][param3]" value="">');
                        });
                        var $sum = $('#' + containerId + ' .giant-cal-summary');
                        if (!dates || !dates.length) $sum.html('<i class="fa-regular fa-calendar-xmark"></i> No active dates selected.');
                        else $sum.html('<i class="fa-regular fa-calendar-check"></i> ' + dates.length + ' active date' + (dates.length === 1 ? '' : 's') + ' selected.');
                    };

                    var initFlatpickr = function (rows) {
                        var defaults = [];
                        (rows || []).forEach(function (r) {
                            var d = parseMirtaDate(r && r.param1);
                            if (d) defaults.push(d);
                        });
                        if (typeof flatpickr !== 'function') {
                            console && console.warn && console.warn('flatpickr not loaded');
                            return;
                        }
                        var modalWidth = $('#' + calendarId).width() || 600;
                        var months = modalWidth >= 700 ? 2 : 1;
                        var fp = flatpickr('#' + calendarId, {
                            inline: true,
                            mode: 'multiple',
                            dateFormat: 'Y-m-d',
                            defaultDate: defaults,
                            showMonths: months,
                            locale: { firstDayOfWeek: 1 },
                            onChange: function (selectedDates) { rebuildCalendarInputs(selectedDates); }
                        });
                        rebuildCalendarInputs(fp.selectedDates);
                    };

                    var safeInit = function (rows) {
                        try { initFlatpickr(rows || []); } catch (err) { try { console && console.warn && console.warn('Calendar render failed:', err); } catch(ignored) {} }
                    };

                    if (defaultValues && defaultValues.co_id) {
                        waitingFor[fieldData.name] = true;
                        $.ajax({
                            type: 'post',
                            data: { pbxAction: 'getConditionExtendedInfos', co_id: defaultValues.co_id },
                            success: function (responseJson) {
                                var rows = [];
                                try { rows = (jQuery.parseJSON(responseJson) || {}).ranges || []; } catch (e) {}
                                safeInit(rows);
                            },
                            error: function () { safeInit([]); },
                            complete: function () { waitingFor[fieldData.name] = false; }
                        });
                    } else {
                        safeInit([]);
                    }

                    return;
                }

                if (isDates || isCallerId) {
                    // Rows of values kept on the record: up to 11 dates (each
                    // with an "every year" tick) or 22 caller numbers.
                    var escV     = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
                    var maxRows  = isDates ? 11 : 22;
                    var rowClass = isDates ? 'giant-date-row' : 'giant-cid-row';
                    var reindexRows = function () {
                        $('#' + rowsId + ' .' + rowClass).each(function (i) {
                            $(this).find('[name]').each(function () { $(this).attr('name', $(this).attr('name').replace(/\[\d+\]|\[__i__\]/, '[' + i + ']')); });
                        });
                        $('#' + addBtnId).prop('disabled', $('#' + rowsId + ' .' + rowClass).length >= maxRows);
                    };
                    var renderValueRow = function (row) {
                        row = row || {};
                        var h = '<div class="row ' + rowClass + ' align-items-center mb-2">';
                        if (isDates) {
                            h += '<div class="col-md-5"><input type="date" class="form-control" name="co_dates[__i__][date]" value="' + escV(row.date || '') + '"></div>';
                            h += '<div class="col-md-5"><label style="margin:0; font-weight:400; display:inline-flex; align-items:center; gap:6px;"><input type="checkbox" name="co_dates[__i__][recurring]" value="on"' + (row.recurring ? ' checked' : '') + '> Every year</label></div>';
                        } else {
                            h += '<div class="col-md-10"><input type="text" class="form-control" name="co_callerids[__i__]" value="' + escV(row.value || '') + '" placeholder="e.g. 07700900123"></div>';
                        }
                        h += '<div class="col-md-2 text-right"><button type="button" class="btn btn-sm btn-outline-danger giant-row-remove" title="Remove"><i class="fa-solid fa-trash"></i></button></div>';
                        h += '</div>';
                        $('#' + rowsId).append(h);
                        reindexRows();
                    };
                    var populateRows = function (rows) {
                        $('#' + rowsId).empty();
                        if (rows && rows.length) rows.forEach(function (r) { renderValueRow(r); }); else renderValueRow();
                    };
                    $(document).off('click', '#' + addBtnId).on('click', '#' + addBtnId, function (e) {
                        e.preventDefault();
                        if ($('#' + rowsId + ' .' + rowClass).length < maxRows) renderValueRow();
                    });
                    $(document).off('click', '#' + rowsId + ' .giant-row-remove').on('click', '#' + rowsId + ' .giant-row-remove', function (e) {
                        e.preventDefault();
                        $(this).closest('.' + rowClass).remove();
                        reindexRows();
                        if (!$('#' + rowsId + ' .' + rowClass).length) renderValueRow();
                    });
                    if (defaultValues && defaultValues.co_id) {
                        waitingFor[fieldData.name] = true;
                        $.ajax({
                            type: 'post',
                            data: { pbxAction: 'getConditionExtendedInfos', co_id: defaultValues.co_id },
                            success: function (responseJson) {
                                var resp = {};
                                try { resp = jQuery.parseJSON(responseJson) || {}; } catch (e) {}
                                populateRows(isDates ? (resp.dates || []) : (resp.callerIds || []).map(function (v) { return { value: v }; }));
                            },
                            error: function () { populateRows([]); },
                            complete: function () { waitingFor[fieldData.name] = false; }
                        });
                    } else {
                        populateRows([]);
                    }
                    return;
                }

                var dayOptions = {"1":"Monday","2":"Tuesday","3":"Wednesday","4":"Thursday","5":"Friday","6":"Saturday","0":"Sunday"};

                var renderRangeRow = function (row) {
                    row = row || {param1:"", param2:"", param3:""};
                    var firstCol;
                    if (isCalendar) {
                        firstCol = '<input type="date" class="form-control" name="' + fieldData.name + '[__i__][param1]" value="' + (row.param1 || '') + '">';
                    } else {
                        var dayOpts = '';
                        for (var d in dayOptions) {
                            var sel = (String(row.param1) === d) ? ' selected' : '';
                            dayOpts += '<option value="' + d + '"' + sel + '>' + dayOptions[d] + '</option>';
                        }
                        firstCol = '<select class="form-control" name="' + fieldData.name + '[__i__][param1]">' + dayOpts + '</select>';
                    }

                    var rowHtml = '';
                    rowHtml += '<div class="row time-range-row align-items-center mb-2">';
                    rowHtml += '  <div class="col-md-4">' + firstCol + '</div>';
                    rowHtml += '  <div class="col-md-3"><input type="time" class="form-control" name="' + fieldData.name + '[__i__][param2]" value="' + (row.param2 || '') + '" placeholder="Start"></div>';
                    rowHtml += '  <div class="col-md-3"><input type="time" class="form-control" name="' + fieldData.name + '[__i__][param3]" value="' + (row.param3 || '') + '" placeholder="End"></div>';
                    rowHtml += '  <div class="col-md-2 text-right"><button type="button" class="btn btn-sm btn-outline-danger time-range-remove" title="Remove"><i class="fa-solid fa-trash"></i></button></div>';
                    rowHtml += '</div>';
                    $('#' + rowsId).append(rowHtml);
                    reindexTimeRanges();
                };

                var reindexTimeRanges = function () {
                    $('#' + rowsId + ' .time-range-row').each(function (i) {
                        $(this).find('[name]').each(function () {
                            var n = $(this).attr('name');
                            $(this).attr('name', n.replace(/\[\d+\]|\[__i__\]/, '[' + i + ']'));
                        });
                    });
                };

                var populateFromValue = function (rows) {
                    $('#' + rowsId).empty();
                    if (rows && rows.length) {
                        rows.forEach(function (row) { renderRangeRow(row); });
                    } else {
                        renderRangeRow();
                    }
                };

                var hasValidDefault = (defaultValue && typeof defaultValue === 'object' && defaultValue.length);
                if (hasValidDefault) {
                    populateFromValue(defaultValue);
                } else if (defaultValues && defaultValues.co_id) {
                    waitingFor[fieldData.name] = true;
                    renderRangeRow({param1:"", param2:"", param3:""}); // placeholder while loading
                    $.ajax({
                        type: 'post',
                        data: {
                            pbxAction: 'getConditionExtendedInfos',
                            co_id: defaultValues.co_id,
                        },
                        success: function (responseJson) {
                            try {
                                var response = jQuery.parseJSON(responseJson);
                                populateFromValue(response.ranges || []);
                            } catch (e) {
                                populateFromValue([]);
                            }
                            waitingFor[fieldData.name] = false;
                        },
                        error: function () {
                            populateFromValue([]);
                            waitingFor[fieldData.name] = false;
                        }
                    });
                } else {
                    renderRangeRow();
                }

                $('#' + addBtnId).off('click').on('click', function (e) {
                    e.preventDefault();
                    renderRangeRow();
                });

                $(document).off('click', '#' + rowsId + ' .time-range-remove');
                $(document).on('click', '#' + rowsId + ' .time-range-remove', function (e) {
                    e.preventDefault();
                    $(this).closest('.time-range-row').remove();
                    reindexTimeRanges();
                });

                if (!isCalendar) {
                    $('#' + quickBtnsId + ' .giant-quick-tpl').off('click').on('click', function (e) {
                        e.preventDefault();
                        var tpl = $(this).data('tpl');
                        $('#' + rowsId).empty();
                        if (tpl === 'weekdays') {
                            ["1","2","3","4","5"].forEach(function (d) { renderRangeRow({param1:d, param2:"09:00", param3:"17:00"}); });
                        } else if (tpl === 'alldays') {
                            ["1","2","3","4","5","6","0"].forEach(function (d) { renderRangeRow({param1:d, param2:"09:00", param3:"17:00"}); });
                        } else if (tpl === 'clear') {
                            renderRangeRow();
                        }
                    });
                }

                return;

            } else if (fieldData.type == "multipleSelect") {

                // Stackable selects (e.g. Telephone Number → multiple
                // destinations). Each row is a flex container so the remove
                // icon sits inline with its select. The first row's remove
                // button is hidden when only one row remains, so the
                // customer can't end up with zero entries — but its slot
                // is reserved (visibility: hidden) so all selects line up.
                var fieldName = fieldData.name;
                var multiId   = fieldName + 'Multi';

                var rowHtml = function (selectAttrs, selectClass) {
                    return '<div class="giant-multi-row">' +
                             '<select class="form-control ' + (selectClass || '') + '" name="' + fieldName + '[]"' + (selectAttrs || '') + '></select>' +
                             '<button type="button" class="' + fieldName + 'RemoveButton giant-multi-remove giant-icon-btn giant-icon-delete" aria-label="Remove">' +
                               '<i class="fa-solid fa-trash"></i>' +
                             '</button>' +
                           '</div>';
                };

                form.append(
                    '<div class="form-group">' + label +
                        '<div id="' + multiId + '" class="giant-multi-container">' +
                            rowHtml(' id="' + fieldName + 'Input"', '') +
                        '</div>' +
                        '<button type="button" id="' + fieldName + 'AddButton" class="giant-multi-add">' +
                            '<i class="fa-solid fa-plus"></i> Add another' +
                        '</button>' +
                        description +
                    '</div>'
                );

                var $multiContainer = $('#' + multiId);

                var refreshRemoveVisibility = function () {
                    var $rows = $multiContainer.find('.giant-multi-row');
                    $rows.find('.giant-multi-remove').css('visibility',
                        $rows.length > 1 ? 'visible' : 'hidden'
                    );
                };

                // Stop the same option being chosen in more than one row (e.g.
                // the same agent twice in a queue). Options already picked in
                // ANOTHER row are disabled so select2 greys them out. The row the
                // user is actively changing is skipped — disabling options on the
                // active row makes select2 snap its display back to the old value.
                var refreshMultiDedup = function (skipEl) {
                    var chosen = {};
                    $multiContainer.find('select').each(function () {
                        if (this.value) { chosen[this.value] = true; }
                    });
                    $multiContainer.find('select').each(function () {
                        if (this === skipEl) { return; }
                        var own = this.value;
                        var changed = false;
                        $(this).find('option').each(function () {
                            var want = (this.value === '' || this.value === own) ? false : !!chosen[this.value];
                            if (this.disabled !== want) { this.disabled = want; changed = true; }
                        });
                        // Let select2 re-read the option states (without firing our
                        // own change handler again — different namespace).
                        if (changed && $(this).data('select2')) { $(this).trigger('change.select2'); }
                    });
                };

                // Re-evaluate whenever any row's selection changes, skipping the
                // row being changed so its own display isn't disturbed.
                $multiContainer.off('change.giantdedup', 'select');
                $multiContainer.on('change.giantdedup', 'select', function () {
                    refreshMultiDedup(this);
                });

                // Populate the first select.
                var defaultValueItem = (defaultValue && defaultValue.length > 0) ? defaultValue[0] : '';
                var $firstSelect = $multiContainer.find('select').first();
                if (fieldData.options == "dynamic") {
                    addDynamicOptions($firstSelect, defaultValueItem);
                } else {
                    addOptions($firstSelect, fieldData.options, defaultValueItem);
                }

                // Initialise additional rows for any extra defaultValues.
                if (defaultValue && defaultValue.length > 1) {
                    for (var di = 1; di < defaultValue.length; di++) {
                        $multiContainer.append(rowHtml('', 'secondarySelect ' + fieldName + 'Input'));
                        var $lastSel = $multiContainer.find('select').last();
                        if (fieldData.options == "dynamic") {
                            addDynamicOptions($lastSel, defaultValue[di]);
                        } else {
                            addOptions($lastSel, fieldData.options, defaultValue[di]);
                        }
                    }
                }

                refreshRemoveVisibility();
                refreshMultiDedup();

                // Delegate the remove handler so it works for rows added
                // later. The container is stable; rows come and go.
                $multiContainer.off('click', '.giant-multi-remove');
                $multiContainer.on('click', '.giant-multi-remove', function (e) {
                    e.preventDefault();
                    var $row = $(this).closest('.giant-multi-row');
                    var $sel = $row.find('select');
                    if ($sel.data('select2')) { $sel.select2('destroy'); }
                    $row.remove();
                    refreshRemoveVisibility();
                    refreshMultiDedup();
                });

                $('#' + fieldName + 'AddButton').off('click');
                $('#' + fieldName + 'AddButton').on('click', (function (fName, fOpts, $container) {
                    return function (e) {
                        e.preventDefault();
                        $container.append(rowHtml('', 'secondarySelect ' + fName + 'Input'));
                        var $newSelect = $container.find('select').last();

                        // Clone the option list from the first (already-
                        // populated) select so we don't re-fetch dynamic
                        // options. Clone children() (not just option) so any
                        // <optgroup>s come along, then clear the copied
                        // selection so the new row starts empty.
                        var $firstOpts = $container.find('select').first().children().clone();
                        $firstOpts.find('option').addBack('option').prop('selected', false).removeAttr('selected');
                        $newSelect.append($firstOpts);

                        // Match the rest of the form: apply select2 to the new
                        // row so it looks consistent with the first — including
                        // the per-type icon renderer if one is registered for
                        // this field (so added destination rows keep their icons).
                        var addCfg = {
                            dropdownParent: $('#giantModal'),
                            width: '100%',
                            placeholder: 'Search...',
                            allowClear: true,
                        };
                        var addTpl = window.giantSelect2Templates && window.giantSelect2Templates[$newSelect.attr('name')];
                        if (addTpl) {
                            if (addTpl.result)    addCfg.templateResult    = addTpl.result;
                            if (addTpl.selection) addCfg.templateSelection = addTpl.selection;
                        } else {
                            addCfg.templateResult    = window.giantIconOptionTemplate;
                            addCfg.templateSelection = window.giantIconOptionTemplate;
                        }
                        $newSelect.select2(addCfg);

                        // A fresh <select> with no explicit selection falls back
                        // to its FIRST option — i.e. the top agent — which would
                        // duplicate an existing row. Default the new row to the
                        // first option NOT already chosen elsewhere (or leave it
                        // empty if every option is taken).
                        var usedVals = {};
                        $container.find('select').each(function () {
                            if (this !== $newSelect[0] && this.value) { usedVals[this.value] = true; }
                        });
                        var firstFree = '';
                        $newSelect.find('option').each(function () {
                            if (this.value !== '' && !usedVals[this.value]) { firstFree = this.value; return false; }
                        });
                        if (firstFree === '' && !$newSelect.find('option[value=""]').length) {
                            // Everything is taken — offer an empty row rather than a duplicate.
                            $newSelect.prepend('<option value=""></option>');
                        }
                        $newSelect.val(firstFree).trigger('change.select2');

                        refreshRemoveVisibility();
                        refreshMultiDedup();
                    };
                })(fieldName, fieldData.options, $multiContainer));

            } else if (fieldData.type == "password") {

                var fieldHtml = '<div class="input-group mb-3">';
                fieldHtml += '<input type="text" class="form-control" id="' + fieldData.name + 'Input" name="' + fieldData.name + '" value="' + defaultValue + '">'
                fieldHtml += '<div class="input-group-append"><button id="' + fieldData.name + 'Button" class="btn btn-primary" type="button">Generate</button></div>';
                fieldHtml += '</div>';

                form.append('<div class="form-group">' + label + fieldHtml + description + '</div>');

                $('#' + fieldData.name + 'Button').off("click");
                $('#' + fieldData.name + 'Button').on("click", function (event) {
                    $('#' + fieldData.name + 'Input').val(generatePassword(16));
                });
            } else if (fieldData.options) { //select

                var fieldHtml = '<select class="form-control" id="' + fieldData.name + 'Input" name="' + fieldData.name + '"></select>';
                form.append('<div class="form-group">' + label + fieldHtml + description + '</div>');

                if (fieldData.options == "dynamic") {
                    addDynamicOptions($('#' + fieldData.name + 'Input'), defaultValue);
                } else {
                    addOptions($('#' + fieldData.name + 'Input'), fieldData.options, defaultValue);
                }
            } else if (fieldData.type == "file") {

                var dropId = fieldData.name + 'Drop';
                var dropHtml = '';
                dropHtml += '<div class="drop-zone" id="' + dropId + '">';
                dropHtml += '  <input type="file" class="drop-zone-input" id="' + fieldData.name + 'Input" name="' + fieldData.name + '" accept=".wav,.mp3,.ogg,.gsm,audio/*">';
                dropHtml += '  <div class="drop-zone-content">';
                dropHtml += '    <i class="fa-duotone fa-cloud-arrow-up fa-2x" style="--fa-primary-color: #00d9a7; --fa-secondary-color: #99e15f;"></i>';
                dropHtml += '    <p class="drop-zone-text">Drag & drop your audio file here</p>';
                dropHtml += '    <p class="drop-zone-hint">or click to browse</p>';
                dropHtml += '    <span class="drop-zone-formats">WAV, MP3, OGG, GSM</span>';
                dropHtml += '  </div>';
                dropHtml += '  <div class="drop-zone-file" style="display:none;">';
                dropHtml += '    <i class="fa-duotone fa-file-audio fa-lg" style="--fa-primary-color: #00d9a7; --fa-secondary-color: #99e15f;"></i>';
                dropHtml += '    <span class="drop-zone-filename"></span>';
                dropHtml += '    <button type="button" class="drop-zone-remove" title="Remove">&times;</button>';
                dropHtml += '  </div>';
                dropHtml += '</div>';
                form.append('<div class="form-group">' + label + dropHtml + description + '</div>');
                form.attr('enctype', 'multipart/form-data');

                (function(dId, fName) {
                    var $dz = $('#' + dId);
                    var $input = $('#' + fName + 'Input');

                    $dz.on('click', function(e) {
                        if (!$(e.target).hasClass('drop-zone-remove')) $input.trigger('click');
                    });

                    $dz.on('dragover', function(e) {
                        e.preventDefault();
                        $(this).addClass('drop-zone-over');
                    });

                    $dz.on('dragleave drop', function(e) {
                        e.preventDefault();
                        $(this).removeClass('drop-zone-over');
                    });

                    $dz.on('drop', function(e) {
                        var files = e.originalEvent.dataTransfer.files;
                        if (files.length) {
                            $input[0].files = files;
                            $input.trigger('change');
                        }
                    });

                    $input.on('change', function() {
                        if (this.files && this.files[0]) {
                            var picked = this.files[0];
                            $dz.find('.drop-zone-content').hide();
                            $dz.find('.drop-zone-filename').text(picked.name);
                            $dz.find('.drop-zone-file').show();
                            $dz.addClass('drop-zone-has-file');
                            $dz.removeData('giantConverted');
                            giantPrepareAudioUpload($dz, picked);   // → 8 kHz mono WAV, where the browser can
                        }
                    });

                    $dz.find('.drop-zone-remove').on('click', function(e) {
                        e.stopPropagation();
                        $input.val('');
                        $dz.removeData('giantConverted').removeClass('is-converting');
                        $dz.find('.drop-zone-note').remove();
                        $dz.find('.drop-zone-file').hide();
                        $dz.find('.drop-zone-content').show();
                        $dz.removeClass('drop-zone-has-file');
                    });
                })(dropId, fieldData.name);

            } else if (fieldData.type == "textarea") {
                // <textarea> doesn't accept a `value` attribute — content
                // goes between tags. Escape so multi-line defaults from
                // edit-row data attrs render correctly without HTML injection.
                var taRows    = fieldData.rows != null ? fieldData.rows : 4;
                var taValue   = $('<div>').text(defaultValue == null ? '' : String(defaultValue)).html();
                var fieldHtml = '<textarea rows="' + taRows + '" class="form-control" id="' + fieldData.name + 'Input" name="' + fieldData.name + '">' + taValue + '</textarea>';
                form.append('<div class="form-group">' + label + fieldHtml + description + '</div>');
            } else if (fieldData.type == "datetime") {
                // HTML5 datetime-local picker. the phone system returns dates as
                // "YYYY-MM-DD HH:MM:SS" but the input only accepts
                // "YYYY-MM-DDTHH:MM" — translate on render. The submit
                // handler reads the input back as YYYY-MM-DDTHH:MM and
                // server-side normalisation re-pads to seconds.
                var dtVal = String(defaultValue || '').trim();
                if (dtVal && dtVal !== '0000-00-00 00:00:00') {
                    dtVal = dtVal.replace(' ', 'T').substring(0, 16);
                } else {
                    dtVal = '';
                }
                var dtHtml = '<input type="datetime-local" class="form-control" id="' + fieldData.name + 'Input" name="' + fieldData.name + '" value="' + dtVal + '">';
                form.append('<div class="form-group">' + label + dtHtml + description + '</div>');
            } else if (fieldData.type == "date") {
                // HTML5 date picker. Supports a dynamic floor via
                // `minWorkingDaysFromToday` (used by mobile porting, whose
                // earliest date is today + 2 working days) or a static `min`.
                // `defaultToMin` pre-fills the value with that floor.
                var dMin = '';
                if (fieldData.minWorkingDaysFromToday != null) {
                    dMin = workingDaysFromTodayISO(fieldData.minWorkingDaysFromToday);
                } else if (fieldData.min) {
                    dMin = fieldData.min;
                }
                var dDateVal = (defaultValue === '' || defaultValue == null)
                    ? (fieldData.defaultToMin ? dMin : (fieldData.default || ''))
                    : String(defaultValue).substring(0, 10);
                var dMinAttr = dMin ? ' min="' + dMin + '"' : '';
                var dateHtml = '<input type="date" class="form-control" id="' + fieldData.name + 'Input" name="' + fieldData.name + '" value="' + dDateVal + '"' + dMinAttr + '>';
                form.append('<div class="form-group">' + label + dateHtml + description + '</div>');
                // Working days only (mobile porting): a weekend or bank-holiday
                // pick moves to the next working day, and says so.
                if (fieldData.workingDaysOnly) {
                    (function () {
                        var $di = $('#' + fieldData.name + 'Input');
                        var holidays = {};
                        var isoOf = function (d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); };
                        var isOff = function (iso) { var d = new Date(iso + 'T00:00:00'); var n = d.getDay(); return n === 0 || n === 6 || !!holidays[iso]; };
                        var nextOn = function (iso) { var d = new Date(iso + 'T00:00:00'); for (var i = 0; i < 30; i++) { d.setDate(d.getDate() + 1); var k = isoOf(d); if (!isOff(k)) return k; } return iso; };
                        var $note = $('<div class="text-muted small giant-date-note" style="margin-top:4px;"></div>').insertAfter($di);
                        var check = function () {
                            var v = $di.val();
                            if (!v || !isOff(v)) { $note.html(''); return; }
                            var why = holidays[v] ? holidays[v] : 'a weekend';
                            var moved = nextOn(v);
                            $di.val(moved);
                            $note.html('<i class="fa-solid fa-circle-info"></i> Ports don\'t complete on ' + why + ' \u2014 moved to ' + moved + '.');
                        };
                        $di.on('change', check);
                        $.ajax({ type: 'post', data: { pbxAction: 'getUkBankHolidays' }, dataType: 'json',
                            success: function (r) { ((r && r.dates) || []).forEach(function (x) { if (x && x.date) holidays[x.date] = x.title || 'a bank holiday'; }); check(); } });
                        check();
                    })();
                }
            } else if (fieldData.type == "number") {
                var numAttrs = '';
                if (fieldData.min != null) numAttrs += ' min="' + fieldData.min + '"';
                if (fieldData.max != null) numAttrs += ' max="' + fieldData.max + '"';
                var numHtml = '<input type="number" class="form-control" id="' + fieldData.name + 'Input" name="' + fieldData.name + '" value="' + defaultValue + '"' + numAttrs + '>';
                form.append('<div class="form-group">' + label + numHtml + description + '</div>');
            } else if (fieldData.type == "range") {
                var rMin   = fieldData.min  != null ? fieldData.min  : 0;
                var rMax   = fieldData.max  != null ? fieldData.max  : 100;
                var rStep  = fieldData.step != null ? fieldData.step : 1;
                var rValue = (defaultValue === '' || defaultValue == null) ? rMin : defaultValue;
                var rangeHtml = '<div class="giant-range-wrap">';
                rangeHtml +=     '<input type="range" class="giant-range" id="' + fieldData.name + 'Input" name="' + fieldData.name + '" min="' + rMin + '" max="' + rMax + '" step="' + rStep + '" value="' + rValue + '">';
                rangeHtml +=     '<output class="giant-range-value" for="' + fieldData.name + 'Input">' + rValue + '</output>';
                rangeHtml +=   '</div>';
                form.append('<div class="form-group">' + label + rangeHtml + description + '</div>');
                $('#' + fieldData.name + 'Input').on('input', function () {
                    $(this).siblings('.giant-range-value').text($(this).val());
                });
            } else {//text
                var textAttrs = (fieldData.maxlength != null) ? ' maxlength="' + fieldData.maxlength + '"' : '';
                var fieldHtml = '<input type="text" class="form-control" id="' + fieldData.name + 'Input" name="' + fieldData.name + '" value="' + defaultValue + '"' + textAttrs + '>'
                form.append('<div class="form-group">' + label + fieldHtml + description + '</div>');
            }
        } else {//hidden

            var fieldHtml = '<input type="hidden" class="form-control" id="' + fieldData.name + 'Input" name="' + fieldData.name + '" value="' + defaultValue + '">'
            form.append('<div class="form-group">' + fieldHtml + '</div>');
        }

        if (fieldData.mask) {
            $('[name="' + fieldData.name + '"]').inputmask(fieldData.mask);
        }
        if (fieldData.onChange) {
            $('[name="' + fieldData.name + '"]').off("change");
            $('[name="' + fieldData.name + '"]').on("change", fieldData.onChange);

            toTrigger.push(fieldData.name);
        }

    });

    var buttonDisplay = "Add";

    if (type == "edit") {
        buttonDisplay = "Save";
    }

    if (type == "add" && tileName == "smsLog") {
        buttonDisplay = "Send";
    }


    var action = type + capitalizeFirstLetter(tileName);
    form.append('<input type="hidden" name="pbxAction" value="' + action + '">');
    form.append('<input type="submit" class="btn btn-primary" value="' + buttonDisplay + '">');
    form.append(' <button id="giantCancelAddButton" class="btn btn-secondary">Cancel</button>');

    $('#giantCancelAddButton').off('click');
    $('#giantCancelAddButton').on('click', function (event) {
        event.preventDefault();

        // Editing a flow node in the embedded drawer: just close the drawer.
        if (window._flowEmbeddedEdit) { flowCloseDrawer(false); return; }

        // Return to flow builder if we came from there
        if (window._flowReturnAfterSave && window._flowTypeSrc && window._flowTypeIdSrc) {
            window._flowReturnAfterSave = false;
            openCallFlowBuilder(window._flowTypeSrc, window._flowTypeIdSrc, window._flowDisplayName || '');
            return;
        }

        // Re-apply wide class for data-heavy tiles
        var wideTiles = ['callLog', 'smsLog', 'extension', 'phone'];
        if (wideTiles.indexOf(tileName) > -1) {
            $('#giantModal .modal-dialog').addClass('giant-modal-wide');
        }
        $('#giantModalListDiv').show();
        $('#giantModalAddFormDiv').hide();
    });

    $('#giantModalAddForm').off('submit');
    $('#giantModalAddForm').on('submit', function (event) {

        event.preventDefault();

        // An audio file still being converted to WAV: hold the submit for it.
        if ($(this).find('.drop-zone.is-converting').length) {
            if (typeof giantToast === 'function') giantToast('Still converting the audio, one moment…', 'info');
            return;
        }

        // A forwarding destination: UK landline or UK mobile only, posted in
        // national format. (The AI receptionist form reuses the cu_param1
        // name for its provider, hence the action check.)
        var formAction = String($(this).find('input[name="pbxAction"]').val() || '');
        if (formAction === 'addCustomDestination' || formAction === 'editCustomDestination') {
            var $fwd = $(this).find('input[name="cu_param1"]');
            if ($fwd.length) {
                clearTimeout(giantFwdTimer);
                if (!giantForwardFieldCheck($fwd, true)) {   // shows the verdict under the field
                    if (String($fwd.val() || '').trim() === '') {
                        $fwd.addClass('is-invalid').after('<div class="giant-fwd-error" style="color:#b4232a;font-size:12px;font-weight:600;margin-top:4px;">' + GIANT_UK_FORWARD_ERROR + '</div>');
                    }
                    $fwd.trigger('focus');
                    return;
                }
            }
        }

        $('.giantModalPanel').hide();
        $('#giantModalSpinnerDiv').show();

        var hasFile = $(this).find('input[type="file"]').length > 0;
        var savedFields = $(this).serializeArray();                         // for save-time hints
        var savedAction = String($(this).find('input[name="pbxAction"]').val() || '');
        var ajaxOptions = {
            type: 'post',
            success: function (responseJson) {
                var response = jQuery.parseJSON(responseJson);

                if (response && response.error) {
                    $('#giantModalAlertDiv').show();
                    $('#giantModalAlert').html(response.error);
                }

                if (response && response.rps && typeof showRpsToast === 'function') {
                    showRpsToast(response.rps);
                }

                // Embedded drawer (flow builder): on an error keep the form up to
                // fix and retry; on success close the drawer and refresh that node.
                if (window._flowEmbeddedEdit) {
                    if (response && response.error) {
                        $('#giantModalSpinnerDiv').hide();
                        $('#giantModalAddFormDiv').show();
                        return;
                    }
                    flowCloseDrawer(true);
                    return;
                }

                // Created something from inside another form's picker: go back
                // to that form with the new object selected.
                if (!(response && response.error) && window._formReturn) {
                    var ret = window._formReturn;
                    window._formReturn = null;
                    giantFormReturn(ret);
                    return;
                }
                // Saved with a gap a call could fall into? Say so, gently.
                if (!(response && response.error)) giantFormSaveHints(savedAction, savedFields);
                // An extension password change that reached (or missed) the app login.
                if (!(response && response.error) && response && (response.app || response.devices)) giantVoiceCloudPassHint(response.app, response.devices);

                // Return to flow builder if we came from there
                if (window._flowReturnAfterSave && window._flowTypeSrc && window._flowTypeIdSrc) {
                    window._flowReturnAfterSave = false;
                    openCallFlowBuilder(window._flowTypeSrc, window._flowTypeIdSrc, window._flowDisplayName || '');
                } else {
                    refreshList(tileName);
                }
            }
        };

        if (hasFile) {
            var formData = new FormData(this);
            // Audio converted in the browser replaces whatever was picked.
            $(this).find('.drop-zone').each(function () {
                var converted = $(this).data('giantConverted');
                var $in = $(this).find('.drop-zone-input');
                if (converted && $in.length && $in.attr('name')) { formData.set($in.attr('name'), converted, converted.name); }
            });
            ajaxOptions.data = formData;
            ajaxOptions.processData = false;
            ajaxOptions.contentType = false;
        } else {
            ajaxOptions.data = $(this).serialize();
        }

        $.ajax(ajaxOptions);
    });
    var waitingEditInterval = setInterval(() => {
        var waiting = false;
        Object.entries(waitingFor).forEach(function (data, index) {
            if (data[1] == true) {
                waiting = true;
                return
            }
        });
        if (!waiting) {
            clearInterval(waitingEditInterval);
            toTrigger.forEach(function (fieldName) {

                $('[name="' + fieldName + '"]').trigger("change");

            });

            // Initialize Select2 on all select elements in the form
            $('#giantModalAddForm select.form-control').each(function() {
                if (!$(this).data('select2')) {
                    var config = {
                        dropdownParent: $('#giantModal'),
                        width: '100%',
                        placeholder: 'Search...',
                        allowClear: true,
                    };
                    if ($(this).attr('name') === 'ph_pm_id') {
                        var renderPmOption = function (sizeClass) {
                            return function (state) {
                                if (!state.id) return state.text;
                                var $opt = $(state.element);
                                var ver    = $opt.data('pm_image_ver');
                                var inline = $opt.data('pm_image_src');
                                var mfgSrc = $opt.data('pm_mfg_src');
                                var mfgName = $opt.data('pm_mfg_name');
                                var description = $opt.data('pm_description');
                                var modelFmtOpts = mfgSrc ? { stripManufacturer: mfgName } : null;
                                var labelHtml = formatPhoneModelName(state.text, modelFmtOpts);
                                var mfgTag = manufacturerLogoTag(mfgSrc, mfgName, 'giant-pm-option-mfg');
                                var src = resolvePhoneModelSrc(inline, state.id, ver);
                                var imgHtml = src
                                    ? '<img src="' + src + '" class="giant-pm-option-img" decoding="async">'
                                    : '<span class="giant-pm-option-img giant-pm-option-img-empty"><i class="fa-solid fa-mobile"></i></span>';
                                var titleAttr = description ? ' title="' + $('<div>').text(description).html() + '"' : '';
                                return $('<span class="giant-pm-option ' + sizeClass + '"' + titleAttr + '>' + imgHtml + '<span class="giant-pm-option-text">' + mfgTag + '<span>' + labelHtml + '</span></span></span>');
                            };
                        };
                        config.templateResult    = renderPmOption('giant-pm-option-lg');
                        config.templateSelection = renderPmOption('giant-pm-option-sm');
                    } else if (window.giantSelect2Templates && window.giantSelect2Templates[$(this).attr('name')]) {
                        // Per-field renderers registered by tile-specific JS
                        // (e.g. aiAgent.js registers a voice-avatar renderer
                        // for cu_param12). Keeps tile presentation out of the
                        // generic engine — the engine just looks up by name.
                        var giantTpl = window.giantSelect2Templates[$(this).attr('name')];
                        if (giantTpl.result)    config.templateResult    = giantTpl.result;
                        if (giantTpl.selection) config.templateSelection = giantTpl.selection;
                    } else {
                        // Everything else — media, hold music, voicemail boxes,
                        // agents, numbers, enumerations — gets a type icon too.
                        config.templateResult    = window.giantIconOptionTemplate;
                        config.templateSelection = window.giantIconOptionTemplate;
                    }
                    $(this).select2(config);
                }
            });

            // Phone edit/add: rearrange top fields into a 2-column layout with a live model preview.
            if (tileName === 'phone') {
                var $form = $('#giantModalAddForm');
                var $name = $form.find('[name="ph_name"]').closest('.form-group');
                var $mac  = $form.find('[name="ph_mac"]').closest('.form-group');
                var $pm   = $form.find('[name="ph_pm_id"]').closest('.form-group');

                if ($name.length && $pm.length && !$form.find('.giant-phone-edit-top').length) {
                    var $grid = $('<div class="giant-phone-edit-top"></div>');
                    var $preview = $('<div class="giant-phone-edit-preview">' +
                        '<div class="giant-phone-edit-preview-inner"><span class="giant-phone-edit-preview-empty"><i class="fa-solid fa-mobile fa-2x"></i></span></div>' +
                        '<div class="giant-phone-edit-preview-mfg"></div>' +
                        '<div class="giant-phone-edit-preview-meta">' +
                          '<div class="giant-phone-edit-preview-name"></div>' +
                          '<div class="giant-phone-edit-preview-lines"></div>' +
                          '<div class="giant-phone-edit-preview-desc"></div>' +
                        '</div>' +
                      '</div>');
                    var $right = $('<div class="giant-phone-edit-fields"></div>');

                    $name.before($grid);
                    $grid.append($preview).append($right);
                    $right.append($name).append($mac).append($pm);

                    var refreshPreview = function () {
                        var $sel = $form.find('[name="ph_pm_id"]');
                        var val = $sel.val();
                        var $opt = $sel.find('option[value="' + val + '"]');
                        var ver = $opt.data('pm_image_ver');
                        var inline = $opt.data('pm_image_src');
                        var lines = $opt.data('pm_endline');
                        var mfgSrc = $opt.data('pm_mfg_src');
                        var mfgName = $opt.data('pm_mfg_name');
                        var description = $opt.data('pm_description');
                        var rawName = $opt.text();
                        var src = resolvePhoneModelSrc(inline, val, ver);

                        var $mfg = $preview.find('.giant-phone-edit-preview-mfg');
                        if (mfgSrc) {
                            $mfg.html('<img src="' + mfgSrc + '" alt="' + (mfgName || '') + '" title="' + (mfgName || '') + '" decoding="async">').show();
                        } else {
                            $mfg.empty().hide();
                        }

                        var $inner = $preview.find('.giant-phone-edit-preview-inner');
                        if (src) {
                            $inner.html('<img src="' + src + '" alt="" decoding="async">');
                        } else {
                            $inner.html('<span class="giant-phone-edit-preview-empty"><i class="fa-solid fa-mobile fa-2x"></i></span>');
                        }

                        var $nameEl  = $preview.find('.giant-phone-edit-preview-name');
                        var $linesEl = $preview.find('.giant-phone-edit-preview-lines');
                        var $descEl  = $preview.find('.giant-phone-edit-preview-desc');
                        if (val && rawName) {
                            $nameEl.html(formatPhoneModelName(rawName));
                            if (lines) {
                                $linesEl.html('<i class="fa-solid fa-phone"></i> Max ' + lines + ' line' + (lines == 1 ? '' : 's'));
                                $linesEl.show();
                            } else {
                                $linesEl.hide();
                            }
                            if (description) {
                                $descEl.text(description).show();
                            } else {
                                $descEl.hide();
                            }
                        } else {
                            $nameEl.text('');
                            $linesEl.hide();
                            $descEl.hide();
                        }
                    };

                    $form.find('[name="ph_pm_id"]').on('change', refreshPreview);
                    refreshPreview();
                }
            }

            $('.giantModalPanel').hide();
            $('#giantModal .modal-dialog').removeClass('giant-modal-wide');
            $('#giantModalAddFormDiv').show();
            // Tile-specific layout passes run last, after the width reset above,
            // so nothing they set is stripped again (the AI Agent form pins its width here).
            giantFormAfterRender($('#giantModalAddForm'));


            return;
        }
    }, 500);
}

function showAdditionalData(dataHtml) {
    $('.giantModalPanel').hide();
    $('#giantModalAdditionalDataDiv').show();
    $('#giantModalAdditionalDataDiv').children().remove();
    $('#giantModalAdditionalDataDiv').append(dataHtml);
    $('#giantModalAdditionalDataDiv').append('</br></br><button class="btn btn-secondary giantBackButton">Back</button>');

    $('.giantBackButton').off('click');
    $('.giantBackButton').on('click', function (event) {
        event.preventDefault();
        $('.giantModalPanel').hide();
        $('#giantModalListDiv').show();
    });
}

function showQr(data) {

    //data = encodeURIComponent(data);

    var formHtml = '<form id="giantModalSendEmailForm" class = "modalForm" method="post">' +
        '    <input type="hidden" name="pbxAction" value="sendQrCode">' +
        '    <input type="hidden" name="qrLink" value="' + data + '">' +
        '    <div class="form-group">' +
        '        <label class="col-form-label">Send by email:</label>' +
        '        <div class="input-group mb-3">' +
        '            <input type="text" class="form-control" name="email"> ' +
        '            <div class="input-group-append">' +
        '                <input type="submit" class="btn btn-primary" value="Send">' +
        '            </div>' +
        '        </div>' +
        '    </div>' +
        '</form>';

    $('.giantModalPanel').hide();
    $('#giantModalQrDiv').show();
    $('#giantModalQrDiv').children().remove();
    $('#giantModalQrDiv').append('<div id="giantModalQrCanvas" style="display:inline-block"></div>');
    try { new QRCode(document.getElementById('giantModalQrCanvas'), { text: decodeURIComponent(String(data || '')), width: 150, height: 150 }); } catch (e) {}
    $('#giantModalQrDiv').append(formHtml);
    $('#giantModalQrDiv').append('</br></br><button id="giantBackButton" class="btn btn-secondary">Back</button>');

    $('#giantBackButton').off('click');
    $('#giantBackButton').on('click', function (event) {
        event.preventDefault();
        $('.giantModalPanel').hide();
        $('#giantModalListDiv').show();
    });

    $('#giantModalSendEmailForm').on('click', function (event) {
        event.preventDefault();
        $.ajax({
            type: 'post',
            data: $(this).serialize(),
            success: function (responseJson) {
                var response = jQuery.parseJSON(responseJson);
            }
        });
    });
}

// Build a single <option> string (shared by flat + grouped rendering).
function buildOptionHtml(optionValue, optionDisplay, defaultValue, additionalData) {
    var selected = (optionValue == defaultValue) ? ' selected' : '';
    var additionalDataHtml = '';
    if (additionalData && additionalData[optionValue]) {
        Object.entries(additionalData[optionValue]).forEach(function (entry) {
            additionalDataHtml += ' data-' + entry[0] + '="' + entry[1] + '"';
        });
    }
    return '<option value="' + optionValue + '"' + selected + additionalDataHtml + '>' + optionDisplay + '</option>';
}

function addOptions(selectInput, options, defaultValue = '', additionalData = []) {

    if (!options) {
        return;
    }

    var escLabel = function (s) { return $('<div>').text(s == null ? '' : s).html(); };

    Object.entries(options).forEach(function (optionData) {
        var optionValue   = optionData[0];
        var optionDisplay = optionData[1];

        // Grouped structure: a value that is itself a map of options is
        // rendered as an <optgroup> (grouped-by-type destination dropdowns).
        // Any caller can opt into grouping just by nesting — flat maps still
        // render exactly as before.
        if (optionDisplay && typeof optionDisplay === 'object') {
            var groupHtml = '<optgroup label="' + escLabel(optionValue) + '">';
            Object.entries(optionDisplay).forEach(function (grpOpt) {
                groupHtml += buildOptionHtml(grpOpt[0], grpOpt[1], defaultValue, additionalData);
            });
            groupHtml += '</optgroup>';
            selectInput.append(groupHtml);
            return;
        }

        selectInput.append(buildOptionHtml(optionValue, optionDisplay, defaultValue, additionalData));
    });
}

function addDynamicOptions(selectInput, defaultValue = '') {

    var fieldName = selectInput.attr('name').replace('[]', '');
    var fieldToken = fieldName + Math.floor(Math.random() * 10000);
    waitingFor[fieldToken] = true;

    var cacheKey = fieldName;
    if (cacheKeys[fieldName]) {
        cacheKey = cacheKeys[fieldName];
    }

    if (requestSend[cacheKey]) {

        var waitingForCacheInterval = setInterval(() => {
            if (cache[cacheKey]) {
                addOptions(selectInput, cache[cacheKey]["options"], defaultValue, cache[cacheKey]["data"]);
                clearInterval(waitingForCacheInterval);
                waitingFor[fieldToken] = false;
            }
        }, 500);

    } else {

        requestSend[cacheKey] = true;
        $.ajax({
            type: 'post',
            data: {
                pbxAction: "getOptions",
                fieldName: fieldName,
            },
            success: function (responseJson) {
                var response = jQuery.parseJSON(responseJson);
                var additionalData = [];
                if (response.data) {
                    additionalData = response.data;
                }

                cache[cacheKey] = {options: response.options, data: additionalData}
                addOptions(selectInput, response.options, defaultValue, additionalData);

                // Eagerly preload & decode any inline image data attached to options
                // (e.g. phone model images, manufacturer logos). This ensures the browser
                // has them fully decoded before the dropdown is ever opened so every
                // thumbnail paints instantly together instead of popping in one-by-one.
                if (additionalData && typeof additionalData === 'object') {
                    Object.keys(additionalData).forEach(function (k) {
                        var entry = additionalData[k];
                        if (!entry) return;
                        ['pm_image_src', 'pm_mfg_src'].forEach(function (field) {
                            var src = entry[field];
                            if (!src) return;
                            var img = new Image();
                            img.decoding = 'async';
                            img.src = src;
                            if (typeof img.decode === 'function') {
                                img.decode().catch(function () {});
                            }
                        });
                    });
                }

                waitingFor[fieldToken] = false;
            }
        });
    }
}

function addText(element, text) {
    element.html(text);
}

function addDynamicText(element) {

    var elementName = element.attr('name').replace('[]', '');
    var elementToken = elementName + Math.floor(Math.random() * 10000);
    waitingFor[elementToken] = true;

    $.ajax({
        type: 'post',
        data: {
            pbxAction: "getText",
            elementName: elementName,
        },
        success: function (responseJson) {
            var response = jQuery.parseJSON(responseJson);
            addText(element, response.text);
            waitingFor[elementToken] = false;
        }
    });
}

function setupRomoveForms() {

    $('.removeForm').off('submit');
    $('.removeForm').on('submit', function (event) {
        event.preventDefault();
        $.ajax({
            type: 'post',
            data: $(this).serialize(),
            success: function (response) {
                if (response.error) {
                    $('#giantModalAlertDiv').show();
                    $('#giantModalAlert').html(response.error);
                } else {
                    $(event.relatedTarget).parent().parent().remove();
                }
            }
        });
    });
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function generatePassword(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;

    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }

    return result;
}

// ===== RECORDING PLAYBACK POPUP WITH WAVEFORM =====
// ── Browser-side audio conversion for media uploads ─────────────────────
// Whatever the customer picks (MP3, M4A, OGG, FLAC, a 44.1 kHz stereo WAV…)
// is decoded with the Web Audio API and re-written as 8 kHz mono 16-bit PCM
// WAV — the telephony format the switch plays natively — before it is
// uploaded. Anything the browser can't decode (GSM, an odd codec) is sent as
// picked, exactly as before, so a conversion problem never blocks an upload.
var GIANT_WAV_RATE = 8000;

// Float samples (-1…1) → a complete 16-bit mono PCM WAV file (ArrayBuffer).
function giantPcmToWav(samples, sampleRate) {
    var n = samples.length, buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
    var str = function (o, s) { for (var i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    str(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); str(8, 'WAVE');
    str(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, sampleRate, true); v.setUint32(28, sampleRate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
    str(36, 'data'); v.setUint32(40, n * 2, true);
    for (var i = 0, o = 44; i < n; i++, o += 2) {
        var s = Math.max(-1, Math.min(1, samples[i]));
        v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
    return buf;
}

// Decode any browser-supported audio container to PCM (callback form: works in older Safari too).
function giantDecodeAudio(arrayBuffer) {
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return Promise.reject(new Error('Web Audio is not available'));
    var ac = new Ctx();
    var done = function () { try { if (ac.close) ac.close(); } catch (e) {} };
    return new Promise(function (resolve, reject) {
        try { ac.decodeAudioData(arrayBuffer, resolve, function (e) { reject(e || new Error('decode failed')); }); }
        catch (e) { reject(e); }
    }).then(function (d) { done(); return d; }, function (e) { done(); throw e; });
}

// The picked File → an 8 kHz mono 16-bit WAV File, or null when it should go up as picked.
function giantAudioToWav(file) {
    var ext = String(file.name || '').split('.').pop().toLowerCase();
    var Off = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (ext === 'gsm' || !Off || typeof file.arrayBuffer !== 'function') return Promise.resolve(null);
    return file.arrayBuffer().then(giantDecodeAudio).then(function (decoded) {
        var frames = Math.max(1, Math.ceil(decoded.duration * GIANT_WAV_RATE));
        var off = new Off(1, frames, GIANT_WAV_RATE);      // a mono destination: the browser downmixes + resamples
        var src = off.createBufferSource();
        src.buffer = decoded;
        src.connect(off.destination);
        src.start(0);
        return new Promise(function (resolve, reject) {
            off.oncomplete = function (e) { resolve(e.renderedBuffer); };
            try { var p = off.startRendering(); if (p && p.then) p.then(resolve, reject); }
            catch (e) { reject(e); }
        });
    }).then(function (rendered) {
        var wav  = giantPcmToWav(rendered.getChannelData(0), GIANT_WAV_RATE);
        var base = String(file.name || 'audio').replace(/\.[^.]+$/, '') || 'audio';
        return new File([wav], base + '.wav', { type: 'audio/wav' });
    });
}

// Drop-zone glue: convert the picked file, say what happened, and make the
// converted WAV what the form posts (stored on the zone + put into the input).
function giantPrepareAudioUpload($dz, file) {
    var $name = $dz.find('.drop-zone-filename');
    $dz.find('.drop-zone-note').remove();
    var $note = $('<span class="drop-zone-note"></span>').insertAfter($name);
    var fmt = function (b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB'; };
    $dz.addClass('is-converting');
    $note.text('Converting to 8 kHz WAV…');
    giantAudioToWav(file).then(function (converted) {
        $dz.removeClass('is-converting');
        if (!converted) { $note.text('Uploaded as picked (' + fmt(file.size) + ')'); return; }
        $dz.data('giantConverted', converted);
        $name.text(converted.name);
        $note.addClass('is-ok').text('Converted to 8 kHz mono WAV, ' + fmt(converted.size));
        try {   // so even a plain form post carries the WAV
            var dt = new DataTransfer(); dt.items.add(converted);
            $dz.find('.drop-zone-input')[0].files = dt.files;
        } catch (e) { /* the submit handler swaps it in from the zone's data */ }
    }).catch(function () {
        $dz.removeClass('is-converting');
        $note.text('Could not convert in this browser — uploaded as picked (' + fmt(file.size) + ')');
    });
}

function openRecordingPopup(recId, callInfo, customPostBody, transcriptFetch) {

    // Close any existing popup
    $('.giant-rec-overlay').remove();

    var html = '<div class="giant-rec-overlay">';
    html += '<div class="giant-rec-popup">';
    html += '  <div class="giant-rec-popup-header">';
    var popupTitle = (callInfo && callInfo.direction === 'Voicemail') ? 'Voicemail Message' : 'Call Recording';
    html += '    <div class="giant-rec-popup-title"><i class="fa-duotone fa-waveform-lines" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f; margin-bottom:0;"></i> ' + popupTitle + '</div>';
    html += '    <button class="giant-rec-popup-close" id="recPopupClose"><i class="fa-solid fa-xmark"></i></button>';
    html += '  </div>';
    html += '  <div class="giant-rec-popup-body">';
    html += '    <div class="giant-rec-popup-info">';
    if (callInfo.caller) html += '<span><i class="fa-solid fa-user"></i> ' + callInfo.caller.substring(0, 40) + '</span>';
    if (callInfo.started) html += '<span><i class="fa-solid fa-clock"></i> ' + callInfo.started + '</span>';
    if (callInfo.direction) html += '<span><i class="fa-solid fa-arrow-right-arrow-left"></i> ' + callInfo.direction + '</span>';
    html += '    </div>';
    html += '    <div class="giant-rec-waveform" id="recWaveformWrap">';
    html += '      <div class="giant-rec-loading" id="recLoading"><div class="giant-rec-loading-bars">';
    html += '        <span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span>';
    html += '      </div><div class="giant-rec-loading-text">Loading audio...</div></div>';
    html += '      <canvas id="recWaveformCanvas" style="display:none;"></canvas>';
    html += '    </div>';
    html += '    <div class="giant-rec-controls">';
    html += '      <button class="giant-rec-popup-play" id="recPopupPlay"><i class="fa-solid fa-play"></i></button>';
    html += '      <div class="giant-rec-progress-wrap">';
    html += '        <div class="giant-rec-progress-bar" id="recProgressBar"><div class="giant-rec-progress-fill" id="recProgressFill"></div></div>';
    html += '        <div class="giant-rec-time"><span id="recTimeCurrent">0:00</span><span id="recTimeTotal">Loading...</span></div>';
    html += '      </div>';
    html += '      <button class="giant-rec-speed" id="recSpeed">1x</button>';
    html += '    </div>';
    html += '    <div class="giant-rec-ai-panel" id="recAiPanel" style="display:none;"></div>';
    html += '    <div class="giant-rec-transcript-panel" id="recTranscriptPanel" style="display:none;">';
    html += '      <div class="giant-rec-transcript-head"><span><i class="fa-solid fa-comments"></i> Transcript</span><span class="giant-rec-transcript-note" title="The carrier transcript has no reliable timestamps, so bubble times are estimated from the audio length.">estimated timing</span></div>';
    html += '      <div class="giant-rec-transcript-scroll" id="recTranscript"></div>';
    html += '    </div>';
    html += '    <audio id="recPopupAudio" preload="none" style="display:none;"></audio>';
    html += '  </div>';
    html += '</div>';
    html += '</div>';

    $('body').append(html);

    var $overlay = $('.giant-rec-overlay');
    var $audio = $('#recPopupAudio')[0];
    var $playBtn = $('#recPopupPlay');
    var audioCtx = null;
    var analyser = null;
    var animFrame = null;
    var speeds = [1, 1.25, 1.5, 2, 0.5, 0.75];
    var speedIdx = 0;

    function fmtTime(s) {
        if (isNaN(s)) return '0:00';
        var m = Math.floor(s / 60);
        var sec = Math.floor(s % 60);
        return m + ':' + (sec < 10 ? '0' : '') + sec;
    }

    // ----- Synced transcript bubbles -----
    // The carrier transcript carries no usable timestamps, so we estimate each
    // turn's [start, end] by splitting the real recording duration in proportion
    // to its text length. Then we highlight + auto-scroll the active bubble as
    // the audio plays, and let any bubble be clicked to seek to that turn.
    var transcriptTurns = null;
    var transcriptDuration = 0;
    var transcriptActiveIdx = -1;

    function buildTranscriptTiming() {
        if (!transcriptTurns || !transcriptTurns.length || !transcriptDuration) return;
        var totalChars = 0, i;
        for (i = 0; i < transcriptTurns.length; i++) {
            transcriptTurns[i]._w = Math.max(1, (transcriptTurns[i].text || '').length);
            totalChars += transcriptTurns[i]._w;
        }
        var acc = 0;
        for (i = 0; i < transcriptTurns.length; i++) {
            transcriptTurns[i].start = acc;
            acc += (transcriptTurns[i]._w / totalChars) * transcriptDuration;
            transcriptTurns[i].end = acc;
        }
        renderTranscriptBubbles();
    }

    function renderTranscriptBubbles() {
        var $box = $('#recTranscript').empty();
        transcriptTurns.forEach(function (t, idx) {
            var side = (parseInt(t.speaker, 10) % 2 === 0) ? 'right' : 'left';
            var $row = $(
                '<div class="giant-rec-bubble-row ' + side + '" data-idx="' + idx + '">' +
                  '<div class="giant-rec-bubble">' +
                    '<div class="giant-rec-bubble-meta">' +
                      '<span class="giant-rec-bubble-who">Speaker ' + $('<div>').text(t.speaker).html() + '</span>' +
                      '<span class="giant-rec-bubble-time">' + fmtTime(t.start) + ' – ' + fmtTime(t.end) + '</span>' +
                    '</div>' +
                    '<div class="giant-rec-bubble-text"></div>' +
                  '</div>' +
                '</div>'
            );
            $row.find('.giant-rec-bubble-text').text(t.text);
            $box.append($row);
        });
        $box.find('.giant-rec-bubble-row').on('click', function () {
            var t = transcriptTurns[+$(this).data('idx')];
            if (t && $audio.duration) {
                $audio.currentTime = Math.min(t.start + 0.05, $audio.duration - 0.05);
                if ($audio.paused) { $audio.play(); $playBtn.html('<i class="fa-solid fa-pause"></i>'); }
            }
        });
        $('#recTranscriptPanel').show();
    }

    function syncTranscript(ct) {
        if (!transcriptTurns || !transcriptTurns.length) return;
        var idx = -1, i;
        for (i = 0; i < transcriptTurns.length; i++) {
            if (ct >= transcriptTurns[i].start && ct < transcriptTurns[i].end) { idx = i; break; }
        }
        if (idx === transcriptActiveIdx) return;
        transcriptActiveIdx = idx;
        var $rows = $('#recTranscript .giant-rec-bubble-row').removeClass('is-active');
        if (idx >= 0) {
            var $r = $rows.eq(idx).addClass('is-active');
            var $sc = $('#recTranscript');
            if ($r.length) {
                var target = $r.position().top + $sc.scrollTop() - ($sc.height() / 2) + ($r.outerHeight() / 2);
                $sc.stop().animate({ scrollTop: Math.max(0, target) }, 200);
            }
        }
    }

    // Colour-graded sentiment badge (red → amber → green by score). Shared shape
    // with the call-log Sentiment column. Score range isn't documented, so a
    // negative value is treated as −1…1 → 0…1; otherwise taken as 0…1.
    function giantSentimentBadge(score, brief) {
        var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
        var norm = null;
        if (score !== null && score !== undefined && !isNaN(score)) {
            norm = Number(score);
            if (norm < 0) { norm = (norm + 1) / 2; }
            norm = Math.max(0, Math.min(1, norm));
        }
        var label = 'Sentiment';
        if (norm !== null) {
            label = norm < 0.2 ? 'Very Negative' : (norm < 0.4 ? 'Negative' : (norm < 0.6 ? 'Neutral' : (norm < 0.8 ? 'Positive' : 'Very Positive')));
        }
        var hue = (norm !== null) ? Math.round(norm * 120) : 200;
        var bg = 'hsl(' + hue + ',72%,92%)', fg = 'hsl(' + hue + ',55%,28%)', bd = 'hsl(' + hue + ',60%,80%)';
        var scoreTxt = (score !== null && score !== undefined && !isNaN(score)) ? (' ' + Number(score).toFixed(2)) : '';
        var tip = brief ? (' title="' + esc(brief) + '"') : '';
        return '<span class="giant-sentiment-badge"' + tip + ' style="display:inline-flex;align-items:center;gap:6px;padding:2px 10px;border-radius:999px;background:' + bg + ';color:' + fg + ';border:1px solid ' + bd + ';font-weight:700;font-size:12px;">' + esc(label) + esc(scoreTxt) + '</span>';
    }

    // AI summary + sentiment panel in the player, from /aianalysis.
    function renderRecAi(resp) {
        var $p = $('#recAiPanel');
        if (!$p.length) { return; }
        var hasScore = resp && resp.sentimentScore !== null && resp.sentimentScore !== undefined;
        var hasAi = resp && (resp.summary || resp.sentimentBrief || hasScore);
        if (!hasAi) { $p.empty().hide(); return; }
        var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
        var h = '<div class="giant-rec-ai-head"><span><i class="fa-solid fa-wand-magic-sparkles"></i> AI summary</span>';
        if (hasScore || resp.sentimentBrief) {
            h += giantSentimentBadge(hasScore ? resp.sentimentScore : null, resp.sentimentBrief);
        }
        h += '</div>';
        if (resp.summary) { h += '<div class="giant-rec-ai-summary">' + esc(resp.summary) + '</div>'; }
        $p.html(h).show();
    }

    function loadTranscript(fetchData) {
        $('#recTranscriptPanel').show();
        $('#recTranscript').html('<div class="giant-rec-transcript-loading"><i class="fa-solid fa-spinner fa-spin"></i> Loading transcript…</div>');
        $.ajax({ type: 'post', dataType: 'json', data: fetchData })
            .done(function (resp) {
                if (!resp || !resp.ok) {
                    transcriptTurns = null;
                    renderRecAi(null);
                    // A voicemail says why (still processing, or transcription off); recordings just hide the panel.
                    if (transcriptFetch && resp && resp.error) {
                        $('#recTranscript').html('<div class="giant-rec-transcript-loading">' + $('<div>').text(resp.error).html() + '</div>');
                    } else {
                        $('#recTranscriptPanel').hide();
                    }
                    return;
                }
                renderRecAi(resp);   // AI summary + sentiment (independent of the transcript)
                if (resp.segments && resp.segments.length) {
                    transcriptTurns = resp.segments;
                    if (transcriptDuration) { buildTranscriptTiming(); }
                    else { $('#recTranscript').html('<div class="giant-rec-transcript-loading"><i class="fa-solid fa-spinner fa-spin"></i> Syncing to audio…</div>'); }
                } else {
                    transcriptTurns = null;
                    $('#recTranscriptPanel').hide();
                }
            })
            .fail(function () { $('#recTranscriptPanel').hide(); renderRecAi(null); });
    }

    // Call recordings fetch their transcript + AI analysis by recording id;
    // voicemails pass their own fetch (mailbox + ids) as transcriptFetch.
    if (transcriptFetch) {
        loadTranscript(transcriptFetch);
    } else if ((typeof customPostBody === 'undefined') && recId && String(recId).indexOf('vm_') !== 0) {
        loadTranscript({ pbxAction: 'getCallRecordingTranscript', itemId: recId });
    }

    // Close
    function closePopup() {
        if (animFrame) cancelAnimationFrame(animFrame);
        if ($audio) { $audio.pause(); $audio.src = ''; }
        if (audioCtx) { try { audioCtx.close(); } catch(e) {} }
        $overlay.remove();
    }

    $('#recPopupClose').on('click', closePopup);
    $overlay.on('click', function(e) { if (e.target === this) closePopup(); });
    $(document).on('keydown.recPopup', function(e) { if (e.key === 'Escape') closePopup(); });

    // Speed toggle
    $('#recSpeed').on('click', function() {
        speedIdx = (speedIdx + 1) % speeds.length;
        $audio.playbackRate = speeds[speedIdx];
        $(this).text(speeds[speedIdx] + 'x');
    });

    // Progress bar click to seek
    $('#recProgressBar').on('click', function(e) {
        if ($audio.duration) {
            var rect = this.getBoundingClientRect();
            $audio.currentTime = ((e.clientX - rect.left) / rect.width) * $audio.duration;
        }
    });

    // Waveform click to seek
    $('#recWaveformWrap').on('click', function(e) {
        if ($audio.duration) {
            var rect = this.getBoundingClientRect();
            $audio.currentTime = ((e.clientX - rect.left) / rect.width) * $audio.duration;
        }
    });

    // Draw waveform
    function drawWaveform(dataArray, bufferLength, progress) {
        var canvas = document.getElementById('recWaveformCanvas');
        if (!canvas) return;
        var ctx = canvas.getContext('2d');
        var w = canvas.width = canvas.offsetWidth * 2;
        var h = canvas.height = canvas.offsetHeight * 2;
        ctx.clearRect(0, 0, w, h);

        var barW = Math.max(2, w / bufferLength);
        var gap = 1;

        for (var i = 0; i < bufferLength; i++) {
            var v = dataArray[i] / 255.0;
            var barH = Math.max(2, v * h * 0.8);
            var x = (i / bufferLength) * w;
            var pct = i / bufferLength;

            if (pct < progress) {
                ctx.fillStyle = '#00d9a7';
            } else {
                ctx.fillStyle = '#d1d5db';
            }

            ctx.fillRect(x, (h - barH) / 2, barW - gap, barH);
        }
    }

    // Static waveform from frequency data
    function drawStaticWaveform(buffer) {
        var canvas = document.getElementById('recWaveformCanvas');
        if (!canvas) return;
        var ctx = canvas.getContext('2d');
        var w = canvas.width = canvas.offsetWidth * 2;
        var h = canvas.height = canvas.offsetHeight * 2;

        // Mix all channels (mono or stereo) into one array
        var numChannels = buffer.numberOfChannels;
        var data = new Float32Array(buffer.length);
        buffer.copyFromChannel(data, 0);
        if (numChannels > 1) {
            var ch2 = new Float32Array(buffer.length);
            buffer.copyFromChannel(ch2, 1);
            for (var s = 0; s < data.length; s++) {
                data[s] = (data[s] + ch2[s]) / 2;
            }
        }
        var step = Math.ceil(data.length / (w / 3));
        var bars = [];
        for (var i = 0; i < data.length; i += step) {
            var sum = 0;
            for (var j = 0; j < step && i + j < data.length; j++) {
                sum += Math.abs(data[i + j]);
            }
            bars.push(sum / step);
        }
        var max = Math.max.apply(null, bars) || 1;

        window._recBars = bars;
        window._recBarsMax = max;

        var barW = Math.max(2, w / bars.length);
        for (var k = 0; k < bars.length; k++) {
            var v = bars[k] / max;
            var barH = Math.max(2, v * h * 0.85);
            ctx.fillStyle = '#d1d5db';
            ctx.fillRect(k * barW, (h - barH) / 2, barW - 1, barH);
        }
    }

    // Update waveform progress coloring
    function updateWaveformProgress(progress) {
        var canvas = document.getElementById('recWaveformCanvas');
        if (!canvas || !window._recBars) return;
        var ctx = canvas.getContext('2d');
        var w = canvas.width;
        var h = canvas.height;
        var bars = window._recBars;
        var max = window._recBarsMax;
        ctx.clearRect(0, 0, w, h);

        var barW = Math.max(2, w / bars.length);
        for (var k = 0; k < bars.length; k++) {
            var v = bars[k] / max;
            var barH = Math.max(2, v * h * 0.85);
            ctx.fillStyle = (k / bars.length) < progress ? '#00d9a7' : '#d1d5db';
            ctx.fillRect(k * barW, (h - barH) / 2, barW - 1, barH);
        }
    }

    // Fetch audio
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.pbxConfig.endpoint, true);
    xhr.responseType = 'arraybuffer';
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onload = function() {
        if (xhr.status !== 200) {
            $('#recTimeTotal').text('Error');
            return;
        }

        var arrayBuffer = xhr.response;

        // Sniff the container so the blob is labelled correctly (WAV / MP3 /
        // OGG). A wrong MIME breaks HTML5 playback — the browser makes byte-range
        // requests that fail (ERR_REQUEST_RANGE_NOT_SATISFIABLE) — and Web Audio
        // decode. An empty / non-audio body (e.g. an error page) is caught here
        // so we never hand the <audio> element a bad blob.
        var head = new Uint8Array((arrayBuffer && arrayBuffer.byteLength) ? arrayBuffer.slice(0, 4) : 0);
        var isRiff = head[0] === 0x52 && head[1] === 0x49 && head[2] === 0x46 && head[3] === 0x46; // "RIFF" (WAV)
        var isMpeg = (head[0] === 0xFF && (head[1] & 0xE0) === 0xE0) || (head[0] === 0x49 && head[1] === 0x44 && head[2] === 0x33); // MP3 frame / ID3
        var isOgg  = head[0] === 0x4F && head[1] === 0x67 && head[2] === 0x67 && head[3] === 0x53; // "OggS"
        if (!isRiff && !isMpeg && !isOgg) {
            $('#recLoading').html('<div class="giant-rec-loading-text">No audio available for this recording yet.</div>');
            $('#recTimeTotal').text('—');
            return;
        }

        var blobMime = isMpeg ? 'audio/mpeg' : (isOgg ? 'audio/ogg' : 'audio/wav');
        var blob = new Blob([arrayBuffer], { type: blobMime });
        var blobUrl = URL.createObjectURL(blob);
        $audio.src = blobUrl;

        // Decode for the waveform. Non-fatal: some encodings (μ-law/GSM WAV)
        // reject decode but still play via the blob URL — so on failure we just
        // skip the waveform. Pass an error callback AND swallow the returned
        // promise so a decode failure never surfaces as an uncaught EncodingError.
        try {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            var decodePromise = audioCtx.decodeAudioData(
                arrayBuffer.slice(0),
                function (buffer) {
                    $('#recLoading').fadeOut(200, function() {
                        $('#recWaveformCanvas').css('opacity', 0).show();
                        drawStaticWaveform(buffer);
                        $('#recWaveformCanvas').animate({ opacity: 1 }, 200);
                    });
                },
                function () {
                    $('#recLoading').fadeOut(200, function() { $('#recWaveformCanvas').show(); });
                }
            );
            if (decodePromise && decodePromise.catch) { decodePromise.catch(function () {}); }
        } catch(e) {
            $('#recLoading').fadeOut(200, function() {
                $('#recWaveformCanvas').show();
            });
        }

        $audio.onloadedmetadata = function() {
            $('#recTimeTotal').text(fmtTime($audio.duration));
            transcriptDuration = $audio.duration;
            buildTranscriptTiming();  // (re)build now that we know the real length
        };

        $audio.ontimeupdate = function() {
            var pct = $audio.currentTime / $audio.duration;
            $('#recProgressFill').css('width', (pct * 100) + '%');
            $('#recTimeCurrent').text(fmtTime($audio.currentTime));
            updateWaveformProgress(pct);
            syncTranscript($audio.currentTime);
        };

        $audio.onended = function() {
            $playBtn.html('<i class="fa-solid fa-play"></i>');
            updateWaveformProgress(0);
            $('#recProgressFill').css('width', '0%');
            $('#recTimeCurrent').text('0:00');
        };

        // Play button
        $playBtn.off('click').on('click', function() {
            if ($audio.paused) {
                $audio.play();
                $(this).html('<i class="fa-solid fa-pause"></i>');
            } else {
                $audio.pause();
                $(this).html('<i class="fa-solid fa-play"></i>');
            }
        });
    };

    xhr.onerror = function() {
        $('#recLoading').html('<div class="giant-rec-loading-text" style="color:#dc2626;">Failed to load recording</div>');
        $('#recTimeTotal').text('Error');
    };

    var postBody = customPostBody || ('pbxAction=playCallRecord&itemId=' + encodeURIComponent(recId));
    xhr.send(pbxApi.body(postBody));
}

// ===== CALL FLOW BUILDER =====
var flowTypeIcons = {
    EXT: 'fa-user', IVR: 'fa-list-tree', QUEUE: 'fa-arrows-turn-to-dots',
    HUNTLIST: 'fa-users-rays', PLAYBACK: 'fa-compact-disc', VOICEMAIL: 'fa-voicemail',
    CONDITION: 'fa-code-branch', CUSTOM: 'fa-phone-arrow-right', PARK: 'fa-parking',
    FLOW: 'fa-diagram-project', MEETME: 'fa-users', SMS: 'fa-message',
    DISA: 'fa-key', PAGING: 'fa-bullhorn', MUSICONHOLD: 'fa-music',
    RESPONSEPATH: 'fa-route', CALLERIDMOD: 'fa-id-card', PHONEBOOK: 'fa-address-book',
};

// Destination-type icons in the Numbers call-routing select. Reuses the
// call-flow icon map, keyed off the option value's "TYPE-" prefix
// (EXT-, HUNTLIST-, IVR-, QUEUE-, CUSTOM-, VOICEMAIL-, PLAYBACK-, …).
window.giantSelect2Templates = window.giantSelect2Templates || {};
(function () {
    var renderDest = function (state) {
        // Only real "TYPE-id" destination tags get a type icon. The blank
        // placeholder, "None"/"0", and the "+ Create New …" sentinels have no
        // dash, so they render as plain text.
        if (!state.id) return state.text;
        var sid = String(state.id);
        if (sid.indexOf('-') === -1 || !flowTypeIcons[sid.split('-')[0]]) {
            // Not a destination tag ("Default", "None", a media file, "+ Create new…"):
            // the shared resolver still finds it an icon.
            return window.giantIconOptionTemplate ? window.giantIconOptionTemplate(state) : state.text;
        }
        var type = sid.split('-')[0];
        var icon = flowTypeIcons[type] || 'fa-arrow-right-to-bracket';
        var $el = $('<span class="giant-dest-opt"><i class="fa-solid giant-dest-opt-ico"></i><span class="giant-dest-opt-txt"></span></span>');
        $el.find('i').addClass(icon);
        $el.find('.giant-dest-opt-txt').text(state.text);
        return $el;
    };
    // Shared so other destination dropdowns (call-flow, port form) reuse the
    // exact same per-type icon rendering.
    window.giantRenderDestOption = renderDest;

    // Every routing-destination select shares the same type-icon rendering.
    // The generic form select2 init looks these up by the select's name.
    ['di_destination[]', 'hu_extensions[]', 'qu_on_timeout', 'co_dest_true', 'co_dest_false',
     'iv_ivr_1', 'iv_ivr_2', 'iv_ivr_3', 'iv_ivr_4', 'iv_ivr_5', 'iv_ivr_6', 'iv_ivr_7',
     'iv_ivr_8', 'iv_ivr_9', 'iv_ivr_0', 'iv_ivr_star', 'iv_ivr_sharp', 'iv_ivr_timeout', 'iv_ivr_wrong',
     'qu_on_exitkey', 'qu_on_nobodyhome', 'qu_on_nofreemember', 'qu_on_oncallback', 'qu_on_full',
     'hu_on_timeout', 'vm_on_operator', 'di_unconditional',
     'ex_dest_noanswer', 'ex_dest_busy', 'ex_dest_offline', 'ex_dest_unconditional'].forEach(function (name) {
        window.giantSelect2Templates[name] = { result: renderDest, selection: renderDest };
        // Exit fields are stacks (several steps in order), so their selects are named name[].
        if (name.indexOf('[]') < 0) window.giantSelect2Templates[name + '[]'] = { result: renderDest, selection: renderDest };
    });
})();

// ── One icon vocabulary for every dropdown ──────────────────────────────
// Destination tags get their type's icon (above); everything else is keyed
// by what the field lists — announcements, hold music, voicemail boxes,
// extensions, numbers, ring strategies … — or by a well-known value, with a
// neutral glyph as the last resort so no option is ever bare.
var giantFieldIcons = {
    // announcements / media files
    iv_me_id: 'fa-compact-disc', iv_options_me: 'fa-compact-disc', periodic_announce: 'fa-compact-disc', hu_confirmmessage_id: 'fa-compact-disc',
    qu_youarenext_me_id: 'fa-compact-disc', qu_thereare_me_id: 'fa-compact-disc', qu_callswaiting_me_id: 'fa-compact-disc',
    qu_thankyou_me_id: 'fa-compact-disc', qu_holdtime_me_id: 'fa-compact-disc', qu_current_me_id: 'fa-compact-disc',
    // hold music
    musiconhold: 'fa-music', ex_mu_id: 'fa-music',
    // voicemail boxes
    ex_mailbox: 'fa-voicemail',
    // people: queue agents, the extension behind each phone line
    agents: 'fa-user', ph_line0_ex_id: 'fa-user', ph_line1_ex_id: 'fa-user', ph_line2_ex_id: 'fa-user',
    ph_line3_ex_id: 'fa-user', ph_line4_ex_id: 'fa-user', ph_line5_ex_id: 'fa-user',
    // numbers
    ex_cidnum: 'fa-hashtag', smsFrom: 'fa-hashtag',
    // custom destination service type
    cu_ct_id: 'fa-phone-arrow-right',
    // enumerations
    hu_type: 'fa-arrows-turn-to-dots', strategy: 'fa-arrows-turn-to-dots', co_type: 'fa-code-branch',
    timezone: 'fa-earth-europe', language: 'fa-language', qu_parameters: 'fa-sliders', cu_param2: 'fa-sliders',
    welcomeoption: 'fa-comment-dots', announce_holdtime: 'fa-clock', announce_position: 'fa-list-ol', announce_round_seconds: 'fa-clock',
    qu_ringinuse: 'fa-phone-volume', ex_alertwhenoffline: 'fa-bell', callback: 'fa-phone-flip', dialout: 'fa-phone-arrow-up-right',
    di_recording: 'fa-circle-dot', di_transcript: 'fa-quote-left', di_aisummary: 'fa-wand-magic-sparkles', di_aisentiment: 'fa-face-smile',
    di_fax: 'fa-fax', di_sms_store: 'fa-message', ai_summary: 'fa-wand-magic-sparkles', ai_transcript: 'fa-quote-left',
};
var giantValueIcons = { yes: 'fa-check', no: 'fa-xmark', on: 'fa-check', off: 'fa-xmark', 'true': 'fa-check', 'false': 'fa-xmark', enabled: 'fa-check', disabled: 'fa-xmark' };

// The icon for one option: by destination tag, then by the group it sits
// in, then by the field, then by the value, then a neutral fallback.
function giantOptionIcon(fieldName, value, label, group, selectIcon) {
    var sid = (value == null) ? '' : String(value);
    if (sid === '') return '';                                            // placeholder / "choose…"
    var type = sid.indexOf('-') > 0 ? sid.split('-')[0] : '';
    if (type && flowTypeIcons[type]) return flowTypeIcons[type];
    var text = (label == null) ? '' : String(label);
    if (/^\s*\+/.test(text)) return 'fa-plus';                          // "+ Create new …"
    var name = (fieldName || '').replace(/[]$/, '');
    var isMedia = /_me_id$/.test(name) || name === 'iv_options_me' || name === 'periodic_announce' || name === 'hu_confirmmessage_id';
    if (isMedia || (group && /announcement|media/i.test(group))) return sid === '0' ? 'fa-circle-dot' : 'fa-compact-disc';
    if (group && /music|playlist/i.test(group)) return 'fa-music';
    if (selectIcon) return selectIcon;
    if (giantFieldIcons[name]) return giantFieldIcons[name];
    if (/^\s*[—-]?\s*(none|no |set up later|default)/i.test(text)) return 'fa-circle-dot';
    if (giantValueIcons[sid.toLowerCase()]) return giantValueIcons[sid.toLowerCase()];
    return 'fa-angle-right';
}

// Select2 result/selection renderer used by every dropdown that isn't a
// destination list (those delegate here for their non-tag entries).
window.giantIconOptionTemplate = function (state) {
    if (!state || (!state.id && state.id !== 0)) return state ? state.text : '';
    var $opt = state.element ? $(state.element) : null;
    var $sel = $opt ? $opt.closest('select') : null;
    var icon = giantOptionIcon(
        $sel ? $sel.attr('name') : '',
        state.id, state.text,
        $opt ? $opt.parent('optgroup').attr('label') : '',
        $sel ? $sel.attr('data-icon') : ''
    );
    if (!icon) return state.text;
    var $el = $('<span class="giant-dest-opt"><i class="fa-solid giant-dest-opt-ico"></i><span class="giant-dest-opt-txt"></span></span>');
    $el.find('i').addClass(icon);
    $el.find('.giant-dest-opt-txt').text(state.text);
    return $el;
};

// Turn a plain <select> that lists objects into the same searchable, iconed
// dropdown the forms use. `icon` is the glyph for every option (stored on the
// select as data-icon); `$parent` is the overlay the menu must stay inside.
function giantIconSelect($sel, icon, $parent) {
    if (!$sel || !$sel.length || !$.fn.select2) return;
    if (icon) $sel.attr('data-icon', icon);
    if ($sel.data('select2')) $sel.select2('destroy');
    var cfg = { width: '100%', templateResult: window.giantIconOptionTemplate, templateSelection: window.giantIconOptionTemplate };
    if ($parent && $parent.length) cfg.dropdownParent = $parent;
    $sel.select2(cfg);
}

var flowTypeLabels = {
    EXT: 'Extension', IVR: 'IVR Menu', QUEUE: 'Queue',
    HUNTLIST: 'Hunt List', PLAYBACK: 'Playback', VOICEMAIL: 'Voicemail',
    CONDITION: 'Condition', CUSTOM: 'Custom Dest.', PARK: 'Park',
    FLOW: 'Flow', MEETME: 'Conference', SMS: 'SMS',
    DISA: 'DISA', PAGING: 'Paging', MUSICONHOLD: 'Music on Hold',
    RESPONSEPATH: 'Response Path', CALLERIDMOD: 'Caller ID Mod', PHONEBOOK: 'Phone Book',
    RINGMUSICONHOLD: 'Ring with MOH', SAMENUMBERVM: 'Voicemail',
};

// Human label for a generic exit branch keyed by its typesrc — e.g.
// "QUEUE-TIMEOUT" → "On timeout", "EXT-NOANSWER" → "On no answer",
// "IVR_T" → "On timeout". Unknown suffixes fall back to a tidy "On …".
var flowExitSuffixLabels = {
    TIMEOUT: 'On timeout', T: 'On timeout', NOANSWER: 'On no answer', BUSY: 'On busy',
    OFFLINE: 'On offline', UNCONDITIONAL: 'Unconditional forward', ONCONDITION: 'On condition',
    FULL: 'When full', EXITKEY: 'On exit key', NOBODYHOME: 'Nobody available',
    NOFREEMEMBER: 'No free agent', PERIODICANNOUNCE: 'Periodic announce', I: 'Invalid input',
    INVALID: 'Invalid input', FAILOVER: 'On failure', FAILURE: 'On failure', THEN: 'Then',
    SMS: 'On SMS', FAXSUCCESS: 'Fax received',
    // Exits the PBX's own flow renderer follows (showflow.php)
    WRONG: 'Invalid input', HANGUP: 'On hang-up', MEDIAFILE: 'Announcement', HASH: 'Press #',
    OPERATOR: 'Operator (press 0)', ONCALLBACK: 'On callback',
    // IVR settings stored as destination rows (shown on the card, not as branches)
    ANNOUNCEMENT: 'Welcome message', OPTIONSMEDIAFILE: 'Options message', OPTIONSNOTAVAILABLE: 'Options not available',
};
function flowExitLabel(key) {
    var k = String(key || '');
    if (k.indexOf('CUSTOMIVR_') === 0) return 'Entering ' + k.slice(10);   // an IVR's custom entry (PBX: "Entering <name>")
    if (k === 'FLOW' || k === 'FEATURE') return 'Then';                      // bare typesrc = the onward step
    var m = k.match(/^[A-Z]+[-_](.+)$/);
    if (!m) return k;
    var suffix = m[1].toUpperCase();
    if (flowExitSuffixLabels[suffix]) return flowExitSuffixLabels[suffix];
    return 'On ' + suffix.toLowerCase().replace(/_/g, ' ');
}

// Friendly <optgroup> names + display order for grouping a flat destination
// map ({ "TYPE-id": label }) by type. Mirrors the server-side
// destGroupLabels()/groupDestinationMap() so every destination dropdown groups
// identically whether it's server- or client-built.
var destGroupNames = {
    EXT: 'Extensions', HUNTLIST: 'Ring Groups', QUEUE: 'Call Queues',
    IVR: 'IVR Menus', CONDITION: 'Time Conditions', VOICEMAIL: 'Voicemail',
    PLAYBACK: 'Announcements', CUSTOM: 'Additional Destinations',
};
var destGroupOrder = ['EXT', 'HUNTLIST', 'QUEUE', 'IVR', 'CONDITION', 'VOICEMAIL', 'PLAYBACK', 'CUSTOM'];

function giantDestOptgroupsHtml(map, selectedVal) {
    if (!map) return '';
    var esc = function (s) { return $('<div>').text(s == null ? '' : s).html(); };
    var buckets = {};
    Object.entries(map).forEach(function (e) {
        var type = String(e[0]).split('-')[0].toUpperCase();
        if (!destGroupNames[type]) type = '__OTHER__';
        (buckets[type] = buckets[type] || []).push(e);
    });
    var order = destGroupOrder.slice();
    if (buckets['__OTHER__']) order.push('__OTHER__');
    var html = '';
    order.forEach(function (type) {
        var items = buckets[type];
        if (!items || !items.length) return;
        html += '<optgroup label="' + esc(type === '__OTHER__' ? 'Other' : destGroupNames[type]) + '">';
        items.forEach(function (e) {
            var sel = (selectedVal != null && String(e[0]) === String(selectedVal)) ? ' selected' : '';
            html += '<option value="' + esc(e[0]) + '"' + sel + '>' + esc(e[1]) + '</option>';
        });
        html += '</optgroup>';
    });
    return html;
}

// ===== Create from the builder =====
// Everything routable that a customer can create, opened in the same drawer
// as editing so the builder never goes away. Extensions are deliberately not
// here — they're billed seats created through the product.
var flowCreateTiles = {
    huntList:          { label: 'Ring group',             icon: 'fa-users-rays' },
    queue:             { label: 'Queue',                  icon: 'fa-arrows-turn-to-dots' },
    ivr:               { label: 'IVR menu',               icon: 'fa-list-tree' },
    condition:         { label: 'Time condition',         icon: 'fa-code-branch' },
    voicemail:         { label: 'Voicemail box',          icon: 'fa-voicemail' },
    media:             { label: 'Announcement',           icon: 'fa-compact-disc' },
    customDestination: { label: 'Additional destination', icon: 'fa-phone-arrow-right' }
};

function flowCreateNew(tile) {
    if (!flowCreateTiles[tile] || typeof addFormData === 'undefined' || !addFormData[tile]) return;
    var $armed = $('.giant-flow-branch-add.is-armed').first();
    flowOpenDrawer('__NEW__', tile, 'New ' + flowCreateTiles[tile].label.toLowerCase());
    var ctx = window._flowEmbeddedEdit;
    ctx.mode   = 'add';
    ctx.tile   = tile;
    ctx.armed  = $armed.length ? flowTargetFromEl($armed) : null;
    ctx.before = Object.keys((window._flowData && window._flowData.destinations) || {});
    $('#giantFlowDrawerHead .giant-flow-drawer-kicker').text('Creating');
    showForm(tile, 'add', addFormData[tile], {});
}

// After a create saved in the drawer: refresh the library, find what's new,
// and either snap it into the slot that was armed or point at it in the library.
function flowAfterCreate(ctx) {
    $.ajax({
        type: 'post',
        data: { pbxAction: 'getFlowDestinations' },
        success: function (json) {
            var r   = flowParseJson(json);
            var map = (r && r.destinations) ? r.destinations : null;
            if (!map) { reRenderFlow(); flowNotice('Created. Reopen the flow to see it in the library.', 'ok'); return; }

            var before = {};
            (ctx.before || []).forEach(function (k) { before[k] = true; });
            var fresh = Object.keys(map).filter(function (k) { return !before[k]; });
            if (window._flowData) {
                window._flowData.destinations = map;
                if (r.globals) window._flowData.globals = r.globals;
            }
            if (window._flowLibState) window._flowLibState.q = '';

            // A condition's create form is only its name and type: once it's in
            // the flow, open it straight into its editor to set the times and
            // the if / otherwise routes.
            var setupNext = (ctx.tile === 'condition');

            if (fresh.length === 1) {
                var tag = fresh[0], parts = tag.split('-');
                var node = { type: parts[0], id: parts.slice(1).join('-'), name: String(map[tag]), tag: tag };
                if (ctx.armed) {
                    var parent = flowAddAt(ctx.armed, node);
                    flowHydrateNode(node);
                    syncCurrentFlow();
                    reRenderFlow();
                    flowMarkDirty();
                    flowNotice('Created "' + node.name + '" and added it to the flow. Save the flow to keep it.', 'ok');
                    flowAfterBranchAdd(parent);
                    if (setupNext) setTimeout(function () { flowEditNode(node.type, node.id, node.name); }, 400);
                    return;
                }
                reRenderFlow();
                flowFlashWidget(tag);
                flowNotice('Created "' + node.name + '". It\'s in the library — drag it onto the flow or press its +.', 'ok');
                if (setupNext) setTimeout(function () { flowEditNode(node.type, node.id, node.name); }, 400);
                return;
            }
            reRenderFlow();
            flowNotice(fresh.length ? 'Created. The new items are in the library.' : 'Saved.', 'ok');
        },
        error: function () { reRenderFlow(); }
    });
}

// Open its group, scroll the library to a widget and pulse it.
function flowFlashWidget(tag) {
    var $w = $('.giant-flow-widget[data-tag="' + tag + '"]').first();
    if (!$w.length) return;
    $('.giant-flow-container').removeClass('lib-collapsed');
    $w.closest('.giant-flow-lib-group').removeClass('is-closed');
    var $body = $('.giant-flow-lib-body');
    if ($body.length) $body.animate({ scrollTop: $body.scrollTop() + ($w.offset().top - $body.offset().top) - 60 }, 250);
    $w.addClass('is-new');
    setTimeout(function () { $w.removeClass('is-new'); }, 2600);
}

// ===== Forms: what the flow builder taught us =====
// Runs once a form has rendered: an IVR's keys as a keypad, play buttons on
// media pickers, drag-to-order and presence on hunt-list members, and
// "Create new…" entries in every destination picker.
function giantTileFromAction(action) {
    var t = String(action || '').replace(/^(add|edit|remove)/, '');
    return t ? t.charAt(0).toLowerCase() + t.slice(1) : '';
}
var giantMediaPickers = ['iv_me_id', 'iv_options_me', 'qu_youarenext_me_id', 'qu_thereare_me_id', 'qu_callswaiting_me_id', 'periodic_announce', 'qu_info_periodic_announce'];

// Tile scripts can register their own post-render pass here (aiAgent.js does).
window.giantFormRenderHooks = window.giantFormRenderHooks || {};

// Extensions: what else a password change touches. Shown the whole time the
// form is open (not only once the value differs): the softphone app login is
// updated on save when the extension is on the app, and any zero-touch desk
// phone on the extension needs a resync or reboot to pick the new one up.
window.giantFormRenderHooks.extension = function ($form) {
    var v = window._giantFormValues || {};
    var $in = $form.find('#passwordInput');
    if (!$in.length || $in.closest('.form-group').find('.giant-vc-pass-note').length) return;
    var esc = function (t) { return $('<div>').text(t == null ? '' : String(t)).html(); };
    var linked = String(v.vc_linked || '') === '1';
    var devices = giantParseDevices(v.vc_devices);
    var lines = [];
    if (linked) {
        lines.push('<div><i class="fa-solid fa-mobile-screen"></i> This extension is linked to the softphone app. Saving a new password updates the app login as well, and the app may ask them to sign in again.</div>');
    }
    if (devices.length) {
        var names = devices.map(function (d) { return '<b>' + esc(d.label) + '</b>'; });
        var list = names.length === 1 ? names[0] : names.slice(0, -1).join(', ') + ' and ' + names[names.length - 1];
        lines.push('<div><i class="fa-solid fa-phone-office"></i> ' + (devices.length === 1 ? 'A desk phone is set up on this extension: ' : 'Desk phones are set up on this extension: ') + list +
            '. After saving a new password, resync ' + (devices.length === 1 ? 'its' : 'their') + ' configuration or reboot ' + (devices.length === 1 ? 'it' : 'them') +
            ' and the new password is picked up automatically. You can do that from the save confirmation, or from the Phones tile.</div>');
    }
    if (!lines.length) return;
    $in.closest('.form-group').append('<div class="giant-list-hint is-warn giant-vc-pass-note"><div class="giant-list-hint-text">' + lines.join('') + '</div></div>');
};

// vc_devices reaches the form as a JSON string (data-* attribute) or an array.
function giantParseDevices(raw) {
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    try { var a = JSON.parse(String(raw)); return Array.isArray(a) ? a : []; } catch (e) { return []; }
}

// After an extension password change: what happened to the app login, and the
// desk phones that now need a resync or reboot (each with a button to do it).
function giantVoiceCloudPassHint(app, devices) {
    var esc = function (t) { return $('<div>').text(t == null ? '' : String(t)).html(); };
    devices = giantParseDevices(devices);
    var parts = [], kind = 'ok';
    if (app && app.linked) {
        if (app.synced) {
            parts.push('The softphone app login was updated to match. If the app signs them out, the new password or a fresh QR from the the app tile gets them back in.');
        } else {
            kind = 'warn';
            parts.push('The softphone app login could not be updated' + (app.message ? ': ' + esc(app.message) : '') + '. Regenerate their login from the the app tile so the app can reconnect.');
        }
    }
    if (devices.length) {
        kind = 'warn';
        var btns = devices.map(function (d) {
            return '<button type="button" class="giant-pass-reboot" data-ph-id="' + esc(d.id) + '"><i class="fa-solid fa-power-off"></i> Reboot ' + esc(d.label) + '</button>';
        }).join(' ');
        parts.push((devices.length === 1 ? 'The desk phone on this extension picks the new password up on its next resync or reboot. ' : 'The desk phones on this extension pick the new password up on their next resync or reboot. ') + btns);
    }
    if (!parts.length) return;
    giantListHint('<i class="fa-solid ' + (kind === 'ok' ? 'fa-circle-check' : 'fa-triangle-exclamation') + '"></i> Password saved. ' + parts.join(' '), kind, false, devices.length > 0);
}

// The reboot buttons in that hint: same call as the Phones tile's "Reboot phone".
$(document).off('click.giantPassReboot').on('click.giantPassReboot', '.giant-pass-reboot', function () {
    var $b = $(this), id = String($b.data('ph-id') || '');
    if (!id || $b.prop('disabled')) return;
    $b.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> Rebooting…');
    $.ajax({
        type: 'post', dataType: 'json',
        data: { pbxAction: 'rebootPhone', ph_id: id, mode: 'reboot' },
        success: function (r) {
            if (r && r.ok) $b.html('<i class="fa-solid fa-circle-check"></i> Reboot sent');
            else $b.prop('disabled', false).html('<i class="fa-solid fa-triangle-exclamation"></i> ' + $('<div>').text((r && r.error) || 'Could not reach the phone').html() + ' — retry');
        },
        error: function () { $b.prop('disabled', false).html('<i class="fa-solid fa-triangle-exclamation"></i> Could not reach the phone — retry'); }
    });
});

function giantFormAfterRender($form) {
    if (!$form || !$form.length) return;
    var action = String($form.find('input[name="pbxAction"]').val() || '');
    var tile = giantTileFromAction(action);
    var inDrawer = $('#giantModal').hasClass('flow-embedded-edit');

    if (typeof window.giantFormRenderHooks[tile] === 'function') {
        try { window.giantFormRenderHooks[tile]($form, inDrawer); } catch (e) { console.error('form hook failed for ' + tile, e); }
    }

    // IVR: the key destinations laid out as a keypad, each with its key chip.
    if (tile === 'ivr') {
        var order = ['iv_ivr_1', 'iv_ivr_2', 'iv_ivr_3', 'iv_ivr_4', 'iv_ivr_5', 'iv_ivr_6', 'iv_ivr_7', 'iv_ivr_8', 'iv_ivr_9', 'iv_ivr_star', 'iv_ivr_0', 'iv_ivr_sharp'];
        var $first = $form.find('select[name="iv_ivr_1[]"], select[name="iv_ivr_1"]').first().closest('.form-group');
        if ($first.length && !$form.find('.giant-ivr-keypad').length) {
            var $pad = $('<div class="giant-ivr-keypad"></div>');
            $('<div class="giant-ivr-keypad-title">Key presses <span>each key can have several steps in order</span></div>').insertBefore($first);
            $pad.insertBefore($first);
            order.forEach(function (name) {
                var $g = $form.find('select[name="' + name + '[]"], select[name="' + name + '"]').first().closest('.form-group');
                if (!$g.length) return;
                var key = name.replace('iv_ivr_', '').replace('star', '*').replace('sharp', '#');
                $g.addClass('giant-ivr-key');
                var $lbl = $g.find('label').first();
                $lbl.html('<span class="giant-flow-key">' + key + '</span>');
                $g.find('.form-text, small').remove();
                $pad.append($g);
            });
        }
    }

    // Media pickers: hear the file the caller will hear.
    giantMediaPickers.forEach(function (name) {
        var $sel = $form.find('select[name="' + name + '"]');
        if (!$sel.length || $sel.closest('.form-group').find('.giant-form-play').length) return;
        var $btn = $('<button type="button" class="giant-flow-play giant-form-play" title="Play this announcement"><i class="fa-solid fa-play"></i></button>');
        var sync = function () { var v = String($sel.val() || ''); var ok = v && v !== '0' && v.indexOf('__') !== 0; $btn.attr('data-id', ok ? v : '').data('id', ok ? v : '').toggle(!!ok); };
        $sel.closest('.form-group').append($('<div class="giant-form-play-row"></div>').append($btn).append('<span class="giant-form-play-txt">Play the selected announcement</span>'));
        $sel.on('change', sync);
        sync();
    });

    // Hunt list members: drag to set the ring order, with live presence.
    var $members = $form.find('#hu_extensionsGroup');
    if ($members.length) {
        if (!$members.prev('.giant-order-hint').length) {
            $('<div class="giant-order-hint"><i class="fa-solid fa-grip-vertical"></i> Drag to set the order they ring in (for Sequence and Cycle types).</div>').insertBefore($members);
        }
        $members.children('.col-md-6').each(function () {
            var $c = $(this);
            if ($c.data('orderable')) return;
            $c.data('orderable', true).attr('draggable', 'true').addClass('giant-orderable');
            $c.find('.form-check').prepend('<i class="fa-solid fa-grip-vertical giant-order-grip" title="Drag to reorder"></i>');
        });
        var $dragging = null;
        $members.off('dragstart.order dragover.order drop.order dragend.order')
            .on('dragstart.order', '.giant-orderable', function (e) { $dragging = $(this); $(this).addClass('is-dragging'); try { e.originalEvent.dataTransfer.setData('text/plain', 'x'); } catch (err) {} })
            .on('dragover.order', '.giant-orderable', function (e) { e.preventDefault(); if (!$dragging || $dragging.is(this)) return; var r = this.getBoundingClientRect(); var after = (e.originalEvent.clientY - r.top) > r.height / 2; if (after) $(this).after($dragging); else $(this).before($dragging); })
            .on('drop.order', '.giant-orderable', function (e) { e.preventDefault(); })
            .on('dragend.order', '.giant-orderable', function () { $(this).removeClass('is-dragging'); $dragging = null; });
        // Presence dots on each member (best effort, in the background).
        var tags = [];
        $members.find('input[type="checkbox"]').each(function () { var v = String($(this).val() || ''); if (v.indexOf('EXT-') === 0) tags.push(v); });
        if (tags.length) {
            $.ajax({ type: 'post', data: { pbxAction: 'getFlowLive', tags: tags.slice(0, 60) }, success: function (json) {
                var r = flowParseJson(json); if (!r || !r.live) return;
                var txt = { online: 'Available', busy: 'On a call', ringing: 'Ringing', offline: 'Offline', unknown: 'State unknown' };
                $members.find('input[type="checkbox"]').each(function () {
                    var v = String($(this).val() || ''), info = r.live[v];
                    if (!info || !info.state) return;
                    var $lbl = $members.find('label[for="' + this.id + '"]');
                    $lbl.find('.giant-flow-presence, .giant-latency-pill').remove();
                    $lbl.append('<span class="giant-flow-presence is-inline is-' + info.state + '" title="' + giantPresenceTitle(info, txt) + '"></span>');
                    var lp = giantLatencyPill(info);
                    if (lp) $lbl.append(lp);
                });
            } });
        }
    }

    // "Create new…" at the bottom of every single-value destination picker.
    if (!inDrawer && typeof flowCreateTiles !== 'undefined' && typeof addFormData !== 'undefined') {
        var destNames = Object.keys(window.giantSelect2Templates || {}).filter(function (n) { return n.indexOf('[]') < 0 && n !== 'di_destination' && n !== 'hu_extensions'; });
        var addCreateNew = function ($sel) {
            if (!$sel.length || $sel.find('optgroup.giant-create-new').length) return;
            var $og = $('<optgroup class="giant-create-new" label="Create new…"></optgroup>');
            Object.keys(flowCreateTiles).forEach(function (t) {
                if (t === tile || !addFormData[t]) return;
                $og.append($('<option></option>').attr('value', '__NEW_' + t + '__').text('+ New ' + flowCreateTiles[t].label.toLowerCase()));
            });
            if ($og.children().length) $sel.append($og);
        };
        destNames.forEach(function (name) {
            $form.find('select[name="' + name + '"], select[name="' + name + '[]"]').each(function () { addCreateNew($(this)); });
        });
        // Rows added later with "Add another" get the entries too.
        $form.off('click.giantCreateNewRows').on('click.giantCreateNewRows', '.giant-multi-add', function () {
            var $grp = $(this).closest('.form-group');
            setTimeout(function () { $grp.find('select').each(function () { addCreateNew($(this)); }); }, 0);
        });
    }
}

// A picker's "Create new…" was chosen: remember this form, open the create
// form, and come back with the new object selected.
$(document).off('change.giantCreateNew').on('change.giantCreateNew', '#giantModalAddForm select', function () {
    var v = String($(this).val() || '');
    if (v.indexOf('__NEW_') !== 0 || $('#giantModal').hasClass('flow-embedded-edit')) return;
    var tile = v.slice(6, -2);
    if (typeof addFormData === 'undefined' || !addFormData[tile]) return;
    var $form = $('#giantModalAddForm'), $sel = $(this);
    var before = {};
    $sel.find('option').each(function () { before[String(this.value)] = true; });
    $sel.val('').trigger('change.select2');
    var values = {};
    $form.serializeArray().forEach(function (f) {
        if (f.name === 'pbxAction') return;
        if (/\[\]$/.test(f.name)) { var k = f.name.slice(0, -2); (values[k] = values[k] || []).push(f.value); }
        else values[f.name] = f.value;
    });
    window._formReturn = { action: String($form.find('input[name="pbxAction"]').val() || ''), values: values, field: String($sel.attr('name') || ''), before: before };
    showForm(tile, 'add', addFormData[tile], {});
});
function giantFormReturn(ret) {
    var reopen = function (newTag) {
        var mode = /^add/.test(ret.action) ? 'add' : 'edit';
        var tile = giantTileFromAction(ret.action);
        var defs = mode === 'edit' ? (typeof editFormData !== 'undefined' ? editFormData[tile] : null) : (typeof addFormData !== 'undefined' ? addFormData[tile] : null);
        if (!defs) { refreshList(tile); return; }
        var values = $.extend({}, ret.values);
        if (newTag) {
            var k = ret.field.replace(/\[\]$/, '');
            if (Array.isArray(values[k])) {
                // A stack: fill the row that was set to "create new", else add a row.
                var slot = values[k].indexOf('');
                if (slot > -1) values[k][slot] = newTag; else values[k].push(newTag);
            } else {
                values[k] = newTag;
            }
        }
        showForm(tile, mode, defs, values);
        if (newTag) setTimeout(function () { giantListHint('<i class="fa-solid fa-circle-check"></i> Created and selected below. Save this form to keep it.', 'ok', true); }, 400);
    };
    $.ajax({
        type: 'post', data: { pbxAction: 'getFlowDestinations' },
        success: function (json) {
            var r = flowParseJson(json), map = (r && r.destinations) || {};
            var fresh = Object.keys(map).filter(function (k) { return !ret.before[k]; });
            reopen(fresh.length === 1 ? fresh[0] : null);
        },
        error: function () { reopen(null); }
    });
}

// A dismissable strip above a list (or a form) — save-time hints and the like.
function giantListHint(html, kind, onForm, sticky) {
    $('.giant-list-hint').not('.giant-vc-pass-note').remove();
    var $h = $('<div class="giant-list-hint' + (kind ? ' is-' + kind : '') + '"><div class="giant-list-hint-text">' + html + '</div><button type="button" class="giant-list-hint-close" title="Dismiss"><i class="fa-solid fa-xmark"></i></button></div>');
    $h.find('.giant-list-hint-close').on('click', function () { $h.remove(); });
    if (onForm) $('#giantModalAddFormDiv').prepend($h); else $('#giantModalListDiv').prepend($h);
    if (!sticky) setTimeout(function () { $h.fadeOut(300, function () { $h.remove(); }); }, 14000);
}
// After a save: gaps a call could fall into, from the values just saved.
function giantFormSaveHints(action, fields) {
    var tile = giantTileFromAction(action);
    var v = {}, lists = {};
    (fields || []).forEach(function (f) {
        if (/\[\]$/.test(f.name)) { var k = f.name.slice(0, -2); (lists[k] = lists[k] || []).push(f.value); }
        else v[f.name] = f.value;
    });
    var empty = function (x) { return x == null || x === '' || x === '0'; };
    var hints = [];
    if (tile === 'queue' && empty(v.qu_on_timeout)) hints.push('This queue has no <b>On timeout</b> route: a caller who waits the full time has nowhere to go.');
    if (tile === 'huntList' && empty(v.hu_on_timeout)) hints.push('This ring group has no <b>If nobody answers</b> route: an unanswered call has nowhere to go.');
    if (tile === 'ivr') {
        if (empty(v.iv_ivr_timeout)) hints.push('This IVR has no <b>On timeout</b> route for callers who press nothing.');
        var anyKey = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'star', 'sharp'].some(function (k) { return !empty(v['iv_ivr_' + k]); });
        if (!anyKey) hints.push('No key presses are routed yet, so the menu leads nowhere.');
    }
    if (tile === 'destination' && lists.di_destination && lists.di_destination.length > 1 && typeof flowTerminalTypes !== 'undefined') {
        var seq = lists.di_destination, endAt = -1;
        for (var i = 0; i < seq.length; i++) { if (flowTerminalTypes[String(seq[i]).split('-')[0]]) { endAt = i; break; } }
        if (endAt > -1 && endAt < seq.length - 1) hints.push('Step ' + (endAt + 2) + ' onwards can\'t be reached: the call ends at step ' + (endAt + 1) + '.');
    }
    if (hints.length) giantListHint('<i class="fa-solid fa-triangle-exclamation"></i> Saved. ' + hints.join(' '), 'warn');
}

// Numbers list: the unconditional-divert switch flips straight from the row.
$(document).off('change.giantDidUncond').on('change.giantDidUncond', '.giant-did-uncond-input', function () {
    var $in = $(this), on = $in.is(':checked'), id = $in.data('di_id');
    $in.prop('disabled', true);
    $.ajax({
        type: 'post',
        data: { pbxAction: 'toggleDidUnconditional', di_id: id, on: on ? 1 : 0 },
        success: function (json) {
            var r = flowParseJson(json);
            $in.prop('disabled', false);
            if (!r || r.error) {
                $in.prop('checked', !on);
                giantListHint('<i class="fa-solid fa-triangle-exclamation"></i> ' + $('<div>').text((r && r.error) || 'Couldn\'t change the divert.').html(), 'warn');
                return;
            }
            giantListHint('<i class="fa-solid fa-circle-check"></i> Unconditional divert switched ' + (on ? 'on' : 'off') + '.', 'ok');
        },
        error: function () {
            $in.prop('disabled', false).prop('checked', !on);
            giantListHint('<i class="fa-solid fa-triangle-exclamation"></i> Couldn\'t change the divert. Check your connection and try again.', 'warn');
        }
    });
});

// ===== Chunked drawing =====
// renderFlowBuilder draws the first levels and leaves placeholders for deeper
// branches of a big tree; these fill in a few per frame. Links, minimap and
// the audit wait for the last chunk rather than running after every piece.
function flowChunkFlush() {
    var pending = window._flowChunkPending || [];
    if (!pending.length) { flowChunkDone(); return; }
    var batch = pending.splice(0, 6);
    batch.forEach(function (c) {
        var html = '', ended = false;
        c.nodes.forEach(function (child, i) {
            html += renderFlowNode(child, 'chunk_' + c.id + '_' + i, $.extend({}, c.ctx, { isLast: i === c.nodes.length - 1, depth: 0, afterEnd: ended }));
            if (flowTerminalTypes[child.type]) ended = true;
            if (i < c.nodes.length - 1) html += '<div class="giant-flow-connector"></div>';
        });
        var $ph = $('.giant-flow-chunk[data-chunk="' + c.id + '"]');
        if ($ph.length) $ph.replaceWith(html);
        window._flowChunkDrawn = (window._flowChunkDrawn || 0) + 1;
    });
    flowLoaderChunkProgress(window._flowChunkDrawn || 0, pending.length);
    requestAnimationFrame(flowChunkFlush);
}
function flowChunkDone() {
    window._flowChunkBusy = false;
    $('#flowDrawing').hide();
    fixBranchConnectors();
    flowSyncPlayButtons();
    flowLivePaint();
    flowAuditPaint();
    if (window._flowFitOnDone) {
        window._flowFitOnDone = false;
        setTimeout(function () {
            if (window._flowFitAndCenter) { window._flowFitAndCenter({ maxZoom: 1.2, minZoom: 0.5 }); fixBranchConnectors(); }
            flowLoaderComplete();   // now it really is drawn
        }, 80);
    } else {
        if (window._flowCenterIfFits) window._flowCenterIfFits();
        flowLoaderComplete();
    }
}

// ===== Branch focus =====
// The path from the top of the tree to a node: [{node, index, arr, parentKey}].
function flowPathToUid(uid) {
    var want = String(uid), found = null;
    var walk = function (arr, parentKey, trail) {
        for (var i = 0; i < arr.length && !found; i++) {
            var n = arr[i];
            if (!n) continue;
            var here = trail.concat([{ node: n, index: i, arr: arr, parentKey: parentKey }]);
            if (String(n._uid) === want) { found = here; return; }
            if (n.children) {
                var keys = Object.keys(n.children);
                for (var k = 0; k < keys.length && !found; k++) walk(n.children[keys[k]] || [], keys[k], here);
            }
        }
    };
    walk((window._flowData && window._flowData.flow) || [], null, []);
    return found;
}
function flowFocusOn(uid) {
    window._flowFocusUid = (uid === '' || uid == null) ? null : String(uid);
    $('.giant-flow-branch-dropdown, .giant-flow-keypad').remove();
    window._flowHistorySilent = true;
    reRenderFlow();
    window._flowHistorySilent = false;
    window._flowFitOnDone = true;
    if (!window._flowChunkBusy) flowChunkDone();
}
$(document).off('click.flowFocus').on('click.flowFocus', '.giant-flow-node-focus', function (e) {
    e.stopPropagation();
    flowFocusOn($(this).data('index'));
});
$(document).off('dblclick.flowFocus').on('dblclick.flowFocus', '.giant-flow-node', function (e) {
    if ($(e.target).closest('button, select, input, a').length) return;
    if (!$(this).find('.giant-flow-node-focus').length) return;   // nothing under it to focus on
    flowFocusOn($(this).data('index'));
});
$(document).off('click.flowCrumb').on('click.flowCrumb', '.giant-flow-crumb[data-uid]', function (e) {
    e.stopPropagation();
    flowFocusOn($(this).data('uid'));
});

// ===== Live extras: extension presence, voicemail unread counts =====
// Fetched after the tree has drawn (never in the way of loading it), for the
// extensions and voicemail boxes on the canvas, then painted onto the cards
// in place. Refreshed every minute while the builder is open.
function flowLiveTags() {
    var tags = {};
    $('#flowCanvas .giant-flow-node[data-tag^="EXT-"], #flowCanvas .giant-flow-node[data-tag^="VOICEMAIL-"]').each(function () {
        tags[String($(this).data('tag'))] = true;
    });
    return Object.keys(tags);
}
function flowLiveRefresh() {
    var tags = flowLiveTags();
    if (!tags.length) return;
    $.ajax({
        type: 'post',
        data: { pbxAction: 'getFlowLive', tags: tags },
        success: function (json) {
            var r = flowParseJson(json);
            if (!r || !r.live) return;
            window._flowLive = $.extend(window._flowLive || {}, r.live);
            flowLivePaint();
        }
    });
}
// "On a call with Customer (01onboard…)", "Ringing (inbound)" — from the live lookup,
// then the device behind the extension and its round trip, when known.
function giantPresenceTitle(info, txt) {
    var t = txt[info.state] || info.state || '';
    if (info.with) t += ' with ' + info.with;
    if (info.direction) t += ' (' + info.direction + ')';
    if (info.device) t += ' · ' + info.device;
    if (info.latency_label) {
        var band = { fair: ' (higher than ideal)', high: ' (high latency)', unreachable: ' (not answering checks)' };
        t += ' · ' + info.latency_label + (band[info.latency] || '');
    }
    return $('<div>').text(t).html();
}
// The latency pill for a live-lookup entry, worded server-side (ExtensionLive::latencyInfo). '' when there is nothing to say.
function giantLatencyPill(info) {
    if (!info || !info.latency) return '';
    var icon = (info.latency === 'fair' || info.latency === 'high') ? '<i class="fa-solid fa-triangle-exclamation"></i>'
             : (info.latency === 'unreachable' ? '<i class="fa-solid fa-circle-exclamation"></i>' : '');
    return $('<span class="giant-latency-pill"></span>').addClass('is-' + info.latency).attr('title', info.latency_title || '')
        .html(icon + $('<span>').text(info.latency_label || '').html())[0].outerHTML;
}
function flowLivePaint() {
    var live = window._flowLive || {};
    var stateText = { online: 'Available', busy: 'On a call', ringing: 'Ringing', offline: 'Offline', unknown: 'State unknown' };
    Object.keys(live).forEach(function (tag) {
        var info = live[tag] || {};
        var $els = $('.giant-flow-node[data-tag="' + tag + '"], .giant-flow-widget[data-tag="' + tag + '"]');
        if (!$els.length) return;
        if (tag.indexOf('EXT-') === 0 && info.state) {
            $els.each(function () {
                var $icon = $(this).find('.giant-flow-node-icon').first();
                if (!$icon.length) return;
                var $dot = $icon.find('.giant-flow-presence');
                if (!$dot.length) $dot = $('<span class="giant-flow-presence"></span>').appendTo($icon);
                $dot.attr('class', 'giant-flow-presence is-' + info.state).attr('title', giantPresenceTitle(info, stateText));
            });
            // …and the round trip on the card itself, so a slow phone shows without hovering.
            $els.filter('.giant-flow-node').each(function () {
                var $meta = $(this).find('.giant-flow-node-meta').first();
                var $p = $meta.find('.giant-latency-pill');
                var html = giantLatencyPill(info);
                if (!html) { $p.remove(); return; }
                if (!$meta.length) $meta = $('<div class="giant-flow-node-meta"></div>').insertAfter($(this).find('.giant-flow-node-type').first());
                if ($p.length) $p.replaceWith(html); else $meta.append(html);
            });
        }
        if (tag.indexOf('VOICEMAIL-') === 0 && info.new != null) {
            $els.filter('.giant-flow-node').each(function () {
                var $meta = $(this).find('.giant-flow-node-meta').first();
                if (!$meta.length) $meta = $('<div class="giant-flow-node-meta"></div>').insertAfter($(this).find('.giant-flow-node-type').first());
                var $b = $meta.find('.giant-flow-vmnew');
                if (!$b.length) $b = $('<span class="giant-flow-vmnew"></span>').appendTo($meta);
                $b.toggleClass('is-zero', !info.new).text(info.new ? info.new + ' new' : 'No new messages').attr('title', (info.total || 0) + ' message' + (info.total === 1 ? '' : 's') + ' in total');
            });
        }
    });
}
function flowLiveStart() {
    flowLiveStop();
    setTimeout(flowLiveRefresh, 400);
    window._flowLiveTimer = setInterval(flowLiveRefresh, 60000);
}
function flowLiveStop() {
    if (window._flowLiveTimer) clearInterval(window._flowLiveTimer);
    window._flowLiveTimer = null;
}

// Element types that never have onward steps of their own.
var flowNoExitTypes = { CONFERENCE: 1, MEETME: 1, CUSTOM: 1, DISA: 1, PLAYBACK: 1, MUSICONHOLD: 1, RECORD: 1, RECORDING: 1, SPECIAL: 1, SMS: 1, PAGING: 1, CAMPAIGN: 1, PARK: 1, PHONEBOOK: 1 };
// …and the ones where the call ends (as opposed to playing and carrying on).
var flowTerminalTypes = { VOICEMAIL: 1, CUSTOM: 1, SPECIAL: 1, CONFERENCE: 1, MEETME: 1, DISA: 1, SMS: 1, PAGING: 1, RECORD: 1, RECORDING: 1, PARK: 1, PHONEBOOK: 1, CAMPAIGN: 1 };
// Does the element drawn in full elsewhere in this tree have any steps?
function flowTagHasSteps(tag) {
    var hit = false;
    (function walk(arr) {
        (arr || []).forEach(function (x) {
            if (hit || !x) return;
            if (x.tag === tag && !(x.repeat && !x.expanded) && x.children) {
                Object.keys(x.children).forEach(function (k) { if ((x.children[k] || []).length) hit = true; });
                if (hit) return;
            }
            if (x.children) Object.values(x.children).forEach(walk);
        });
    })((window._flowData && window._flowData.flow) || []);
    return hit;
}

// ===== Dead ends =====
// Exits a call can actually reach; empty, they leave a caller with nowhere to go.
var flowDeadEndKeys = {
    'true': 1, 'false': 1, 'destination': 1,
    'QUEUE-TIMEOUT': 1, 'HUNTLIST-TIMEOUT': 1, 'IVR_TIMEOUT': 1, 'IVR_WRONG': 1,
    'EXT-NOANSWER': 1, 'EXT-BUSY': 1, 'EXT-OFFLINE': 1
};

// ===== Automatic audit: dead ends, calls that fall off the end, loops =====
// Runs after every render. Each finding is pinned to the card it belongs to
// and listed behind the toolbar badge, which jumps to it.
function flowAuditLabel(n, key) {
    if (key === 'true') return 'If it matches';
    if (key === 'false') return 'Otherwise';
    if (key === 'destination') return 'Normal routing';
    if (key === 'unconditional') return 'Unconditional';
    if (key.indexOf('press_') === 0) return 'Press ' + flowKeyLabel(key);
    return flowExitLabel(key);
}
function flowAudit() {
    var issues = [];
    var flow = (window._flowData && window._flowData.flow) || [];
    var passThrough = { PLAYBACK: 1, MUSICONHOLD: 1 };
    var nameOf = function (n) { return n.type === 'DIDROOT' ? 'Incoming call' : (n.name || n.tag); };
    var walkList = function (list) {
        var ended = null;
        (list || []).forEach(function (n) {
            if (!n) return;
            if (ended) issues.push({ uid: n._uid, kind: 'unreachable', text: '"' + nameOf(n) + '" can\'t be reached — the call has already ended at "' + nameOf(ended) + '"', node: n });
            walkNode(n);
            if (flowTerminalTypes[n.type] && !ended) ended = n;
        });
        var last = list && list.length ? list[list.length - 1] : null;
        if (last && passThrough[last.type] && !(last.repeat && !last.expanded)) {
            issues.push({ uid: last._uid, kind: 'falls', text: 'Nothing after "' + nameOf(last) + '" — the call ends when it finishes playing', node: last });
        }
    };
    var walkNode = function (n) {
        if (n.repeat && !n.expanded) return;      // audited where it's drawn in full
        if (n._provisional) return;               // its real exits haven't loaded yet
        var ch = n.children || {};
        Object.keys(ch).forEach(function (k) {
            if ((ch[k] || []).length) { walkList(ch[k]); return; }
            if (n.type === 'DIDROOT') {
                var lanes = n.branchMeta || {};
                if (k === 'destination' && !(lanes.destination && lanes.destination.active === false)) {
                    issues.push({ uid: n._uid, kind: 'dead', key: k, text: 'Incoming call · Normal routing — nothing routed', node: n });
                }
                return;
            }
            if (flowDeadEndKeys[k]) issues.push({ uid: n._uid, kind: 'dead', key: k, text: nameOf(n) + ' · ' + flowAuditLabel(n, k) + ' — nothing routed', node: n });
        });
        if (n.type === 'IVR' && !ch['IVR_TIMEOUT']) {
            issues.push({ uid: n._uid, kind: 'soft', key: 'IVR_TIMEOUT', text: nameOf(n) + ' has no timeout route for callers who press nothing', node: n });
        }
        if (n.loop) issues.push({ uid: n._uid, kind: 'loop', text: nameOf(n) + ' loops back to an earlier step', node: n });
    };
    if (flow.length === 1 && flow[0] && flow[0].type === 'DIDROOT') walkNode(flow[0]); else walkList(flow);
    // Stable ids, and whether the customer has accepted each one.
    var acks = flowAckLoad();
    issues.forEach(function (i) { i.id = flowIssueId(i); i.accepted = acks.indexOf(i.id) > -1; });
    return issues;
}
// Accepted findings are remembered per flow, per browser.
function flowAckKey() { return 'giantFlowAck:' + (window._flowTypeSrc || '') + '-' + (window._flowTypeIdSrc || ''); }
function flowAckLoad() { try { return JSON.parse(localStorage.getItem(flowAckKey()) || '[]'); } catch (e) { return []; } }
function flowAckSave(list) { try { localStorage.setItem(flowAckKey(), JSON.stringify(list)); } catch (e) {} }
function flowIssueId(i) { return i.kind + '|' + (i.node && i.node.tag ? i.node.tag : 'root') + '|' + (i.key || ''); }
function flowIssueIcon(i) {
    return i.kind === 'loop' ? 'fa-rotate' : (i.kind === 'falls' ? 'fa-flag-checkered' : (i.kind === 'soft' ? 'fa-circle-question' : (i.kind === 'unreachable' ? 'fa-eye-slash' : 'fa-triangle-exclamation')));
}
function flowAuditPaint() {
    var issues = flowAudit();
    window._flowIssues = issues;
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var open = issues.filter(function (i) { return !i.accepted; });
    var accepted = issues.filter(function (i) { return i.accepted; });
    // Per-card counts (open findings only)
    $('.giant-flow-issue').remove();
    var byUid = {};
    open.forEach(function (i) { if (i.uid != null && i.node && i.node.type !== 'DIDROOT') (byUid[i.uid] = byUid[i.uid] || []).push(i); });
    Object.keys(byUid).forEach(function (uid) {
        var list = byUid[uid];
        var $type = $('.giant-flow-node[data-index="' + uid + '"] .giant-flow-node-type').first();
        if (!$type.length) return;
        $type.append(' <span class="giant-flow-issue" title="' + esc(list.map(function (i) { return i.text; }).join('\n')) + '"><i class="fa-solid fa-triangle-exclamation"></i> ' + list.length + '</span>');
    });
    // Toolbar badge + list
    var $b = $('#flowIssues');
    if (!$b.length) return;
    if (!issues.length) {
        $b.attr('class', 'giant-flow-issues is-clear').html('<i class="fa-solid fa-circle-check"></i> No dead ends');
        $('#flowIssuesPop').hide().empty();
        return;
    }
    var hard = open.filter(function (i) { return i.kind !== 'soft'; }).length;
    if (!open.length) {
        $b.attr('class', 'giant-flow-issues is-clear').html('<i class="fa-solid fa-circle-check"></i> ' + accepted.length + ' accepted');
    } else {
        $b.attr('class', 'giant-flow-issues' + (hard ? ' is-warn' : ' is-soft')).html('<i class="fa-solid fa-triangle-exclamation"></i> ' + open.length + ' to check');
    }
    var html = '<div class="giant-flow-issues-head"><div class="giant-flow-issues-title">Where a call can get stuck</div>';
    if (open.length) html += '<button type="button" class="giant-btn-sm is-primary" id="flowAnalyseStart"><i class="fa-solid fa-list-check" style="margin-bottom:0;"></i> Review one by one</button>';
    html += '</div>';
    issues.forEach(function (i, idx) {
        html += '<button type="button" class="giant-flow-issue-item is-' + i.kind + (i.accepted ? ' is-accepted' : '') + '" data-i="' + idx + '"><i class="fa-solid ' + flowIssueIcon(i) + '"></i><span>' + esc(i.text) + '</span>'
              + (i.accepted ? '<em class="giant-flow-issue-unaccept" data-id="' + esc(i.id) + '" title="Stop treating this as fine">Accepted · undo</em>' : '')
              + '</button>';
    });
    $('#flowIssuesPop').html(html);
}
// Jump to a finding: zoom to a readable size, scroll to the exact slot or card, flash it.
function flowIssueReveal(i) {
    if (!i || !i.node) return false;
    if (i.node.collapsed) { i.node.collapsed = false; window._flowHistorySilent = true; reRenderFlow(); window._flowHistorySilent = false; }
    var $target = null;
    if (i.key && i.node.type !== 'DIDROOT') {
        $target = $('.giant-flow-branch-add.giant-flow-ghost[data-typesrc="' + flowBranchTypeSrc(i.node, i.key) + '"][data-typeidsrc="' + i.node.id + '"]').first();
    } else if (i.key && i.node.type === 'DIDROOT') {
        $target = $('.giant-flow-branch-add.giant-flow-ghost[data-typesrc="DID"]').first();
    }
    if (!$target || !$target.length) $target = $('.giant-flow-node[data-index="' + i.uid + '"]').first();
    if (!$target.length) return false;
    if (window._flowZoomAt && (window._flowZoom || 1) < 0.9) {
        var vp = document.getElementById('flowViewport'), vr = vp ? vp.getBoundingClientRect() : null;
        if (vr) window._flowZoomAt(1, vr.width / 2, vr.height / 2);
    }
    if (window._flowRevealEl) window._flowRevealEl($target[0], 80);
    $target.addClass('is-flash');
    setTimeout(function () { $target.removeClass('is-flash'); }, 1800);
    return true;
}
$(document).off('click.flowUnaccept').on('click.flowUnaccept', '.giant-flow-issue-unaccept', function (e) {
    e.stopPropagation();
    e.preventDefault();
    var id = String($(this).data('id'));
    flowAckSave(flowAckLoad().filter(function (x) { return x !== id; }));
    flowAuditPaint();
    $('#flowIssuesPop').show();
});
$(document).off('click.flowAnalyseStart').on('click.flowAnalyseStart', '#flowAnalyseStart', function (e) {
    e.stopPropagation();
    $('#flowIssuesPop').hide();
    flowAnalyseStart();
});

// ===== Flow analyser: review each finding, accept it or apply a fix =====
function flowAnalyseStart() {
    var open = (window._flowIssues || []).filter(function (i) { return !i.accepted; });
    if (!open.length) { flowNotice('Nothing to review — no dead ends or loops.', 'ok'); return; }
    if ($('#flowWalkPanel').is(':visible')) flowWalkClose();
    window._flowAnalyse = { ids: open.map(function (i) { return i.id; }), idx: 0, fixed: 0, accepted: 0 };
    flowAnalyseShow();
}
function flowAnalyseClose() {
    $('#flowAnalyser').hide();
    window._flowAnalyse = null;
}
function flowAnalyseCurrent() {
    var st = window._flowAnalyse;
    if (!st || st.idx >= st.ids.length) return null;
    var id = st.ids[st.idx];
    return (window._flowIssues || []).filter(function (i) { return i.id === id && !i.accepted; })[0] || null;
}
// Tags already used in this flow, so suggestions prefer what the customer knows.
function flowUsedTags() {
    var used = {};
    (function walk(arr) { (arr || []).forEach(function (n) { if (!n) return; if (n.tag) used[n.tag] = true; if (n.children) Object.values(n.children).forEach(walk); }); })((window._flowData && window._flowData.flow) || []);
    return used;
}
function flowPickTag(prefix) {
    var map = (window._flowData && window._flowData.destinations) || {}, used = flowUsedTags();
    var tags = Object.keys(map).filter(function (t) { return t.indexOf(prefix) === 0; });
    var pick = tags.filter(function (t) { return used[t]; })[0] || tags[0];
    return pick ? { tag: pick, name: String(map[pick]), type: pick.split('-')[0], id: pick.split('-').slice(1).join('-') } : null;
}
function flowNodeFromTag(tag) {
    var map = (window._flowData && window._flowData.destinations) || {};
    var parts = String(tag).split('-');
    return { type: parts[0], id: parts.slice(1).join('-'), name: String(map[tag] || tag), tag: String(tag) };
}
// Where a finding's fix goes: the branch (owner + key), or after a step.
function flowIssueTarget(i) {
    if (i.kind === 'dead' || i.kind === 'soft') {
        var owner = i.node;
        return { typeSrc: owner.type === 'DIDROOT' ? flowBranchTypeSrc(owner, i.key) : flowBranchTypeSrc(owner, i.key), typeIdSrc: owner.id, owner: owner, key: i.key };
    }
    if (i.kind === 'falls') {
        var p = flowPathToUid(i.uid);
        if (!p || !p.length) return null;
        var last = p[p.length - 1], parent = p.length > 1 ? p[p.length - 2].node : null;
        return parent ? { typeSrc: flowBranchTypeSrc(parent, last.parentKey), typeIdSrc: parent.id, after: String(i.uid) } : { main: true, after: String(i.uid) };
    }
    return null;
}
function flowSuggest(i) {
    var s = [], owner = i.node, vm = flowPickTag('VOICEMAIL-');
    var route = function (tag) {
        return function () {
            var target = flowIssueTarget(i);
            if (!target) return false;
            if (i.kind === 'soft' && owner && owner.children && !owner.children[i.key]) owner.children[i.key] = [];
            var node = flowNodeFromTag(tag);
            flowAddAt(target, node);
            flowHydrateNode(node);
            return true;
        };
    };
    if (i.kind === 'dead' || i.kind === 'soft') {
        if (owner && owner.type === 'IVR' && (i.key === 'IVR_TIMEOUT' || i.key === 'IVR_WRONG')) s.push({ label: 'Repeat the menu', icon: 'fa-rotate-left', run: route(owner.tag) });
        if (vm) s.push({ label: 'Send to voicemail: ' + vm.name, icon: 'fa-voicemail', run: route(vm.tag) });
        if (owner && owner.type === 'DIDROOT') {
            var ivr = flowPickTag('IVR-'), hl = flowPickTag('HUNTLIST-'), ext = flowPickTag('EXT-');
            if (ivr) s.push({ label: 'Route to ' + ivr.name, icon: 'fa-list-tree', run: route(ivr.tag) });
            else if (hl) s.push({ label: 'Route to ' + hl.name, icon: 'fa-users-rays', run: route(hl.tag) });
            else if (ext) s.push({ label: 'Route to ' + ext.name, icon: 'fa-user', run: route(ext.tag) });
        }
        if (owner && (owner.type === 'QUEUE' || owner.type === 'HUNTLIST')) {
            var alt = flowPickTag(owner.type === 'QUEUE' ? 'HUNTLIST-' : 'QUEUE-');
            if (alt) s.push({ label: 'Try ' + alt.name + ' instead', icon: owner.type === 'QUEUE' ? 'fa-users-rays' : 'fa-arrows-turn-to-dots', run: route(alt.tag) });
        }
    }
    if (i.kind === 'falls') {
        if (vm) s.push({ label: 'Send to voicemail after it: ' + vm.name, icon: 'fa-voicemail', run: route(vm.tag) });
    }
    if (i.kind === 'unreachable') {
        s.push({ label: 'Remove it', icon: 'fa-trash', run: function () { var f = flowFindByUid(i.uid); if (!f) return false; f.array.splice(f.position, 1); return true; } });
        s.push({ label: 'Move it before the call ends', icon: 'fa-arrow-up', run: function () {
            var f = flowFindByUid(i.uid); if (!f) return false;
            var arr = f.array, endAt = -1;
            for (var k = 0; k < arr.length; k++) { if (flowTerminalTypes[arr[k].type]) { endAt = k; break; } }
            if (endAt < 0 || endAt >= f.position) return false;
            var n = arr.splice(f.position, 1)[0]; arr.splice(endAt, 0, n); return true;
        } });
    }
    if (i.kind === 'loop') {
        s.push({ label: 'Remove the looping step', icon: 'fa-trash', run: function () { var f = flowFindByUid(i.uid); if (!f) return false; f.array.splice(f.position, 1); return true; } });
    }
    return s;
}
function flowAnalyseShow() {
    var st = window._flowAnalyse;
    if (!st) return;
    var $p = $('#flowAnalyser');
    if (!$p.length) $p = $('<div class="giant-flow-walkpanel giant-flow-analyser" id="flowAnalyser"></div>').appendTo('.giant-flow-main');
    $p.show();
    while (st.idx < st.ids.length && !flowAnalyseCurrent()) st.idx++;   // fixed or accepted meanwhile
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var i = flowAnalyseCurrent();
    var html = '<div class="giant-flow-walk-title"><i class="fa-solid fa-list-check"></i> Review the flow <button type="button" class="giant-flow-walk-close" id="flowAnalyseClose" title="Close"><i class="fa-solid fa-xmark"></i></button></div>';
    if (!i) {
        var left = (window._flowIssues || []).filter(function (x) { return !x.accepted; }).length;
        html += '<div class="giant-flow-walk-q"><span class="is-ok"><i class="fa-solid fa-circle-check"></i> Review complete: ' + st.fixed + ' fixed, ' + st.accepted + ' accepted' + (left ? ', ' + left + ' left for later' : '') + '.</span></div>';
        if (st.fixed) html += '<div class="giant-flow-walk-actions"><button type="button" class="giant-btn-sm is-primary" id="flowAnalyseSave"><i class="fa-solid fa-floppy-disk" style="margin-bottom:0;"></i> Save the flow</button> <button type="button" class="giant-btn-sm is-secondary" id="flowAnalyseDone">Close</button></div>';
        else html += '<div class="giant-flow-walk-actions"><button type="button" class="giant-btn-sm is-secondary" id="flowAnalyseDone">Close</button></div>';
        $p.html(html);
        return;
    }
    flowIssueReveal(i);
    var routing = (i.kind === 'dead' || i.kind === 'soft' || i.kind === 'falls');
    var sug = flowSuggest(i);
    html += '<div class="giant-flow-analyse-step">' + (st.idx + 1) + ' of ' + st.ids.length + '</div>';
    html += '<div class="giant-flow-walk-q"><i class="fa-solid ' + flowIssueIcon(i) + ' is-' + i.kind + '"></i> ' + esc(i.text) + '.</div>';
    html += '<div class="giant-flow-analyse-ask">Is that OK, or would you like to fix it?</div>';
    if (sug.length) {
        html += '<div class="giant-flow-walk-choices">';
        sug.forEach(function (sg, k) { html += '<button type="button" class="giant-flow-walk-choice giant-flow-analyse-fix" data-k="' + k + '"><i class="fa-solid ' + sg.icon + '"></i>' + esc(sg.label) + '</button>'; });
        html += '</div>';
    }
    if (routing) {
        html += '<div class="giant-flow-analyse-pick"><select class="form-control giant-flow-analyse-select"><option value="">Or choose a destination…</option>' + giantDestOptgroupsHtml((window._flowData && window._flowData.destinations) || {}) + '</select>'
              + '<button type="button" class="giant-btn-sm is-primary" id="flowAnalyseRoute"><i class="fa-solid fa-check" style="margin-bottom:0;"></i> Route</button></div>';
    }
    html += '<div class="giant-flow-walk-actions">';
    html += '<button type="button" class="giant-btn-sm is-secondary giant-flow-analyse-ok" id="flowAnalyseAccept"><i class="fa-solid fa-thumbs-up" style="margin-bottom:0;"></i> It\'s fine</button> ';
    html += '<button type="button" class="giant-btn-sm is-secondary" id="flowAnalyseSkip">Skip</button>';
    if (st.idx > 0) html += ' <button type="button" class="giant-btn-sm is-secondary" id="flowAnalysePrev"><i class="fa-solid fa-arrow-left" style="margin-bottom:0;"></i></button>';
    html += '</div>';
    $p.html(html);
    if ($.fn.select2) {
        $p.find('.giant-flow-analyse-select').select2({ dropdownParent: $('#giantModal'), width: '100%', placeholder: 'Or choose a destination…', templateResult: window.giantRenderDestOption, templateSelection: window.giantRenderDestOption });
    }
    window._flowAnalyseSug = sug;
}
function flowAnalyseApply(run) {
    if (!window._flowEditing) $('#flowEditToggle').trigger('click');
    var ok = false;
    try { ok = run(); } catch (e) { ok = false; }
    if (!ok) { flowNotice('Couldn\'t apply that fix here.', 'error'); return; }
    var st = window._flowAnalyse;
    if (st) st.fixed++;
    syncCurrentFlow();
    reRenderFlow();
    flowMarkDirty();
    flowAuditPaint();
    if (st) { st.idx++; flowAnalyseShow(); }
}
$(document).off('click.flowAnalyse').on('click.flowAnalyse', '#flowAnalyser button', function (e) {
    e.preventDefault();
    e.stopPropagation();
    var st = window._flowAnalyse, $b = $(this), id = this.id;
    if (id === 'flowAnalyseClose' || id === 'flowAnalyseDone') { flowAnalyseClose(); return; }
    if (id === 'flowAnalyseSave') { flowAnalyseClose(); $('.giant-flow-save').trigger('click'); return; }
    if (!st) return;
    if ($b.hasClass('giant-flow-analyse-fix')) { var sg = (window._flowAnalyseSug || [])[+$b.data('k')]; if (sg) flowAnalyseApply(sg.run); return; }
    if (id === 'flowAnalyseRoute') {
        var tag = $('#flowAnalyser .giant-flow-analyse-select').val();
        if (!tag) return;
        var i = flowAnalyseCurrent();
        if (!i) return;
        flowAnalyseApply(function () {
            var target = flowIssueTarget(i);
            if (!target) return false;
            if (i.kind === 'soft' && i.node && i.node.children && !i.node.children[i.key]) i.node.children[i.key] = [];
            var node = flowNodeFromTag(tag);
            flowAddAt(target, node);
            flowHydrateNode(node);
            return true;
        });
        return;
    }
    if (id === 'flowAnalyseAccept') {
        var cur = flowAnalyseCurrent();
        if (cur) { var acks = flowAckLoad(); if (acks.indexOf(cur.id) < 0) acks.push(cur.id); flowAckSave(acks); st.accepted++; }
        flowAuditPaint();
        st.idx++;
        flowAnalyseShow();
        return;
    }
    if (id === 'flowAnalyseSkip') { st.idx++; flowAnalyseShow(); return; }
    if (id === 'flowAnalysePrev') { st.idx = Math.max(0, st.idx - 1); flowAnalyseShow(); return; }
});
$(document).off('click.flowIssues').on('click.flowIssues', '#flowIssues', function (e) {
    e.stopPropagation();
    if (!(window._flowIssues || []).length) return;
    $('#flowIssuesPop').toggle();
});
$(document).off('click.flowIssuesAway').on('click.flowIssuesAway', function (e) {
    if (!$(e.target).closest('#flowIssuesPop, #flowIssues').length) $('#flowIssuesPop').hide();
});
$(document).off('click.flowIssueJump').on('click.flowIssueJump', '.giant-flow-issue-item', function (e) {
    e.stopPropagation();
    if ($(e.target).closest('.giant-flow-issue-unaccept').length) return;
    var i = (window._flowIssues || [])[+$(this).data('i')];
    if (!i || !i.node) return;
    $('#flowIssuesPop').hide();
    if (!flowIssueReveal(i) && window._flowFocusUid != null) {
        // Outside the focused branch: show the whole flow, wait for it to
        // finish drawing, then jump.
        var idx = +$(this).data('i'), tries = 0;
        flowFocusOn('');
        var again = function () {
            if (window._flowChunkBusy && tries++ < 60) { setTimeout(again, 100); return; }
            $('.giant-flow-issue-item[data-i="' + idx + '"]').trigger('click');
        };
        setTimeout(again, 150);
    }
});

// ===== Undo / redo =====
// The tree is plain data, so history is a stack of snapshots taken whenever a
// re-render finds the tree changed. Server data arriving (hydration, a drawer
// save) is applied "silently" so it doesn't become a step of its own.
function flowSerialize() {
    try { return JSON.stringify((window._flowData && window._flowData.flow) || [], function (k, v) { return k === '_provisional' ? undefined : v; }); }
    catch (e) { return ''; }
}
function flowHistoryTrack() {
    var now = flowSerialize();
    if (window._flowHistorySilent) { window._flowLastSnap = now; flowHistoryButtons(); return; }
    if (window._flowLastSnap != null && now !== window._flowLastSnap) {
        (window._flowUndo = window._flowUndo || []).push(window._flowLastSnap);
        if (window._flowUndo.length > 60) window._flowUndo.shift();
        window._flowRedo = [];
        window._flowDirty = true;
    }
    window._flowLastSnap = now;
    flowHistoryButtons();
}
function flowHistoryReset() {
    window._flowUndo = [];
    window._flowRedo = [];
    window._flowLastSnap = flowSerialize();
    window._flowDirty = false;
    flowHistoryButtons();
}
function flowHistoryButtons() {
    $('#flowUndo').prop('disabled', !(window._flowUndo || []).length);
    $('#flowRedo').prop('disabled', !(window._flowRedo || []).length);
}
function flowHistoryApply(snap) {
    try { window._flowData.flow = JSON.parse(snap); } catch (e) { return; }
    syncCurrentFlow();
    window._flowHistorySilent = true;
    reRenderFlow();
    window._flowHistorySilent = false;
    window._flowLastSnap = snap;
    flowMarkDirty();
    flowHistoryButtons();
}
function flowUndo() {
    var u = window._flowUndo || [];
    if (!u.length) return;
    (window._flowRedo = window._flowRedo || []).push(flowSerialize());
    flowHistoryApply(u.pop());
}
function flowRedo() {
    var r = window._flowRedo || [];
    if (!r.length) return;
    (window._flowUndo = window._flowUndo || []).push(flowSerialize());
    flowHistoryApply(r.pop());
}

// ===== Keyboard + selection =====
// Click a card to select it; Delete removes it, Escape closes whatever's
// open, Ctrl+Z / Ctrl+Y (or Ctrl+Shift+Z) undo and redo.
$(document).off('click.flowSelect').on('click.flowSelect', '.giant-flow-node', function (e) {
    if ($(e.target).closest('button, select, input, a, .giant-flow-agent-pill, .giant-flow-play').length) return;
    var was = $(this).hasClass('is-selected');
    $('.giant-flow-node').removeClass('is-selected');
    if (!was) $(this).addClass('is-selected');
});
$(document).off('keydown.flowKeys').on('keydown.flowKeys', function (e) {
    if (!$('#giantModal .modal-dialog.giant-modal-flow').length) return;
    if ($('#giantConfirmDialog').length) return;   // a confirm dialog owns the keyboard
    var t = e.target, tag = (t && t.tagName || '').toLowerCase();
    var typing = tag === 'input' || tag === 'textarea' || tag === 'select' || (t && t.isContentEditable);
    var mod = e.ctrlKey || e.metaKey;
    if (e.key === 'Escape') {
        if (window._flowEmbeddedEdit) { flowCloseDrawer(false); return; }
        $('.giant-flow-branch-dropdown, .giant-flow-keypad').remove();
        $('.giant-flow-branch-add').removeClass('is-armed');
        $('.giant-flow-node').removeClass('is-selected');
        flowPickClear();
        if ($('#flowWalkPanel').is(':visible')) flowWalkClose();
        if ($('#flowAnalyser').is(':visible')) flowAnalyseClose();
        return;
    }
    if (typing || window._flowEmbeddedEdit) return;
    if (mod && !e.shiftKey && (e.key === 'z' || e.key === 'Z')) { e.preventDefault(); flowUndo(); return; }
    if (mod && ((e.key === 'y' || e.key === 'Y') || (e.shiftKey && (e.key === 'z' || e.key === 'Z')))) { e.preventDefault(); flowRedo(); return; }
    if ((e.key === 'Delete' || e.key === 'Backspace') && window._flowEditing) {
        var $sel = $('.giant-flow-node.is-selected').first();
        if ($sel.length) { e.preventDefault(); $sel.find('.giant-flow-node-remove').first().trigger('click'); }
    }
});

// Member / agent pills: jump to that extension's card if it's in this flow,
// otherwise open it for editing.
$(document).off('click.flowAgent').on('click.flowAgent', '.giant-flow-agent-pill.is-link', function (e) {
    e.stopPropagation();
    var tag = String($(this).data('tag') || ''), name = String($(this).data('name') || '');
    if (!tag) return;
    var $card = $('.giant-flow-node[data-tag="' + tag + '"]').first();
    if ($card.length) {
        if (window._flowRevealEl) window._flowRevealEl($card[0], 60);
        $('.giant-flow-node').removeClass('is-selected');
        $card.addClass('is-selected is-flash');
        setTimeout(function () { $card.removeClass('is-flash'); }, 1600);
        return;
    }
    var parts = tag.split('-');
    flowEditNode(parts[0], parts.slice(1).join('-'), name);
});

// ===== Walk a call =====
// Step through the flow the way a call would: announcements and pass-through
// steps run on their own; at each decision (an IVR, a condition, a queue, a
// hunt list, an extension with exits) the panel offers that element's real
// exits as buttons. The path lights up as it goes. A compact repeat carries on
// through its full copy elsewhere in the tree.
function flowWalkOpen() {
    $('#flowWalkPanel').show();
    $('#flowWalk').addClass('is-active');
    flowWalkStart();
}
function flowWalkClose() {
    $('#flowWalkPanel').hide();
    $('#flowWalk').removeClass('is-active');
    flowWalkClear();
    window._flowWalkState = null;
}
function flowWalkClear() {
    $('#flowCanvas').removeClass('is-walking');
    $('.giant-flow-node, .giant-flow-link, .giant-flow-start').removeClass('is-walk is-walk-here');
    $('#flowCanvas svg.giant-flow-links .giant-flow-walk-arrow').remove();
    window._flowWalking = false;
    if (window._flowWalkState && $('#flowWalkPanel').is(':visible')) {
        // The tree changed under the walk: offer a restart rather than a stale trail.
        window._flowWalkState = null;
        $('#flowWalkBody').html('<div class="giant-flow-walk-msg">The flow changed. <button type="button" class="giant-btn-sm is-primary" id="flowWalkRestart">Walk again</button></div>');
    }
}
function flowWalkStart() {
    var flow = (window._flowData && window._flowData.flow) || [];
    var st = window._flowWalkState = { visited: ['start'], names: [], history: [], pending: null };
    var list = flow;
    // Focused on a branch: walk from the focused element, since that's what's drawn.
    if (window._flowFocusUid != null) {
        var fp = flowPathToUid(window._flowFocusUid);
        if (fp && fp.length) { flowWalkRun([fp[fp.length - 1].node], 0); return; }
    }
    if (flow.length === 1 && flow[0] && flow[0].type === 'DIDROOT') {
        var root = flow[0], ch0 = root.children || {};
        var uncond = !!(root.branchMeta && root.branchMeta.unconditional && root.branchMeta.unconditional.active) && (ch0.unconditional || []).length;
        list = uncond ? ch0.unconditional : (ch0.destination || []);
    }
    flowWalkRun(list, 0);
}
// A node's full copy: a compact repeat has no branches of its own here, but
// the same element drawn in full elsewhere does (the exits are the element's).
function flowWalkFull(n) {
    var hasKids = function (x) { return !!(x && x.children && Object.keys(x.children).length); };
    if (hasKids(n) && !(n.repeat && !n.expanded)) return n;
    var hit = null;
    (function walk(arr) {
        (arr || []).forEach(function (x) {
            if (hit || !x) return;
            if (x.tag === n.tag && x !== n && hasKids(x) && !(x.repeat && !x.expanded)) { hit = x; return; }
            if (x.children) Object.values(x.children).forEach(walk);
        });
    })((window._flowData && window._flowData.flow) || []);
    return hit || n;
}
function flowWalkRun(list, i) {
    var st = window._flowWalkState;
    if (!st) return;
    var guard = 0, last = null;
    while (i < (list || []).length && guard++ < 300) {
        var n = list[i];
        if (!n) { i++; continue; }
        st.visited.push(n._uid);
        st.names.push(n.name || n.tag);
        last = n;
        var full = flowWalkFull(n), ch = full.children || {};
        switch (n.type) {
            case 'IVR': case 'CONDITION': case 'QUEUE': case 'HUNTLIST': case 'EXT':
                return flowWalkAsk(n, full);
            case 'FLOW': case 'FEATURE':
                if ((ch[n.type] || []).length) return flowWalkRun(ch[n.type], 0);
                i++; continue;
            case 'PLAYBACK': case 'MUSICONHOLD':
                i++; continue;                                    // plays, then carries on
            default:
                return flowWalkEnd('The call ends at ' + (n.name || n.tag) + '.', false);
        }
    }
    if (!last && st.visited.length <= 1) return flowWalkEnd('This flow has no steps yet.', true);
    return flowWalkEnd('The call has nowhere else to go after ' + (st.names[st.names.length - 1] || 'the last step') + '.', true);
}
function flowWalkAsk(n, full) {
    var st = window._flowWalkState;
    var ch = full.children || {};
    var has = function (k) { return !!(ch[k] && ch[k].length); };
    var choices = [];
    if (n.type === 'IVR') {
        flowIvrKeyOrder.forEach(function (k) { if (has(k)) choices.push({ key: k, label: 'Press ' + flowKeyLabel(k), kind: 'key' }); });
        Object.keys(ch).forEach(function (k) { if (k.indexOf('CUSTOMIVR_') === 0 && has(k)) choices.push({ key: k, label: flowExitLabel(k) }); });
        choices.push({ key: 'IVR_TIMEOUT', label: 'No key pressed', dead: !has('IVR_TIMEOUT') });
        choices.push({ key: 'IVR_WRONG',   label: 'Wrong key',      dead: !has('IVR_WRONG') });
    } else if (n.type === 'CONDITION') {
        choices.push({ key: 'true',  label: 'It matches',       dead: !has('true') });
        choices.push({ key: 'false', label: 'It doesn\'t match', dead: !has('false') });
    } else if (n.type === 'QUEUE') {
        choices.push({ end: true, label: 'An agent answers' });
        [['QUEUE-TIMEOUT', 'Timeout'], ['QUEUE-EXITKEY', 'Caller presses the exit key'], ['QUEUE-NOBODYHOME', 'Nobody logged in'],
         ['QUEUE-NOFREEMEMBER', 'No free agent'], ['QUEUE-FULL', 'Queue is full'], ['QUEUE-ONCALLBACK', 'Caller asks for a callback']]
        .forEach(function (p) { if (has(p[0]) || p[0] === 'QUEUE-TIMEOUT') choices.push({ key: p[0], label: p[1], dead: !has(p[0]) }); });
    } else if (n.type === 'HUNTLIST') {
        choices.push({ end: true, label: 'Someone answers' });
        choices.push({ key: 'HUNTLIST-TIMEOUT', label: 'Nobody answers', dead: !has('HUNTLIST-TIMEOUT') });
    } else if (n.type === 'EXT') {
        choices.push({ end: true, label: 'They answer' });
        [['EXT-NOANSWER', 'No answer'], ['EXT-BUSY', 'Busy'], ['EXT-OFFLINE', 'Offline'], ['EXT-UNCONDITIONAL', 'Always diverted'], ['EXT-ONCONDITION', 'On condition']]
        .forEach(function (p) { if (has(p[0]) || p[0] === 'EXT-NOANSWER') choices.push({ key: p[0], label: p[1], dead: !has(p[0]) }); });
    }
    st.pending = { node: n, full: full, choices: choices, visitedLen: st.visited.length, namesLen: st.names.length };
    flowWalkRender('What happens at <b>' + $('<div>').text(n.name || n.tag).html() + '</b>?', choices, false);
    flowWalkPaint(n._uid);
}
function flowWalkEnd(msg, warn) {
    var st = window._flowWalkState;
    if (st) st.pending = null;
    flowWalkRender('<span class="' + (warn ? 'is-warn' : 'is-ok') + '"><i class="fa-solid ' + (warn ? 'fa-triangle-exclamation' : 'fa-flag-checkered') + '"></i> ' + $('<div>').text(msg).html() + '</span>', [], true);
    flowWalkPaint(st && st.visited.length ? st.visited[st.visited.length - 1] : null);
}
function flowWalkRender(question, choices, ended) {
    var st = window._flowWalkState || { names: [], history: [] };
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var trail = st.names.slice(-5).map(esc).join(' <i class="fa-solid fa-angle-right"></i> ');
    var html = '<div class="giant-flow-walk-trail"><i class="fa-solid fa-phone-volume"></i> Incoming call' + (trail ? ' <i class="fa-solid fa-angle-right"></i> ' + trail : '') + '</div>';
    html += '<div class="giant-flow-walk-q">' + question + '</div>';
    if (choices.length) {
        html += '<div class="giant-flow-walk-choices">';
        choices.forEach(function (c, i) {
            var cls = 'giant-flow-walk-choice' + (c.dead ? ' is-dead' : '') + (c.end ? ' is-end' : '') + (c.kind === 'key' ? ' is-key' : '');
            html += '<button type="button" class="' + cls + '" data-i="' + i + '" title="' + (c.dead ? 'Nothing is routed here — the call would have nowhere to go' : '') + '">'
                  + (c.dead ? '<i class="fa-solid fa-triangle-exclamation"></i>' : (c.end ? '<i class="fa-solid fa-phone"></i>' : ''))
                  + esc(c.label) + '</button>';
        });
        html += '</div>';
    }
    html += '<div class="giant-flow-walk-actions">';
    if ((st.history || []).length) html += '<button type="button" class="giant-btn-sm is-secondary" id="flowWalkBack"><i class="fa-solid fa-arrow-left" style="margin-bottom:0;"></i> Back a step</button> ';
    html += '<button type="button" class="giant-btn-sm is-secondary" id="flowWalkRestart"><i class="fa-solid fa-rotate-left" style="margin-bottom:0;"></i> ' + (ended ? 'Walk again' : 'Restart') + '</button>';
    html += '</div>';
    $('#flowWalkBody').html(html);
}
function flowWalkPaint(hereUid) {
    var st = window._flowWalkState;
    if (!st) return;
    $('.giant-flow-node, .giant-flow-link, .giant-flow-start').removeClass('is-walk is-walk-here');
    $('.giant-flow-start').addClass('is-walk');
    var lit = 0;
    st.visited.forEach(function (u) { lit += $('.giant-flow-node[data-index="' + u + '"]').addClass('is-walk').length; });
    // Only dim the rest when there's a path on the canvas to stand out.
    $('#flowCanvas').toggleClass('is-walking', lit > 0);
    for (var i = 0; i < st.visited.length - 1; i++) {
        $('.giant-flow-link[data-from="' + st.visited[i] + '"][data-to="' + st.visited[i + 1] + '"]').addClass('is-walk');
    }
    if (hereUid != null) {
        var $here = $('.giant-flow-node[data-index="' + hereUid + '"]').addClass('is-walk-here');
        if ($here.length && window._flowRevealEl) window._flowRevealEl($here[0], 80);
    }
    flowWalkArrows(hereUid);
    window._flowWalking = true;
}
// Small arrows travelling along every link of the walked path, brightest on
// the segment that leads to the step the walk is at.
function flowWalkArrows(hereUid) {
    var svg = document.querySelector('#flowCanvas svg.giant-flow-links');
    if (!svg) return;
    var NS = 'http://www.w3.org/2000/svg';
    Array.prototype.slice.call(svg.querySelectorAll('.giant-flow-walk-arrow')).forEach(function (el) { el.parentNode.removeChild(el); });
    var reduce = false;
    try { reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
    if (reduce) return;
    var walked = svg.querySelectorAll('path.giant-flow-link.is-walk');
    for (var i = 0; i < walked.length; i++) {
        var p = walked[i], d = p.getAttribute('d');
        var len = 200;
        try { len = p.getTotalLength(); } catch (e) {}
        var here  = hereUid != null && p.getAttribute('data-to') === String(hereUid);
        var count = Math.max(1, Math.min(3, Math.round(len / 110)));
        var dur   = Math.max(0.9, len / 160);
        for (var k = 0; k < count; k++) {
            var poly = document.createElementNS(NS, 'polygon');
            poly.setAttribute('points', here ? '-9,-5.5 5,0 -9,5.5' : '-7,-4.5 4,0 -7,4.5');
            poly.setAttribute('class', 'giant-flow-walk-arrow' + (here ? ' is-here' : ''));
            var am = document.createElementNS(NS, 'animateMotion');
            am.setAttribute('dur', dur.toFixed(2) + 's');
            am.setAttribute('begin', (-(dur * k / count)).toFixed(2) + 's');
            am.setAttribute('repeatCount', 'indefinite');
            am.setAttribute('rotate', 'auto');
            am.setAttribute('path', d);
            poly.appendChild(am);
            svg.appendChild(poly);
        }
    }
}
$(document).off('click.flowWalkChoice').on('click.flowWalkChoice', '.giant-flow-walk-choice', function (e) {
    e.preventDefault();
    var st = window._flowWalkState;
    if (!st || !st.pending) return;
    var c = st.pending.choices[+$(this).data('i')];
    if (!c) return;
    var n = st.pending.node, full = st.pending.full;
    st.history.push({ node: n, full: full, visitedLen: st.pending.visitedLen, namesLen: st.pending.namesLen });
    if (c.end)  return flowWalkEnd('The call is answered at ' + (n.name || n.tag) + '.', false);
    if (c.dead) return flowWalkEnd('Nothing is routed for "' + c.label + '" on ' + (n.name || n.tag) + ' — the call has nowhere to go.', true);
    flowWalkRun((full.children || {})[c.key] || [], 0);
});
$(document).off('click.flowWalkNav').on('click.flowWalkNav', '#flowWalkBack, #flowWalkRestart', function (e) {
    e.preventDefault();
    if (this.id === 'flowWalkRestart') { flowWalkStart(); return; }
    var st = window._flowWalkState;
    if (!st || !st.history.length) return;
    var h = st.history.pop();
    st.visited.length = h.visitedLen;
    st.names.length   = h.namesLen;
    flowWalkAsk(h.node, h.full);
});

// ===== Minimap =====
// The tree's cards drawn small in the corner, with the viewport's window over
// them; click or drag to move. Hidden when the whole tree already fits.
function flowDrawMinimap() {
    var mm = document.getElementById('flowMinimap'), canvas = document.getElementById('flowCanvas'), chain = document.getElementById('flowChain'), vp = document.getElementById('flowViewport');
    if (!mm || !canvas || !chain || !vp || window._flowChunkBusy) return;
    var cr = canvas.getBoundingClientRect();
    var z  = (canvas.offsetWidth && cr.width) ? cr.width / canvas.offsetWidth : (window._flowZoom || 1);
    var chr = chain.getBoundingClientRect();
    var W = chr.width / z, H = chr.height / z;           // tree size, layout px
    var vw = vp.clientWidth, vh = vp.clientHeight;
    var zoom = window._flowZoom || 1;
    if (!W || !H || (W * zoom <= vw && H * zoom <= vh)) { mm.style.display = 'none'; return; }
    mm.style.display = 'block';
    var pad = 6, s = Math.min((mm.width - pad * 2) / W, (mm.height - pad * 2) / H);
    var ox = pad + ((mm.width - pad * 2) - W * s) / 2, oy = pad + ((mm.height - pad * 2) - H * s) / 2;
    var ctx = mm.getContext('2d');
    ctx.clearRect(0, 0, mm.width, mm.height);
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(0, 0, mm.width, mm.height);
    var cards = canvas.querySelectorAll('.giant-flow-node, .giant-flow-start, .giant-flow-ghost');
    for (var i = 0; i < cards.length; i++) {
        var r = cards[i].getBoundingClientRect();
        var x = ox + (r.left - chr.left) / z * s, y = oy + (r.top - chr.top) / z * s, w = Math.max(2, r.width / z * s), h = Math.max(2, r.height / z * s);
        ctx.fillStyle = cards[i].classList.contains('giant-flow-start') ? '#00d9a7' : (cards[i].classList.contains('giant-flow-ghost') ? '#e5e7eb' : (cards[i].classList.contains('is-walk') ? '#00b88d' : '#c7d0da'));
        ctx.fillRect(x, y, w, h);
    }
    // The viewport's window, in layout px: top-left = -pan / zoom
    var vx = ox + (-(window._flowPanX || 0) / zoom) * s, vy = oy + (-(window._flowPanY || 0) / zoom) * s;
    var vwm = vw / zoom * s, vhm = vh / zoom * s;
    ctx.strokeStyle = '#00d9a7'; ctx.lineWidth = 1.5;
    ctx.fillStyle = 'rgba(0,217,167,0.10)';
    ctx.fillRect(vx, vy, vwm, vhm);
    ctx.strokeRect(vx, vy, vwm, vhm);
    mm._map = { ox: ox, oy: oy, s: s };
}
(function () {
    var dragging = false;
    var go = function (mm, e) {
        var m = mm._map; if (!m || !window._flowCenterOn) return;
        var r = mm.getBoundingClientRect();
        var mx = e.clientX - r.left, my = e.clientY - r.top;
        window._flowCenterOn((mx - m.ox) / m.s, (my - m.oy) / m.s);
    };
    $(document).off('mousedown.flowMini').on('mousedown.flowMini', '#flowMinimap', function (e) { e.preventDefault(); e.stopPropagation(); dragging = true; go(this, e); });
    $(document).off('mousemove.flowMini').on('mousemove.flowMini', function (e) { if (dragging) { var mm = document.getElementById('flowMinimap'); if (mm) go(mm, e); } });
    $(document).off('mouseup.flowMini').on('mouseup.flowMini', function () { dragging = false; });
})();

// ===== Follow a branch =====
// Hover an exit row on a card, or a lane's pill, and the whole lane lights up
// together: the row, the pill and the curve between them. Click to keep it
// lit and bring the other end into view; click again, Escape, or a click
// elsewhere lets go.
function flowLaneEls(uid, branch) {
    var $canvas = $('#flowCanvas');
    var same = function (attr, val) { return function () { return $(this).attr(attr) === val; }; };
    var rows  = $canvas.find('.giant-flow-node').filter(same('data-index', String(uid))).children('.giant-flow-exits').children('.giant-flow-exit').filter(same('data-branch', branch));
    var lanes = $canvas.find('.giant-flow-branches').filter(same('data-owner', String(uid))).children('.giant-flow-branch').filter(same('data-branch', branch));
    var key   = String(uid) + ':' + branch;
    var links = $canvas.find('svg.giant-flow-links [data-lane]').filter(function () { return this.getAttribute('data-lane') === key; });
    return { rows: rows, lanes: lanes, links: links };
}
function flowLaneLight(uid, branch, on, cls) {
    var els = flowLaneEls(uid, branch);
    els.rows.toggleClass(cls, on);
    els.lanes.toggleClass(cls, on);
    els.links.each(function () { this.classList.toggle(cls, on); });
}
// Which lane an element speaks for: a row names its card and branch, a pill its lane.
function flowLaneOf($el) {
    var $row = $el.closest('.giant-flow-exit');
    if ($row.length && !$row.hasClass('giant-flow-exit-add')) {
        return { uid: String($row.closest('.giant-flow-node').attr('data-index') || ''), branch: $row.attr('data-branch') || '' };
    }
    var $lane = $el.closest('.giant-flow-branch');
    if ($lane.length) return { uid: String($lane.closest('.giant-flow-branches').attr('data-owner') || ''), branch: $lane.attr('data-branch') || '' };
    return null;
}
function flowPickApply() {
    var p = window._flowPick;
    $('#flowCanvas').toggleClass('has-pick', !!p);
    if (p) flowLaneLight(p.uid, p.branch, true, 'is-picked');
}
function flowPickClear() {
    var p = window._flowPick;
    if (p) flowLaneLight(p.uid, p.branch, false, 'is-picked');
    window._flowPick = null;
    $('#flowCanvas').removeClass('has-pick');
}
$(document).off('.flowLane')
    .on('mouseenter.flowLane', '.giant-flow-exit, .giant-flow-branch-label', function () {
        var k = flowLaneOf($(this)); if (k && k.uid) flowLaneLight(k.uid, k.branch, true, 'is-hot');
    })
    .on('mouseleave.flowLane', '.giant-flow-exit, .giant-flow-branch-label', function () {
        var k = flowLaneOf($(this)); if (k && k.uid) flowLaneLight(k.uid, k.branch, false, 'is-hot');
    })
    .on('click.flowLane', '.giant-flow-exit, .giant-flow-branch-label', function (e) {
        if ($(this).hasClass('giant-flow-exit-add') || $(e.target).closest('button, a, select, input').length) return;
        var k = flowLaneOf($(this)); if (!k || !k.uid) return;
        e.stopPropagation();
        var again = !!(window._flowPick && window._flowPick.uid === k.uid && window._flowPick.branch === k.branch);
        flowPickClear();
        if (again) return;
        window._flowPick = k;
        flowPickApply();
        // The other end of the lane, into view: the pill from a row, the card from a pill.
        var els = flowLaneEls(k.uid, k.branch);
        var target = $(this).hasClass('giant-flow-exit')
            ? els.lanes.children('.giant-flow-branch-label')[0]
            : $('#flowCanvas .giant-flow-node').filter(function () { return $(this).attr('data-index') === k.uid; })[0];
        if (target && window._flowRevealEl) window._flowRevealEl(target, 40);
    })
    .on('click.flowLane', '#flowCanvas', function (e) {
        if (!$(e.target).closest('.giant-flow-exit, .giant-flow-branch-label').length) flowPickClear();
    });

// ===== IVR keypad (on the card) =====
var flowIvrKeyOrder = ['press_1', 'press_2', 'press_3', 'press_4', 'press_5', 'press_6', 'press_7', 'press_8', 'press_9', 'press_star', 'press_0', 'press_sharp'];
function flowKeyLabel(k) {
    return k === 'press_star' ? '*' : (k === 'press_sharp' ? '#' : String(k).replace('press_', ''));
}
// A queue's exits, in card order. The key is the destination typesrc.
var flowQueueExits = [
    { key: 'QUEUE-TIMEOUT',      icon: 'fa-clock',                 chip: 'timeout',    label: 'On timeout',            hint: 'The caller has waited the queue\'s limit' },
    { key: 'QUEUE-EXITKEY',      icon: 'fa-keyboard',              chip: 'exit key',   label: 'On exit key',           hint: 'The caller presses the exit key while waiting' },
    { key: 'QUEUE-NOBODYHOME',   icon: 'fa-user-slash',            chip: 'nobody in',  label: 'Nobody logged in',      hint: 'No agent is logged in to take calls' },
    { key: 'QUEUE-NOFREEMEMBER', icon: 'fa-user-clock',            chip: 'all busy',   label: 'No free agent',         hint: 'Every logged-in agent is on a call' },
    { key: 'QUEUE-FULL',         icon: 'fa-users-slash',           chip: 'full',       label: 'Queue full',            hint: 'The queue already holds its maximum waiting callers' },
    { key: 'QUEUE-ONCALLBACK',   icon: 'fa-phone-arrow-down-left', chip: 'callback',   label: 'On callback',           hint: 'The caller asks to be called back instead of waiting' },
];
function flowQueueFreeExits(node) {
    var used = Object.keys((node && node.children) || {});
    return flowQueueExits.filter(function (x) { return used.indexOf(x.key) === -1; });
}
// Seconds as people say them: 45s, 2 min, 2m 30s.
function flowSecs(n) {
    n = parseInt(n, 10) || 0;
    if (n < 60) return n + 's';
    return (n % 60) ? Math.floor(n / 60) + 'm ' + (n % 60) + 's' : (n / 60) + ' min';
}
// Keys and exits an IVR doesn't route yet.
function flowIvrFreeKeys(node) {
    var used = Object.keys((node && node.children) || {});
    var free = flowIvrKeyOrder.filter(function (k) { return used.indexOf(k) === -1; });
    if (used.indexOf('IVR_TIMEOUT') === -1) free.push('IVR_TIMEOUT');
    if (used.indexOf('IVR_WRONG')   === -1) free.push('IVR_WRONG');
    return free;
}
function flowKeypadHtml(node) {
    var used = Object.keys((node && node.children) || {});
    var esc  = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    // A queue has no keypad: its picker is just the exits not routed yet.
    if (node && node.type === 'QUEUE') {
        var qhtml = '<div class="giant-flow-keypad" data-index="' + node._uid + '">';
        qhtml += '<div class="giant-flow-keypad-title">Add an exit</div>';
        qhtml += '<div class="giant-flow-keypad-extras is-first">';
        flowQueueFreeExits(node).forEach(function (x) {
            qhtml += '<button type="button" data-key="' + x.key + '" title="' + esc(x.hint) + '"><i class="fa-solid ' + x.icon + '"></i> ' + esc(x.label) + '</button>';
        });
        qhtml += '</div>';
        qhtml += '<div class="giant-flow-branch-hint">Pick what happens, then choose where the caller goes</div>';
        qhtml += '</div>';
        return qhtml;
    }
    var html = '<div class="giant-flow-keypad" data-index="' + node._uid + '">';
    html += '<div class="giant-flow-keypad-title">Add a key press</div>';
    html += '<div class="giant-flow-keypad-grid">';
    flowIvrKeyOrder.forEach(function (k) {
        var isUsed = used.indexOf(k) > -1;
        html += '<button type="button" class="giant-flow-keypad-key' + (isUsed ? ' is-used' : '') + '" data-key="' + k + '"' + (isUsed ? ' disabled title="Already routed"' : ' title="Route key ' + flowKeyLabel(k) + '"') + '>' + flowKeyLabel(k) + '</button>';
    });
    html += '</div>';
    var extras = [];
    if (used.indexOf('IVR_TIMEOUT') === -1) extras.push(['IVR_TIMEOUT', '<i class="fa-solid fa-clock"></i> On timeout (no key pressed)']);
    if (used.indexOf('IVR_WRONG')   === -1) extras.push(['IVR_WRONG',   '<i class="fa-solid fa-ban"></i> Invalid input']);
    if (extras.length) {
        html += '<div class="giant-flow-keypad-extras">';
        extras.forEach(function (x) { html += '<button type="button" data-key="' + x[0] + '">' + x[1] + '</button>'; });
        html += '</div>';
    }
    html += '<div class="giant-flow-branch-hint">Pick a key, then choose where it goes</div>';
    html += '</div>';
    return html;
}
$(document).off('click.flowKeyAdd').on('click.flowKeyAdd', '.giant-flow-key-add', function (e) {
    e.preventDefault();
    e.stopPropagation();
    var $card = $(this).closest('.giant-flow-node');
    var f = flowFindByUid($(this).data('index'));
    if (!f) return;
    if ($card.next('.giant-flow-keypad').length) { $card.next('.giant-flow-keypad').remove(); return; }
    $('.giant-flow-keypad, .giant-flow-branch-dropdown').remove();
    $('.giant-flow-branch-add').removeClass('is-armed');
    $card.after(flowKeypadHtml(f.node));
    // Readable size, fully in view.
    if (window._flowZoomAt && (window._flowZoom || 1) < 1) {
        var vp = document.getElementById('flowViewport'), vr = vp ? vp.getBoundingClientRect() : null, br = this.getBoundingClientRect();
        if (vr) window._flowZoomAt(1, br.left + br.width / 2 - vr.left, br.top + br.height / 2 - vr.top);
    }
    if (window._flowRevealEl) window._flowRevealEl($card.next('.giant-flow-keypad')[0], 24);
});
$(document).off('click.flowKeypad').on('click.flowKeypad', '.giant-flow-keypad button[data-key]', function (e) {
    e.preventDefault();
    e.stopPropagation();
    var $pad = $(this).closest('.giant-flow-keypad');
    var f = flowFindByUid($pad.data('index'));
    if (!f) return;
    var key = String($(this).data('key'));
    if (!f.node.children) f.node.children = {};
    if (!f.node.children[key]) { f.node.children[key] = []; window._flowFreshBranch = { uid: f.node._uid, key: key }; }
    var ts = flowBranchTypeSrc(f.node, key), id = f.node.id;
    reRenderFlow();
    flowMarkDirty();
    // Straight on to "where does it go": open the new branch's picker.
    setTimeout(function () {
        $('.giant-flow-branch-add.giant-flow-ghost[data-typesrc="' + ts + '"][data-typeidsrc="' + id + '"]').first().trigger('click');
    }, 80);
});

// ===== Click-to-play announcements =====
// One shared player: press the play button on an announcement's card or
// library widget to hear it, press again to pause. The audio streams through
// the same action the media tile uses (with its storage failover), so it's
// the file callers actually hear.
function flowPlayMedia(id) {
    id = String(id);
    var cur = window._flowAudio;
    if (cur && cur.id === id) {
        if (cur.audio.paused) cur.audio.play(); else cur.audio.pause();
        return;
    }
    flowStopMedia();
    var sel = '.giant-flow-play[data-id="' + id + '"]';
    $(sel).addClass('is-loading').html('<i class="fa-solid fa-spinner fa-spin"></i>');

    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.pbxConfig.endpoint, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.responseType = 'blob';
    xhr.onload = function () {
        $(sel).removeClass('is-loading');
        if (xhr.status !== 200 || !xhr.response || !xhr.response.size) {
            $(sel).html('<i class="fa-solid fa-play"></i>');
            flowNotice(xhr.status === 404 ? 'That announcement has no audio to play yet.' : 'Couldn\'t load that announcement.', 'error');
            return;
        }
        var url   = URL.createObjectURL(xhr.response);
        var audio = new Audio(url);
        window._flowAudio = { id: id, audio: audio, url: url };
        var setPlaying = function (on) {
            $(sel).toggleClass('is-playing', on).html(on ? '<i class="fa-solid fa-pause"></i>' : '<i class="fa-solid fa-play"></i>');
        };
        audio.onplay  = function () { setPlaying(true); };
        audio.onpause = function () { setPlaying(false); };
        audio.onended = function () { flowStopMedia(); };
        audio.onerror = function () { flowNotice('Couldn\'t play that announcement.', 'error'); flowStopMedia(); };
        audio.play();
    };
    xhr.onerror = function () {
        $(sel).removeClass('is-loading').html('<i class="fa-solid fa-play"></i>');
        flowNotice('Couldn\'t load that announcement.', 'error');
    };
    xhr.send(pbxApi.body('pbxAction=playMedia&itemId=' + encodeURIComponent(id)));
}

function flowStopMedia() {
    var cur = window._flowAudio;
    if (cur) {
        try { cur.audio.pause(); } catch (e) {}
        try { URL.revokeObjectURL(cur.url); } catch (e) {}
    }
    window._flowAudio = null;
    $('.giant-flow-play').removeClass('is-playing is-loading').html('<i class="fa-solid fa-play"></i>');
}

// After a re-render the buttons are new — show the one that's still playing.
function flowSyncPlayButtons() {
    var cur = window._flowAudio;
    if (!cur || cur.audio.paused) return;
    $('.giant-flow-play[data-id="' + cur.id + '"]').addClass('is-playing').html('<i class="fa-solid fa-pause"></i>');
}

$(document).off('click.flowPlay').on('click.flowPlay', '.giant-flow-play', function (e) {
    e.preventDefault();
    e.stopPropagation();
    flowPlayMedia($(this).data('id'));
});

// ===== Beta notice =====
// The builder is still in beta: say so in the number list and in the builder
// itself, dismissable once per browser (the Beta pills stay).
function flowBetaStrip() {
    var dismissed = false;
    try { dismissed = localStorage.getItem('giantFlowBetaDismissed') === '1'; } catch (e) {}
    if (dismissed) return '';
    return '<div class="giant-flow-beta" role="note">'
         + '<span class="modal-beta-pill">Beta</span>'
         + '<div class="giant-flow-beta-text"><b>The call flow builder isn\'t finished yet.</b> It can occasionally show or save a route that isn\'t quite right. Please double-check important changes until the full release.</div>'
         + '<button type="button" class="giant-flow-beta-dismiss" title="Got it, hide this"><i class="fa-solid fa-xmark"></i></button>'
         + '</div>';
}
$(document).off('click.flowBeta').on('click.flowBeta', '.giant-flow-beta-dismiss', function () {
    try { localStorage.setItem('giantFlowBetaDismissed', '1'); } catch (e) {}
    $(this).closest('.giant-flow-beta').slideUp(160, function () { $(this).remove(); flowFitViewport(); });
});

// ===== Layout direction =====
// Left-to-right by default on desktop (call flows are wide, not deep: an IVR
// fans out into a dozen exits, chains are short, and cards are wide), top-down
// on narrow screens. A toggle beside the zoom controls remembers the choice.
function flowLayoutIsH() {
    try {
        var s = localStorage.getItem('giantFlowLayout');
        if (s === 'h') return true;
        if (s === 'v') return false;
    } catch (e) {}
    return window.innerWidth >= 900;
}
function flowLayoutButtonState($btn, horizontal) {
    $btn.attr('title', horizontal ? 'Left to right — switch to top-down' : 'Top-down — switch to left to right')
        .find('i').attr('class', 'fa-solid ' + (horizontal ? 'fa-arrows-left-right' : 'fa-arrows-up-down'));
}

// ===== Fullscreen fit =====
// The builder's modal fills the screen; measure where the canvas (or the
// loader) starts and let it run to the bottom, whatever the header height.
function flowFitViewportNow() {
    var $dlg = $('#giantModal .modal-dialog');
    if (!$dlg.length || !$dlg.hasClass('giant-modal-flow')) return;
    var pad = 0;   // fullscreen: the canvas runs to the bottom edge
    var $vp = $('#flowViewport, .giant-flow-loader').first();
    if ($vp.length) {
        var vh = Math.max(320, Math.floor(window.innerHeight - $vp[0].getBoundingClientRect().top - pad));
        $dlg[0].style.setProperty('--giant-flow-vh', vh + 'px');
    }
    var $lib = $('#flowLibrary');
    if ($lib.length) {
        var lh = Math.max(240, Math.floor(window.innerHeight - $lib[0].getBoundingClientRect().top - pad));
        $dlg[0].style.setProperty('--giant-flow-lh', lh + 'px');
    }
    if (window._flowCenterIfFits) window._flowCenterIfFits();   // the canvas just changed size
}
// Measure now and once more shortly after, in case a layout transition (the
// modal's fade-in, a font swap) was still settling on the first pass.
function flowFitViewport() {
    flowFitViewportNow();
    clearTimeout(window._flowFitTimer);
    window._flowFitTimer = setTimeout(function () {
        flowFitViewportNow();
        fixBranchConnectors();   // redraw the links once fonts/icons have settled
    }, 350);
}
$(window).off('resize.flowFit').on('resize.flowFit', function () { flowFitViewport(); });

// ===== Branded loader =====
// A small animated flow of its own, over a progress bar that eases toward the
// end while the tree is fetched and snaps to 100% when it arrives. The step
// text tracks the phases the server actually goes through.
var flowLoaderSteps = [
    [0,   'Reading the number\'s routing…'],
    [24,  'Following every branch and exit…'],
    [46,  'Resolving names, members and agents…'],
    [70,  'Laying out the flow…'],
    [84,  'Drawing the canvas…'],
    [100, 'Ready']
];

function flowLoaderSvg() {
    var reduce = false;
    try { reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
    var s = '<svg viewBox="0 0 240 132" width="240" height="132" aria-hidden="true">';
    // Pill centred on the trunk (x=120), wide enough for the label in any font.
    s += '<rect class="gfl-start" x="70" y="6" width="100" height="22" rx="11"/>';
    s += '<g transform="translate(-11 0)"><path class="gfl-ico" d="M92 13.5c0-.6.4-1.1 1-1.2l2.3-.4c.5-.1 1 .2 1.2.7l.9 2.1c.2.4.1.9-.2 1.2l-1 1c.7 1.4 1.8 2.5 3.2 3.2l1-1c.3-.3.8-.4 1.2-.2l2.1.9c.5.2.8.7.7 1.2l-.4 2.3c-.1.6-.6 1-1.2 1-6.1 0-10.8-4.7-10.8-10.8z"/></g>';
    s += '<text class="gfl-start-txt" x="130" y="20.5" text-anchor="middle">Incoming call</text>';
    s += '<path class="gfl-line" d="M120 28 V52"/>';
    s += '<rect class="gfl-node gfl-n1" x="88" y="52" width="64" height="26" rx="7"/>';
    s += '<path class="gfl-line" d="M120 78 V90 M40 90 H200 M40 90 V102 M120 90 V102 M200 90 V102"/>';
    s += '<rect class="gfl-node gfl-n2" x="10" y="102" width="60" height="24" rx="7"/>';
    s += '<rect class="gfl-node gfl-n3" x="90" y="102" width="60" height="24" rx="7"/>';
    s += '<rect class="gfl-node gfl-n4" x="170" y="102" width="60" height="24" rx="7"/>';
    if (!reduce) {
        s += '<circle class="gfl-dot" r="3"><animateMotion dur="1.6s" repeatCount="indefinite" path="M120 28 V52"/></circle>';
        s += '<circle class="gfl-dot" r="3"><animateMotion dur="1.6s" begin="0.5s" repeatCount="indefinite" path="M120 78 V90 H40 V102"/></circle>';
        s += '<circle class="gfl-dot" r="3"><animateMotion dur="1.6s" begin="0.7s" repeatCount="indefinite" path="M120 78 V102"/></circle>';
        s += '<circle class="gfl-dot" r="3"><animateMotion dur="1.6s" begin="0.9s" repeatCount="indefinite" path="M120 78 V90 H200 V102"/></circle>';
    }
    s += '</svg>';
    return s;
}

// The loader is an overlay over the modal body: the builder draws underneath
// it, and it only reaches 100% and fades once the canvas is fully drawn.
function flowShowLoader($container, title) {
    flowLoaderStop();
    $container.children().remove();
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    var html = ''
      + '<div class="giant-flow-loader-overlay" id="flowLoaderOverlay">'
      + '<div class="giant-flow-loader" role="status" aria-live="polite">'
      + '<div class="giant-flow-loader-art">' + flowLoaderSvg() + '</div>'
      + '<div class="giant-flow-loader-title">' + esc(title || 'Building your call flow') + '</div>'
      + '<div class="giant-flow-loader-text" id="flowLoaderText">' + esc(flowLoaderSteps[0][1]) + '</div>'
      + '<div class="giant-flow-loader-bar"><div class="giant-flow-loader-fill" id="flowLoaderFill" style="width:0%"></div></div>'
      + '<div class="giant-flow-loader-pct" id="flowLoaderPct">0%</div>'
      + '</div>'
      + '</div>';
    $('#giantModal .modal-body').append(html);
    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
    var st = window._flowLoader = { pct: 0, t0: Date.now(), timer: null };
    st.timer = setInterval(function () {
        var elapsed = Date.now() - st.t0;
        flowLoaderSet(Math.max(st.pct, 66 * (1 - Math.exp(-elapsed / 1600))));   // eases toward 66% while the data is fetched
    }, 80);
}

// The data's here: stop the easing and jump to the drawing phase.
function flowLoaderStage(pct) {
    var st = window._flowLoader;
    if (!st) return;
    if (st.timer) { clearInterval(st.timer); st.timer = null; }
    flowLoaderSet(Math.max(st.pct, pct));
}

// Drawing progress: chunks landed vs still to come (the total grows as
// deeper levels are discovered, so this trends to 98% rather than jumping).
function flowLoaderChunkProgress(drawn, pending) {
    var st = window._flowLoader;
    if (!st) return;
    var total = drawn + pending;
    var pct = total ? 72 + 26 * (drawn / total) : 98;
    flowLoaderSet(Math.max(st.pct, Math.min(98, pct)));
}

// The canvas is fully drawn: 100%, then fade the overlay away.
function flowLoaderComplete() {
    var st = window._flowLoader;
    if (!st) return;
    if (st.timer) { clearInterval(st.timer); st.timer = null; }
    flowLoaderSet(100);
    $('#flowLoaderOverlay').addClass('is-done');
    setTimeout(function () {
        $('#flowLoaderOverlay').addClass('is-leaving');
        setTimeout(flowLoaderStop, 320);
    }, 260);
}

function flowLoaderSet(pct) {
    var st = window._flowLoader;
    if (!st) return;
    st.pct = Math.min(100, pct);
    var p = Math.round(st.pct);
    $('#flowLoaderFill').css('width', p + '%');
    $('#flowLoaderPct').text(p + '%');
    var label = flowLoaderSteps[0][1];
    flowLoaderSteps.forEach(function (s) { if (p >= s[0]) label = s[1]; });
    var $t = $('#flowLoaderText');
    if ($t.text() !== label) $t.text(label);
}

function flowLoaderStop() {
    var st = window._flowLoader;
    if (st && st.timer) clearInterval(st.timer);
    window._flowLoader = null;
    $('#flowLoaderOverlay').remove();
}

function flowLoaderFail(msg) {
    var st = window._flowLoader;
    if (st && st.timer) clearInterval(st.timer);
    window._flowLoader = null;
    var $l = $('#flowLoaderOverlay .giant-flow-loader').addClass('is-error');
    $('#flowLoaderText').text(msg || 'Couldn\'t load this flow.');
    $('#flowLoaderPct').text('');
    if (!$l.find('.giant-flow-loader-back').length) {
        var $back = $('<button type="button" class="btn btn-secondary giant-flow-loader-back"><i class="fa-solid fa-arrow-left" style="margin-bottom:0;"></i> Back to numbers</button>');
        $back.on('click', function () {
            $('#flowLoaderOverlay').remove();
            $('#giantModal .modal-dialog').removeClass('giant-modal-wide giant-modal-flow');
            refreshList('callFlow');
        });
        $l.append($back);
    }
}

function openCallFlowBuilder(typeSrc, typeIdSrc, displayName) {

    if (window._flowEmbeddedEdit) flowCloseDrawer(false);
    window._flowEditing = false;   // every flow opens in view mode; editing is switched on deliberately
    window._flowFocusUid = null;   // whole flow
    window._flowFitOnDone = true;  // fit once every chunk of a big tree has drawn
    var $container = $('#giantModalListTableDiv');
    $container.children().remove();
    // Fullscreen modal for the builder: canvas + Widget Library side by side
    $('#giantModal .modal-dialog').addClass('giant-modal-wide giant-modal-flow');
    flowShowLoader($container, 'Building the call flow for ' + (displayName || 'this number'));

    $.ajax({
        type: 'post',
        data: { pbxAction: 'getCallFlow', typeSrc: typeSrc, typeIdSrc: typeIdSrc },
        success: function(json) {
            var resp = flowParseJson(json);

            if (!resp || resp.error) {
                flowLoaderFail((resp && resp.error) || 'Couldn\'t load this flow.');
                return;
            }

            // The data's here; the rest of the bar is the drawing, which the
            // loader overlay covers until the last chunk has landed.
            flowLoaderStage(70);

            // Store for local re-renders
            window._flowData = resp;
            window._flowDisplayName = displayName;

            renderFlowBuilder($container, resp, displayName, typeSrc, typeIdSrc);
            $('.giantModalPanel').hide();
            $('#giantModalListDiv').show();
            $('#giantModal .modal-body').append($('#flowLoaderOverlay'));   // keep it on top of the freshly drawn builder
            fixBranchConnectors();
            flowFitViewport();
            flowHistoryReset();
            flowLiveStart();
            flowAuditPaint();
            // First view of a flow: start at 100% and, once fully drawn, scale
            // to its size (small flows up to 120%, big ones down to 50%) and
            // centre it — flowChunkDone does that and then completes the loader.
            window._flowZoom = 1; window._flowPanX = 0; window._flowPanY = 0;
            if (window._flowApplyTransform) window._flowApplyTransform();
        },
        error: function() {
            flowLoaderFail('Couldn\'t reach the server to load this flow. Check your connection and try again.');
        }
    });
}

// The array holding a flow's "main" steps. For a DID the top level is a
// synthetic DIDROOT whose "destination" lane is the normal routing, so adds,
// reorders and saves must target that lane rather than the root's siblings.
function flowMainArray() {
    var f = (window._flowData && window._flowData.flow) || [];
    if (f.length === 1 && f[0] && f[0].type === 'DIDROOT') {
        f[0].children = f[0].children || {};
        f[0].children.destination = f[0].children.destination || [];
        return f[0].children.destination;
    }
    return f;
}
function syncCurrentFlow() {
    window._currentFlow = flowMainArray().map(function(n) { return n.tag || (n.type + '-' + n.id); });
}

// Which typesrc a node's branch key saves to. The single source of truth for
// the renderer, the save collector and every add / drop path — a branch key is
// the typesrc itself for generic exits (QUEUE-TIMEOUT, EXT-BUSY, CUSTOMIVR_x,
// bare FLOW/FEATURE), with the few human keys (press_N, true/false, the DID
// lanes) mapped here.
function flowBranchTypeSrc(node, bKey) {
    if (!node || bKey == null) return '';
    bKey = String(bKey);
    if (node.type === 'IVR' && (bKey.indexOf('press_') === 0 || bKey === 'welcome')) {
        return bKey.replace('press_', 'IVR_').replace('welcome', 'IVR').toUpperCase();
    }
    if (node.type === 'CONDITION' && (bKey === 'true' || bKey === 'false')) return bKey === 'false' ? 'NOTCONDITION' : 'CONDITION';
    if (node.type === 'DIDROOT' && bKey === 'destination')   return 'DID';               // the DID's normal routing lane
    if (node.type === 'DIDROOT' && bKey === 'unconditional') return 'DID-UNCONDITIONAL'; // the DID's always-on route
    if (/^[A-Z]+([-_][A-Za-z0-9_]+)?$/.test(bKey)) return bKey;                          // generic exit: the key IS the typesrc
    return '';
}

// Append a step to the branch of the tree that saves to (typeSrc, typeIdSrc).
function flowAddToBranch(typeSrc, typeIdSrc, newNode) {
    function walk(nodes) {
        if (!nodes) return false;
        for (var i = 0; i < nodes.length; i++) {
            var n = nodes[i];
            if (!n.children) continue;
            var keys = Object.keys(n.children);
            for (var k = 0; k < keys.length; k++) {
                var bKey = keys[k];
                if (flowBranchTypeSrc(n, bKey) === String(typeSrc) && String(n.id) === String(typeIdSrc)) {
                    n.children[bKey].push(newNode);
                    return n;   // the parent, so callers can warn when it's shared
                }
                var deeper = walk(n.children[bKey]);
                if (deeper) return deeper;
            }
        }
        return null;
    }
    return walk((window._flowData && window._flowData.flow) || []);
}

function flowMarkDirty() {
    window._flowDirty = true;
    $('.giant-flow-save').html('<i class="fa-solid fa-floppy-disk" style="margin-bottom:0;"></i> Save Flow *').css('background', '#f59e0b').css('border-color', '#f59e0b');
}

// Leaving with unsaved changes — Back, the modal's close, or navigating away —
// asks first. Every change marks the flow dirty; opening or saving clears it.
// One dialog at a time: a second trigger while it's up shares the same answer.
function flowConfirmLeave() {
    if (!window._flowDirty) return Promise.resolve(true);
    if (window._flowLeavePrompt) return window._flowLeavePrompt;
    var p = giantConfirm({
        title: 'Leave without saving?',
        message: 'Your changes to this call flow haven\'t been saved and will be lost.',
        confirmText: 'Leave without saving',
        cancelText: 'Keep editing',
        danger: true
    });
    window._flowLeavePrompt = p;
    var clear = function () { if (window._flowLeavePrompt === p) window._flowLeavePrompt = null; };
    p.then(clear, clear);
    return p;
}
// Drop the builder's live state so the modal can close or go back to the list.
function flowTeardown() {
    window._flowDirty = false;
    window._flowLeavePrompt = null;
    try { flowStopMedia(); } catch (e) {}
    try { flowLiveStop(); } catch (e) {}
    try { if (window._flowEmbeddedEdit) flowCloseDrawer(false); } catch (e) {}
}
// Close the builder's modal for real. Bootstrap's own hide goes first; if the
// modal is somehow still up a beat later, press its close button, and as a last
// resort take it down by hand — "Leave without saving" must always leave.
function flowCloseModal() {
    var $m = $('#giantModal');
    var stillOpen = function () {
        var d = $m.data('bs.modal');
        if (d && (d._isShown === false || d.isShown === false)) return false;
        return $m.hasClass('show') || $m.hasClass('in') || $m.css('display') === 'block';
    };
    try { $m.modal('hide'); } catch (e) { console.error('Call flow: modal hide failed', e); }
    setTimeout(function () {
        if (!stillOpen()) return;
        try { $m.find('[data-dismiss="modal"]').first().trigger('click'); } catch (e) {}
        setTimeout(function () {
            if (!stillOpen()) return;
            console.warn('Call flow: modal would not close, taking it down by hand');
            $m.removeClass('show in').css('display', 'none').attr('aria-hidden', 'true');
            $('.modal-backdrop').remove();
            $('body').removeClass('modal-open').css({ 'padding-right': '', overflow: '' });
            $m.trigger('hidden.bs.modal');
        }, 300);
    }, 300);
}
$(document).off('hide.bs.modal.flowGuard').on('hide.bs.modal.flowGuard', '#giantModal', function (e) {
    if (!window._flowDirty || !$('#giantModal .modal-dialog').hasClass('giant-modal-flow')) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    flowConfirmLeave().then(function (ok) {
        if (!ok) return;
        flowTeardown();
        flowCloseModal();
    }).catch(function (err) { console.error('Call flow: leave failed', err); });
});
if (!window._flowUnloadGuard) {
    window._flowUnloadGuard = true;
    window.addEventListener('beforeunload', function (e) {
        if (window._flowDirty && $('#giantModal .modal-dialog.giant-modal-flow').length) { e.preventDefault(); e.returnValue = ''; return ''; }
    });
}

// Which tile's form edits which node type, and the row column that carries the id.
var flowEditTiles = {
    EXT:       { tile: 'extension',         idName: 'ex_id' },
    IVR:       { tile: 'ivr',               idName: 'iv_id' },
    QUEUE:     { tile: 'queue',             idName: 'qu_id' },
    HUNTLIST:  { tile: 'huntList',          idName: 'hu_id' },
    VOICEMAIL: { tile: 'voicemail',         idName: 'uniqueid' },
    CONDITION: { tile: 'condition',         idName: 'co_id' },
    PLAYBACK:  { tile: 'media',             idName: 'me_id' },
    CUSTOM:    { tile: 'customDestination', idName: 'cu_id' }
};

function flowParseJson(json) {
    try { return (typeof json === 'object') ? json : jQuery.parseJSON(json); } catch (e) { return {}; }
}

function flowCountDescendants(node) {
    var n = 0;
    Object.values((node && node.children) || {}).forEach(function (arr) {
        (arr || []).forEach(function (c) { n += 1 + flowCountDescendants(c); });
    });
    return n;
}

// A transient strip above the canvas: shared-object warnings, copy results, errors.
function flowNotice(msg, kind) {
    var $main = $('.giant-flow-main');
    if (!$main.length) return;
    $main.find('.giant-flow-notice').remove();
    var icon = kind === 'error' ? 'fa-circle-exclamation' : (kind === 'warn' ? 'fa-triangle-exclamation' : (kind === 'ok' ? 'fa-circle-check' : 'fa-circle-info'));
    var $n = $('<div class="giant-flow-notice"><i class="fa-solid ' + icon + '"></i><div class="giant-flow-notice-text"></div><button type="button" class="giant-flow-notice-close" title="Dismiss"><i class="fa-solid fa-xmark"></i></button></div>');
    if (kind) $n.addClass('is-' + kind);
    $n.find('.giant-flow-notice-text').text(msg);
    $n.find('.giant-flow-notice-close').on('click', function () { $n.remove(); });
    $main.prepend($n);
    clearTimeout(window._flowNoticeTimer);
    window._flowNoticeTimer = setTimeout(function () { $n.fadeOut(200, function () { $n.remove(); }); }, 9000);
}

// After a step is added under a node: if that node is shared, say so.
function flowAfterBranchAdd(parent) {
    if (parent && parent.refs > 1 && parent.type !== 'DIDROOT') {
        flowNotice('"' + (parent.name || parent.tag) + '" is used by ' + parent.refs + ' routes, so this step will apply to all of them. Use its copy button if this route should be different.', 'warn');
    }
}

// The add-target an armed "+" points at: a branch slot / ghost card (append
// to that branch), a card's port (insert right after that card), or the main
// lane of a non-number flow.
function flowTargetFromEl($el) {
    if (!$el || !$el.length) return null;
    return {
        typeSrc:   String($el.data('typesrc') || ''),
        typeIdSrc: String($el.data('typeidsrc') || ''),
        after:     ($el.data('after') != null && $el.data('after') !== '') ? String($el.data('after')) : null,
        main:      !!$el.data('main')
    };
}

// Find a node anywhere in the tree by its render id → { array, position, node }.
function flowFindByUid(uid) {
    var want = String(uid), hit = null;
    (function walk(arr) {
        for (var i = 0; i < arr.length && !hit; i++) {
            var n = arr[i];
            if (!n) continue;
            if (String(n._uid) === want) { hit = { array: arr, position: i, node: n }; return; }
            if (n.children) Object.values(n.children).forEach(function (b) { if (!hit) walk(b || []); });
        }
    })((window._flowData && window._flowData.flow) || []);
    return hit;
}

// The node whose branch saves to (typeSrc, typeIdSrc), or null.
function flowBranchOwner(typeSrc, typeIdSrc) {
    var found = null;
    (function walk(nodes) {
        (nodes || []).forEach(function (n) {
            if (found || !n || !n.children) return;
            Object.keys(n.children).forEach(function (k) {
                if (found) return;
                if (flowBranchTypeSrc(n, k) === String(typeSrc) && String(n.id) === String(typeIdSrc)) { found = n; return; }
                walk(n.children[k]);
            });
        });
    })((window._flowData && window._flowData.flow) || []);
    return found;
}

// Put a step where a target says: after a card, at the end of a branch, or on
// the main lane. Returns the branch's owning node (for the shared warning).
function flowAddAt(target, newNode) {
    if (!target) return null;
    if (target.after) {
        var f = flowFindByUid(target.after);
        if (f) {
            f.array.splice(f.position + 1, 0, newNode);
            return target.main ? null : flowBranchOwner(target.typeSrc, target.typeIdSrc);
        }
    }
    if (target.main) { flowMainArray().push(newNode); return null; }
    return flowAddToBranch(target.typeSrc, target.typeIdSrc, newNode);
}

// Pull in an element's own exits, members and share count the moment it's
// placed (a dropped widget starts as just a name), or to expand a repeat.
function flowHydrateNode(node, cb) {
    if (!node || !node.type || !node.id) return;
    var fail = function (msg) {
        // Put the card back the way it was (a repeat gets its "show steps"
        // button back) and say why, instead of spinning forever.
        if (node.repeat) node.expanded = false;
        window._flowHistorySilent = true;
        reRenderFlow();
        window._flowHistorySilent = false;
        flowNotice(msg, 'error');
    };
    $.ajax({
        type: 'post',
        timeout: 90000,
        data: { pbxAction: 'getFlowNode', objectType: node.type, objectId: node.id },
        success: function (json) {
            var r = flowParseJson(json);
            if (!r || !r.node) { fail((r && r.error) || 'The server didn\'t return that element\'s steps. Try again in a moment.'); return; }
            try {
                delete r.node.repeat;       // this instance is the one shown in full
                delete node._provisional;   // the real exits replace the placeholder slots
                $.extend(node, r.node);
                window._flowHistorySilent = true;   // server data arriving isn't an undo step
                reRenderFlow();
                window._flowHistorySilent = false;
                if (cb) cb(node);
            } catch (e) {
                window._flowHistorySilent = false;
                fail('Couldn\'t draw that element: ' + (e && e.message ? e.message : e));
            }
        },
        error: function (xhr, status) {
            fail(status === 'timeout' ? 'Loading that element\'s steps took too long. Try again in a moment.' : 'Couldn\'t load that element\'s steps. Check your connection and try again.');
        }
    });
}

// After an element was edited in the drawer: refresh every instance of it in
// the tree (in full where it's expanded, name/settings only where compact).
function flowRefreshNode(type, id) {
    var tag = String(type) + '-' + String(id);
    $.ajax({
        type: 'post',
        data: { pbxAction: 'getFlowNode', objectType: type, objectId: id },
        success: function (json) {
            var r = flowParseJson(json);
            if (!r || !r.node) { reRenderFlow(); return; }
            var fresh = r.node;
            delete fresh.repeat;
            var walk = function (nodes) {
                (nodes || []).forEach(function (n) {
                    if (!n) return;
                    if (n.tag === tag) {
                        var compact = !!(n.repeat && !n.expanded);
                        if (compact) {
                            n.name = fresh.name; n.refs = fresh.refs; n.extras = fresh.extras; n.agents = fresh.agents;
                        } else {
                            var keep = { _uid: n._uid, repeat: n.repeat, expanded: n.expanded, collapsed: n.collapsed };
                            Object.keys(n).forEach(function (k) { delete n[k]; });
                            $.extend(n, JSON.parse(JSON.stringify(fresh)), keep);
                        }
                    } else if (n.children) {
                        Object.values(n.children).forEach(walk);
                    }
                });
            };
            walk((window._flowData && window._flowData.flow) || []);
            syncCurrentFlow();
            window._flowHistorySilent = true;
            reRenderFlow();
            window._flowHistorySilent = false;
            flowNotice('Saved. "' + (fresh.name || tag) + '" is updated in this flow.', 'ok');
        },
        error: function () { reRenderFlow(); }
    });
}

// ===== Embedded edit drawer =====
// A node's normal form opens as a drawer over the library column, so the
// canvas never goes away. The form renderer hides every panel; CSS keeps the
// list panel (the builder) visible and turns the form/spinner/alert panels
// into the drawer while #giantModal carries .flow-embedded-edit.
function flowOpenDrawer(type, id, name) {
    window._flowEmbeddedEdit = { type: String(type), id: String(id), name: name || '' };
    window._flowReturnAfterSave = false;
    // The drawer is absolutely positioned inside the modal *body* (Bootstrap
    // makes it position:relative), so measure the canvas row from there —
    // measuring from .modal-content left a header-sized gap above the drawer.
    var $mb = $('#giantModal .modal-body'), $body = $('.giant-flow-body');
    var top = 0;
    if ($body.length && $mb.length) {
        top = Math.max(0, Math.round($body[0].getBoundingClientRect().top - $mb[0].getBoundingClientRect().top + $mb[0].scrollTop));
        $mb[0].style.setProperty('--giant-drawer-top', top + 'px');
    }
    $('#giantModal').addClass('flow-embedded-edit');
    $('.giant-flow-container').addClass('lib-collapsed');
    $('#giantFlowDrawerHead').remove();
    var $head = $('<div id="giantFlowDrawerHead" class="giant-flow-drawer-head"><div><div class="giant-flow-drawer-kicker">Editing</div><div class="giant-flow-drawer-title"></div></div><button type="button" class="giant-flow-drawer-close" title="Close without saving"><i class="fa-solid fa-xmark"></i></button></div>');
    $head.find('.giant-flow-drawer-title').text(name || type);
    $head.find('.giant-flow-drawer-close').on('click', function () { flowCloseDrawer(false); });
    $('#giantModalAddFormDiv').prepend($head);
}

function flowCloseDrawer(refresh) {
    var ctx = window._flowEmbeddedEdit;
    window._flowEmbeddedEdit = null;
    $('#giantFlowDrawerHead').remove();
    $('#giantModal').removeClass('flow-embedded-edit');
    $('#giantModalAddFormDiv, #giantModalSpinnerDiv, #giantModalAlertDiv').hide();
    $('#giantModalListDiv').show();
    var keepClosed = false;
    try { keepClosed = localStorage.getItem('giantFlowLib') === 'closed'; } catch (e) {}
    if (!keepClosed) $('.giant-flow-container').removeClass('lib-collapsed');
    fixBranchConnectors();
    if (refresh && ctx) {
        if (ctx.mode === 'add') flowAfterCreate(ctx);
        else flowRefreshNode(ctx.type, ctx.id);
    }
}

// Open a node's own edit form in the drawer. The form wants the element's
// list row, so fetch the tile's list and pick it by id (IVRs have a dedicated
// data action that also carries their key destinations).
function flowEditNode(type, id, name) {
    var spec = flowEditTiles[type];
    if (!spec || typeof editFormData === 'undefined' || !editFormData[spec.tile]) return;
    flowOpenDrawer(type, id, name);
    $('.giantModalPanel').hide();
    $('#giantModalSpinnerDiv').show();
    var open = function (row) {
        if (!row) { flowCloseDrawer(false); flowNotice("Couldn't load " + (name || 'this element') + ' for editing.', 'error'); return; }
        showForm(spec.tile, 'edit', editFormData[spec.tile], row);
    };
    if (type === 'IVR') {
        $.ajax({
            type: 'post', data: { pbxAction: 'getIvrData', iv_id: id },
            success: function (json) { var r = flowParseJson(json); open((r && r.data) ? r.data : { iv_id: id }); },
            error: function () { open(null); }
        });
        return;
    }
    var action = 'get' + spec.tile.charAt(0).toUpperCase() + spec.tile.slice(1) + 'List';
    $.ajax({
        type: 'post', data: { pbxAction: action },
        success: function (json) {
            var r = flowParseJson(json), rows = (r && r.data) ? Object.values(r.data) : [], row = null;
            rows.forEach(function (x) { if (!row && x && String(x[spec.idName]) === String(id)) row = x; });
            open(row);
        },
        error: function () { open(null); }
    });
}

// One-line blurb per widget type for the library (customer wording only).
var flowWidgetBlurbs = {
    EXT: 'Ring an extension', HUNTLIST: 'Ring each destination in turn', QUEUE: 'Hold callers for the next free agent',
    IVR: 'Play a menu and route on key press', VOICEMAIL: 'Take a message', PLAYBACK: 'Play a recording',
    CONDITION: 'Route by time, day or caller', CUSTOM: 'Forward to an external number', FLOW: 'Continue in another flow',
    MEETME: 'Join a conference room', SMS: 'Send a text message', DISA: 'Dial-through access', PAGING: 'Page a group',
    MUSICONHOLD: 'Play hold music', PARK: 'Park the call', FEATURE: 'Run a feature', SPECIAL: 'Hang up or play busy'
};

// The Widget Library: every routable object as a draggable card, grouped by
// type, with a search box and "create new" shortcuts. Rendered beside the
// canvas; its open/closed state and search survive re-renders.
function renderFlowLibrary(map) {
    var esc = function (s) { return $('<div>').text(s == null ? '' : s).html(); };
    var state = window._flowLibState = window._flowLibState || { q: '', closed: {} };
    var buckets = {};
    Object.entries(map || {}).forEach(function (e) {
        var tag  = String(e[0]);
        var type = tag.split('-')[0].toUpperCase();
        (buckets[type] = buckets[type] || []).push({ tag: tag, type: type, id: tag.split('-').slice(1).join('-'), name: String(e[1]) });
    });
    var order = (typeof destGroupOrder !== 'undefined' && destGroupOrder) ? destGroupOrder.slice() : [];
    Object.keys(buckets).forEach(function (t) { if (order.indexOf(t) === -1) order.push(t); });
    var total = Object.keys(map || {}).length;
    // Shared items (announcements, services, hold music) sit in their type's
    // group, badged "shared", and listed after the account's own.
    var globals = {};
    ((window._flowData && window._flowData.globals) || []).forEach(function (t) { globals[t] = true; });
    Object.keys(buckets).forEach(function (t) {
        buckets[t].sort(function (a, b) { return (globals[a.tag] ? 1 : 0) - (globals[b.tag] ? 1 : 0); });
    });

    var html = '<aside class="giant-flow-library" id="flowLibrary">';
    html += '<div class="giant-flow-lib-head">';
    html += '<div><div class="giant-flow-lib-title"><i class="fa-duotone fa-grid-2-plus"></i> Widget Library</div>';
    html += '<div class="giant-flow-lib-sub">Drag a widget onto the flow, or press + to add it to the step you last opened.</div></div>';
    html += '<button type="button" class="giant-flow-lib-toggle" title="Hide the library"><i class="fa-solid fa-angles-right"></i></button>';
    html += '</div>';
    html += '<button type="button" class="giant-flow-lib-tab" title="Show the widget library"><i class="fa-duotone fa-grid-2-plus"></i><span>Widgets</span></button>';
    html += '<div class="giant-flow-lib-search"><label class="giant-flow-lib-search-box" for="flowLibSearch"><i class="fa-solid fa-magnifying-glass"></i><input type="search" id="flowLibSearch" placeholder="Search ' + total + ' widget' + (total === 1 ? '' : 's') + '…" value="' + esc(state.q) + '" autocomplete="off"></label></div>';
    html += '<div class="giant-flow-lib-new"><span>Create new</span>';
    Object.keys(flowCreateTiles).forEach(function (tile) {
        if (typeof addFormData === 'undefined' || !addFormData[tile]) return;   // only what this account can create
        var t = flowCreateTiles[tile];
        html += '<button type="button" class="giant-flow-lib-newbtn" data-tile="' + tile + '" title="Create a new ' + esc(t.label.toLowerCase()) + ' without leaving the flow"><i class="fa-duotone ' + t.icon + '"></i> ' + esc(t.label) + '</button>';
    });
    html += '</div>';
    html += '<div class="giant-flow-lib-body">';
    // Shared items missing altogether: say so, with the reason for support on hover.
    var st = window._flowData && window._flowData.sharedStatus;
    if (st && (st.media + st.services + st.holdMusic) === 0) {
        var why = Object.keys(st.errors || {}).map(function (k) { return k + ' — ' + st.errors[k]; }).join('\n');
        if (window.console && console.warn) console.warn('Shared library unavailable', st);
        html += '<div class="giant-flow-lib-note" title="' + esc(why || 'Both the shared-library sources returned nothing.') + '"><i class="fa-solid fa-triangle-exclamation"></i> Shared announcements, services and hold music couldn\'t be loaded right now.</div>';
    }
    order.forEach(function (type) {
        var items = buckets[type];
        if (!items || !items.length) return;
        var gName = (typeof destGroupNames !== 'undefined' && destGroupNames && destGroupNames[type]) || flowTypeLabels[type] || type;
        var icon  = flowTypeIcons[type] || 'fa-circle-nodes';
        var iconClass = 'type-' + (['EXT','IVR','QUEUE','HUNTLIST','PLAYBACK','VOICEMAIL','CONDITION','CUSTOM'].indexOf(type) > -1 ? type : 'default');
        html += '<div class="giant-flow-lib-group' + (state.closed[type] ? ' is-closed' : '') + '" data-type="' + esc(type) + '">';
        html += '<button type="button" class="giant-flow-lib-gh"><i class="fa-solid fa-chevron-down"></i><span>' + esc(gName) + '</span><em>' + items.length + '</em></button>';
        html += '<div class="giant-flow-lib-items">';
        items.forEach(function (it) {
            var isGlobal = !!globals[it.tag];
            html += '<div class="giant-flow-widget' + (isGlobal ? ' is-global' : '') + '" draggable="' + (window._flowEditing ? 'true' : 'false') + '" data-tag="' + esc(it.tag) + '" data-type="' + esc(type) + '" data-id="' + esc(it.id) + '" data-name="' + esc(it.name) + '" data-search="' + esc((it.name + ' ' + gName + ' ' + type + (isGlobal ? ' shared library' : '')).toLowerCase()) + '" title="' + (isGlobal ? 'Shared with every account — drag onto the flow' : 'Drag onto the flow') + '">';
            html += '<div class="giant-flow-node-icon ' + iconClass + '"><i class="fa-duotone ' + icon + '"></i></div>';
            html += '<div class="giant-flow-widget-body"><div class="giant-flow-widget-name">' + esc(it.name) + (isGlobal ? ' <span class="giant-flow-sys" title="Shared with every account">shared</span>' : '') + '</div><div class="giant-flow-widget-blurb">' + esc(flowWidgetBlurbs[type] || flowTypeLabels[type] || type) + '</div></div>';
            if (type === 'PLAYBACK') {
                html += '<button type="button" class="giant-flow-play" data-id="' + esc(it.id) + '" title="Play this announcement"><i class="fa-solid fa-play"></i></button>';
            }
            html += '<button type="button" class="giant-flow-widget-add" title="Add to the flow"><i class="fa-solid fa-plus"></i></button>';
            html += '</div>';
        });
        html += '</div></div>';
    });
    if (!total) html += '<div class="giant-flow-lib-empty">Nothing to route to yet — create an extension, queue or IVR first.</div>';
    html += '<div class="giant-flow-lib-none">No widgets match that search.</div>';
    html += '</div>'; // body
    html += '</aside>';
    return html;
}

function renderFlowBuilder($container, data, displayName, typeSrc, typeIdSrc) {

    var destinations = data.destinations || {};

    // For a DID, model its two routes — normal routing and the always-on
    // "unconditional" route — as side-by-side lanes under a synthetic root so
    // the branch layout and its add/remove/save machinery handle both. Re-renders
    // pass the already-wrapped flow back in, so only wrap once.
    var isDid = String(typeSrc || '').toUpperCase() === 'DID';
    var flow  = data.flow || [];
    if (isDid && !(flow.length === 1 && flow[0] && flow[0].type === 'DIDROOT')) {
        flow = [{
            type: 'DIDROOT', id: typeIdSrc, name: 'Incoming Call', tag: 'DIDROOT-' + typeIdSrc,
            children: { destination: flow, unconditional: (data.unconditional || []) },
            // The unconditional lane is gated by the DID's di_unconditionalstatus;
            // flag it "(off)" when inactive rather than hiding it.
            branchMeta: {
                unconditional: { active: !!data.unconditionalActive },
                destination:   { active: !data.unconditionalActive }   // normal routing is bypassed while unconditional is on
            }
        }];
        data.flow = flow;
    }
    var root = isDid ? flow[0] : null;

    // Big trees draw in chunks: the first levels now, deeper branches over the
    // next frames, so the page never freezes on a huge flow.
    window._flowChunkPending = [];
    window._flowChunkSeq = 0;
    var totalNodes = flow.reduce(function (n, x) { return n + 1 + flowCountDescendants(x); }, 0);
    window._flowChunkOn = totalNodes > 120;
    window._flowChunkDepth = 2;

    // Branch focus: draw just one branch of the tree, with a trail back up.
    var focusPath = null, focusNode = null;
    if (window._flowFocusUid != null) {
        focusPath = flowPathToUid(window._flowFocusUid);
        if (focusPath && focusPath.length) focusNode = focusPath[focusPath.length - 1].node; else window._flowFocusUid = null;
    }

    var html = '<div class="giant-flow-container' + (window._flowEditing ? '' : ' is-locked') + '">';

    // Header
    html += '<div class="giant-flow-header">';
    html += '<div class="giant-flow-title"><i class="fa-duotone fa-diagram-project" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i> Call Flow: ' + displayName + '</div>';
    // How the account's numbers stand, beside the title.
    if (data.numbers && data.numbers.total > 0) {
        var nr = data.numbers, allRouted = nr.routed >= nr.total;
        html += '<span class="giant-flow-stat' + (allRouted ? ' is-done' : '') + '" title="Numbers on this account that have a route"><i class="fa-solid ' + (allRouted ? 'fa-circle-check' : 'fa-phone') + '"></i> ' + nr.routed + ' of ' + nr.total + ' number' + (nr.total === 1 ? '' : 's') + ' routed</span>';
    }
    // Always on, on every flow, over on the right: this builder is still in beta.
    html += '<div class="giant-flow-beta-inline" role="note"><span class="modal-beta-pill">Beta</span><span>This builder isn\'t finished yet — double-check important changes before relying on them.</span></div>';
    html += '<div class="giant-flow-header-actions">';
    html += '<span class="giant-flow-drawing" id="flowDrawing" style="display:none;"><i class="fa-solid fa-spinner fa-spin"></i> Drawing…</span>';
    html += '<button type="button" class="btn btn-secondary giant-flow-edit-toggle' + (window._flowEditing ? ' is-on' : '') + '" id="flowEditToggle" title="' + (window._flowEditing ? 'Editing is on. Press to lock the flow again.' : 'Viewing only. Press to make changes.') + '"><i class="fa-solid ' + (window._flowEditing ? 'fa-lock-open' : 'fa-lock') + '" style="margin-bottom:0;"></i> ' + (window._flowEditing ? 'Editing' : 'Edit flow') + '</button>';
    html += '<button type="button" class="giant-flow-issues" id="flowIssues" title="Dead ends and loops in this flow"></button>';
    html += '<div class="giant-flow-issues-pop" id="flowIssuesPop" style="display:none;"></div>';
    html += '<button class="giant-flow-zoom-btn giant-flow-hist" id="flowUndo" title="Undo (Ctrl+Z)" disabled><i class="fa-solid fa-rotate-left" style="margin-bottom:0;"></i></button>';
    html += '<button class="giant-flow-zoom-btn giant-flow-hist" id="flowRedo" title="Redo (Ctrl+Y)" disabled><i class="fa-solid fa-rotate-right" style="margin-bottom:0;"></i></button>';
    html += '<button class="btn btn-primary giant-flow-save" style="margin-top:0; padding:8px 16px; font-size:12px; margin-right:6px;"><i class="fa-solid fa-floppy-disk" style="margin-bottom:0;"></i> Save Flow</button>';
    html += '<button class="btn btn-secondary giant-flow-back" style="margin-top:0; padding:8px 16px; font-size:12px;"><i class="fa-solid fa-arrow-left" style="margin-bottom:0;"></i> Back</button>';
    html += '</div></div>';

    // Two panes: the canvas, and the Widget Library beside it.
    html += '<div class="giant-flow-body">';
    html += '<div class="giant-flow-main">';

    // Zoom controls
    html += '<div class="giant-flow-zoom-controls">';
    html += '<button class="giant-flow-zoom-btn" id="flowZoomIn" title="Zoom in"><i class="fa-solid fa-plus" style="margin-bottom:0;"></i></button>';
    html += '<span class="giant-flow-zoom-level" id="flowZoomLevel">100%</span>';
    html += '<button class="giant-flow-zoom-btn" id="flowZoomOut" title="Zoom out"><i class="fa-solid fa-minus" style="margin-bottom:0;"></i></button>';
    html += '<button class="giant-flow-zoom-btn" id="flowZoomFit" title="Fit to view"><i class="fa-solid fa-expand" style="margin-bottom:0;"></i></button>';
    html += '<button class="giant-flow-zoom-btn" id="flowZoomBox" title="Zoom to an area: drag a box on the canvas (or hold Shift and drag)"><i class="fa-solid fa-vector-square" style="margin-bottom:0;"></i></button>';
    html += '<span class="giant-flow-zoom-sep"></span>';
    html += '<button class="giant-flow-zoom-btn" id="flowLayoutToggle"><i class="fa-solid" style="margin-bottom:0;"></i></button>';
    html += '<span class="giant-flow-zoom-sep"></span>';
    html += '<button class="giant-flow-zoom-btn" id="flowWalk" title="Walk a call: see the path a caller takes"><i class="fa-solid fa-route" style="margin-bottom:0;"></i></button>';
    html += '</div>';

    // Breadcrumb trail while focused on a branch.
    if (focusNode) {
        var escC = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
        html += '<div class="giant-flow-crumbs"><button type="button" class="giant-flow-crumb" data-uid="" title="Show the whole flow"><i class="fa-solid fa-phone-volume"></i> Incoming call</button>';
        focusPath.forEach(function (p, i) {
            if (p.node.type === 'DIDROOT') return;
            var parentNode = i > 0 ? focusPath[i - 1].node : null;
            if (parentNode && parentNode.type !== 'DIDROOT') html += '<span class="giant-flow-crumb-branch">' + escC(flowAuditLabel(parentNode, p.parentKey)) + '</span>';
            else if (parentNode && parentNode.type === 'DIDROOT' && p.parentKey === 'unconditional') html += '<span class="giant-flow-crumb-branch">Unconditional</span>';
            var isLastCrumb = i === focusPath.length - 1;
            html += '<i class="fa-solid fa-angle-right"></i>';
            html += isLastCrumb
                ? '<span class="giant-flow-crumb is-current">' + escC(p.node.name || p.node.tag) + '</span>'
                : '<button type="button" class="giant-flow-crumb" data-uid="' + p.node._uid + '">' + escC(p.node.name || p.node.tag) + '</button>';
        });
        html += '<button type="button" class="giant-flow-crumb is-exit" data-uid="" title="Show the whole flow"><i class="fa-solid fa-diagram-project"></i> Whole flow</button>';
        html += '</div>';
    }

    // Walk-a-call panel: step through the flow, choosing at each decision.
    html += '<div class="giant-flow-walkpanel" id="flowWalkPanel" style="display:none;">';
    html += '<div class="giant-flow-walk-title"><i class="fa-solid fa-route"></i> Walk a call <button type="button" class="giant-flow-walk-close" id="flowWalkClose" title="Close"><i class="fa-solid fa-xmark"></i></button></div>';
    html += '<div id="flowWalkBody"></div>';
    html += '</div>';

    // Flow canvas (pannable viewport)
    html += '<div class="giant-flow-viewport" id="flowViewport">';
    html += '<div class="giant-flow-pan" id="flowPan">';   // pan lives here, unzoomed, so it's in true screen pixels
    html += '<div class="giant-flow-canvas' + (flowLayoutIsH() ? ' is-horizontal' : '') + '" id="flowCanvas">';
    html += '<div class="giant-flow-chain" id="flowChain">';

    // Start node
    if (focusNode) {
        // One branch of the tree, from the focused element down.
        var fl = focusPath[focusPath.length - 1];
        var fParent = focusPath.length > 1 ? focusPath[focusPath.length - 2].node : null;
        var fCtx = fParent
            ? { typeSrc: flowBranchTypeSrc(fParent, fl.parentKey), typeIdSrc: fParent.id, isLast: fl.index === fl.arr.length - 1, depth: 0 }
            : { main: true, isLast: fl.index === fl.arr.length - 1, depth: 0 };
        if (fParent && fParent.type === 'DIDROOT') fCtx = { typeSrc: flowBranchTypeSrc(fParent, fl.parentKey), typeIdSrc: fParent.id, isLast: fl.index === fl.arr.length - 1, depth: 0 };
        html += '<div class="giant-flow-start is-focus" data-index="start" title="You\'re looking at one branch — use the trail above to go back up"><i class="fa-solid fa-crosshairs"></i> Branch view</div>';
        html += '<div class="giant-flow-connector"></div>';
        html += renderFlowNode(focusNode, 'focus', fCtx);
    } else {
    html += '<div class="giant-flow-start" data-index="start"><i class="fa-solid fa-phone-volume"></i> Incoming Call</div>';

    if (root) {
        // DID: its two routing lanes (normal + unconditional) rendered side by
        // side via the branch layout; each lane carries its own add-step slot.
        // (The root's branches bring their own connector.)
        html += renderFlowNode(root, 'root');
    } else {
        html += '<div class="giant-flow-connector"></div>';
        // Render each node (each card carries its own "+" port for the next step)
        var mainEnded = false;
        flow.forEach(function(node, idx) {
            html += renderFlowNode(node, idx, { main: true, isLast: idx === flow.length - 1, afterEnd: mainEnded });
            if (flowTerminalTypes[node.type]) mainEnded = true;
            if (idx < flow.length - 1) {
                html += '<div class="giant-flow-connector"></div>';
            }
        });

        // Only an empty flow needs a standalone "Add step"
        if (flow.length === 0) {
            html += '<div class="giant-flow-add" id="flowAddNode"><i class="fa-solid fa-plus"></i> Add Step</div>';
        }
    }
    } // focus / whole flow

    html += '</div>'; // chain
    html += '</div>'; // canvas
    html += '</div>'; // pan
    html += '<canvas class="giant-flow-minimap" id="flowMinimap" width="180" height="120" title="Click or drag to move around"></canvas>';
    html += '</div>'; // viewport
    html += '</div>'; // main
    html += renderFlowLibrary(destinations);
    html += '</div>'; // body
    html += '</div>'; // container

    // Add dropdown (hidden, shown when Add is clicked)
    html += '<div id="flowAddDropdown" style="display:none; margin-top:12px;">';
    html += '<select id="flowDestSelect" class="form-control" style="max-width:400px; margin:0 auto; display:block;">';
    html += '<option value="">Select a destination...</option>';
    Object.keys(flowCreateTiles).forEach(function (tile) {
        if (typeof addFormData === 'undefined' || !addFormData[tile]) return;
        html += '<option value="__NEW_' + tile + '__">+ Create new ' + flowCreateTiles[tile].label.toLowerCase() + '</option>';
    });
    html += giantDestOptgroupsHtml(destinations);
    html += '</select>';
    html += '<div style="text-align:center; margin-top:8px;">';
    html += '<button class="btn btn-primary" id="flowAddConfirm" style="margin-top:0; padding:6px 16px; font-size:12px;"><i class="fa-solid fa-check" style="margin-bottom:0;"></i> Add</button>';
    html += ' <button class="btn btn-secondary" id="flowAddCancel" style="margin-top:0; padding:6px 16px; font-size:12px;">Cancel</button>';
    html += '<div class="giant-flow-branch-hint">or press + on a widget in the library</div>';
    html += '</div></div>';

    $container.html(html);

    // Deeper chunks of a big tree fill in over the next frames; either way the
    // "drawn" step (links, minimap, audit, fit, loader) runs once at the end.
    window._flowChunkDrawn = 0;
    if ((window._flowChunkPending || []).length) {
        window._flowChunkBusy = true;
        $('#flowDrawing').show();
        requestAnimationFrame(flowChunkFlush);
    } else {
        window._flowChunkBusy = false;
        requestAnimationFrame(flowChunkDone);
    }

    // Any reflow of the tree (fonts landing, a card growing, collapse/expand)
    // redraws the links, so they never drift from the cards they join.
    if (window._flowRO) { try { window._flowRO.disconnect(); } catch (e) {} }
    if (window.ResizeObserver) {
        var chainEl = document.getElementById('flowChain');
        if (chainEl) {
            window._flowRO = new ResizeObserver(function () {
                if (window._flowRORaf) cancelAnimationFrame(window._flowRORaf);
                window._flowRORaf = requestAnimationFrame(flowDrawLinks);
            });
            window._flowRO.observe(chainEl);
        }
    }

    // Store flow data for manipulation (for a DID root, its "normal routing" lane)
    window._currentFlow = (root ? root.children.destination : flow).map(function(n) { return n.tag || (n.type + '-' + n.id); });
    window._flowTypeSrc = typeSrc;
    window._flowTypeIdSrc = typeIdSrc;

    // Back button
    $('.giant-flow-back').on('click', function() {
        flowConfirmLeave().then(function (ok) {
            if (!ok) return;
            flowTeardown();
            $('#giantModal .modal-dialog').removeClass('giant-modal-wide giant-modal-flow');
            refreshList('callFlow');
        }).catch(function (err) { console.error('Call flow: back failed', err); });
    });

    // Save button
    $('.giant-flow-save').on('click', function() {
        var $btn = $(this);
        $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin" style="margin-bottom:0;"></i> Saving...');

        var saveQueue = [];

        // For a DID root the normal routing lives in the "destination" lane —
        // refresh the top-level list from it so the main save is never stale.
        syncCurrentFlow();

        // 1. Save main flow
        saveQueue.push(function(cb) {
            $.ajax({
                type: 'post',
                data: { pbxAction: 'saveCallFlow', typeSrc: window._flowTypeSrc, typeIdSrc: window._flowTypeIdSrc, flow: window._currentFlow },
                success: function() { cb(); },
                error: function() { cb(); }
            });
        });

        // 2. Save all modified branches by rebuilding from local tree
        function collectBranchSaves(nodes) {
            if (!nodes) return;
            for (var i = 0; i < nodes.length; i++) {
                var n = nodes[i];
                if (n.children) {
                    Object.entries(n.children).forEach(function(b) {
                        var bKey = b[0];
                        var bArr = b[1];
                        // A slot shown before the element's own exits loaded must
                        // never be written back empty — it would clear a real route.
                        if (n._provisional && (!bArr || bArr.length === 0)) return;
                        var bTypeSrc = flowBranchTypeSrc(n, bKey);
                        if (bTypeSrc) {
                            var branchFlow = bArr.map(function(child) { return child.tag || (child.type + '-' + child.id); });
                            saveQueue.push(function(cb) {
                                $.ajax({
                                    type: 'post',
                                    data: { pbxAction: 'saveCallFlow', typeSrc: bTypeSrc, typeIdSrc: n.id, flow: branchFlow },
                                    success: function() { cb(); },
                                    error: function() { cb(); }
                                });
                            });
                        }
                        // Recurse into children
                        collectBranchSaves(bArr);
                    });
                }
            }
        }
        collectBranchSaves(window._flowData.flow);

        // Legacy pending changes (just in case)
        if (false && window._pendingBranchChanges) {
            Object.values(window._pendingBranchChanges).forEach(function(change) {
                saveQueue.push(function(cb) {
                    $.ajax({
                        type: 'post',
                        data: { pbxAction: 'getCallFlowBranch', typeSrc: change.typeSrc, typeIdSrc: change.typeIdSrc },
                        success: function(json) {
                            var resp;
                            try { resp = (typeof json === 'object') ? json : jQuery.parseJSON(json); } catch(e) { resp = {}; }
                            var branchFlow = resp.flow || [];
                            change.adds.forEach(function(a) { branchFlow.push(a); });
                            $.ajax({
                                type: 'post',
                                data: { pbxAction: 'saveCallFlow', typeSrc: change.typeSrc, typeIdSrc: change.typeIdSrc, flow: branchFlow },
                                success: function() { cb(); },
                                error: function() { cb(); }
                            });
                        },
                        error: function() { cb(); }
                    });
                });
            });
        }

        // Execute all saves in sequence
        var idx = 0;
        function runNext() {
            if (idx >= saveQueue.length) {
                // All done
                window._pendingBranchChanges = {};
                $btn.prop('disabled', false).css('background', '').css('border-color', '');
                $btn.html('<i class="fa-solid fa-check" style="margin-bottom:0;"></i> Saved!');
                if (window.giantRefreshSetup) giantRefreshSetup();
                setTimeout(function() {
                    $btn.html('<i class="fa-solid fa-floppy-disk" style="margin-bottom:0;"></i> Save Flow');
                    // Reload to show final state
                    openCallFlowBuilder(window._flowTypeSrc, window._flowTypeIdSrc, window._flowDisplayName || '');
                }, 1000);
                return;
            }
            saveQueue[idx](function() { idx++; runNext(); });
        }
        runNext();
    });

    // Remove a node — anywhere in the tree, addressed by its unique render id
    // (branch positions repeat across a large tree, so they can't address one).
    $(document).off('click', '.giant-flow-node-remove').on('click', '.giant-flow-node-remove', function(e) {
        e.stopPropagation();
        var found = findNodeInTree(window._flowData.flow, String($(this).data('index')));
        if (!found) return;
        found.array.splice(found.position, 1);
        syncCurrentFlow();
        reRenderFlow();
        flowMarkDirty();
    });

    // Make a copy: this route gets its own version of a shared element.
    $(document).off('click', '.giant-flow-node-clone').on('click', '.giant-flow-node-clone', async function(e) {
        e.stopPropagation();
        var $btn = $(this);
        var type = String($btn.data('type')), id = String($btn.data('id')), name = String($btn.data('name') || type);
        var uid  = String($btn.closest('.giant-flow-node').data('index'));
        var ok = await giantConfirm({
            title: 'Make a copy of ' + name + '?',
            message: 'This route will switch to a new copy with the same settings, members and onward steps, so changes here won\'t affect the other routes still using the original.\n\nThe copy is created straight away. Save the flow afterwards so this route points at it.',
            confirmText: 'Make a copy',
            cancelText: 'Keep shared',
            danger: false
        });
        if (!ok) return;
        $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i>');
        $.ajax({
            type: 'post',
            data: { pbxAction: 'cloneFlowObject', objectType: type, objectId: id },
            success: function(json) {
                var resp = flowParseJson(json);
                if (!resp || resp.error || !resp.tag) { reRenderFlow(); flowNotice((resp && resp.error) || 'Couldn\'t make a copy.', 'error'); return; }
                var found = findNodeInTree(window._flowData.flow, uid);
                if (!found) { openCallFlowBuilder(window._flowTypeSrc, window._flowTypeIdSrc, window._flowDisplayName || ''); return; }
                var n = found.node;
                Object.keys(n).forEach(function(k) { delete n[k]; });
                n.type = String(resp.type); n.id = String(resp.id); n.name = resp.name; n.tag = resp.tag;
                syncCurrentFlow();
                reRenderFlow();
                flowMarkDirty();
                flowHydrateNode(n);
                flowNotice('Copied. This route now uses "' + resp.name + '". Save the flow to keep it.', 'ok');
            },
            error: function() { reRenderFlow(); flowNotice('Couldn\'t make a copy.', 'error'); }
        });
    });

    // Collapse / expand the steps under a node; expand a repeated element here.
    $(document).off('click', '.giant-flow-node-toggle, .giant-flow-node-expand').on('click', '.giant-flow-node-toggle, .giant-flow-node-expand', function(e) {
        e.stopPropagation();
        var found = findNodeInTree(window._flowData.flow, String($(this).data('index')));
        if (!found) return;
        var n = found.node;
        if (n.repeat && !n.expanded) {
            n.expanded = true;
            $(this).html('<i class="fa-solid fa-spinner fa-spin"></i> Loading…');
            flowHydrateNode(n);
            return;
        }
        n.collapsed = !n.collapsed;
        reRenderFlow();
    });

    // Edit any node in place: its normal form opens in a drawer over the
    // library, and only that node is refreshed when it's saved.
    $(document).off('click', '.giant-flow-node-edit').on('click', '.giant-flow-node-edit', function(e) {
        e.stopPropagation();
        flowEditNode(String($(this).data('type')), String($(this).data('id')), String($(this).data('name') || ''));
    });

    // Add node
    $('#flowAddNode').on('click', function() {
        $(this).hide();
        $('#flowAddDropdown').show();
        // Init select2 on the dropdown
        if ($.fn.select2) {
            $('#flowDestSelect').select2({ dropdownParent: $('#giantModal'), width: '100%', placeholder: 'Search destinations...',
                templateResult: window.giantRenderDestOption, templateSelection: window.giantRenderDestOption });
        }
    });

    // Per-branch add step
    // Add a step — from an empty branch's ghost card, or a card's "+" port
    // (which inserts right after that card). The picker opens beside it.
    $(document).off('click', '.giant-flow-branch-add').on('click', '.giant-flow-branch-add', function(e) {
        e.stopPropagation();
        if (!window._flowEditing) { flowNotice('Press "Edit flow" to make changes.', 'info'); return; }
        var $btn = $(this);
        var target = flowTargetFromEl($btn) || {};
        // A port lives inside the card; its picker goes after the card.
        var $anchor = $btn.hasClass('giant-flow-port') ? $btn.closest('.giant-flow-node') : $btn;

        if ($anchor.next('.giant-flow-branch-dropdown').length) {
            $anchor.next('.giant-flow-branch-dropdown').remove();
            $btn.removeClass('is-armed');
            return;
        }
        $('.giant-flow-branch-dropdown').remove();
        // The open slot is "armed": a widget's + in the library lands here.
        $('.giant-flow-branch-add').removeClass('is-armed');
        $btn.addClass('is-armed');

        var dd = '<div class="giant-flow-branch-dropdown">';
        dd += '<select class="form-control branch-dest-select" style="font-size:12px; margin-bottom:6px;">';
        dd += '<option value="">Select destination...</option>';
        if (window._flowData && window._flowData.destinations) {
            dd += giantDestOptgroupsHtml(window._flowData.destinations);
        }
        dd += '</select>';
        dd += '<button class="btn btn-primary branch-dest-confirm" data-typesrc="' + (target.typeSrc || '') + '" data-typeidsrc="' + (target.typeIdSrc || '') + '"'
            + (target.after ? ' data-after="' + target.after + '"' : '') + (target.main ? ' data-main="1"' : '')
            + ' style="margin-top:0; padding:4px 12px; font-size:11px;"><i class="fa-solid fa-check" style="margin-bottom:0;"></i> Add</button>';
        dd += '<button type="button" class="branch-dest-cancel" title="Close without adding">Cancel</button>';
        dd += '<div class="giant-flow-branch-hint">or press + on a widget in the library</div>';
        dd += '</div>';
        $anchor.after(dd);

        if ($.fn.select2) {
            $anchor.next('.giant-flow-branch-dropdown').find('.branch-dest-select').select2({
                dropdownParent: $('#giantModal'), width: '100%', placeholder: 'Search...',
                templateResult: window.giantRenderDestOption, templateSelection: window.giantRenderDestOption
            });
        }

        // Bring the picker up to a readable size (around the "+" you pressed)
        // and pan so all of it is in view.
        if ($viewport && $viewport.length) {
            var vr = $viewport[0].getBoundingClientRect(), br = $btn[0].getBoundingClientRect();
            if (flowZoom < 1) zoomAt(1, br.left + br.width / 2 - vr.left, br.top + br.height / 2 - vr.top);
            revealEl($anchor.next('.giant-flow-branch-dropdown')[0], 24);
        }
    });

    // Confirm branch add — saves directly to the API
    // Track pending branch changes
    if (!window._pendingBranchChanges) window._pendingBranchChanges = {};

    // Cancel: close the picker. A key press or exit added a moment ago and
    // still empty goes with it, so a change of mind leaves nothing behind.
    $(document).off('click', '.branch-dest-cancel').on('click', '.branch-dest-cancel', function (e) {
        e.preventDefault();
        e.stopPropagation();
        $(this).closest('.giant-flow-branch-dropdown').remove();
        $('.giant-flow-branch-add').removeClass('is-armed');
        var fresh = window._flowFreshBranch;
        window._flowFreshBranch = null;
        if (fresh) {
            var f = flowFindByUid(fresh.uid);
            if (f && f.node.children && f.node.children[fresh.key] && !f.node.children[fresh.key].length) {
                delete f.node.children[fresh.key];
                reRenderFlow();
            }
        }
    });

    $(document).off('click', '.branch-dest-confirm').on('click', '.branch-dest-confirm', function() {
        var $dd = $(this).closest('.giant-flow-branch-dropdown');
        var val = $dd.find('.branch-dest-select').val();
        var label = $dd.find('.branch-dest-select option:selected').text();
        if (!val) return;
        window._flowFreshBranch = null;   // the new exit is being routed: it stays

        // Add to local flow data for immediate visual feedback
        var parts = val.split('-');
        var newNode = { type: parts[0], id: parts.slice(1).join('-'), name: label, tag: val };

        var parent = flowAddAt(flowTargetFromEl($(this)), newNode);
        flowHydrateNode(newNode);   // pulls in the element's own exits and members
        syncCurrentFlow();
        reRenderFlow();
        flowAfterBranchAdd(parent);

        // Show save reminder
        $('.giant-flow-save').html('<i class="fa-solid fa-floppy-disk" style="margin-bottom:0;"></i> Save Flow *').css('background', '#f59e0b').css('border-color', '#f59e0b');
    });

    // Add new IVR key press branch
    $(document).off('change', '.giant-flow-add-key-select').on('change', '.giant-flow-add-key-select', function() {
        var key = $(this).val();
        var ivrId = $(this).data('ivrid');
        if (!key || !ivrId) return;

        // Add empty branch to local data
        function addKeyToIvr(nodes) {
            if (!nodes) return false;
            for (var i = 0; i < nodes.length; i++) {
                if (nodes[i].type === 'IVR' && String(nodes[i].id) === String(ivrId)) {
                    if (!nodes[i].children) nodes[i].children = {};
                    nodes[i].children[key] = [];
                    return true;
                }
                if (nodes[i].children) {
                    var found = false;
                    Object.values(nodes[i].children).forEach(function(bArr) {
                        if (addKeyToIvr(bArr)) found = true;
                    });
                    if (found) return true;
                }
            }
            return false;
        }
        addKeyToIvr(window._flowData.flow);
        reRenderFlow();
    });

    $('#flowAddCancel').on('click', function() {
        $('#flowAddDropdown').hide();
        $('#flowAddNode').show();
    });

    $('#flowAddConfirm').on('click', function() {
        var val = $('#flowDestSelect').val();
        var label = $('#flowDestSelect option:selected').text();
        if (!val) return;

        // "Create new …" options open the create form in the drawer
        if (val.indexOf('__NEW_') === 0) {
            flowCreateNew(val.slice(6, -2));
            return;
        }

        // Add to flow data locally (for a DID root, its normal-routing lane)
        var parts = val.split('-');
        var mainArr = flowMainArray();
        var newNode = { type: parts[0], id: parts.slice(1).join('-'), name: label, tag: val, order: mainArr.length };
        mainArr.push(newNode);
        flowHydrateNode(newNode);   // pulls in the element's own exits and members
        syncCurrentFlow();
        reRenderFlow();
    });

    // Drag and drop reordering
    var $chain = $('#flowChain');
    var dragIdx = null;

    // Universal drag and drop — works across all nodes and branches
    var dragSource = null; // { index, node, parentArray }

    // Nodes are addressed by the unique id stamped on them at render time —
    // branch positions repeat all over a large tree, so they can't address one.
    // Returns { array, position, node } or null.
    function findNodeInTree(tree, idxStr) {
        var want = String(idxStr);
        var hit = null;
        (function walk(arr) {
            for (var i = 0; i < arr.length && !hit; i++) {
                var n = arr[i];
                if (!n) continue;
                if (String(n._uid) === want) { hit = { array: arr, position: i, node: n }; return; }
                if (n.children) Object.values(n.children).forEach(function (b) { if (!hit) walk(b || []); });
            }
        })(tree || []);
        return hit;
    }

    // What's being dropped: an existing node being moved (spliced out of its
    // old place), or a fresh copy of a Widget Library card — which then pulls
    // in its own exits and members.
    function takeDragPayload() {
        if (dragSource) return dragSource.array.splice(dragSource.position, 1)[0];
        var d = window._flowLibDrag;
        if (d) {
            var fresh = { type: d.type, id: d.id, name: d.name, tag: d.tag };
            flowHydrateNode(fresh);
            return fresh;
        }
        return null;
    }

    // Is `target` the node itself or anywhere in its sub-tree? (A node can't
    // be dropped into its own steps — it would be spliced out and never land.)
    function flowNodeContains(root, target) {
        if (!root || !target) return false;
        if (root === target) return true;
        var hit = false;
        Object.values(root.children || {}).forEach(function (arr) {
            (arr || []).forEach(function (c) { if (!hit && flowNodeContains(c, target)) hit = true; });
        });
        return hit;
    }

    // The node whose branch saves to (typeSrc, typeIdSrc).
    function flowFindBranchOwner(typeSrc, typeIdSrc) {
        var found = null;
        (function walk(nodes) {
            (nodes || []).forEach(function (n) {
                if (found || !n || !n.children) return;
                Object.keys(n.children).forEach(function (k) {
                    if (found) return;
                    if (flowBranchTypeSrc(n, k) === String(typeSrc) && String(n.id) === String(typeIdSrc)) { found = n; return; }
                    walk(n.children[k]);
                });
            });
        })((window._flowData && window._flowData.flow) || []);
        return found;
    }

    $(document).off('dragstart.flow').on('dragstart.flow', '.giant-flow-node', function(e) {
        if (!window._flowEditing) { e.preventDefault(); return false; }
        dragIdx = $(this).data('index');
        dragSource = findNodeInTree(window._flowData.flow, dragIdx);
        $(this).addClass('dragging');
        // Its exits travel with it — show the whole sub-tree as "in hand".
        $('.giant-flow-branches[data-owner="' + dragIdx + '"]').addClass('drag-with');
        e.originalEvent.dataTransfer.effectAllowed = 'move';
        flowDrawLinks();   // fade that sub-tree's links too
    });

    $(document).off('dragend.flow').on('dragend.flow', '.giant-flow-node', function() {
        $(this).removeClass('dragging');
        $('.giant-flow-branches').removeClass('drag-with');
        $('.giant-flow-node').removeClass('drop-above drop-below');
        $('.giant-flow-add, .giant-flow-branch-add').removeClass('drop-target-active');
        dragSource = null;
        flowDrawLinks();
    });

    $(document).off('dragover.flow').on('dragover.flow', '.giant-flow-node', function(e) {
        e.preventDefault();
        e.originalEvent.dataTransfer.dropEffect = 'move';
        var $node = $(this);
        if ($node.hasClass('dragging')) return;
        var rect = this.getBoundingClientRect();
        $('.giant-flow-node').removeClass('drop-above drop-below');
        // "above" = before, "below" = after — along the row when left-to-right.
        var before = $('#flowCanvas').hasClass('is-horizontal')
            ? (e.originalEvent.clientX < rect.left + rect.width / 2)
            : (e.originalEvent.clientY < rect.top + rect.height / 2);
        if (before) {
            $node.addClass('drop-above');
        } else {
            $node.addClass('drop-below');
        }
    });

    $(document).off('dragleave.flow').on('dragleave.flow', '.giant-flow-node', function() {
        $(this).removeClass('drop-above drop-below');
    });

    // Allow dropping on Add Step button and branch + circles
    $(document).off('dragover.flowAdd').on('dragover.flowAdd', '.giant-flow-add, .giant-flow-branch-add', function(e) {
        e.preventDefault();
        e.originalEvent.dataTransfer.dropEffect = 'move';
        $(this).addClass('drop-target-active');
    });

    $(document).off('dragleave.flowAdd').on('dragleave.flowAdd', '.giant-flow-add, .giant-flow-branch-add', function() {
        $(this).removeClass('drop-target-active');
    });

    // Drop on main Add Step — append to main flow
    $(document).off('drop.flowMainAdd').on('drop.flowMainAdd', '.giant-flow-add', function(e) {
        e.preventDefault();
        $(this).removeClass('drop-target-active');
        var movedNode = takeDragPayload();
        if (!movedNode) return;
        flowMainArray().push(movedNode); // for a DID root, its normal-routing lane
        syncCurrentFlow();
        reRenderFlow();
        $('.giant-flow-save').html('<i class="fa-solid fa-floppy-disk" style="margin-bottom:0;"></i> Save Flow *').css('background', '#f59e0b').css('border-color', '#f59e0b');
        dragSource = null;
    });

    // Drop on branch label or connector — append to that branch
    $(document).off('dragover.flowBranch').on('dragover.flowBranch', '.giant-flow-branch-label, .giant-flow-branch', function(e) {
        e.preventDefault();
        e.originalEvent.dataTransfer.dropEffect = 'move';
        $(this).closest('.giant-flow-branch').find('.giant-flow-branch-add').addClass('drop-target-active');
    });

    $(document).off('dragleave.flowBranch').on('dragleave.flowBranch', '.giant-flow-branch-label, .giant-flow-branch', function() {
        $(this).closest('.giant-flow-branch').find('.giant-flow-branch-add').removeClass('drop-target-active');
    });

    $(document).off('drop.flowBranch').on('drop.flowBranch', '.giant-flow-branch-label, .giant-flow-branch', function(e) {
        e.preventDefault();
        var $branchAdd = $(this).closest('.giant-flow-branch').find('.giant-flow-branch-add');
        if ($branchAdd.length && (dragSource || window._flowLibDrag)) {
            $branchAdd.trigger('drop', e);
        }
    });

    // Drop on branch + circle — append to that branch
    $(document).off('drop.flowBranchAdd').on('drop.flowBranchAdd', '.giant-flow-branch-add', function(e) {
        e.preventDefault();
        $(this).removeClass('drop-target-active');
        var target = flowTargetFromEl($(this)) || {};
        if (dragSource) {
            var owner = target.after ? (flowFindByUid(target.after) || {}).node : flowFindBranchOwner(target.typeSrc, target.typeIdSrc);
            if (owner && flowNodeContains(dragSource.node, owner)) {
                flowNotice('An element can\'t be moved into its own steps.', 'warn');
                return;
            }
        }
        var movedNode = takeDragPayload();
        if (!movedNode) return;

        // After a card (its port), or at the end of a branch — IVR keys,
        // condition slots, the DID lanes and every generic exit.
        var parent = flowAddAt(target, movedNode);
        syncCurrentFlow();
        reRenderFlow();
        flowAfterBranchAdd(parent);
        $('.giant-flow-save').html('<i class="fa-solid fa-floppy-disk" style="margin-bottom:0;"></i> Save Flow *').css('background', '#f59e0b').css('border-color', '#f59e0b');
        dragSource = null;
    });

    $(document).off('drop.flow').on('drop.flow', '.giant-flow-node', function(e) {
        e.preventDefault();
        $('.giant-flow-node').removeClass('drop-above drop-below');
        var dropIdxStr = String($(this).data('index'));
        var dropTarget = findNodeInTree(window._flowData.flow, dropIdxStr);

        if (!dropTarget) return;
        if (dragSource && dragSource.array === dropTarget.array && dragSource.position === dropTarget.position) return;
        if (dragSource && flowNodeContains(dragSource.node, dropTarget.node)) {
            flowNotice('An element can\'t be moved into its own steps.', 'warn');
            return;
        }

        var wasMove = !!dragSource;
        var movedNode = takeDragPayload();
        if (!movedNode) return;

        // Recalculate drop position (removing a moved node may shift indices)
        var newDropTarget = wasMove ? findNodeInTree(window._flowData.flow, dropIdxStr) : dropTarget;
        if (newDropTarget) {
            // Determine above or below based on CSS class
            var insertAt = newDropTarget.position;
            if ($(this).hasClass('drop-below')) insertAt++;
            newDropTarget.array.splice(insertAt, 0, movedNode);
        } else {
            // Fallback — add to main flow (for a DID root, its normal-routing lane)
            flowMainArray().push(movedNode);
        }

        // Rebuild currentFlow from the main lane
        syncCurrentFlow();

        reRenderFlow();
        $('.giant-flow-save').html('<i class="fa-solid fa-floppy-disk" style="margin-bottom:0;"></i> Save Flow *').css('background', '#f59e0b').css('border-color', '#f59e0b');
        dragSource = null;
    });

    // ===== WIDGET LIBRARY =====
    // Drag a card onto any "+" slot, between two steps or onto a branch; or
    // press its "+" to add it to the slot you last opened (armed), else to the
    // end of the flow. Library open/closed state is remembered per browser.
    var $lib = $('#flowLibrary');
    var libState = window._flowLibState || (window._flowLibState = { q: '', closed: {} });
    try { if (localStorage.getItem('giantFlowLib') === 'closed') $('.giant-flow-container').addClass('lib-collapsed'); } catch (err) {}

    $lib.find('.giant-flow-lib-toggle, .giant-flow-lib-tab').on('click', function () {
        var $c = $('.giant-flow-container').toggleClass('lib-collapsed');
        try { localStorage.setItem('giantFlowLib', $c.hasClass('lib-collapsed') ? 'closed' : 'open'); } catch (err) {}
        fixBranchConnectors();
    });

    function flowLibFilter() {
        var q = String($('#flowLibSearch').val() || '').trim().toLowerCase();
        libState.q = q;
        var any = false;
        $lib.find('.giant-flow-lib-group').each(function () {
            var $g = $(this), n = 0;
            $g.find('.giant-flow-widget').each(function () {
                var hit = !q || String($(this).data('search')).indexOf(q) > -1;
                $(this).toggle(hit);
                if (hit) n++;
            });
            $g.toggle(n > 0);
            if (n) any = true;
            if (q) $g.removeClass('is-closed'); // a search opens every group it hits
        });
        $lib.find('.giant-flow-lib-none').toggle(!any && !!q);
    }
    $('#flowLibSearch').on('input', flowLibFilter);
    if (libState.q) flowLibFilter();

    $lib.find('.giant-flow-lib-gh').on('click', function () {
        var $g = $(this).closest('.giant-flow-lib-group').toggleClass('is-closed');
        libState.closed[$g.data('type')] = $g.hasClass('is-closed');
    });

    $lib.find('.giant-flow-lib-newbtn').on('click', function () {
        flowCreateNew(String($(this).data('tile')));
    });

    $lib.on('click', '.giant-flow-widget-add', function (e) {
        e.stopPropagation();
        if (!window._flowEditing) return;
        var $w = $(this).closest('.giant-flow-widget');
        var node = { type: String($w.data('type')), id: String($w.data('id')), name: String($w.data('name')), tag: String($w.data('tag')) };
        var $armed = $('.giant-flow-branch-add.is-armed').first();
        var parent = null;
        if ($armed.length) {
            parent = flowAddAt(flowTargetFromEl($armed), node);
        } else {
            flowMainArray().push(node);
        }
        flowHydrateNode(node);   // pulls in the element's own exits and members
        syncCurrentFlow();
        reRenderFlow();
        flowMarkDirty();
        flowAfterBranchAdd(parent);
    });

    $(document).off('dragstart.flowLib').on('dragstart.flowLib', '.giant-flow-widget', function (e) {
        if (!window._flowEditing) { e.preventDefault(); return false; }
        var $w = $(this);
        window._flowLibDrag = { tag: String($w.data('tag')), type: String($w.data('type')), id: String($w.data('id')), name: String($w.data('name')) };
        dragSource = null;
        $w.addClass('dragging');
        $('.giant-flow-container').addClass('lib-dragging');
        try {
            e.originalEvent.dataTransfer.effectAllowed = 'copyMove';
            e.originalEvent.dataTransfer.setData('text/plain', window._flowLibDrag.tag); // Firefox won't start a drag without data
        } catch (err) {}
    });
    $(document).off('dragend.flowLib').on('dragend.flowLib', '.giant-flow-widget', function () {
        $(this).removeClass('dragging');
        $('.giant-flow-container').removeClass('lib-dragging');
        $('.giant-flow-node').removeClass('drop-above drop-below');
        $('.giant-flow-add, .giant-flow-branch-add').removeClass('drop-target-active');
        window._flowLibDrag = null;
    });

    // ===== PAN & ZOOM =====
    window._flowZoom = window._flowZoom || 1;
    window._flowPanX = window._flowPanX || 0;
    window._flowPanY = window._flowPanY || 0;
    var flowZoom = window._flowZoom;
    var flowPanX = window._flowPanX, flowPanY = window._flowPanY;
    var isPanning = false, panStartX = 0, panStartY = 0;
    var $viewport = $('#flowViewport');
    var $canvas = $('#flowCanvas');
    var $pan = $('#flowPan');

    window._flowApplyTransform = function() {
        flowZoom = window._flowZoom;
        flowPanX = window._flowPanX;
        flowPanY = window._flowPanY;
        applyTransform();
    };

    function applyTransform() {
        window._flowZoom = flowZoom;
        window._flowPanX = flowPanX;
        window._flowPanY = flowPanY;
        // CSS zoom (not transform) so drag-and-drop hit detection keeps working;
        // the pan is a margin on the unzoomed wrapper, so it's real screen px.
        $canvas.css('zoom', flowZoom);
        $pan.css('margin-left', flowPanX + 'px');
        $pan.css('margin-top', flowPanY + 'px');
        // The dot grid moves and scales with the tree.
        var grid = Math.max(8, 24 * flowZoom);
        $viewport.css({ backgroundSize: grid + 'px ' + grid + 'px', backgroundPosition: flowPanX + 'px ' + flowPanY + 'px' });
        // Zoomed right out, drop the small print (slot labels, settings strips).
        // Hidden without changing layout — but redraw the links anyway in case
        // anything did move.
        var zoomedOut = flowZoom < 0.75;
        if ($canvas.hasClass('is-zoomed-out') !== zoomedOut) {
            $canvas.toggleClass('is-zoomed-out', zoomedOut);
            setTimeout(flowDrawLinks, 0);
        }
        $('#flowZoomLevel').text(Math.round(flowZoom * 100) + '%');
        if (typeof flowDrawMinimap === 'function') flowDrawMinimap();
    }

    // The tree's size in layout px (its rect is scaled by the canvas zoom).
    function measureContent() {
        var chain = document.getElementById('flowChain');
        if (!chain) return null;
        var r = chain.getBoundingClientRect();
        var z = flowZoom || 1;
        return { w: r.width / z, h: r.height / z };
    }

    // Pick a zoom for the tree's size and centre it: small flows come up to
    // maxZoom, big ones down to minZoom; whatever still doesn't fit anchors
    // top-left so the start of the flow is in view.
    function fitAndCenter(opts) {
        opts = opts || {};
        if (!$viewport.length) return;
        var vw = $viewport.width(), vh = $viewport.height() || 500;
        var c = measureContent();
        if (!c || !c.w || !c.h) return;
        var margin = 40;
        var fit = Math.min((vw - margin) / c.w, (vh - margin) / c.h);
        var z = Math.min(fit, opts.maxZoom != null ? opts.maxZoom : 1.2);
        z = Math.max(z, opts.minZoom != null ? opts.minZoom : 0.5);
        flowZoom = Math.round(z * 100) / 100;
        var cw = c.w * flowZoom, ch = c.h * flowZoom;
        flowPanX = cw < vw ? Math.round((vw - cw) / 2) : 16;
        flowPanY = ch < vh ? Math.round((vh - ch) / 2) : 16;
        applyTransform();
    }

    // Keep a tree that fits centred (each axis independently); leave a bigger
    // one where the user panned it.
    function centerIfFits() {
        if (!$viewport.length) return;
        var vw = $viewport.width(), vh = $viewport.height() || 500;
        var c = measureContent();
        if (!c || !c.w || !c.h) return;
        var cw = c.w * flowZoom, ch = c.h * flowZoom;
        if (cw <= vw) flowPanX = Math.round((vw - cw) / 2);
        if (ch <= vh) flowPanY = Math.round((vh - ch) / 2);
        applyTransform();
    }

    // Zoom keeping the point (ax, ay) of the viewport fixed under the cursor.
    function zoomAt(nz, ax, ay) {
        nz = Math.min(Math.max(nz, 0.2), 2);
        if (nz === flowZoom) return;
        var k = nz / flowZoom;
        flowPanX = ax - (ax - flowPanX) * k;
        flowPanY = ay - (ay - flowPanY) * k;
        flowZoom = Math.round(nz * 100) / 100;
        applyTransform();
        centerIfFits();
    }
    // Pan just enough that an element is fully inside the viewport.
    function revealEl(el, pad) {
        if (!el || !$viewport.length) return;
        pad = pad || 24;
        var vr = $viewport[0].getBoundingClientRect(), r = el.getBoundingClientRect();
        var dx = 0, dy = 0;
        if (r.right  > vr.right  - pad) dx = vr.right  - pad - r.right;
        if (r.left   < vr.left   + pad) dx = vr.left   + pad - r.left;
        if (r.bottom > vr.bottom - pad) dy = vr.bottom - pad - r.bottom;
        if (r.top    < vr.top    + pad) dy = vr.top    + pad - r.top;
        if (dx || dy) { flowPanX += dx; flowPanY += dy; applyTransform(); }
    }

    // Zoom so a rectangle of the viewport (screen px) fills the view.
    function zoomToRect(rx, ry, rw, rh) {
        var vw = $viewport.width(), vh = $viewport.height() || 500;
        var nz = Math.min(Math.max(flowZoom * Math.min(vw / rw, vh / rh), 0.2), 2);
        var cx = (rx + rw / 2 - flowPanX) / flowZoom;   // the box's centre in layout px
        var cy = (ry + rh / 2 - flowPanY) / flowZoom;
        flowZoom = Math.round(nz * 100) / 100;
        flowPanX = Math.round(vw / 2 - cx * flowZoom);
        flowPanY = Math.round(vh / 2 - cy * flowZoom);
        applyTransform();
        centerIfFits();
    }
    window._flowFitAndCenter = fitAndCenter;
    window._flowCenterIfFits = centerIfFits;
    window._flowZoomAt       = zoomAt;
    window._flowRevealEl     = revealEl;
    // Pan so a layout-px point sits at the centre of the viewport (minimap).
    window._flowCenterOn = function (lx, ly) {
        var vw = $viewport.width(), vh = $viewport.height() || 500;
        flowPanX = Math.round(vw / 2 - lx * flowZoom);
        flowPanY = Math.round(vh / 2 - ly * flowZoom);
        applyTransform();
    };

    // Start at 100% zoom
    flowZoom = window._flowZoom || 1;
    flowPanX = window._flowPanX || 0;
    flowPanY = window._flowPanY || 0;
    applyTransform();

    // Zoom buttons
    $('#flowZoomIn').on('click', function() {
        zoomAt(flowZoom + 0.1, $viewport.width() / 2, ($viewport.height() || 500) / 2);
    });

    $('#flowZoomOut').on('click', function() {
        zoomAt(flowZoom - 0.1, $viewport.width() / 2, ($viewport.height() || 500) / 2);
    });

    $('#flowZoomFit').on('click', function () { fitAndCenter({ maxZoom: 1.2, minZoom: 0.2 }); });

    // Layout direction toggle — a class flip on the canvas, remembered per browser.
    flowLayoutButtonState($('#flowLayoutToggle'), $canvas.hasClass('is-horizontal'));
    $('#flowLayoutToggle').on('click', function () {
        var h = !$canvas.hasClass('is-horizontal');
        try { localStorage.setItem('giantFlowLayout', h ? 'h' : 'v'); } catch (e) {}
        $canvas.toggleClass('is-horizontal', h);
        flowLayoutButtonState($(this), h);
        fitAndCenter({ maxZoom: 1.2, minZoom: 0.5 });
        fixBranchConnectors();
    });

    // Edit / view mode. Every flow opens locked; editing tools appear once
    // it's switched on. Locking again with unsaved changes is refused.
    $('#flowEditToggle').on('click', function () {
        if (window._flowEditing && window._flowDirty) {
            flowNotice('Save your changes (or undo them) before locking editing again.', 'warn');
            return;
        }
        window._flowEditing = !window._flowEditing;
        var on = window._flowEditing;
        $('.giant-flow-container').toggleClass('is-locked', !on);
        $('.giant-flow-node, .giant-flow-widget').attr('draggable', on ? 'true' : 'false');
        $(this).toggleClass('is-on', on)
            .attr('title', on ? 'Editing is on. Press to lock the flow again.' : 'Viewing only. Press to make changes.')
            .html('<i class="fa-solid ' + (on ? 'fa-lock-open' : 'fa-lock') + '" style="margin-bottom:0;"></i> ' + (on ? 'Editing' : 'Edit flow'));
        if (on) {
            var keepClosed = false;
            try { keepClosed = localStorage.getItem('giantFlowLib') === 'closed'; } catch (e) {}
            if (!keepClosed) $('.giant-flow-container').removeClass('lib-collapsed');
            flowNotice('Editing is on. Drag widgets from the library, use a card\'s + to add after it, and press Save Flow when you\'re done.', 'ok');
        } else {
            $('.giant-flow-branch-dropdown, .giant-flow-keypad').remove();
            $('.giant-flow-node').removeClass('is-selected');
        }
        fixBranchConnectors();
        flowFitViewport();
    });

    // Undo / redo, and the walk-a-call panel.
    $('#flowUndo').on('click', function () { flowUndo(); });
    $('#flowRedo').on('click', function () { flowRedo(); });
    flowHistoryButtons();
    $('#flowWalk').on('click', function () {
        if ($('#flowWalkPanel').is(':visible')) { flowWalkClose(); return; }
        $('.giant-flow-branch-dropdown, .giant-flow-keypad').remove();
        if ($('#flowAnalyser').is(':visible')) flowAnalyseClose();
        flowWalkOpen();
    });
    $('#flowWalkClose').on('click', function () { flowWalkClose(); });

    // Mouse wheel zoom
    $viewport.on('wheel', function(e) {
        e.preventDefault();
        var delta = e.originalEvent.deltaY > 0 ? -0.05 : 0.05;
        var r = $viewport[0].getBoundingClientRect();
        zoomAt(flowZoom + delta, e.originalEvent.clientX - r.left, e.originalEvent.clientY - r.top);
    });

    // Track if a node drag is happening
    var nodeDragActive = false;

    $(document).off('dragstart.flowFlag').on('dragstart.flowFlag', '.giant-flow-node', function() {
        nodeDragActive = true;
    });
    $(document).off('dragend.flowFlag').on('dragend.flowFlag', '.giant-flow-node', function() {
        setTimeout(function() { nodeDragActive = false; }, 100);
    });

    // Box zoom: drag a rectangle on the background (in box mode, or with Shift)
    // and it fills the view. Box mode is one-shot.
    var zoomBoxMode = false, boxStart = null, $box = null;
    $('#flowZoomBox').on('click', function () {
        zoomBoxMode = !zoomBoxMode;
        $(this).toggleClass('is-active', zoomBoxMode);
        $viewport.toggleClass('is-zoombox', zoomBoxMode);
    });

    // Pan — only on background, never during node drag
    $viewport.on('mousedown', function(e) {
        if (nodeDragActive) return;
        var $t = $(e.target);
        var isInteractive = $t.closest('.giant-flow-node, button, select, .giant-flow-add, .giant-flow-branch-add, .giant-flow-branch-dropdown, a, input, [draggable]').length > 0;

        if (e.button === 0 && !isInteractive && (zoomBoxMode || e.shiftKey)) {
            var vr = $viewport[0].getBoundingClientRect();
            boxStart = { x: e.clientX - vr.left, y: e.clientY - vr.top };
            $box = $('<div class="giant-flow-marquee"></div>').css({ left: boxStart.x, top: boxStart.y, width: 0, height: 0 }).appendTo($viewport);
            e.preventDefault();
            return;
        }

        if (e.button === 1 || (e.button === 0 && !isInteractive)) {
            isPanning = true;
            panStartX = e.clientX - flowPanX;
            panStartY = e.clientY - flowPanY;
            $viewport.css('cursor', 'grabbing');
            e.preventDefault();
        }
    });

    $(document).on('mousemove.flowPan', function(e) {
        if (boxStart && $box) {
            var vr = $viewport[0].getBoundingClientRect();
            var x = e.clientX - vr.left, y = e.clientY - vr.top;
            $box.css({ left: Math.min(x, boxStart.x), top: Math.min(y, boxStart.y), width: Math.abs(x - boxStart.x), height: Math.abs(y - boxStart.y) });
            return;
        }
        if (!isPanning) return;
        flowPanX = e.clientX - panStartX;
        flowPanY = e.clientY - panStartY;
        applyTransform();
    });

    $(document).on('mouseup.flowPan', function(e) {
        if (boxStart && $box) {
            var vr = $viewport[0].getBoundingClientRect();
            var x = e.clientX - vr.left, y = e.clientY - vr.top;
            var rx = Math.min(x, boxStart.x), ry = Math.min(y, boxStart.y);
            var rw = Math.abs(x - boxStart.x), rh = Math.abs(y - boxStart.y);
            $box.remove(); $box = null; boxStart = null;
            if (zoomBoxMode) { zoomBoxMode = false; $('#flowZoomBox').removeClass('is-active'); $viewport.removeClass('is-zoombox'); }
            if (rw > 12 && rh > 12) zoomToRect(rx, ry, rw, rh);
            return;
        }
        if (isPanning) {
            isPanning = false;
            $viewport.css('cursor', '');
        }
    });
}

function renderCallFlowList(response, tileName) {
    var $container = $('#giantModalListTableDiv');
    $container.children().remove();

    var dataCount = response.data ? Object.keys(response.data).length : 0;
    var html = flowBetaStrip();

    if (dataCount === 0) {
        html += '<div class="giant-empty-state" style="padding:40px 20px;">';
        html += '<i class="fa-duotone fa-diagram-project fa-3x" style="--fa-primary-color: #d1d5db; --fa-secondary-color: #e5e7eb; margin-bottom:16px !important;"></i>';
        html += '<p style="font-size:15px; font-weight:600; color:#1a1a2e; margin:0 0 6px;">No phone numbers</p>';
        html += '<p style="font-size:13px; color:#6c757d; margin:0;">Your call flows will appear here once you have phone numbers assigned.</p>';
        html += '</div>';
    } else {
        html += '<div class="giant-vm-grid">';
        Object.entries(response.data).forEach(function(entry) {
            var item = entry[1];
            var number = item.number_display || ('0' + (item.di_area || '') + (item.di_number || ''));
            var comment = item.di_comment || '';
            var summary = item.flow_summary || 'No flow configured';
            var count = item.flow_count || 0;

            html += '<div class="giant-vm-card giant-flow-card-item" data-typesrc="DID" data-typeidsrc="' + item.di_id + '" data-name="' + number + '">';
            html += '  <div class="giant-vm-card-icon"><i class="fa-duotone fa-diagram-project fa-lg" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f; margin-bottom:0;"></i></div>';
            html += '  <div class="giant-vm-card-body">';
            html += '    <div class="giant-vm-card-name">' + number + (comment ? ' <span style="color:#9ca3af; font-weight:400;">- ' + comment + '</span>' : '') + '</div>';
            html += '    <div class="giant-vm-card-meta" style="font-size:12px; color:#6c757d;">' + summary + '</div>';
            html += '  </div>';
            html += '  <div class="giant-vm-card-counts">';
            var issues = parseInt(item.flow_issues || 0, 10) || 0;
            if (issues > 0) html += '    <span class="giant-flow-card-issues" title="Places a call can get stuck — open the flow and press the findings badge to review them"><i class="fa-solid fa-triangle-exclamation"></i> ' + issues + ' to check</span>';
            html += '    <span class="giant-vm-badge-total">' + count + ' step' + (count !== 1 ? 's' : '') + '</span>';
            html += '  </div>';
            html += '  <div class="giant-vm-card-actions">';
            html += '    <button class="giant-icon-btn giant-icon-edit" style="width:auto; padding:4px 10px; font-size:11px; border-radius:6px;" title="Edit Flow"><i class="fa-solid fa-diagram-project" style="margin-bottom:0;"></i></button>';
            html += '  </div>';
            html += '</div>';
        });
        html += '</div>';
    }

    $container.html(html);

    // Click card to open flow builder
    $('.giant-flow-card-item').off('click').on('click', function() {
        var typeSrc = $(this).data('typesrc');
        var typeIdSrc = $(this).data('typeidsrc');
        var name = $(this).data('name');
        openCallFlowBuilder(typeSrc, typeIdSrc, name);
    });

    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').find('.giant-empty-state').filter(function() { return !$(this).closest('#giantModalListTableDiv').length; }).remove();

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

function reRenderFlow() {
    flowHistoryTrack();   // every change lands here, so this is where undo history is kept
    // Preserve zoom/pan state across re-renders
    var savedZoom = window._flowZoom;
    var savedPanX = window._flowPanX;
    var savedPanY = window._flowPanY;

    var $container = $('#giantModalListTableDiv');
    renderFlowBuilder($container, window._flowData, window._flowDisplayName, window._flowTypeSrc, window._flowTypeIdSrc);
    fixBranchConnectors();

    // Restore zoom/pan
    window._flowZoom = savedZoom;
    window._flowPanX = savedPanX;
    window._flowPanY = savedPanY;
    if (window._flowApplyTransform) window._flowApplyTransform();
    flowFitViewport();
    if (window._flowCenterIfFits) window._flowCenterIfFits();   // a small tree stays centred as it changes
    flowSyncPlayButtons();
    flowLivePaint();   // presence dots and unread badges survive the re-render
    flowAuditPaint();  // dead ends, falls-off-the-end, loops
}

// Draw every link as SVG over the canvas: a soft curve from a node's edge to
// each of its branch labels, straight runs between steps, a dot where each
// link lands, and a pulse travelling forward along each one. Coordinates are
// layout px inside the zoomed canvas, so zoom and pan need no redraw; it's
// re-run after anything that reflows the tree. The CSS-drawn connectors stay
// as invisible spacers (and as the fallback if this ever fails).
function flowDrawLinks() {
    var canvas = document.getElementById('flowCanvas');
    if (!canvas || window._flowChunkBusy) return;   // drawn once the last chunk has landed
    var $canvas = $(canvas);
    $canvas.children('svg.giant-flow-links').remove();

    var horizontal = canvas.classList.contains('is-horizontal');
    var cr = canvas.getBoundingClientRect();
    // Effective scale between measured rects and layout px — whatever this
    // browser does with CSS zoom inside getBoundingClientRect.
    var z = (canvas.offsetWidth && cr.width) ? (cr.width / canvas.offsetWidth) : (window._flowZoom || 1);
    var reduce = false;
    try { reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}

    var pt = function (r, side) {
        var x = (side === 'l') ? r.left : (side === 'r') ? r.right : r.left + r.width / 2;
        var y = (side === 't') ? r.top  : (side === 'b') ? r.bottom : r.top + r.height / 2;
        return [Math.round((x - cr.left) / z * 10) / 10, Math.round((y - cr.top) / z * 10) / 10];
    };

    var links = [];
    // Straight runs: every spacer connector except the one feeding a branches
    // container (those links start at the card and curve).
    $canvas.find('.giant-flow-connector').each(function () {
        // A spacer (or a run of them) leading into a branches container isn't
        // a link of its own — the curves start at the card.
        var $n = $(this).next();
        while ($n.length && $n.hasClass('giant-flow-connector')) $n = $n.next();
        if ($n.hasClass('giant-flow-branches')) return;
        var r = this.getBoundingClientRect();
        var a = pt(r, horizontal ? 'l' : 't'), b = pt(r, horizontal ? 'r' : 'b');
        // Which cards this joins (for walking a call): the card before it, or
        // the branch's owner when it's the label's lead-in; and the card after.
        var $prev = $(this).prevAll('.giant-flow-node, .giant-flow-start').first();
        var from  = $prev.length ? String($prev.data('index')) : String($(this).closest('.giant-flow-branches').data('owner') || '');
        var $next = $(this).nextAll('.giant-flow-node').first();
        var to    = $next.length ? String($next.data('index')) : '';
        // Every run inside a lane keeps the lane's colour — from the pill to the
        // first step, between steps, and on to the call-end cap — until a
        // nested lane sets its own.
        var $lane   = $(this).closest('.giant-flow-branch');
        var runKind = $lane.attr('data-kind') || '';
        var runOff  = $(this).closest('.giant-flow-branch.is-inactive').length > 0;
        var runLane = $lane.length ? (($lane.closest('.giant-flow-branches').attr('data-owner') || '') + ':' + ($lane.attr('data-branch') || '')) : '';
        links.push({ d: 'M' + a[0] + ' ' + a[1] + ' L' + b[0] + ' ' + b[1], s: a, e: b, len: Math.abs(b[0] - a[0]) + Math.abs(b[1] - a[1]), from: from, to: to, kind: runKind, off: runOff, lane: runLane });
    });
    // Curves: from the owning card (or the start pill) to each branch label.
    $canvas.find('.giant-flow-branches').each(function () {
        var $b = $(this);
        var $src = $b.prevAll('.giant-flow-node, .giant-flow-start').first();
        if (!$src.length) return;
        var s = pt($src[0].getBoundingClientRect(), horizontal ? 'r' : 'b');
        var faded = $b.hasClass('drag-with');
        var from  = String($src.data('index') || '');
        var $exits = $src.children('.giant-flow-exits').children('.giant-flow-exit');
        $b.children('.giant-flow-branch').each(function () {
            var $lbl = $(this).children('.giant-flow-branch-label').first();
            var t = pt(($lbl.length ? $lbl[0] : this).getBoundingClientRect(), horizontal ? 'l' : 't');
            var $first = $(this).children('.giant-flow-node').first();
            var to = $first.length ? String($first.data('index')) : '';
            // Left-to-right: start at this exit's own anchor on the card's edge.
            var s0 = s;
            var bName = $(this).attr('data-branch');
            var kind  = $(this).attr('data-kind') || '';
            var off   = $(this).hasClass('is-inactive') || $b.closest('.giant-flow-branch.is-inactive').length > 0;
            if (horizontal && bName != null && $exits.length) {
                var $dot = $exits.filter(function () { return $(this).attr('data-branch') === bName; }).children('.giant-flow-exit-dot').first();
                if ($dot.length) s0 = pt($dot[0].getBoundingClientRect(), 'c');
            }
            var d;
            if (horizontal) {
                var mx = (s0[0] + t[0]) / 2;
                d = 'M' + s0[0] + ' ' + s0[1] + ' C' + mx + ' ' + s0[1] + ' ' + mx + ' ' + t[1] + ' ' + t[0] + ' ' + t[1];
            } else {
                var my = (s0[1] + t[1]) / 2;
                d = 'M' + s0[0] + ' ' + s0[1] + ' C' + s0[0] + ' ' + my + ' ' + t[0] + ' ' + my + ' ' + t[0] + ' ' + t[1];
            }
            var dx = t[0] - s0[0], dy = t[1] - s0[1];
            links.push({ d: d, s: s0, e: t, len: Math.sqrt(dx * dx + dy * dy) * 1.15, faded: faded, from: from, to: to, kind: kind, off: off, lane: from + ':' + (bName || '') });
        });
    });

    if (!links.length) { canvas.classList.remove('has-links'); return; }
    // A very large tree keeps its curves but not hundreds of animated pulses.
    if (links.length > 300) reduce = true;

    var W = Math.ceil(cr.width / z), H = Math.ceil(cr.height / z);
    var svg = '<svg class="giant-flow-links" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true">';
    // Arrowhead for links on a walked path
    svg += '<defs><marker id="gfArrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="#00b88d"/></marker></defs>';
    links.forEach(function (l) {
        var kindCls = ((l.kind && l.kind !== 'exit') ? ' is-' + l.kind : '') + (l.off ? ' is-off' : '');
        var laneAttr = l.lane ? ' data-lane="' + String(l.lane).replace(/&/g, '&amp;').replace(/"/g, '&quot;') + '"' : '';
        var cls = 'giant-flow-link' + (l.faded ? ' is-faded' : '') + kindCls;
        svg += '<path class="' + cls + '" d="' + l.d + '" data-from="' + (l.from || '') + '" data-to="' + (l.to || '') + '"' + laneAttr + '/>';
        svg += '<circle class="giant-flow-link-dot' + (l.faded ? ' is-faded' : '') + kindCls + '" cx="' + l.e[0] + '" cy="' + l.e[1] + '" r="3"' + laneAttr + '/>';
        if (!reduce && !l.faded && !l.off) {
            // Constant-ish speed, phased by position so pulses flow outward
            // from the incoming call; a negative begin means no waiting dot.
            var dur   = Math.min(2.4, Math.max(0.7, l.len / 220));
            var phase = ((horizontal ? l.s[0] : l.s[1]) / 420) % dur;
            var begin = -(dur - phase);
            svg += '<circle class="giant-flow-pulse' + kindCls + '" r="3.5"' + laneAttr + '><animateMotion dur="' + dur.toFixed(2) + 's" begin="' + begin.toFixed(2) + 's" repeatCount="indefinite" path="' + l.d + '"/></circle>';
        }
    });
    svg += '</svg>';
    $canvas.prepend(svg);
    canvas.classList.add('has-links');
    flowPickApply();   // a pinned lane stays lit across redraws
}

// Position each branches container's connector bar so it spans exactly from
// the first branch's stub to the last one's: horizontal (top-down layout) or
// vertical (left-to-right). Measured through getBoundingClientRect, which the
// canvas's CSS zoom scales, so divide back to layout pixels before setting.
// (Fallback geometry — the SVG overlay drawn afterwards is what's visible.)
function fixBranchConnectors() {
    setTimeout(function() {
        var canvasEl = document.getElementById('flowCanvas');
        var horizontal = !!(canvasEl && canvasEl.classList.contains('is-horizontal'));
        var z = window._flowZoom || 1;
        if (canvasEl && canvasEl.offsetWidth) {
            var ccr = canvasEl.getBoundingClientRect();
            if (ccr.width) z = ccr.width / canvasEl.offsetWidth;   // effective rect→layout scale
        }
        $('.giant-flow-branches').each(function() {
            var el = this;
            var $children = $(el).children('.giant-flow-branch');
            if ($children.length < 2) {
                el.style.setProperty('--bar-left', '50%');
                el.style.setProperty('--bar-right', '50%');
                el.style.setProperty('--bar-top', '50%');
                el.style.setProperty('--bar-bottom', '50%');
                return;
            }
            var p = el.getBoundingClientRect();
            var f = $children.first()[0].getBoundingClientRect();
            var l = $children.last()[0].getBoundingClientRect();
            if (horizontal) {
                var firstMid = (f.top + f.height / 2 - p.top) / z;
                var lastMid  = (l.top + l.height / 2 - p.top) / z;
                el.style.setProperty('--bar-top', firstMid + 'px');
                el.style.setProperty('--bar-bottom', (p.height / z - lastMid) + 'px');
            } else {
                var firstCenter = (f.left + f.width / 2 - p.left) / z;
                var lastCenter  = (l.left + l.width / 2 - p.left) / z;
                el.style.setProperty('--bar-left', firstCenter + 'px');
                el.style.setProperty('--bar-right', (p.width / z - lastCenter) + 'px');
            }
        });
        flowDrawLinks();
        flowDrawMinimap();
        if (window._flowWalking) flowWalkClear();   // the tree changed under the walk
    }, 50);
}

// What a branch is called, and its colour class: "Press 1", "If it matches",
// "On timeout · 2 min", "No answer (off)"… used by the pill on the connector
// and by the exit row on the card, so the two always agree.
// Which family a branch belongs to. The family colours the pill, the row on
// the card, its anchor, its curve and its pulse the same way, so a colour
// always means the same thing anywhere on the canvas:
//   match   green   the condition matches; an extension's on-condition divert
//   nomatch red     otherwise; a key the menu doesn't offer; phone offline;
//                   nobody logged in; a failed call
//   timeout yellow  nobody pressed a key, nobody answered, waited too long
//   busy    orange  phone engaged; every agent busy; queue full
//   press   blue    the caller did something: a key, a dialled entry, the
//                   exit key, asked for a callback, pressed 0, sent an SMS
//   divert  purple  an unconditional forward (number or extension)
//   end     rose    the call ends here
//   exit    teal    the plain onward path: normal routing, then, welcome
function flowBranchKind(branchName) {
    var b = String(branchName || '');
    if (b === 'true' || b === 'EXT-ONCONDITION') return 'match';
    if (b === 'false' || b === 'IVR_WRONG' || b === 'IVR_I' || /[-_]INVALID$/.test(b)
        || b === 'EXT-OFFLINE' || b === 'QUEUE-NOBODYHOME' || /[-_](FAILOVER|FAILURE)$/.test(b)) return 'nomatch';
    if (b === '__end') return 'end';
    if (/TIMEOUT$/.test(b) || b === 'IVR_T' || b === 'EXT-NOANSWER') return 'timeout';
    if (b === 'EXT-BUSY' || b === 'QUEUE-NOFREEMEMBER' || b === 'QUEUE-FULL') return 'busy';
    if (b === 'unconditional' || /[-_]UNCONDITIONAL$/.test(b)) return 'divert';
    if (b.indexOf('press_') === 0 || b.indexOf('CUSTOMIVR_') === 0 || b === 'QUEUE-EXITKEY'
        || b === 'QUEUE-ONCALLBACK' || b === 'VOICEMAIL-OPERATOR' || b === 'DID-SMS') return 'press';
    return 'exit';
}
// The pill / row-label class for a family.
var flowBranchKindClass = { match: 'branch-true', nomatch: 'branch-false', timeout: 'branch-timeout', busy: 'branch-busy', press: 'branch-press', divert: 'branch-divert', end: 'branch-end', exit: 'branch-exit' };

// Why a lane can't fire right now: '' (it can), 'off' (its switch is off —
// an unconditional divert, an extension's busy/no-answer route) or
// 'bypassed' (something earlier takes every call: normal routing while the
// number's unconditional divert is on, an extension's other exits while it
// is diverted unconditionally).
function flowLaneInactive(node, branchName) {
    var meta = node && node.branchMeta;
    if (!meta) return '';
    if (meta[branchName] && meta[branchName].active === false) {
        return branchName === 'destination' ? 'bypassed' : 'off';
    }
    if (node.type === 'EXT' && branchName !== 'EXT-UNCONDITIONAL' && meta['EXT-UNCONDITIONAL'] && meta['EXT-UNCONDITIONAL'].active === true
        && node.children && (node.children['EXT-UNCONDITIONAL'] || []).length) {
        return 'bypassed';
    }
    return '';
}

function flowBranchLabel(node, branchName) {
    var text = branchName;
    if (branchName === 'welcome') { text = 'Welcome'; }
    else if (branchName === 'true') { text = 'If it matches'; }
    else if (branchName === 'false') { text = 'Otherwise'; }
    else if (branchName === 'destination') { text = 'Normal routing'; }
    else if (branchName === 'unconditional') { text = 'Unconditional (always)'; }
    else if (/^[A-Z]+([-_]|$)/.test(branchName)) { text = flowExitLabel(branchName); }   // generic exit keyed by typesrc (incl. bare FLOW/FEATURE)
    else { text = String(branchName).replace('press_', 'Press ').replace('star', '*').replace('sharp', '#'); }
    // A lane that can't fire still shows, flagged with why.
    var inactive = flowLaneInactive(node, branchName);
    if (inactive) text += ' (' + inactive + ')';
    // Timings on the exits they govern.
    if (node && node.details) {
        if (branchName === 'QUEUE-TIMEOUT'    && node.details.timeout)     text += ' · ' + flowSecs(node.details.timeout);
        if (branchName === 'HUNTLIST-TIMEOUT' && node.details.dialTimeout) text += ' · ' + node.details.dialTimeout + 's';
    }
    return { text: text, cls: flowBranchKindClass[flowBranchKind(branchName)] || 'branch-exit' };
}

function renderFlowNode(node, idx, ctx) {
    var type = node.type || '';
    var icon = flowTypeIcons[type] || 'fa-circle-nodes';
    var label = flowTypeLabels[type] || type;
    var iconClass = 'type-' + (['EXT','IVR','QUEUE','HUNTLIST','PLAYBACK','VOICEMAIL','CONDITION','CUSTOM'].indexOf(type) > -1 ? type : 'default');

    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };
    // Every node gets a unique id once; handlers address nodes by it.
    if (node._uid == null) { window._flowUidSeq = (window._flowUidSeq || 0) + 1; node._uid = window._flowUidSeq; }
    var uid         = node._uid;
    var isRepeat    = !!(node.repeat && !node.expanded);   // drawn in full earlier in this tree
    var isGlobal    = !!(window._flowData && window._flowData.globals && window._flowData.globals.indexOf(node.tag) > -1);

    // An element just placed hasn't got its exits from the server yet — show
    // its standard slots straight away (a condition's if / otherwise, a
    // queue's or hunt list's timeout, an extension's no-answer) so there's
    // somewhere to build. Provisional: never written back while empty.
    if (!isRepeat && !node.children) {
        var dflt = { CONDITION: ['true', 'false'], QUEUE: ['QUEUE-TIMEOUT'], HUNTLIST: ['HUNTLIST-TIMEOUT'], EXT: ['EXT-NOANSWER'] }[type];
        if (dflt) {
            node.children = {};
            dflt.forEach(function (k) { node.children[k] = []; });
            node._provisional = true;
        }
    }

    var hidden      = isRepeat || !!node.collapsed;        // its branches aren't drawn under this card
    var hasBranches = !!(node.children && Object.keys(node.children).length);
    // A repeat: does the element actually have steps to show (per the server,
    // else by finding its full copy), and could it have any at all?
    var repeatHasSteps = isRepeat && (node.hasSteps != null ? !!node.hasSteps : flowTagHasSteps(node.tag));
    var repeatCanHave  = isRepeat && !flowNoExitTypes[type];

    var html = '';
    // A synthetic DID root has no card of its own — only its side-by-side lanes.
    if (type !== 'DIDROOT') {
    html += '<div class="giant-flow-node' + (isRepeat ? ' is-repeat' : '') + (hasBranches && !isRepeat ? ' has-exits' : '') + (node.collapsed ? ' is-collapsed' : '') + (ctx && ctx.afterEnd ? ' is-unreachable' : '') + '" draggable="' + (window._flowEditing ? 'true' : 'false') + '" data-index="' + uid + '" data-tag="' + (node.tag || '') + '"' + (ctx && ctx.afterEnd ? ' title="Can\'t be reached: the call has already ended at the step before"' : '') + '>';
    if (type === 'PLAYBACK') {
        // An announcement's icon is its play control.
        html += '<button type="button" class="giant-flow-node-icon giant-flow-play is-icon" data-id="' + esc(node.id || '') + '" title="Play this announcement"><i class="fa-solid fa-play"></i></button>';
    } else {
        html += '<div class="giant-flow-node-icon ' + iconClass + '"><i class="fa-duotone ' + icon + '"></i></div>';
    }
    html += '<div class="giant-flow-node-body">';
    html += '<div class="giant-flow-node-name">' + (node.name || node.tag) + '</div>';
    html += '<div class="giant-flow-node-type">' + label
          + (node.loop ? ' <span class="giant-flow-loop" title="This element is already earlier in this path — the call loops back to it here">&#8635; loops back</span>' : '')
          + (node.refs > 1 ? ' <span class="giant-flow-shared" title="Used by ' + node.refs + ' routes. Changing the steps under it changes all of them; use Make a copy if this route should differ."><i class="fa-solid fa-share-nodes"></i> shared &middot; ' + node.refs + '</span>' : '')
          + (isGlobal ? ' <span class="giant-flow-sys" title="Shared with every account; it can\'t be edited here">shared</span>' : '')
          + '</div>';
    // What the element does, at a glance — its schedule, strategy, timing,
    // number… so the flow reads without opening anything.
    var d = node.details || {};
    var meta = [];
    if (type === 'CONDITION') {
        // A shared list it follows (our UK bank holidays, or another master);
        // then the dates themselves (full list on hover) or the hours per run
        // of days for a week-time condition.
        if (d.shared) meta.push({ html: '<i class="fa-solid fa-flag"></i>Shared · ' + esc(d.shared), title: 'A list we keep up to date for you — its dates can\'t be edited here' });
        if (d.schedule) {
            var schedIcon = d.scheduleKind === 'weekly' ? 'fa-clock' : (d.scheduleKind === 'callerid' ? 'fa-id-card' : 'fa-calendar-days');
            meta.push({ html: '<i class="fa-solid ' + schedIcon + '"></i>' + esc(d.schedule), title: d.scheduleFull || '', cls: 'is-wrap' + (d.scheduleEmpty ? ' is-warn' : '') });
        }
        if (d.schedulePast) meta.push({ html: '<i class="fa-solid fa-triangle-exclamation"></i>All these dates have passed', title: 'This condition can\'t match again until its dates are updated', cls: 'is-warn' });
    }
    if (type === 'QUEUE') {
        if (d.strategy)   meta.push({ html: '<i class="fa-solid fa-arrows-turn-to-dots"></i>' + esc(d.strategy), title: 'How calls are shared between agents' });
        if (d.timeout)    meta.push({ html: '<i class="fa-solid fa-hourglass-half"></i>Waits up to ' + flowSecs(d.timeout), title: 'The longest a caller can wait before the timeout exit' });
        if (d.ringTime)   meta.push({ html: '<i class="fa-solid fa-bell"></i>' + flowSecs(d.ringTime) + ' per agent', title: 'How long each agent\'s phone rings before the queue moves on' });
        if (d.maxWaiting) meta.push({ html: '<i class="fa-solid fa-users-line"></i>Max ' + esc(d.maxWaiting) + ' waiting', title: 'Callers beyond this take the "queue full" exit' });
        if (d.ringInUse)  meta.push({ html: '<i class="fa-solid fa-phone-volume"></i>Rings busy agents', title: 'Agents are rung even while on a call or offline' });
    }
    if (type === 'HUNTLIST') {
        if (d.ringType) meta.push('<i class="fa-solid fa-users-rays"></i>' + esc(d.ringType));
        if (d.ringTime) meta.push('<i class="fa-solid fa-stopwatch"></i>' + esc(d.ringTime) + 's each');
    }
    if (type === 'EXT' && d.number) meta.push('<i class="fa-solid fa-hashtag"></i>Ext ' + esc(d.number));
    if (type === 'VOICEMAIL') {
        if (d.mailbox) meta.push('<i class="fa-solid fa-inbox"></i>Mailbox ' + esc(d.mailbox));
        if (d.email)   meta.push('<i class="fa-solid fa-envelope"></i>' + esc(d.email));
    }
    if (type === 'CUSTOM') {
        if (d.service) meta.push({ html: '<i class="fa-solid fa-shield-halved"></i>' + esc(d.service), title: 'A shared service: the call is handed to it' });
        if (d.number)  meta.push('<i class="fa-solid fa-phone"></i>' + esc(d.number));
        if (d.cid)     meta.push('<i class="fa-solid fa-id-card"></i>' + esc(d.cid));
        if (d.timeout) meta.push('<i class="fa-solid fa-stopwatch"></i>' + esc(d.timeout) + 's');
    }
    if (type === 'PLAYBACK' && d.duration) meta.push('<i class="fa-solid fa-clock"></i>' + esc(d.duration));
    if (meta.length) {
        html += '<div class="giant-flow-node-meta">' + meta.map(function (m) {
            if (typeof m === 'string') return '<span>' + m + '</span>';
            return '<span class="' + (m.cls || '') + '"' + (m.title ? ' title="' + esc(m.title) + '"' : '') + '>' + m.html + '</span>';
        }).join('') + '</div>';
    }
    // Members / agents: pills that jump to that extension's card, or open it.
    if (node.agents && node.agents.length > 0) {
        var maxShow = 3;
        var shown = node.agents.slice(0, maxShow);
        var extra = node.agents.length - maxShow;
        html += '<div class="giant-flow-node-agents">';
        shown.forEach(function(a, ai) {
            // Extract just the name part before " - "
            var shortName = String(a).split(' - ')[0];
            var aTag = (node.agentTags || [])[ai] || '';
            html += '<span class="giant-flow-agent-pill' + (aTag ? ' is-link' : '') + '"' + (aTag ? ' data-tag="' + esc(aTag) + '" data-name="' + esc(shortName) + '" title="Go to ' + esc(shortName) + '"' : '') + '>' + esc(shortName) + '</span>';
        });
        if (extra > 0) {
            html += '<span class="giant-flow-agent-more">+' + extra + ' more</span>';
        }
        html += '</div>';
    }
    // Settings stored as destination rows but not call-path exits (an IVR's
    // announcement, on-hangup…): shown on the card, not as branches.
    if (node.extras && Object.keys(node.extras).length) {
        html += '<div class="giant-flow-node-extras">';
        Object.keys(node.extras).forEach(function (k) {
            html += '<div class="giant-flow-extra">';
            html += '<span class="giant-flow-extra-k">' + esc(flowExitLabel(k)) + '</span>';
            (node.extras[k] || []).forEach(function (x) {
                var xIcon = flowTypeIcons[x.type] || 'fa-arrow-right-to-bracket';
                html += '<span class="giant-flow-extra-v"><i class="fa-solid ' + xIcon + '"></i>' + esc(x.name || x.tag);
                // An announcement: hear it right here.
                if (x.type === 'PLAYBACK' && x.id) {
                    html += ' <button type="button" class="giant-flow-play is-mini" data-id="' + esc(x.id) + '" title="Play this announcement"><i class="fa-solid fa-play"></i></button>';
                }
                html += '</span>';
            });
            html += '</div>';
        });
        html += '</div>';
    }
    if (isRepeat) {
        html += '<div class="giant-flow-node-repeat"><i class="fa-solid fa-arrow-turn-up"></i> ' + (repeatHasSteps ? 'Its steps are drawn earlier in this flow' : 'Also used earlier in this flow') + '</div>';
    }
    html += '</div>';
    var safeName = esc(node.name || node.tag);
    html += '<div class="giant-flow-node-actions">';
    if (hasBranches && !isRepeat) {
        html += '<button class="giant-flow-node-toggle' + (node.collapsed ? ' is-hidden' : '') + '" data-index="' + uid + '" title="' + (node.collapsed ? 'Show' : 'Hide') + ' the steps under this"><i class="fa-solid ' + (node.collapsed ? 'fa-eye' : 'fa-eye-slash') + '"></i></button>';
        if (String(window._flowFocusUid) !== String(uid)) {
            html += '<button class="giant-flow-node-focus" data-index="' + uid + '" title="Focus on this branch (or double-click the card)"><i class="fa-solid fa-crosshairs"></i></button>';
        }
    }
    if (flowEditTiles[type] && !isGlobal) {
        html += '<button class="giant-flow-node-edit" data-type="' + type + '" data-id="' + esc(node.id || '') + '" data-name="' + safeName + '" title="Edit ' + label + '"><i class="fa-solid fa-pen"></i></button>';
    }
    if (['HUNTLIST', 'QUEUE', 'IVR', 'CONDITION'].indexOf(type) > -1 && !isGlobal) {
        html += '<button class="giant-flow-node-clone" data-type="' + type + '" data-id="' + esc(node.id || '') + '" data-name="' + safeName + '" title="Make a copy of this ' + String(label).toLowerCase() + ' for this route"><i class="fa-solid fa-clone"></i></button>';
    }
    html += '<button class="giant-flow-node-remove" data-index="' + uid + '" title="Remove"><i class="fa-solid fa-xmark"></i></button>';
    html += '</div>';
    // The card's "+" port on its trailing edge: adds the next step right
    // after this one in its branch (click to pick, or drop a widget on it).
    if (ctx && (ctx.main || ctx.typeSrc)) {
        var portAttrs = ctx.main ? 'data-main="1"' : 'data-typesrc="' + ctx.typeSrc + '" data-typeidsrc="' + esc(ctx.typeIdSrc) + '"';
        html += '<button class="giant-flow-branch-add giant-flow-port" ' + portAttrs + ' data-after="' + uid + '" title="Add a step after this one"><i class="fa-solid fa-plus" style="margin-bottom:0;"></i></button>';
    }
    // Every way out of this element as its own row — "Press 1 · Sales",
    // "On timeout · Voicemail" — with an anchor on the card's edge, so the
    // card reads like a menu and each curve leaves from the row it belongs to.
    if (hasBranches && !isRepeat) {
        var exitKeys  = Object.keys(node.children);
        var anyRouted = exitKeys.some(function (k) { return (node.children[k] || []).length > 0; });
        html += '<div class="giant-flow-exits">';
        exitKeys.forEach(function (bName) {
            var lbl   = flowBranchLabel(node, bName);
            var steps = node.children[bName] || [];
            var first = steps[0];
            var v, vCls = '';
            if (first) {
                v = esc(first.name || first.tag);
                if (steps.length > 1) v += ' <em>+' + (steps.length - 1) + ' more</em>';
            } else if (flowDeadEndKeys[bName]) { v = 'Nothing routed yet'; vCls = ' is-warn'; }
            else { v = 'Not routed'; vCls = ' is-empty'; }
            var kind = flowBranchKind(bName);
            html += '<div class="giant-flow-exit is-' + kind + (flowLaneInactive(node, bName) ? ' is-inactive' : '') + '" data-branch="' + esc(bName) + '" data-kind="' + kind + '" title="' + esc(lbl.text) + (first ? ' goes to ' + esc(first.name || first.tag) : '') + '">';
            // A menu's rows start with the key itself, as on a keypad.
            if (type === 'IVR' && bName.indexOf('press_') === 0) {
                html += '<span class="giant-flow-key">' + esc(flowKeyLabel(bName)) + '</span>';
            } else if (type === 'IVR' && bName === 'IVR_TIMEOUT') {
                html += '<span class="giant-flow-key is-exit"><i class="fa-solid fa-clock"></i> timeout</span>';
            } else if (type === 'IVR' && bName === 'IVR_WRONG') {
                html += '<span class="giant-flow-key is-exit"><i class="fa-solid fa-ban"></i> invalid</span>';
            } else if (type === 'IVR' && bName.indexOf('CUSTOMIVR_') === 0) {
                html += '<span class="giant-flow-key is-dial" title="The caller dials ' + esc(bName.slice(10)) + ' at the menu"><i class="fa-solid fa-keyboard"></i> ' + esc(bName.slice(10)) + '</span>';
            } else {
                html += '<span class="giant-flow-exit-k ' + lbl.cls + '">' + esc(lbl.text) + '</span>';
            }
            html += '<span class="giant-flow-exit-v' + vCls + '"><i class="fa-solid fa-arrow-right-long"></i>' + v + '</span>';
            html += '<span class="giant-flow-exit-dot"></span>';
            html += '</div>';
        });
        // A terminating element with a side route still ends the call otherwise.
        if (flowTerminalTypes[type] && anyRouted) {
            html += '<div class="giant-flow-exit is-end" data-branch="__end" data-kind="end"><span class="giant-flow-exit-k branch-end">' + (type === 'VOICEMAIL' ? 'After the message' : 'Otherwise') + '</span><span class="giant-flow-exit-v is-empty"><i class="fa-solid fa-phone-slash"></i>Call ends</span><span class="giant-flow-exit-dot"></span></div>';
        }
        if (type === 'IVR' && flowIvrFreeKeys(node).length) {
            html += '<button type="button" class="giant-flow-exit giant-flow-exit-add giant-flow-key-add" data-index="' + uid + '" title="Add a key press or exit"><i class="fa-solid fa-plus"></i> Add a key press or exit</button>';
        }
        if (type === 'QUEUE' && flowQueueFreeExits(node).length) {
            html += '<button type="button" class="giant-flow-exit giant-flow-exit-add giant-flow-key-add" data-index="' + uid + '" title="Add an exit: what happens on the exit key, when nobody is logged in, when the queue is full…"><i class="fa-solid fa-plus"></i> Add an exit</button>';
        }
        html += '</div>';
    }
    html += '</div>';
    }

    // Where the call ends: the last step of a branch that finishes the call
    // (voicemail, an external number, a hang-up…) gets an explicit end cap,
    // so every path visibly finishes somewhere.
    var anySteps = false;
    Object.keys(node.children || {}).forEach(function (k) { if ((node.children[k] || []).length) anySteps = true; });
    var endCapHtml = '<div class="giant-flow-endcap" title="The call ends here"><span class="giant-flow-endcap-dot"><i class="fa-solid fa-phone-slash"></i></span><span class="giant-flow-endcap-txt">Call end</span></div>';
    if (flowTerminalTypes[type] && !anySteps && !isRepeat) {
        html += '<div class="giant-flow-connector"></div>';
        html += endCapHtml;
    }

    // Branches hidden under this card: a repeated element (expand on demand)
    // or one the user collapsed.
    if (hidden && hasBranches) {
        var hiddenCount = flowCountDescendants(node);
        html += '<button class="giant-flow-node-expand" data-index="' + uid + '" title="Show the hidden steps"><i class="fa-solid fa-chevron-right"></i> ' + hiddenCount + ' hidden step' + (hiddenCount === 1 ? '' : 's') + '</button>';
    } else if (isRepeat && repeatHasSteps) {
        html += '<button class="giant-flow-node-expand" data-index="' + uid + '" title="Show this element\'s steps here as well"><i class="fa-solid fa-diagram-subtask"></i> Show its steps here</button>';
    } else if (isRepeat && repeatCanHave) {
        html += '<button class="giant-flow-node-expand is-quiet" data-index="' + uid + '" title="It has no onward steps yet — open its slots here to add some"><i class="fa-solid fa-plus"></i> Add steps here</button>';
    }
    // Render branches
    else if (node.children && Object.keys(node.children).length > 0) {
        html += '<div class="giant-flow-connector"></div>';
        html += '<div class="giant-flow-branches" data-owner="' + uid + '">';
        Object.entries(node.children).forEach(function(branch) {
            var branchName = branch[0];
            var branchNodes = branch[1];
            var lbl        = flowBranchLabel(node, branchName);
            var labelClass = lbl.cls;
            var labelText  = lbl.text;

            var branchTypeSrc = flowBranchTypeSrc(node, branchName);
            var branchTypeIdSrc = node.id || '';
            var childCtx = branchTypeSrc ? { typeSrc: branchTypeSrc, typeIdSrc: branchTypeIdSrc } : null;

            html += '<div class="giant-flow-branch' + (flowLaneInactive(node, branchName) ? ' is-inactive' : '') + '" data-branch="' + esc(branchName) + '" data-kind="' + flowBranchKind(branchName) + '">';
            html += '<div class="giant-flow-branch-label ' + labelClass + '">' + esc(labelText) + '</div>';
            html += '<div class="giant-flow-connector"></div>';
            var depth  = (ctx && ctx.depth) || 0;
            var kidCtx = $.extend({}, childCtx || {}, { depth: depth + 1 });
            if (window._flowChunkOn && branchNodes.length && depth + 1 >= (window._flowChunkDepth || 2)) {
                // Deeper levels of a big tree draw in the next frames.
                var chunkId = ++window._flowChunkSeq;
                (window._flowChunkPending = window._flowChunkPending || []).push({ id: chunkId, nodes: branchNodes, ctx: kidCtx });
                html += '<div class="giant-flow-chunk" data-chunk="' + chunkId + '" title="Drawing…"><span></span><span></span><span></span></div>';
            } else {
                var ended = false;   // steps after a terminating one can't be reached
                branchNodes.forEach(function(child, childIdx) {
                    html += renderFlowNode(child, 'child_' + branchName + '_' + childIdx, $.extend({}, kidCtx, { isLast: childIdx === branchNodes.length - 1, afterEnd: ended }));
                    if (flowTerminalTypes[child.type]) ended = true;
                    if (childIdx < branchNodes.length - 1) {
                        html += '<div class="giant-flow-connector"></div>';
                    }
                });
            }
            // An empty branch shows a ghost card where its first step would go;
            // once it has steps, each card's own "+" port adds after it.
            if (branchTypeSrc && branchNodes.length === 0) {
                // Exits a call can actually reach with nothing routed: flag them.
                var deadEnd = !!flowDeadEndKeys[branchName];
                html += '<div class="giant-flow-slot is-empty">';
                html += '<button class="giant-flow-branch-add giant-flow-ghost' + (deadEnd ? ' is-warn' : '') + '" data-typesrc="' + branchTypeSrc + '" data-typeidsrc="' + esc(branchTypeIdSrc) + '" data-branch="' + esc(branchName) + '" title="' + (deadEnd ? 'Nothing is routed here yet — a call reaching this point has nowhere to go' : 'Add the first step to this branch') + '">';
                html += '<span class="giant-flow-ghost-icon"><i class="fa-solid ' + (deadEnd ? 'fa-triangle-exclamation' : 'fa-plus') + '" style="margin-bottom:0;"></i></span>';
                html += '<span class="giant-flow-ghost-body"><span class="giant-flow-ghost-title">' + (deadEnd ? 'Nothing routed yet' : 'Add a step') + '</span><span class="giant-flow-ghost-sub">' + esc(node.name || 'Incoming call') + ' &middot; ' + esc(labelText) + '</span></span>';
                html += '</button>';
                html += '</div>';
            }
            html += '</div>';
        });
        // A terminating element with a side route (a voicemail box's press-0
        // operator) still ends the call otherwise: show that as its own lane.
        if (flowTerminalTypes[type] && anySteps) {
            html += '<div class="giant-flow-branch giant-flow-branch-end" data-branch="__end" data-kind="end">';
            html += '<div class="giant-flow-branch-label branch-end">' + (type === 'VOICEMAIL' ? 'After the message' : 'Otherwise') + '</div>';
            html += '<div class="giant-flow-connector"></div>';
            html += endCapHtml;
            html += '</div>';
        }
        html += '</div>';

        // (Add Key moved inside the IVR node block)
        if (false) {
        }
    }

    return html;
}

// =============================================================================
// Transcript search results — renders matching calls (from searchCallTranscripts)
// as cards with a highlighted snippet, in place of the call-log table.
// =============================================================================
function highlightTranscriptSnippet(text, q) {
    var safe = $('<div>').text(text == null ? '' : String(text)).html();
    if (!q) return safe;
    try {
        var safeQ = $('<div>').text(q).html().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        return safe.replace(new RegExp('(' + safeQ + ')', 'ig'), '<mark class="giant-tsearch-mark">$1</mark>');
    } catch (e) { return safe; }
}

function renderTranscriptSearchResults(resp, q) {
    var $res = $('#giantTranscriptResults');
    if (!$res.length) return;
    if (!resp || !resp.ok) {
        $res.html('<div class="giant-tsearch-status">' + $('<div>').text((resp && resp.error) || 'Search failed.').html() + '</div>');
        return;
    }

    var rows = resp.data || [];
    var capNote = resp.capped ? ' · scanned the first ' + resp.scanned + ' calls — narrow the dates for a deeper search' : '';
    var head = '<div class="giant-tsearch-head">' +
        '<div class="giant-tsearch-count">' + rows.length + ' match' + (rows.length === 1 ? '' : 'es') +
            ' for “' + $('<div>').text(q).html() + '”' + capNote + '</div>' +
        '<button id="giantTranscriptBack" class="giant-btn-sm is-secondary"><i class="fa-solid fa-arrow-left" style="margin-bottom:0;"></i> Back to call log</button>' +
        '</div>';

    var body = '';
    if (!rows.length) {
        body = '<div class="giant-tsearch-empty"><i class="fa-solid fa-magnifying-glass"></i>' +
               '<p>No calls in this range mentioned that.</p>' +
               '<span>Try a wider date range or different wording.</span></div>';
    } else {
        rows.forEach(function (r, i) {
            body += '<div class="giant-tsearch-card" data-idx="' + i + '">' +
                '<div class="giant-tsearch-card-top">' +
                    '<span class="giant-tsearch-caller"><i class="fa-solid fa-user"></i> ' + $('<div>').text(r.caller || 'Unknown').html() + '</span>' +
                    '<span class="giant-tsearch-cmeta">' + $('<div>').text((r.direction || '') + (r.started ? ' · ' + r.started : '')).html() + '</span>' +
                '</div>' +
                '<div class="giant-tsearch-snippet">' + highlightTranscriptSnippet(r.snippet || '', q) + '</div>' +
                '<div class="giant-tsearch-card-actions">' +
                    '<button class="giant-tsearch-open giant-btn-sm is-primary"><i class="fa-solid fa-play" style="margin-bottom:0;"></i> Play &amp; transcript</button>' +
                '</div>' +
            '</div>';
        });
    }

    $res.html(head + body);
    $('#giantTranscriptBack').on('click', function () { $res.hide().empty(); $('#giantModalListTableDiv').show(); });
    $res.find('.giant-tsearch-open').on('click', function () {
        var r = rows[+$(this).closest('.giant-tsearch-card').data('idx')];
        if (r && r.recordid) {
            openRecordingPopup(String(r.recordid), { caller: r.caller, started: r.started, direction: r.direction, duration: r.duration });
        }
    });
}

// =============================================================================
// Transcript dialog — shared by voicemail and call-recording surfaces.
// Fires an AJAX POST with the supplied opts.fetch payload and renders the
// returned text in a scrollable, copy-able dialog. Reuses the existing
// .giant-confirm-overlay component so styling matches the rest of the portal.
// =============================================================================
function showTranscriptDialog(opts) {
    opts = opts || {};
    jQuery('#giantTranscriptDialog').remove();

    var $dlg = jQuery(
      '<div id="giantTranscriptDialog" class="giant-confirm-overlay">' +
        '<div class="giant-confirm" data-variant="primary" style="max-width: 640px;">' +
          '<div class="giant-confirm-head">' +
            '<div class="giant-confirm-icon"><i class="fa-duotone fa-quote-left" style="--fa-primary-color: #00d9a7; --fa-secondary-color: #99e15f;"></i></div>' +
            '<div>' +
              '<div class="giant-confirm-title">' + (opts.title || 'Transcript') + '</div>' +
              (opts.subtitle ? '<div class="giant-transcript-subtitle">' + jQuery('<div>').text(opts.subtitle).html() + '</div>' : '') +
            '</div>' +
          '</div>' +
          '<div class="giant-confirm-body">' +
            '<div class="giant-transcript-loading" style="padding:24px; text-align:center; color:#9ca3af;">' +
              '<i class="fa-duotone fa-spinner fa-spin-pulse fa-2xl" style="--fa-primary-color: #00d9a7; --fa-secondary-color: #99e15f;"></i>' +
              '<p style="margin-top:10px; font-size:13px;">Fetching transcript…</p>' +
            '</div>' +
          '</div>' +
          '<div class="giant-confirm-actions">' +
            '<button type="button" class="giant-transcript-copy giant-confirm-cancel" style="display:none;"><i class="fa-solid fa-copy"></i> Copy</button>' +
            '<button type="button" class="giant-confirm-ok">Close</button>' +
          '</div>' +
        '</div>' +
      '</div>'
    );

    jQuery('body').append($dlg);

    var close = function () { jQuery(document).off('keydown.giantTranscript'); $dlg.remove(); };
    $dlg.on('click', function (e) { if (e.target === this) close(); });
    jQuery(document).on('keydown.giantTranscript', function (e) { if (e.key === 'Escape') close(); });
    $dlg.find('.giant-confirm-ok').on('click', close);

    jQuery.ajax({
        type: 'post',
        data: opts.fetch || {},
        dataType: 'json'
    }).done(function (resp) {
        if (!resp || !resp.ok) {
            $dlg.find('.giant-confirm-body').html(
                '<div class="giant-transcript-empty">' +
                  '<i class="fa-duotone fa-circle-info" style="--fa-primary-color: #6b7280; --fa-secondary-color: #d1d5db; font-size: 28px; margin-bottom: 8px;"></i>' +
                  '<div>' + ((resp && resp.error) || 'No transcript available.') + '</div>' +
                '</div>'
            );
            return;
        }

        var safeText = jQuery('<div>').text(resp.text).html();
        $dlg.find('.giant-confirm-body').html(
            '<div class="giant-transcript-text">' + safeText + '</div>'
        );

        var $copy = $dlg.find('.giant-transcript-copy').show();
        $copy.off('click').on('click', function () {
            var $btn = jQuery(this);
            var orig = $btn.html();
            try {
                navigator.clipboard.writeText(resp.text).then(function () {
                    $btn.html('<i class="fa-solid fa-check"></i> Copied');
                    setTimeout(function () { $btn.html(orig); }, 1500);
                });
            } catch (e) {
                // Fallback for older browsers / non-secure contexts
                var ta = document.createElement('textarea');
                ta.value = resp.text;
                document.body.appendChild(ta);
                ta.select();
                try { document.execCommand('copy'); } catch (e2) {}
                document.body.removeChild(ta);
                $btn.html('<i class="fa-solid fa-check"></i> Copied');
                setTimeout(function () { $btn.html(orig); }, 1500);
            }
        });
    }).fail(function () {
        $dlg.find('.giant-confirm-body').html(
            '<div class="giant-transcript-empty">' +
              '<i class="fa-duotone fa-circle-info" style="--fa-primary-color: #6b7280; --fa-secondary-color: #d1d5db; font-size: 28px; margin-bottom: 8px;"></i>' +
              '<div>Transcript is unavailable for this recording.</div>' +
            '</div>'
        );
    });
}

/* ===========================================================
   DISA / Campaign / Music-on-Hold custom layouts
   (Caller-ID Blacklist uses the standard list/add path —
   only needs a small "Bulk paste" injection, handled below.)
   =========================================================== */

function gvEsc(s) {
    return $('<div>').text(s == null ? '' : String(s)).html();
}

// ---------- DISA ----------
function renderDisaLayout(response, tileName) {
    var $container = $('#giantModalListTableDiv');
    $container.children().remove();
    var rows = response.data || [];
    var media = response.mediaList || [];

    var html = '<div class="giant-disa-list">';
    if (!rows.length) {
        html += '<div class="giant-empty-state" style="padding:30px 12px;">' +
                '<p style="margin:0 0 6px; font-weight:700; color:rgb(var(--text));">No DISA entries yet</p>' +
                '<p style="margin:0; color:rgb(var(--muted));">Add one so on-call staff can dial in, enter a PIN, and dial out presenting your office number.</p>' +
                '</div>';
    }
    rows.forEach(function (r) {
        html += '<div class="giant-disa-card" data-ds_id="' + gvEsc(r.ds_id) + '">';
        html += '  <div class="giant-disa-card-head">';
        html += '    <div class="giant-disa-name">' + gvEsc(r.ds_name) + '</div>';
        html += '    <div class="giant-disa-meta">' +
                '<span class="giant-disa-pill"><i class="fa-solid fa-key"></i> PIN ' + gvEsc(r.ds_pin) + '</span>' +
                (r.ds_outbound === 'y' ? '<span class="giant-disa-pill is-on"><i class="fa-solid fa-arrow-up-right"></i> Outbound</span>' : '') +
                (r.ds_calleridnum ? '<span class="giant-disa-pill"><i class="fa-solid fa-id-card"></i> CID ' + gvEsc(r.ds_calleridnum) + '</span>' : '') +
                '</div>';
        html += '    <div class="giant-disa-card-actions">';
        html += '      <button class="giant-disa-edit giant-icon-btn giant-icon-edit" title="Edit"><i class="fa-solid fa-pen"></i></button>';
        html += '      <button class="giant-disa-remove giant-icon-btn giant-icon-delete" title="Remove"><i class="fa-solid fa-trash"></i></button>';
        html += '    </div>';
        html += '  </div>';
        html += '</div>';
    });
    html += '</div>';
    $container.html(html);

    // Stash the media + DID lists on the modal so the form opener
    // can read them without another round-trip.
    $('#giantModal').data('disaMedia', media);
    $('#giantModal').data('disaDids', response.didList || []);

    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').append('<button id="giantAddButton" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Dial-in</button>');

    $('#giantAddButton').off('click').on('click', function () { gvOpenDisaForm({}); });
    $('.giant-disa-edit').off('click').on('click', function () {
        var data = $(this).closest('.giant-disa-card').data();
        gvOpenDisaForm(rows.filter(function (x) { return String(x.ds_id) === String(data.ds_id); })[0] || {});
    });
    $('.giant-disa-remove').off('click').on('click', async function () {
        if (!(await giantConfirm('Remove this dial-in entry?'))) return;
        var id = $(this).closest('.giant-disa-card').data('ds_id');
        $.post('', { pbxAction: 'removeDisa', ds_id: id }, function () { refreshList(tileName); });
    });

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

function gvOpenDisaForm(item) {
    var media = $('#giantModal').data('disaMedia') || [];
    var isEdit = !!item.ds_id;
    var mediaOptions = '<option value="">— No prompt (silence) —</option>';
    media.forEach(function (m) {
        var sel = (String(m.id) === String(item.ds_me_id || '')) ? ' selected' : '';
        mediaOptions += '<option value="' + gvEsc(m.id) + '"' + sel + '>' + gvEsc(m.name) + '</option>';
    });

    var html = '<div class="gv-form-shell">';
    html += '  <div>';
    html += '    <div class="gv-form-eyebrow">' + (isEdit ? 'Dial-in · Edit' : 'Dial-in · Create') + '</div>';
    html += '    <h3 class="gv-form-heading">' + (isEdit ? gvEsc(item.ds_name || 'Edit dial-in') : 'New dial-in') + '</h3>';
    html += '  </div>';

    html += '  <input type="hidden" name="ds_id" value="' + gvEsc(item.ds_id || '') + '">';

    html += '  <div class="gv-form-row">';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvDisaName">Name <span class="gv-required">*</span></label>';
    html += '      <input id="gvDisaName" type="text" name="ds_name" value="' + gvEsc(item.ds_name || '') + '" required>';
    html += '      <div class="gv-field-hint">A friendly label so future-you remembers what this dial-in is for.</div>';
    html += '    </div>';
    html += '  </div>';

    html += '  <div class="gv-form-row gv-cols-2">';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvDisaPin">PIN <span class="gv-required">*</span></label>';
    html += '      <input id="gvDisaPin" type="text" name="ds_pin" inputmode="numeric" pattern="\\d{2,12}" value="' + gvEsc(item.ds_pin || '') + '" required>';
    html += '      <div class="gv-field-hint">2&ndash;12 digits. Caller dials this after the prompt.</div>';
    html += '    </div>';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvDisaPrompt">Prompt audio</label>';
    html += '      <select id="gvDisaPrompt" name="ds_me_id">' + mediaOptions + '</select>';
    html += '      <div class="gv-field-hint">Optional greeting played before the PIN tone.</div>';
    html += '    </div>';
    html += '  </div>';

    html += '  <label class="gv-check-row">';
    html += '    <input type="checkbox" name="ds_outbound" value="y"' + (item.ds_outbound === 'y' ? ' checked' : '') + '>';
    html += '    <span class="gv-check-row-text">Allow outbound dialling after PIN';
    html += '      <span class="gv-check-row-hint">Once the caller authenticates, they hear a dial tone and can place outbound calls.</span>';
    html += '    </span>';
    html += '  </label>';

    var dids = $('#giantModal').data('disaDids') || [];
    var didOptions = '<option value="">— Use the caller&rsquo;s own number —</option>';
    var saved = String(item.ds_calleridnum || '');
    var savedFound = false;
    dids.forEach(function (d) {
        var sel = (String(d.value) === saved) ? ' selected' : '';
        if (sel) savedFound = true;
        didOptions += '<option value="' + gvEsc(d.value) + '"' + sel + '>' + gvEsc(d.label) + '</option>';
    });
    // Edge-case: a CID was previously set to a number no longer
    // on the account (DID removed) — keep it visible so we don't
    // silently lose the saved value on next save.
    if (saved && !savedFound) {
        didOptions += '<option value="' + gvEsc(saved) + '" selected>' + gvEsc(saved) + ' (no longer on your account)</option>';
    }

    html += '  <div class="gv-form-row gv-cols-2">';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvDisaCidNum">Outbound caller ID number</label>';
    html += '      <select id="gvDisaCidNum" name="ds_calleridnum">' + didOptions + '</select>';
    html += '      <div class="gv-field-hint">Pick one of your tenant&rsquo;s phone numbers. The recipient sees this.</div>';
    html += '    </div>';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvDisaCidName">Outbound caller ID name</label>';
    html += '      <input id="gvDisaCidName" type="text" name="ds_calleridname" value="' + gvEsc(item.ds_calleridname || '') + '">';
    html += '      <div class="gv-field-hint">Display name (some carriers strip this).</div>';
    html += '    </div>';
    html += '  </div>';

    html += '  <label class="gv-check-row">';
    html += '    <input type="checkbox" name="ds_blockcid" value="y"' + (item.ds_blockcid === 'y' ? ' checked' : '') + '>';
    html += '    <span class="gv-check-row-text">Suppress caller&rsquo;s own caller ID';
    html += '      <span class="gv-check-row-hint">Useful when you don&rsquo;t want the caller&rsquo;s personal mobile to leak through.</span>';
    html += '    </span>';
    html += '  </label>';

    html += '  <div class="gv-form-actions">';
    html += '    <button type="submit" class="gv-btn-primary">' + (isEdit ? 'Save changes' : 'Create dial-in') + '</button>';
    html += '    <button type="button" class="gv-btn-secondary" id="gvDisaCancel">Cancel</button>';
    html += '  </div>';
    html += '</div>';

    $('#giantModalAddForm').html(html).off('submit').on('submit', function (e) {
        e.preventDefault();
        var payload = $(this).serializeArray().reduce(function (acc, x) { acc[x.name] = x.value; return acc; }, {});
        payload.pbxAction = isEdit ? 'editDisa' : 'addDisa';
        if (!payload.ds_outbound) payload.ds_outbound = 'n';
        if (!payload.ds_blockcid) payload.ds_blockcid = 'n';
        $.post('', payload, function (resp) {
            try { resp = JSON.parse(resp); } catch (e) { resp = {}; }
            if (resp.error) { alert(resp.error); return; }
            refreshList('disa');
        });
    });
    $('#gvDisaCancel').off('click').on('click', function () { refreshList('disa'); });

    $('.giantModalPanel').hide();
    $('#giantModalAddFormDiv').show();
}

// ---------- Outbound Campaigns ----------
function renderCampaignLayout(response, tileName) {
    var $container = $('#giantModalListTableDiv');
    $container.children().remove();
    var rows = response.data || [];

    var html = '<div class="giant-camp-list">';
    if (!rows.length) {
        html += '<div class="giant-empty-state" style="padding:30px 12px;">' +
                '<p style="margin:0 0 6px; font-weight:700; color:rgb(var(--text));">No campaigns yet</p>' +
                '<p style="margin:0; color:rgb(var(--muted));">Create a campaign to schedule outbound calls — appointment reminders, customer call-outs, surveys.</p>' +
                '</div>';
    }
    rows.forEach(function (r) {
        var active = r.cp_state === 'ACTIVE';
        html += '<div class="giant-camp-card" data-cp_id="' + gvEsc(r.cp_id) + '">';
        html += '  <div class="giant-camp-head">';
        html += '    <div>';
        html += '      <div class="giant-camp-name">' + gvEsc(r.cp_name) + '</div>';
        html += '      <div class="giant-camp-meta">' +
                '<span class="giant-camp-pill ' + (active ? 'is-on' : 'is-off') + '"><i class="fa-solid fa-circle" style="font-size:6px;"></i> ' + (active ? 'Active' : 'Paused') + '</span>' +
                (r.cp_callerid ? ' <span class="giant-camp-pill"><i class="fa-solid fa-id-card"></i> ' + gvEsc(r.cp_callerid) + '</span>' : '') +
                (r.cp_datestart ? ' <span class="giant-camp-pill"><i class="fa-solid fa-calendar"></i> ' + gvEsc(r.cp_datestart.substr(0, 10)) + ' &rarr; ' + gvEsc((r.cp_dateend || '').substr(0, 10)) + '</span>' : '') +
                '</div>';
        html += '    </div>';
        html += '    <div class="giant-camp-card-actions">';
        html += '      <button class="giant-camp-toggle giant-icon-btn" data-state="' + (active ? 'PAUSED' : 'ACTIVE') + '" title="' + (active ? 'Pause' : 'Resume') + '"><i class="fa-solid fa-' + (active ? 'pause' : 'play') + '"></i></button>';
        html += '      <button class="giant-camp-numbers giant-icon-btn giant-icon-edit" title="Manage numbers"><i class="fa-solid fa-list"></i></button>';
        html += '      <button class="giant-camp-edit giant-icon-btn giant-icon-edit" title="Edit"><i class="fa-solid fa-pen"></i></button>';
        html += '      <button class="giant-camp-remove giant-icon-btn giant-icon-delete" title="Remove"><i class="fa-solid fa-trash"></i></button>';
        html += '    </div>';
        html += '  </div>';
        html += '  <div class="giant-camp-numbers-slot" id="campNums_' + gvEsc(r.cp_id) + '" style="display:none;"></div>';
        html += '</div>';
    });
    html += '</div>';
    $container.html(html);

    // Cache the DID list for the campaign form opener.
    $('#giantModal').data('campaignDids', response.didList || []);

    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').append('<button id="giantAddButton" class="btn btn-primary"><i class="fa-solid fa-plus"></i> New Campaign</button>');
    $('#giantAddButton').off('click').on('click', function () { gvOpenCampaignForm({}); });

    $('.giant-camp-edit').off('click').on('click', function () {
        var id = $(this).closest('.giant-camp-card').data('cp_id');
        gvOpenCampaignForm(rows.filter(function (x) { return String(x.cp_id) === String(id); })[0] || {});
    });
    $('.giant-camp-toggle').off('click').on('click', function () {
        var id = $(this).closest('.giant-camp-card').data('cp_id');
        var state = $(this).data('state');
        $.post('', { pbxAction: 'setCampaignState', cp_id: id, state: state }, function () { refreshList(tileName); });
    });
    $('.giant-camp-remove').off('click').on('click', async function () {
        if (!(await giantConfirm('Delete this campaign and its number list?'))) return;
        var id = $(this).closest('.giant-camp-card').data('cp_id');
        $.post('', { pbxAction: 'removeCampaign', cp_id: id }, function () { refreshList(tileName); });
    });
    $('.giant-camp-numbers').off('click').on('click', function () {
        var id = $(this).closest('.giant-camp-card').data('cp_id');
        gvOpenCampaignNumbers(id);
    });

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

function gvOpenCampaignForm(item) {
    var isEdit = !!item.cp_id;

    var html = '<div class="gv-form-shell">';
    html += '  <div>';
    html += '    <div class="gv-form-eyebrow">' + (isEdit ? 'Campaign · Edit' : 'Campaign · Create') + '</div>';
    html += '    <h3 class="gv-form-heading">' + (isEdit ? gvEsc(item.cp_name || 'Edit campaign') : 'New campaign') + '</h3>';
    html += '  </div>';

    html += '  <input type="hidden" name="cp_id" value="' + gvEsc(item.cp_id || '') + '">';

    html += '  <div class="gv-form-row">';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvCampName">Name <span class="gv-required">*</span></label>';
    html += '      <input id="gvCampName" type="text" name="cp_name" value="' + gvEsc(item.cp_name || '') + '" required>';
    html += '      <div class="gv-field-hint">Label this campaign so you can find it later.</div>';
    html += '    </div>';
    html += '  </div>';

    var dids = $('#giantModal').data('campaignDids') || [];
    var saved = String(item.cp_callerid || '');
    var savedFound = false;
    var didOptions = '<option value="">— Pick a number —</option>';
    dids.forEach(function (d) {
        var sel = (String(d.value) === saved) ? ' selected' : '';
        if (sel) savedFound = true;
        didOptions += '<option value="' + gvEsc(d.value) + '"' + sel + '>' + gvEsc(d.label) + '</option>';
    });
    if (saved && !savedFound) {
        didOptions += '<option value="' + gvEsc(saved) + '" selected>' + gvEsc(saved) + ' (no longer on your account)</option>';
    }

    html += '  <div class="gv-form-row gv-cols-2">';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvCampCidNum">Outbound caller ID number</label>';
    html += '      <select id="gvCampCidNum" name="cp_callerid">' + didOptions + '</select>';
    html += '      <div class="gv-field-hint">Pick one of your tenant&rsquo;s phone numbers to present to recipients.</div>';
    html += '    </div>';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvCampCidName">Outbound caller ID name</label>';
    html += '      <input id="gvCampCidName" type="text" name="cp_calleridname" value="' + gvEsc(item.cp_calleridname || '') + '">';
    html += '      <div class="gv-field-hint">Display name (some carriers strip this).</div>';
    html += '    </div>';
    html += '  </div>';

    html += '  <div class="gv-form-row gv-cols-2">';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvCampStart">Start</label>';
    html += '      <input id="gvCampStart" type="datetime-local" name="cp_datestart" value="' + gvEsc((item.cp_datestart || '').replace(' ', 'T').substr(0, 16)) + '">';
    html += '      <div class="gv-field-hint">When the campaign begins dialling.</div>';
    html += '    </div>';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvCampEnd">End</label>';
    html += '      <input id="gvCampEnd" type="datetime-local" name="cp_dateend" value="' + gvEsc((item.cp_dateend || '').replace(' ', 'T').substr(0, 16)) + '">';
    html += '      <div class="gv-field-hint">Hard cut-off — no calls placed after this time.</div>';
    html += '    </div>';
    html += '  </div>';

    html += '  <div style="padding:10px 14px; border:1px solid rgb(var(--accent) / .35); background:rgb(var(--accent) / .06); border-radius:10px; color:rgb(var(--text)); font-size:12.5px; line-height:1.5;">';
    html += '    <i class="fa-solid fa-circle-info" style="color:rgb(var(--accent)); margin-bottom:0;"></i> ';
    html += '    New campaigns start <strong>paused</strong>. Add numbers from the list, then press play to activate when you&rsquo;re ready.';
    html += '  </div>';

    html += '  <div class="gv-form-actions">';
    html += '    <button type="submit" class="gv-btn-primary">' + (isEdit ? 'Save changes' : 'Create campaign') + '</button>';
    html += '    <button type="button" class="gv-btn-secondary" id="gvCampCancel">Cancel</button>';
    html += '  </div>';
    html += '</div>';

    $('#giantModalAddForm').html(html).off('submit').on('submit', function (e) {
        e.preventDefault();
        var payload = $(this).serializeArray().reduce(function (acc, x) { acc[x.name] = x.value; return acc; }, {});
        // Normalise datetime-local back to "YYYY-MM-DD HH:MM:SS" for the PBX.
        if (payload.cp_datestart) { payload.cp_datestart = payload.cp_datestart.replace('T', ' ') + ':00'; }
        if (payload.cp_dateend)   { payload.cp_dateend   = payload.cp_dateend.replace('T', ' ') + ':00'; }
        payload.pbxAction = isEdit ? 'editCampaign' : 'addCampaign';
        $.post('', payload, function (resp) {
            try { resp = JSON.parse(resp); } catch (e) { resp = {}; }
            if (resp.error) { alert(resp.error); return; }
            refreshList('campaign');
        });
    });
    $('#gvCampCancel').off('click').on('click', function () { refreshList('campaign'); });

    $('.giantModalPanel').hide();
    $('#giantModalAddFormDiv').show();
}

function gvOpenCampaignNumbers(campaignId) {
    var html = '<div class="gv-form-shell">';
    html += '  <div>';
    html += '    <div class="gv-form-eyebrow">Campaign · Numbers</div>';
    html += '    <h3 class="gv-form-heading">Manage dial list</h3>';
    html += '  </div>';

    html += '  <div id="gvCampNumsList">Loading…</div>';

    html += '  <div>';
    html += '    <div class="gv-form-eyebrow" style="margin-bottom:10px;">Add numbers</div>';
    html += '    <div class="gv-form-row">';
    html += '      <div class="gv-field">';
    html += '        <label class="gv-field-label" for="gvCampNumsInput">Numbers</label>';
    html += '        <textarea id="gvCampNumsInput" name="numbers" placeholder="07700900123&#10;07700900456&#10;or comma-separated"></textarea>';
    html += '        <div class="gv-field-hint">One per line or comma-separated. Duplicates are ignored.</div>';
    html += '      </div>';
    html += '    </div>';
    html += '    <div class="gv-form-row" style="margin-top:14px;">';
    html += '      <div class="gv-field">';
    html += '        <label class="gv-field-label" for="gvCampNumsDesc">Shared description (optional)</label>';
    html += '        <input id="gvCampNumsDesc" type="text" name="description">';
    html += '        <div class="gv-field-hint">Applies to every number imported in this batch.</div>';
    html += '      </div>';
    html += '    </div>';
    html += '  </div>';

    html += '  <div class="gv-form-actions">';
    html += '    <button type="submit" class="gv-btn-primary">Import numbers</button>';
    html += '    <button type="button" class="gv-btn-secondary" id="gvCampNumsCancel">Back to campaigns</button>';
    html += '  </div>';
    html += '</div>';

    $('#giantModalAddForm').html(html);
    $('#giantModalAddForm').off('submit').on('submit', function (e) {
        e.preventDefault();
        var data = $(this).serializeArray().reduce(function (acc, x) { acc[x.name] = x.value; return acc; }, {});
        data.pbxAction = 'bulkAddCampaignNumbers';
        data.cp_id       = campaignId;
        $.post('', data, function (resp) {
            try { resp = JSON.parse(resp); } catch (e) { resp = {}; }
            if (resp.error) { alert(resp.error); return; }
            alert('Imported ' + (resp.added || 0) + ' number(s). Errors: ' + ((resp.errors || []).length));
            gvOpenCampaignNumbers(campaignId);  // re-render to show new rows
        });
    });
    $('#gvCampNumsCancel').off('click').on('click', function () { refreshList('campaign'); });

    // Load existing rows
    $.post('', { pbxAction: 'getCampaignNumbers', cp_id: campaignId }, function (resp) {
        try { resp = JSON.parse(resp); } catch (e) { resp = {}; }
        if (resp.error) { $('#gvCampNumsList').html('<div class="giant-alert">' + gvEsc(resp.error) + '</div>'); return; }
        var rows = resp.rows || [];
        if (!rows.length) { $('#gvCampNumsList').html('<div style="color:rgb(var(--muted));">No numbers yet.</div>'); return; }
        var t = '<table class="giant-camp-nums"><thead><tr><th>Phone</th><th>Attempts</th><th>Disposition</th><th>Bill (s)</th><th></th></tr></thead><tbody>';
        rows.forEach(function (r) {
            t += '<tr>' +
                 '<td>' + gvEsc(r.cn_phone) + '</td>' +
                 '<td>' + gvEsc(r.cn_attempts) + '</td>' +
                 '<td>' + gvEsc(r.cn_disposition || '—') + '</td>' +
                 '<td>' + gvEsc(r.cn_billsec) + '</td>' +
                 '<td><button class="gv-camp-num-rm giant-icon-btn giant-icon-delete" data-id="' + gvEsc(r.cn_id) + '"><i class="fa-solid fa-trash"></i></button></td>' +
                 '</tr>';
        });
        t += '</tbody></table>';
        $('#gvCampNumsList').html(t);
        $('.gv-camp-num-rm').off('click').on('click', async function () {
            if (!(await giantConfirm('Remove this number?'))) return;
            var nid = $(this).data('id');
            $.post('', { pbxAction: 'removeCampaignNumber', cn_id: nid }, function () { gvOpenCampaignNumbers(campaignId); });
        });
    });

    $('.giantModalPanel').hide();
    $('#giantModalAddFormDiv').show();
}

// ---------- Music on Hold (now with playlist editor) ----------
function renderMusicOnHoldLayout(response, tileName) {
    var $container = $('#giantModalListTableDiv');
    $container.children().remove();
    var raw = response.data || [];
    var rows = Array.isArray(raw) ? raw : Object.keys(raw).map(function (k) { return raw[k]; });
    var media = response.mediaList || [];

    var shared = Array.isArray(response.shared) ? response.shared : [];
    var defaultMoh = String(response.defaultMoh == null ? '' : response.defaultMoh);
    var esc = function (t) { return $('<div>').text(t == null ? '' : String(t)).html(); };

    // Which playlist callers hear when nothing more specific is chosen.
    var html = '<div class="giant-moh-default">';
    html += '<label for="gvMohDefault"><i class="fa-solid fa-star"></i> Default hold music</label>';
    html += '<select id="gvMohDefault" class="form-control">';
    html += '<option value=""' + (defaultMoh === '' ? ' selected' : '') + '>System default</option>';
    if (rows.length) {
        html += '<optgroup label="Your playlists">';
        rows.forEach(function (r) { html += '<option value="' + esc(r.mh_id) + '"' + (String(r.mh_id) === defaultMoh ? ' selected' : '') + '>' + esc(r.mh_name) + '</option>'; });
        html += '</optgroup>';
    }
    if (shared.length) {
        html += '<optgroup label="Shared playlists">';
        shared.forEach(function (m) { html += '<option value="' + esc(m.id) + '"' + (String(m.id) === defaultMoh ? ' selected' : '') + '>' + esc(m.name) + (m.stream ? ' (live stream)' : '') + '</option>'; });
        html += '</optgroup>';
    }
    html += '</select>';
    html += '<div class="giant-moh-default-hint">Plays to anyone on hold unless a queue or route picks something else. Changes take effect on the next call.</div>';
    html += '</div>';

    html += '<div class="giant-moh-list">';
    if (!rows.length) {
        html += '<div class="giant-empty-state" style="padding:30px 12px;">' +
                '<p style="margin:0 0 6px; font-weight:700; color:rgb(var(--text));">No playlists of your own yet</p>' +
                '<p style="margin:0; color:rgb(var(--muted));">Create a playlist of your media files, or pick a shared playlist above.</p>' +
                '</div>';
    }
    rows.forEach(function (r) {
        var fileList = (r.mh_files || '').split(',').filter(Boolean);
        html += '<div class="giant-moh-card" data-mh_id="' + gvEsc(r.mh_id) + '">';
        html += '  <div class="giant-moh-head">';
        html += '    <div>';
        html += '      <div class="giant-moh-name">' + gvEsc(r.mh_name) + '</div>';
        html += '      <div class="giant-moh-meta">' +
                '<span class="giant-moh-pill"><i class="fa-solid fa-shuffle"></i> ' + gvEsc(r.mh_mode || 'RANDOM') + '</span>' +
                ' <span class="giant-moh-pill"><i class="fa-solid fa-music"></i> ' + fileList.length + ' track' + (fileList.length === 1 ? '' : 's') + '</span>' +
                '</div>';
        html += '    </div>';
        html += '    <div class="giant-moh-card-actions">';
        html += '      <button class="giant-moh-edit giant-icon-btn giant-icon-edit" title="Edit"><i class="fa-solid fa-pen"></i></button>';
        html += '      <button class="giant-moh-remove giant-icon-btn giant-icon-delete" title="Remove"><i class="fa-solid fa-trash"></i></button>';
        html += '    </div>';
        html += '  </div>';
        html += '</div>';
    });
    html += '</div>';

    if (shared.length) {
        var body = '<div class="giant-moh-list">';
        shared.forEach(function (m) {
            body += '<div class="giant-moh-card is-shared" data-mu_id="' + esc(m.id) + '">';
            body += '  <div class="giant-moh-head"><div>';
            body += '    <div class="giant-moh-name">' + esc(m.name) + '</div>';
            body += '    <div class="giant-moh-meta"><span class="giant-moh-pill"><i class="fa-solid ' + (m.stream ? 'fa-tower-broadcast' : 'fa-music') + '"></i> ' + (m.stream ? 'Live stream' : 'Playlist') + '</span>' +
                    (String(m.id) === defaultMoh ? ' <span class="giant-moh-pill is-default"><i class="fa-solid fa-star"></i> Your default</span>' : '') + '</div>';
            body += '  </div><div class="giant-moh-card-actions"><span class="giant-shared-pill"><i class="fa-solid fa-people-group"></i> Shared</span></div></div>';
            body += '</div>';
        });
        body += '</div>';
        html += giantSharedAccordion('musicOnHold', {
            title: 'Shared playlists', icon: 'fa-radio', count: shared.length,
            note: 'Maintained for every account. Choose one as your default above.'
        }, body);
    }
    $container.html(html);

    $('#gvMohDefault').off('change').on('change', function () {
        var $sel = $(this), val = String($sel.val() || '');
        $sel.prop('disabled', true);
        $.ajax({
            type: 'post', dataType: 'json',
            data: { pbxAction: 'setDefaultMusicOnHold', mh_id: val },
            success: function (r) {
                $sel.prop('disabled', false);
                if (r && r.ok) { giantListHint('<i class="fa-solid fa-circle-check"></i> Default hold music saved.', 'ok'); refreshList(tileName); }
                else giantListHint('<i class="fa-solid fa-triangle-exclamation"></i> ' + esc((r && r.error) || 'Could not save the default hold music.'), 'warn');
            },
            error: function () { $sel.prop('disabled', false); giantListHint('<i class="fa-solid fa-triangle-exclamation"></i> Could not save the default hold music. Check your connection and try again.', 'warn'); }
        });
    });

    $('#giantModal').data('mohMedia', media);
    $('#giantModalListDiv').find('#giantAddButton').remove();
    $('#giantModalListDiv').append('<button id="giantAddButton" class="btn btn-primary"><i class="fa-solid fa-plus"></i> New Playlist</button>');
    $('#giantAddButton').off('click').on('click', function () { gvOpenMohForm({}); });
    $('.giant-moh-edit').off('click').on('click', function () {
        var id = $(this).closest('.giant-moh-card').data('mh_id');
        gvOpenMohForm(rows.filter(function (x) { return String(x.mh_id) === String(id); })[0] || {});
    });
    $('.giant-moh-remove').off('click').on('click', async function () {
        if (!(await giantConfirm('Remove this playlist?'))) return;
        var id = $(this).closest('.giant-moh-card').data('mh_id');
        $.post('', { pbxAction: 'removeMusicOnHold', mh_id: id }, function () { refreshList(tileName); });
    });

    $('.giantModalPanel').hide();
    $('#giantModalListDiv').show();
}

function gvOpenMohForm(item) {
    var media = $('#giantModal').data('mohMedia') || [];
    var isEdit = !!item.mh_id;
    var selectedIds = (item.mh_files || '').split(',').filter(Boolean);

    var html = '<div class="gv-form-shell">';
    html += '  <div>';
    html += '    <div class="gv-form-eyebrow">' + (isEdit ? 'Playlist · Edit' : 'Playlist · Create') + '</div>';
    html += '    <h3 class="gv-form-heading">' + (isEdit ? gvEsc(item.mh_name || 'Edit playlist') : 'New playlist') + '</h3>';
    html += '  </div>';

    html += '  <input type="hidden" name="mh_id" value="' + gvEsc(item.mh_id || '') + '">';
    html += '  <input type="hidden" name="mh_files" id="gvMohFiles">';

    html += '  <div class="gv-form-row gv-cols-2">';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvMohName">Name <span class="gv-required">*</span></label>';
    html += '      <input id="gvMohName" type="text" name="mh_name" value="' + gvEsc(item.mh_name || '') + '" required>';
    html += '      <div class="gv-field-hint">Reference name for routing (e.g. &ldquo;Default hold&rdquo;).</div>';
    html += '    </div>';
    html += '    <div class="gv-field">';
    html += '      <label class="gv-field-label" for="gvMohMode">Playback mode</label>';
    html += '      <select id="gvMohMode" name="mh_mode">' +
            '<option value="RANDOM"' + (item.mh_mode !== 'SEQUENTIAL' ? ' selected' : '') + '>Random</option>' +
            '<option value="SEQUENTIAL"' + (item.mh_mode === 'SEQUENTIAL' ? ' selected' : '') + '>Sequential</option>' +
            '</select>';
    html += '      <div class="gv-field-hint">Random shuffles, Sequential plays tracks in order.</div>';
    html += '    </div>';
    html += '  </div>';

    html += '  <div class="gv-field">';
    html += '    <label class="gv-field-label">Tracks <span class="gv-required">*</span></label>';
    if (media.length) {
        html += '    <div class="gv-track-picker">';
        media.forEach(function (m) {
            var checked = selectedIds.indexOf(String(m.id)) > -1 ? ' checked' : '';
            html += '<label>' +
                    '<input type="checkbox" class="gv-moh-file" value="' + gvEsc(m.id) + '"' + checked + '>' +
                    '<span><i class="fa-solid fa-music" style="opacity:.55; margin-right:6px;"></i>' + gvEsc(m.name) + '</span>' +
                    '</label>';
        });
        html += '    </div>';
        html += '    <div class="gv-field-hint">Tick the audio files this playlist should rotate through.</div>';
    } else {
        html += '    <div class="gv-track-picker-empty">';
        html += '      <i class="fa-duotone fa-music-slash fa-2x" style="--fa-primary-color: rgb(var(--muted) / .55); --fa-secondary-color: rgb(var(--muted) / .35); display:block; margin-bottom:10px;"></i>';
        html += '      No media files uploaded yet. Open the <strong>Media Files</strong> tile to upload audio first.';
        html += '    </div>';
    }
    html += '  </div>';

    html += '  <div class="gv-form-actions">';
    html += '    <button type="submit" class="gv-btn-primary">' + (isEdit ? 'Save changes' : 'Create playlist') + '</button>';
    html += '    <button type="button" class="gv-btn-secondary" id="gvMohCancel">Cancel</button>';
    html += '  </div>';
    html += '</div>';

    $('#giantModalAddForm').html(html);
    $('#giantModalAddForm').off('submit').on('submit', function (e) {
        e.preventDefault();
        var ids = $.map($('.gv-moh-file:checked'), function (el) { return el.value; });
        $('#gvMohFiles').val(ids.join(','));
        var payload = $(this).serializeArray().reduce(function (acc, x) { acc[x.name] = x.value; return acc; }, {});
        payload.pbxAction = isEdit ? 'editMusicOnHold' : 'addMusicOnHold';
        $.post('', payload, function (resp) {
            try { resp = JSON.parse(resp); } catch (e) { resp = {}; }
            if (resp.error) { alert(resp.error); return; }
            refreshList('musicOnHold');
        });
    });
    $('#gvMohCancel').off('click').on('click', function () { refreshList('musicOnHold'); });

    $('.giantModalPanel').hide();
    $('#giantModalAddFormDiv').show();
}

/* ---------- Caller-ID blacklist bulk-paste injection ----------
   The blacklist uses the standard list+add+edit flow (addFormData /
   editFormData) so the normal renderer handles it. We just augment
   the rendered list with a "Bulk paste" button next to the standard
   Add button. */
$(document).on('show.bs.modal', '#giantModal', function (e) {
    var name = $(e.relatedTarget).data('name');
    if (name !== 'callerIdBlacklist') return;
    // Hook the next list render to inject our bulk button.
    var bumped = setInterval(function () {
        var $add = $('#giantAddButton');
        if (!$add.length || $('#gvBlacklistBulk').length) return;
        clearInterval(bumped);
        $add.after('<button id="gvBlacklistBulk" class="btn btn-default" style="margin-left:8px;"><i class="fa-solid fa-paste"></i> Bulk paste</button>');
        $('#gvBlacklistBulk').off('click').on('click', function () {
            var html = '<div class="gv-form-shell">';
            html += '  <div>';
            html += '    <div class="gv-form-eyebrow">Blacklist · Bulk paste</div>';
            html += '    <h3 class="gv-form-heading">Block multiple numbers at once</h3>';
            html += '  </div>';
            html += '  <div class="gv-form-row">';
            html += '    <div class="gv-field">';
            html += '      <label class="gv-field-label" for="gvBlNumbers">Numbers to block</label>';
            html += '      <textarea id="gvBlNumbers" name="numbers" placeholder="07700900123&#10;07700900456&#10;07700900789"></textarea>';
            html += '      <div class="gv-field-hint">One per line or comma-separated. Duplicates are ignored.</div>';
            html += '    </div>';
            html += '  </div>';
            html += '  <div class="gv-form-row">';
            html += '    <div class="gv-field">';
            html += '      <label class="gv-field-label" for="gvBlReason">Shared reason (optional)</label>';
            html += '      <input id="gvBlReason" type="text" name="reason" placeholder="e.g. PPI spam, robocaller">';
            html += '      <div class="gv-field-hint">Applies to every number in this batch.</div>';
            html += '    </div>';
            html += '  </div>';
            html += '  <div class="gv-form-actions">';
            html += '    <button type="submit" class="gv-btn-primary">Block all numbers</button>';
            html += '    <button type="button" class="gv-btn-secondary" id="gvBlBulkCancel">Cancel</button>';
            html += '  </div>';
            html += '</div>';
            $('#giantModalAddForm').html(html);
            $('#giantModalAddForm').off('submit').on('submit', function (e2) {
                e2.preventDefault();
                var data = $(this).serializeArray().reduce(function (acc, x) { acc[x.name] = x.value; return acc; }, {});
                data.pbxAction = 'bulkAddCallerIdBlacklist';
                $.post('', data, function (resp) {
                    try { resp = JSON.parse(resp); } catch (e3) { resp = {}; }
                    if (resp.error) { alert(resp.error); return; }
                    alert('Blocked ' + (resp.added || 0) + ' number(s). Errors: ' + ((resp.errors || []).length));
                    refreshList('callerIdBlacklist');
                });
            });
            $('#gvBlBulkCancel').off('click').on('click', function () { refreshList('callerIdBlacklist'); });
            $('.giantModalPanel').hide();
            $('#giantModalAddFormDiv').show();
        });
    }, 100);
    setTimeout(function () { clearInterval(bumped); }, 5000);
});

// ===== Landing page =====
// A tile's second line. The server writes what it can count; the pollers
// already on the page (extensions, devices, today's calls) and the voicemail
// check below overwrite it with what's happening right now.
window.giantTileState = function (key, text, live) {
    var $s = $('.tile-state[data-tile-state="' + key + '"]');
    if (!$s.length) return;
    $s.text(text).addClass('is-count').toggleClass('is-live', !!live);
};

$(function () {
    // Unread voicemail on the Voicemail tile — one call, only when the tile is there.
    var $vm = $('.tile-state[data-tile-state="voicemail"]');
    if ($vm.length) {
        $.ajax({
            type: 'post',
            data: { pbxAction: 'getVoicemailCount' },
            success: function (json) {
                var r = flowParseJson(json), n = (r && r.count != null) ? parseInt(r.count, 10) : NaN;
                if (isNaN(n)) return;
                var base = $vm.hasClass('is-count') ? $vm.text() : '';
                giantTileState('voicemail', (base ? base + ' · ' : '') + (n ? n + ' new' : 'no new messages'), n > 0);
            }
        });
    }

    // Checklist buttons and number chips open the matching tool.
    $(document).on('click', '[data-setup-open]', function (e) {
        e.preventDefault();
        var key = String($(this).data('setup-open') || ''), term = $(this).data('open-search');
        window._giantPendingListSearch = term ? { tile: key, term: String(term) } : null;
        var $t = $('#tour-' + key);
        if ($t.length) $t.trigger('click');
    });

    // The checklist can be hidden per device; it goes for good once every step is done.
    var $setup = $('#giantSetup'), $restore = $('#giantSetupRestore');
    if ($setup.length) {
        var setupKey = 'giantSetupHide:' + ($setup.data('tenant') || '');
        var setupProgress = function () {
            var $all = $setup.find('.giant-setup-step'), done = $all.filter('.is-done').length;
            $('#giantSetupRestoreCount').text(done + ' of ' + $all.length + ' done');
        };
        var setupCollapse = function (animate) {
            setupProgress();
            if (animate) $setup.slideUp(160, function () { $restore.prop('hidden', false); });
            else { $setup.hide(); $restore.prop('hidden', false); }
            try { localStorage.setItem(setupKey, '1'); } catch (e) {}
        };
        try { if (localStorage.getItem(setupKey) === '1') setupCollapse(false); } catch (e) {}
        $('#giantSetupHide').on('click', function () { setupCollapse(true); });
        $restore.on('click', function () {
            $restore.prop('hidden', true);
            $setup.slideDown(180);
            try { localStorage.removeItem(setupKey); } catch (e) {}
        });
        // Keep the pill's count honest as live steps tick.
        window.giantSetupProgress = setupProgress;
    }

    // "Further down" links scroll rather than jump.
    $('.giant-jump a[href^="#"]').on('click', function (e) {
        var el = document.querySelector($(this).attr('href'));
        if (!el) return;
        e.preventDefault();
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    // Long number lists fold after the first couple of rows.
    if (typeof window.giantSetupShowMore === 'function' && $('#phoneNumbersGrid').length) {
        window.giantSetupShowMore('#phoneNumbersGrid', 12, 'number', 'numbers');
    }
});

// ===== Find box =====
// Filters the tool tiles as you type (with everyday synonyms, so "ring group"
// finds Hunt Lists), and from two characters looks up the account's own
// numbers, extensions, menus and so on. Picking a result opens that tool with
// its list already narrowed to the match.
$(function () {
    var SYN = {
        destination: 'number numbers did phone telephone inbound caller id',
        port: 'port porting transfer move provider bring keep number',
        mobilePort: 'pac mobile port transfer',
        callerIdBlacklist: 'block blocked spam nuisance blacklist reject caller',
        callFlow: 'flow routing route builder where calls go diagram',
        ivr: 'menu menus auto attendant press 1 options key press',
        huntList: 'ring group ring groups hunt simultaneous team ring everyone',
        queue: 'queue call queue agents waiting hold callers',
        voicemail: 'voicemail mailbox messages greeting inbox',
        condition: 'time conditions opening hours holiday schedule out of hours',
        media: 'audio media recording announcement greeting mp3 wav upload sound file',
        musicOnHold: 'hold music playlist on hold',
        customDestination: 'forward divert external mobile outside number destination',
        featureCode: 'feature codes star code dial code',
        shortNumber: 'speed dial short number',
        disa: 'dial in disa pin dial out',
        extension: 'extension extensions user users seat person people sip login handset',
        phone: 'devices desk phone handset provisioning hardware',
        voiceCloud: 'app softphone mobile app voicecloud',
        teamsRouting: 'microsoft teams direct routing',
        phoneBook: 'phone book contacts directory address book',
        conference: 'conference meeting room bridge',
        aiAgent: 'ai agent receptionist assistant bot answer',
        aiAgentLog: 'ai conversations transcripts',
        campaign: 'outbound campaign dialler dialer bulk calls',
        callLog: 'call log logs history cdr calls recordings',
        analytics: 'analytics reports stats statistics graphs trends',
        smsLog: 'sms text texts messages',
        fax: 'fax',
        apiAccess: 'api key keys developer token',
        integration: 'integrations crm connect apps',
        tenantSettings: 'settings global account options recording'
    };
    var $input = $('#giantFindInput'), $results = $('#giantFindResults'), $empty = $('#giantFindEmpty'), $tools = $('#giantTools');
    if (!$input.length) return;
    var timer = null, seq = 0;
    var strip = function (html) { return $('<div>').html(html || '').text(); };
    var esc = function (s) { return $('<div>').text(s == null ? '' : String(s)).html(); };

    function hay($tile, deep) {
        var key = String($tile.data('name') || '');
        var s = [
            $tile.find('.tile-label').text(),
            $tile.find('.tile-state').text(),
            SYN[key] || '',
            $tile.closest('.giant-tools-group').find('.giant-tools-eyebrow-label').text()
        ];
        if (deep && window.modalDescriptions && window.modalDescriptions[key]) s.push(strip(window.modalDescriptions[key]));
        return s.join(' ').toLowerCase();
    }
    function filterTiles(q) {
        var terms = q.toLowerCase().split(/\s+/).filter(Boolean);
        var $items = $tools.find('.tile-item');
        if (!terms.length) {
            $items.show();
            $tools.find('.giant-tools-group').show();
            $tools.removeClass('is-searching');
            $empty.prop('hidden', true);
            if (window.giantToolsRestore) window.giantToolsRestore();
            return;
        }
        $tools.addClass('is-searching');
        var matches = function (deep) {
            var n = 0;
            $items.each(function () {
                var h = hay($(this).find('.tile'), deep);
                var ok = terms.every(function (t) { return h.indexOf(t) > -1; });
                $(this).toggle(ok);
                if (ok) n++;
            });
            return n;
        };
        var n = matches(false);
        if (!n) n = matches(true);
        // A match inside "Advanced routing" opens the fold for the search.
        $tools.find('.giant-tools-advanced').each(function () {
            var hit = $(this).find('.tile-item').filter(function () { return this.style.display !== 'none'; }).length > 0;
            $(this).find('.tile-grid').first().prop('hidden', !hit);
        });
        $tools.find('.giant-tools-group').each(function () { $(this).toggle($(this).find('.tile-item:visible').length > 0); });
        $empty.prop('hidden', n > 0 || !$results.prop('hidden'));
    }
    function renderResults(list) {
        if (!list || !list.length) {
            $results.prop('hidden', true).empty();
            $empty.prop('hidden', $tools.find('.tile-item:visible').length > 0 || !$input.val().trim());
            return;
        }
        var html = '<div class="giant-find-results-head">On your account</div>', lastType = '';
        list.forEach(function (r) {
            if (r.type !== lastType) { html += '<div class="giant-find-group">' + esc(r.type) + '</div>'; lastType = r.type; }
            html += '<button type="button" class="giant-find-row" data-open-tile="' + esc(r.tile) + '" data-open-search="' + esc(r.search || r.name) + '">' +
                '<i class="fa-duotone ' + esc(r.icon) + '" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i>' +
                '<span class="giant-find-row-name">' + esc(r.name) + '</span>' +
                (r.sub ? '<span class="giant-find-row-sub">' + esc(r.sub) + '</span>' : '') +
                '<span class="giant-find-row-go"><i class="fa-solid fa-arrow-right"></i></span></button>';
        });
        $results.html(html).prop('hidden', false);
        $empty.prop('hidden', true);
    }
    function lookup(q) {
        var my = ++seq;
        $.ajax({
            type: 'post',
            data: { pbxAction: 'searchDashboard', q: q },
            success: function (json) {
                if (my !== seq) return;              // a newer query is in flight
                var r = flowParseJson(json);
                renderResults((r && r.results) || []);
            },
            error: function () { if (my === seq) renderResults([]); }
        });
    }
    $input.on('input', function () {
        var q = $(this).val().trim();
        filterTiles(q);
        clearTimeout(timer);
        if (q.length < 2) { seq++; renderResults([]); return; }
        timer = setTimeout(function () { lookup(q); }, 250);
    });
    $input.on('keydown', function (e) {
        if (e.key === 'Escape') { $input.val('').trigger('input').blur(); return; }
        if (e.key === 'Enter') {
            e.preventDefault();
            var $first = $results.find('.giant-find-row').first();
            if ($first.length && !$results.prop('hidden')) { $first.trigger('click'); return; }
            var $tile = $tools.find('.tile-item:visible .tile').first();
            if ($tile.length) $tile.trigger('click');
        }
    });
    $input.on('focus', function () {
        if ($results.children().length && $input.val().trim().length >= 2) $results.prop('hidden', false);
    });
    // "/" or Ctrl+K from anywhere on the page jumps to the box.
    $(document).on('keydown.giantFind', function (e) {
        var t = e.target, tag = (t && t.tagName || '').toLowerCase();
        var typing = tag === 'input' || tag === 'textarea' || tag === 'select' || (t && t.isContentEditable);
        if ($('.modal.in, .modal.show').length) return;
        if ((e.key === '/' && !typing) || ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K'))) {
            e.preventDefault();
            $input.focus();
            $input[0].select();
        }
    });
    $(document).on('click', '.giant-find-row', function () {
        var tile = String($(this).data('open-tile') || ''), term = String($(this).data('open-search') || '');
        window._giantPendingListSearch = { tile: tile, term: term };
        var $t = $('#tour-' + tile);
        if ($t.length) $t.trigger('click');
    });
    $(document).on('mousedown', function (e) {
        if (!$(e.target).closest('#giantFind').length && !$results.prop('hidden')) $results.prop('hidden', true);
    });
});

// Set-up checklist steps that only the live page can answer: who is online
// (from the extension poller) and who is on the app (asked once on load).
window.giantSetupLive = function (step, done, text, btnLabel) {
    var $li = $('#giantSetup .giant-setup-step[data-setup-step="' + step + '"]');
    if (!$li.length) return;
    $li.removeClass('is-checking').toggleClass('is-done', !!done);
    var $num = $li.find('.giant-setup-num');
    if (done) $num.html('<i class="fa-solid fa-check"></i>'); else $num.text(String($num.data('n') || ''));
    if (text != null) $li.find('.giant-setup-text span').text(text);
    if (btnLabel) $li.find('.giant-setup-btn').text(btnLabel);
    if (typeof window.giantSetupProgress === 'function') window.giantSetupProgress();

    // Everything ticked: say so, then fold the checklist away for good on this device.
    var $all = $('#giantSetup .giant-setup-step');
    if ($all.length && $all.filter('.is-done').length === $all.length && !window._giantSetupAllSet) {
        window._giantSetupAllSet = true;
        $('#giantSetupSub').addClass('is-allset').html('<i class="fa-solid fa-circle-check"></i> You&rsquo;re all set. Your first call can ring through.');
        var key = 'giantSetupHide:' + ($('#giantSetup').data('tenant') || '');
        setTimeout(function () {
            $('#giantSetup').slideUp(220);
            $('#giantSetupRestore').prop('hidden', true);
            try { localStorage.setItem(key, '1'); } catch (e) {}
        }, 4500);
    }
};

$(function () {
    var $appStep = $('#giantSetup .giant-setup-step[data-setup-step="app"]');
    if ($appStep.length && !$appStep.hasClass('is-done')) {
        $.ajax({
            type: 'post',
            data: { pbxAction: 'getSetupLive' },
            success: function (json) {
                var r = flowParseJson(json), n = (r && r.appUsers != null) ? parseInt(r.appUsers, 10) : NaN;
                if (!isNaN(n) && n > 0) giantSetupLive('app', true, n + (n === 1 ? ' person' : ' people') + ' on the app', 'Manage');
            }
        });
    }
});

// ===== Landing page refinements: advanced routing fold, usage details =====
$(function () {
    // Advanced routing: folded unless the account uses it, or the customer opened it.
    $('.giant-tools-advanced').each(function () {
        var $wrap = $(this), key = 'giantToolsAdv:' + $wrap.data('group');
        var $grid = $wrap.find('.tile-grid').first(), $btn = $wrap.find('.giant-tools-advanced-toggle');
        var open = String($wrap.data('open')) === '1';
        try { var s = localStorage.getItem(key); if (s === '1') open = true; if (s === '0') open = false; } catch (e) {}
        var paint = function (o) {
            $grid.prop('hidden', !o);
            $btn.attr('aria-expanded', o ? 'true' : 'false').toggleClass('is-open', o);
        };
        paint(open);
        $wrap.data('paint', paint).data('openState', open);
        $btn.on('click', function () {
            open = !open;
            paint(open);
            $wrap.data('openState', open);
            try { localStorage.setItem(key, open ? '1' : '0'); } catch (e) {}
        });
    });
    // Open the fold that holds an element (the tour and the find box use this).
    window.giantToolsReveal = function ($el) {
        var $wrap = $($el).closest('.giant-tools-advanced');
        if ($wrap.length) { var p = $wrap.data('paint'); if (p) p(true); }
    };
    // Put every fold back to the customer's own setting.
    window.giantToolsRestore = function () {
        $('.giant-tools-advanced').each(function () { var p = $(this).data('paint'); if (p) p(!!$(this).data('openState')); });
    };

    // A heading with nothing under it is noise. Other scripts (the landline
    // module's footer hook, for one) can hide tiles after render, so prune
    // empty groups and correct the fold's count once the page has settled.
    window.giantToolsPrune = function () {
        var visible = function ($scope) { return $scope.find('.tile-item').filter(function () { return this.style.display !== 'none'; }).length; };
        $('.giant-tools-advanced').each(function () {
            var n = visible($(this));
            $(this).find('.giant-tools-advanced-toggle b').text(n);
            $(this).toggle(n > 0);
        });
        $('.giant-tools-group').each(function () { $(this).toggle(visible($(this)) > 0); });
    };
    $(window).on('load', function () { setTimeout(window.giantToolsPrune, 0); });
    setTimeout(window.giantToolsPrune, 0);
});

// ===== Landing page: routing state that follows what the customer just did =====
// Re-reads the counts the page was rendered with and repaints the hero line,
// the checklist, the Call Flows tile and the number cards. Called after a
// flow saves and whenever a tool closes (numbers, extensions, routing objects).
window.giantRefreshSetup = (function () {
    var timer = null, inFlight = false;
    var esc = function (v) { return $('<div>').text(v == null ? '' : String(v)).html(); };
    function paint(r) {
        var st = r.setup || {};
        if (!st.known) return;
        var n = Number(st.numbers || 0), routed = Number(st.routed || 0), unrouted = Number(st.unrouted || 0), ext = Number(st.extensions || 0);
        // Hero line under "How should your calls work?"
        var $hs = $('.giant-routing-hero-state');
        if ($hs.length && n > 0) {
            $hs.toggleClass('is-warn', unrouted > 0).html(unrouted > 0
                ? '<i class="fa-solid fa-triangle-exclamation"></i> ' + unrouted + ' of ' + n + ' numbers ' + (unrouted === 1 ? 'isn\u2019t' : 'aren\u2019t') + ' routed yet'
                : '<i class="fa-solid fa-circle-check"></i> ' + (n === 1 ? 'Your number is routed' : 'All ' + n + ' numbers are routed'));
        }
        // Call Flows tile
        if (r.routeLine && window.giantTileState) giantTileState('callFlow', r.routeLine, false);
        // Checklist steps
        if (window.giantSetupLive) {
            giantSetupLive('extension', ext > 0, ext > 0 ? ext + ' added' : 'A person or desk that can take calls', ext > 0 ? 'Manage' : 'Add extension');
            giantSetupLive('number', n > 0, n > 0 ? n + ' on your account' : 'The number people will ring');
            var routeDone = n > 0 && unrouted === 0, routeText;
            if (routeDone) routeText = n === 1 ? 'Your number is routed' : 'All ' + n + ' numbers routed';
            else if (routed > 0) routeText = unrouted + ' of ' + n + ' numbers left to configure';
            else if (n > 1) routeText = n + ' numbers to point somewhere: a person, a group or a menu';
            else routeText = 'Pick who answers: a person, a group or a menu';
            giantSetupLive('route', routeDone, routeText, routeDone ? 'Review' : 'Build a call flow');
        }
        // Number cards: where each one rings now
        (r.numbers || []).forEach(function (num) {
            var $card = $('.giant-number-card[data-open-search="' + esc(num.search) + '"]');
            if (!$card.length || !num.routeKnown) return;
            var $route = $card.find('.giant-number-card-route');
            if (!$route.length) { $route = $('<span class="giant-number-card-route"></span>').appendTo($card); }
            $card.toggleClass('is-unrouted', !num.routeName);
            $route.html(num.routeName
                ? '<i class="fa-solid fa-arrow-right"></i> <span class="giant-number-card-dest">' + esc(num.routeName) + '</span>' + (num.routeType ? ' <em>' + esc(num.routeType) + '</em>' : '')
                : '<i class="fa-solid fa-triangle-exclamation"></i> Not routed yet');
        });
    }
    return function () {
        if (!$('#giantTools').length) return;
        clearTimeout(timer);
        timer = setTimeout(function () {
            if (inFlight) return;
            inFlight = true;
            $.ajax({
                type: 'post',
                data: { pbxAction: 'getSetupState' },
                success: function (json) { var r = flowParseJson(json); if (r && !r.error) paint(r); },
                complete: function () { inFlight = false; }
            });
        }, 400);
    };
})();
$(function () {
    // Anything done inside a tool can change routing; check when it closes.
    $('#giantModal').on('hidden.bs.modal.giantSetupRefresh', function () { if (window.giantRefreshSetup) giantRefreshSetup(); });
});
