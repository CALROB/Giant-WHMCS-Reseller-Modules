/**
 * AI Agents tile — schema + modal description + per-provider model
 * comparison table.
 *
 * Backed by the phone system CUSTOM rows whose cu_ct_id resolves to the TALKWITHAI
 * custom-type. The standard schema-driven engine in index.js handles render,
 * submit, and refresh; this file plugs in the field shape, the dependency
 * between provider and model, a small comparison panel that helps the
 * customer decide which model to pick, and provider-conditional fields
 * (realtime models use Voice + Turn Detection; speech-to-text uses a
 * Google Cloud TTS voice).
 */
(function () {

    if (!window.modalDescriptions) window.modalDescriptions = {};
    if (!window.addFormData)       window.addFormData       = {};
    if (!window.editFormData)      window.editFormData      = {};

    window.modalDescriptions.aiAgent = "Configure AI agents that can answer calls — set the provider, model, voice, and behaviour.";

    // Value the backend uses to route a save to the external (the external provider
    // Conversational AI) provider instead of a PBX CUSTOM destination.
    var EXTERNAL_PROVIDER = "ExternalVoice";
    var EXTERNAL_ENABLED  = (window.gvFeatureVoiceAgent === true);

    var PROVIDER_OPTIONS = {
        "ChatGPT":         "ChatGPT (Speech to Text)",
        "ChatGPTRealtime": "ChatGPT Realtime",
    };
    if (EXTERNAL_ENABLED) {
        PROVIDER_OPTIONS[EXTERNAL_PROVIDER] = "AI Receptionist";
    }

    // Surfaced as visual cards in the form (post-render). Title + tagline +
    // an icon — the realtime card animates a faux waveform so the customer
    // immediately understands which mode is conversational.
    var TYPE_CARDS = [
        {
            value: "ChatGPTRealtime",
            title: "Realtime",
            tagline: "Streams audio directly to and from the AI for natural, low-latency conversation.",
            iconHtml:
                '<div class="aia-waveform" aria-hidden="true">' +
                  '<span class="aia-wave-bar"></span>' +
                  '<span class="aia-wave-bar"></span>' +
                  '<span class="aia-wave-bar"></span>' +
                  '<span class="aia-wave-bar"></span>' +
                  '<span class="aia-wave-bar"></span>' +
                '</div>',
        },
        {
            value: "ChatGPT",
            title: "Speech to Text",
            tagline: "Transcribes the caller, sends text to the AI, then synthesises the reply in your chosen voice.",
            iconHtml: '<i class="fa-duotone fa-microphone-lines" aria-hidden="true"></i>',
        },
    ];

    // The external provider runs on our carrier platform: it signs in to one of
    // your extensions over SIP and answers that extension's calls, so normal
    // routing (numbers, IVR options, ring groups) reaches it unchanged.
    if (EXTERNAL_ENABLED) {
        TYPE_CARDS.push({
            value: EXTERNAL_PROVIDER,
            title: "AI Receptionist",
            tagline: "The most natural-sounding option. Signs in as one of your extensions and can transfer callers to a person.",
            iconHtml: '<i class="fa-duotone fa-headset" aria-hidden="true"></i>',
        });
    }

    // value -> { label, providers[], speed/quality/cost (1–5), description }.
    // Realtime models stream voice in and out and are tagged ChatGPTRealtime;
    // text models go via the standard ChatGPT provider with platform STT/TTS.
    // Speed/quality/cost are rough relative ratings to help customers choose;
    // tweak as pricing or model behaviour changes.
    var MODELS = {
        "gpt-3.5-turbo": {
            label: "GPT-3.5 (turbo variant)",
            providers: ["ChatGPT"],
            speed: 5, quality: 2, cost: 1,
            description: "Fastest and cheapest. Best for short scripted answers and simple FAQs.",
        },
        "gpt-4": {
            label: "GPT-4",
            providers: ["ChatGPT"],
            speed: 2, quality: 4, cost: 5,
            description: "Original GPT-4. Strong reasoning but the slowest and most expensive option here.",
        },
        "gpt-4-turbo": {
            label: "GPT-4 (turbo variant)",
            providers: ["ChatGPT"],
            speed: 3, quality: 4, cost: 4,
            description: "Faster GPT-4 with a larger context window. Solid all-rounder.",
        },
        "gpt-4o": {
            label: "GPT-4o",
            providers: ["ChatGPT"],
            speed: 4, quality: 5, cost: 3,
            description: "Best balance of speed and quality for text. Recommended general-purpose model.",
        },
        "gpt-4o-mini": {
            label: "GPT-4o-mini",
            providers: ["ChatGPT"],
            speed: 5, quality: 3, cost: 1,
            description: "Cheap and quick with decent quality. Great for high-volume call handling.",
        },
        "gpt-4.1": {
            label: "GPT-4.1",
            providers: ["ChatGPT"],
            speed: 4, quality: 5, cost: 3,
            description: "Latest reasoning model. Excellent on complex prompts and instructions.",
        },
        "gpt-4.1-mini": {
            label: "GPT-4.1 mini",
            providers: ["ChatGPT"],
            speed: 5, quality: 4, cost: 2,
            description: "Lightweight 4.1. Faster and cheaper with most of the smarts.",
        },
        "gpt-4.1-nano": {
            label: "GPT-4.1 nano",
            providers: ["ChatGPT"],
            speed: 5, quality: 3, cost: 1,
            description: "Smallest 4.1 — extremely fast and cheap. Good for simple intents.",
        },
        "gpt-5-chat-latest": {
            label: "GPT-5 chat latest",
            providers: ["ChatGPT"],
            speed: 4, quality: 5, cost: 4,
            description: "Cutting-edge chat model. Best quality available, premium pricing.",
        },
        "gpt-realtime": {
            label: "GPT-5 realtime",
            providers: ["ChatGPTRealtime"],
            speed: 5, quality: 5, cost: 4,
            description: "Native voice in/out with low latency. Most natural-sounding conversational agent.",
        },
        "gpt-realtime-mini": {
            label: "GPT-5 realtime mini",
            providers: ["ChatGPTRealtime"],
            speed: 5, quality: 4, cost: 2,
            description: "Lighter realtime variant — still streams voice, at a lower cost.",
        },
    };

    // Models the external provider can drive. It brings its own speech stack,
    // so only the reasoning model is chosen here. gemini-2.5-flash is confirmed
    // working upstream; gpt-4o is the documented default.
    if (EXTERNAL_ENABLED) {
        MODELS["gpt-4o"].providers.push(EXTERNAL_PROVIDER);
        MODELS["gemini-2.5-flash"] = {
            label: "Gemini 2.5 Flash",
            providers: [EXTERNAL_PROVIDER],
            speed: 5, quality: 4, cost: 1,
            description: "Fast and inexpensive. A good default for reception-style calls.",
        };
    }

    // Engine consumes a flat label map for the initial dropdown render.
    var ALL_MODEL_OPTIONS = {};
    Object.keys(MODELS).forEach(function (value) {
        ALL_MODEL_OPTIONS[value] = MODELS[value].label;
    });

    var VOICE_OPTIONS = {
        alloy:   "Alloy",
        ash:     "Ash",
        ballad:  "Ballad",
        coral:   "Coral",
        echo:    "Echo",
        sage:    "Sage",
        shimmer: "Shimmer",
        verse:   "Verse",
        marin:   "Marin",
        cedar:   "Cedar",
    };

    // Public sample clips for the realtime voices. Hosted by OpenAI on
    // their docs CDN — same files the playground plays. If they ever move
    // these, update the paths or swap to self-hosted samples.
    var VOICE_SAMPLES = {
        alloy:   'https://cdn.openai.com/API/docs/audio/alloy.wav',
        ash:     'https://cdn.openai.com/API/docs/audio/ash.wav',
        ballad:  'https://cdn.openai.com/API/docs/audio/ballad.wav',
        coral:   'https://cdn.openai.com/API/docs/audio/coral.wav',
        echo:    'https://cdn.openai.com/API/docs/audio/echo.wav',
        sage:    'https://cdn.openai.com/API/docs/audio/sage.wav',
        shimmer: 'https://cdn.openai.com/API/docs/audio/shimmer.wav',
        verse:   'https://cdn.openai.com/API/docs/audio/verse.wav',
        marin:   'https://cdn.openai.com/API/docs/audio/marin.wav',
        cedar:   'https://cdn.openai.com/API/docs/audio/cedar.wav',
    };

    var LANGUAGE_OPTIONS = {
        "en-GB": "English (UK)",
        "en-US": "English (US)",
        "fr-FR": "French",
        "de-DE": "German",
        "es-ES": "Spanish",
        "it-IT": "Italian",
        "nl-NL": "Dutch",
        "pl-PL": "Polish",
        "pt-PT": "Portuguese",
    };

    var VAD_OPTIONS = {
        "semantic_vad": "Language-aware (recommended)",
        "server_vad":   "Energy / signal-based",
    };

    function escapeHtml(s) {
        return $('<div>').text(s == null ? '' : String(s)).html();
    }

    // Same teal-family palette + djb2-style hash used for agent avatars,
    // shared here so a given voice always gets the same colour swatch.
    var AVATAR_PALETTE = [
        ['#00d9a7', '#0d8a6c'],
        ['#10b981', '#047857'],
        ['#06b6d4', '#0e7490'],
        ['#14b8a6', '#0f766e'],
        ['#0891b2', '#155e75'],
        ['#22c55e', '#16a34a'],
    ];

    function paletteFor(seed) {
        var s = String(seed || '');
        var hash = 0;
        for (var i = 0; i < s.length; i++) {
            hash = ((hash << 5) - hash + s.charCodeAt(i)) & 0x7FFFFFFF;
        }
        return AVATAR_PALETTE[hash % AVATAR_PALETTE.length];
    }

    function buildVoiceAvatarHtml(voiceValue) {
        if (!voiceValue) return '';
        var c = paletteFor(voiceValue);
        var initial = voiceValue.charAt(0).toUpperCase();
        return '<span class="aia-voice-avatar" style="background:linear-gradient(135deg,' +
                c[0] + ' 0%,' + c[1] + ' 100%)">' +
                escapeHtml(initial) +
                '</span>';
    }

    // Select2 template renderer — used both for the open dropdown options
    // (templateResult) and the closed selection chip (templateSelection).
    function voiceSelect2Template(state) {
        if (!state.id) return state.text;
        return $(
            '<span class="aia-voice-option">' +
                buildVoiceAvatarHtml(state.id) +
                '<span class="aia-voice-label">' + escapeHtml(state.text) + '</span>' +
            '</span>'
        );
    }

    // Engine looks up templates by select name when initialising select2.
    window.giantSelect2Templates = window.giantSelect2Templates || {};
    window.giantSelect2Templates.cu_param12 = {
        result:    voiceSelect2Template,
        selection: voiceSelect2Template,
    };

    // 1–5 dot scale. inverse=true flips colour ramp so higher cost reads as
    // worse (the dots themselves still fill left-to-right).
    function dotScale(level, inverse) {
        var n = Math.max(0, Math.min(5, parseInt(level, 10) || 0));
        var html = '<span class="aia-dots' + (inverse ? ' aia-dots-inverse' : '') + '">';
        for (var i = 1; i <= 5; i++) {
            html += '<span class="aia-dot' + (i <= n ? ' is-on' : '') + '"></span>';
        }
        html += '</span>';
        return html;
    }

    function buildComparisonRows(provider, selectedValue) {

        var rows = '';

        Object.keys(MODELS).forEach(function (value) {
            var m = MODELS[value];
            if (m.providers.indexOf(provider) === -1) return;

            var isSelected = (value === selectedValue);
            rows += '<tr class="aia-cmp-row' + (isSelected ? ' is-selected' : '') + '" data-model="' + escapeHtml(value) + '">';
            rows += '<td class="aia-cmp-name">';
            rows +=   (isSelected ? '<i class="fa-solid fa-circle-check aia-cmp-tick"></i>' : '<span class="aia-cmp-tick-spacer"></span>');
            rows +=   '<span class="aia-cmp-label">' + escapeHtml(m.label) + '</span>';
            rows += '</td>';
            rows += '<td>' + dotScale(m.speed)   + '</td>';
            rows += '<td>' + dotScale(m.quality) + '</td>';
            rows += '<td>' + dotScale(m.cost, true) + '</td>';
            rows += '<td class="aia-cmp-desc">' + escapeHtml(m.description) + '</td>';
            rows += '</tr>';
        });

        return rows;
    }

    function renderComparisonTable(provider, selectedValue) {

        var $modelGroup = $('[name="cu_param3"]').closest('.form-group');
        if ($modelGroup.length === 0) return;

        var $wrap = $modelGroup.next('.aia-cmp-wrap');
        if ($wrap.length === 0) {
            $wrap = $(
                '<div class="aia-cmp-wrap">' +
                  '<div class="aia-cmp-title">' +
                    '<i class="fa-brands fa-openai"></i> Compare models' +
                  '</div>' +
                  '<div class="aia-cmp-scroll">' +
                    '<table class="aia-cmp-table">' +
                      '<colgroup>' +
                        '<col class="aia-cmp-col-model">' +
                        '<col class="aia-cmp-col-stat">' +
                        '<col class="aia-cmp-col-stat">' +
                        '<col class="aia-cmp-col-stat">' +
                        '<col class="aia-cmp-col-notes">' +
                      '</colgroup>' +
                      '<thead>' +
                        '<tr>' +
                          '<th>Model</th>' +
                          '<th>Speed</th>' +
                          '<th>Quality</th>' +
                          '<th>Cost</th>' +
                          '<th>Notes</th>' +
                        '</tr>' +
                      '</thead>' +
                      '<tbody></tbody>' +
                    '</table>' +
                  '</div>' +
                '</div>'
            );
            $modelGroup.after($wrap);

            // Click-to-select row.
            $wrap.on('click', '.aia-cmp-row', function () {
                var value = $(this).data('model');
                var $select = $('[name="cu_param3"]');
                if ($select.val() === String(value)) return;
                $select.val(value).trigger('change');
            });
        }

        $wrap.find('tbody').html(buildComparisonRows(provider, selectedValue));
    }

    // Show or hide a form field by name, including its label/description
    // wrapper so the surrounding spacing collapses cleanly.
    function setFieldVisible(fieldName, visible) {
        $('[name="' + fieldName + '"]').closest('.form-group').toggle(!!visible);
    }

    // Build the visual AI Type picker once per form render. The underlying
    // <select> stays in the DOM (just visually hidden) so the standard
    // submit handler still picks up its value; clicks on cards update the
    // select and fire its change event so all the existing onChange logic
    // (model filter, comparison table, field visibility) keeps working.
    function buildTypeCards($providerGroup) {

        if ($providerGroup.find('.aia-type-cards').length > 0) return;

        var $select = $providerGroup.find('select');
        var current = $select.val();

        var html = '<div class="aia-type-cards">';
        TYPE_CARDS.forEach(function (card) {
            var selected = (card.value === current);
            html += '<button type="button" class="aia-type-card' + (selected ? ' is-selected' : '') + '" data-value="' + escapeHtml(card.value) + '">';
            html +=   '<div class="aia-type-card-icon">' + card.iconHtml + '</div>';
            html +=   '<div class="aia-type-card-body">';
            html +=     '<div class="aia-type-card-title">' + escapeHtml(card.title) + '</div>';
            html +=     '<div class="aia-type-card-desc">' + escapeHtml(card.tagline) + '</div>';
            html +=   '</div>';
            html += '</button>';
        });
        html += '</div>';

        $providerGroup.append(html);

        // Hide the underlying select but keep it submittable.
        $providerGroup.find('select').addClass('aia-hidden-select');
        $providerGroup.find('.select2-container').addClass('aia-hidden-select');

        $providerGroup.on('click', '.aia-type-card', function (e) {
            e.preventDefault();
            var value = $(this).data('value');
            if ($select.val() === String(value)) return;
            $providerGroup.find('.aia-type-card').removeClass('is-selected');
            $(this).addClass('is-selected');
            $select.val(value).trigger('change');
        });
    }

    // Voice preview — single play/pause pill below the Voice select that
    // streams the selected voice's sample clip. Only one preview can be
    // playing at a time across the page (we keep a module-level reference
    // so opening a different preview pauses the previous one).
    var currentPreviewAudio = null;

    function capitalize(s) {
        s = String(s || '');
        return s.charAt(0).toUpperCase() + s.slice(1);
    }

    function injectVoicePreview($form) {

        var $voiceGroup = $form.find('[name="cu_param12"]').closest('.form-group');
        if ($voiceGroup.length === 0) return;
        if ($voiceGroup.find('.aia-voice-preview').length > 0) return;

        var html =
            '<div class="aia-voice-preview">' +
                '<button type="button" class="aia-voice-preview-btn">' +
                    '<i class="fa-solid fa-play"></i>' +
                    '<span class="aia-voice-preview-label">Preview voice</span>' +
                '</button>' +
                '<audio class="aia-voice-preview-audio" preload="none"></audio>' +
            '</div>';

        $voiceGroup.append(html);

        var $select = $voiceGroup.find('[name="cu_param12"]');
        var $btn    = $voiceGroup.find('.aia-voice-preview-btn');
        var $icon   = $btn.find('i');
        var $label  = $btn.find('.aia-voice-preview-label');
        var audioEl = $voiceGroup.find('.aia-voice-preview-audio')[0];

        var resetButton = function () {
            $icon.removeClass('fa-pause fa-spinner fa-spin').addClass('fa-play');
            $btn.removeClass('is-playing is-loading is-error');
        };

        var refreshLabel = function () {
            var voice = $select.val();
            var url = VOICE_SAMPLES[voice];
            if (!url) {
                $btn.prop('disabled', true);
                $label.text('Preview unavailable');
            } else {
                $btn.prop('disabled', false);
                $label.text('Preview "' + capitalize(voice) + '"');
            }
        };

        $select.off('change.aiaPreview').on('change.aiaPreview', function () {
            // Stop playback when the customer picks a different voice.
            if (!audioEl.paused) {
                audioEl.pause();
                audioEl.currentTime = 0;
            }
            resetButton();
            refreshLabel();
        });

        refreshLabel();

        $btn.off('click.aiaPreview').on('click.aiaPreview', function (e) {
            e.preventDefault();
            var voice = $select.val();
            var url = VOICE_SAMPLES[voice];
            if (!url) return;

            // Pause any other voice preview that may be playing elsewhere
            // (e.g. another agent's edit form left open).
            if (currentPreviewAudio && currentPreviewAudio !== audioEl && !currentPreviewAudio.paused) {
                currentPreviewAudio.pause();
                currentPreviewAudio.currentTime = 0;
            }
            currentPreviewAudio = audioEl;

            if (audioEl.paused) {
                if (audioEl.getAttribute('src') !== url) {
                    audioEl.setAttribute('src', url);
                }
                $icon.removeClass('fa-play').addClass('fa-spinner fa-spin');
                $btn.addClass('is-loading');
                var playPromise = audioEl.play();
                if (playPromise && typeof playPromise.then === 'function') {
                    playPromise.then(function () {
                        $icon.removeClass('fa-spinner fa-spin fa-play').addClass('fa-pause');
                        $btn.removeClass('is-loading').addClass('is-playing');
                    }).catch(function () {
                        $icon.removeClass('fa-spinner fa-spin fa-pause').addClass('fa-play');
                        $btn.removeClass('is-loading is-playing').addClass('is-error');
                        $label.text('Preview unavailable');
                    });
                }
            } else {
                audioEl.pause();
                resetButton();
                refreshLabel();
            }
        });

        audioEl.addEventListener('ended', function () {
            resetButton();
        });
        audioEl.addEventListener('error', function () {
            $btn.removeClass('is-loading is-playing').addClass('is-error');
            $icon.removeClass('fa-spinner fa-spin fa-pause').addClass('fa-play');
            $label.text('Preview unavailable');
        });
    }

    // Collapsible "How do I get an API key?" panel injected beneath the
    // cu_param2 input. Customers configuring an agent for the first time
    // rarely have an OpenAI service-account key handy — direct links to
    // the keys page + billing setup save them a support ticket.
    function injectApiKeyHelp($form) {

        if ($form.find('.aia-key-help').length > 0) return;

        var $apiKeyGroup = $form.find('[name="cu_param2"]').closest('.form-group');
        if ($apiKeyGroup.length === 0) return;

        var keysUrl    = 'https://platform.openai.com/api-keys';
        var billingUrl = 'https://platform.openai.com/settings/organization/billing/overview';

        var html =
            '<div class="aia-key-help">' +
                '<button type="button" class="aia-key-help-toggle">' +
                    '<i class="fa-solid fa-circle-question"></i>' +
                    '<span>How do I get an API key?</span>' +
                    '<i class="fa-solid fa-chevron-down aia-key-help-chev"></i>' +
                '</button>' +
                '<div class="aia-key-help-body" style="display:none;">' +
                    '<ol>' +
                        '<li>Open the <a href="' + keysUrl + '" target="_blank" rel="noopener">OpenAI API keys page</a> and sign in with your OpenAI account (or create one).</li>' +
                        '<li>Click <b>+ Create new secret key</b>. Pick <b>Service account</b> if it\'s offered &mdash; the key starts with <code>sk-svcacct-</code> and is the most flexible for production use.</li>' +
                        '<li>Give it a name like <i>"Voice agent"</i> so you can identify it later, then copy the generated key.</li>' +
                        '<li>Paste the key into the <b>API Key</b> field above.</li>' +
                        '<li>If you haven\'t already, <a href="' + billingUrl + '" target="_blank" rel="noopener">add a payment method or top up credit</a> &mdash; without it the agent can\'t make calls to the model and will fail mid-call.</li>' +
                    '</ol>' +
                    '<div class="aia-key-help-actions">' +
                        '<a href="' + keysUrl + '" target="_blank" rel="noopener" class="aia-key-help-link"><i class="fa-solid fa-arrow-up-right-from-square"></i> Open OpenAI keys</a>' +
                        '<a href="' + billingUrl + '" target="_blank" rel="noopener" class="aia-key-help-link"><i class="fa-solid fa-arrow-up-right-from-square"></i> Manage billing</a>' +
                    '</div>' +
                '</div>' +
            '</div>';

        $apiKeyGroup.append(html);

        $form.find('.aia-key-help-toggle').off('click.aiaKeyHelp').on('click.aiaKeyHelp', function () {
            var $body = $(this).siblings('.aia-key-help-body');
            $(this).find('.aia-key-help-chev').toggleClass('is-open');
            $body.slideToggle(180);
        });
    }

    // One-time post-render layout pass: widen the modal, swap provider for
    // cards, hide the model dropdown (the comparison table is the selector),
    // and group submit/cancel into a footer row.
    function setupAiAgentFormChrome() {

        var $form = $('#giantModalAddForm');
        if ($form.length === 0) return;

        $form.addClass('aiAgent-form');
        $('#giantModal .modal-dialog').addClass('giant-modal-wide');

        // The two fields that show before a type is chosen.
        $form.find('[name="cu_name"], [name="cu_param1"]').closest('.form-group').addClass('aia-core');

        // Provider → cards.
        var $providerGroup = $form.find('[name="cu_param1"]').closest('.form-group');
        if ($providerGroup.length) {
            buildTypeCards($providerGroup);
            if (!$providerGroup.find('.aia-type-hint').length) {
                $providerGroup.append('<div class="aia-type-hint"><i class="fa-solid fa-hand-pointer"></i> Pick how this agent should work. Its settings appear once you choose.</div>');
            }
        }

        // Model dropdown is redundant because the Compare Models table is
        // the picker — keep the underlying <select> in the DOM so its value
        // is submitted, just hide its form-group.
        var $modelGroup = $form.find('[name="cu_param3"]').closest('.form-group');
        $modelGroup.addClass('aia-model-group-hidden');

        // Help panel beneath the API key input.
        injectApiKeyHelp($form);

        // Play-button preview beneath the Voice select (realtime only).
        injectVoicePreview($form);

        // Group submit + cancel into a footer row that spans both columns.
        if ($form.children('.aia-form-actions').length === 0) {
            var $submit = $form.children('input[type="submit"]');
            var $cancel = $form.children('#giantCancelAddButton');
            if ($submit.length) {
                var $actions = $('<div class="aia-form-actions"></div>');
                $submit.before($actions);
                $actions.append($submit);
                if ($cancel.length) {
                    $actions.append(' ').append($cancel);
                }
            }
        }
    }

    // Realtime providers handle turn-taking via VAD on a streaming socket
    // and expose Voice + Turn Detection; speech-to-text providers transcribe
    // the caller after a configurable silence threshold and synthesise the
    // reply with a TTS voice. Toggle the field groups so the customer only
    // sees what's relevant for their pick.
    function applyProviderVisibility(provider) {
        var isExternal = (provider === EXTERNAL_PROVIDER);
        var isRealtime = (provider === "ChatGPTRealtime");

        if (isExternal) {
            // The external provider runs on our platform: no per-agent API key,
            // and its own speech stack handles turn-taking. It picks a voice
            // from the platform catalogue (cu_param12, repopulated below).
            setFieldVisible("cu_param2",  false);   // API Key  — platform-managed
            setFieldVisible("cu_param12", true);    // Voice    — platform catalogue
            setFieldVisible("cu_param13", false);   // Turn Detection
            setFieldVisible("cu_param7",  false);   // TTS Voice
            setFieldVisible("cu_param8",  false);   // Min Silence
            loadExternalVoices();
        } else {
            setFieldVisible("cu_param2",  true);
            setFieldVisible("cu_param12", isRealtime);     // Voice
            setFieldVisible("cu_param13", isRealtime);     // Turn Detection
            setFieldVisible("cu_param7",  !isRealtime);    // TTS Voice
            setFieldVisible("cu_param8",  !isRealtime);    // Min Silence
            restoreBuiltInVoices();
        }

        // cu_param5 does double duty: response length for the PBX providers,
        // call length for the external one. Relabel so it isn't misleading.
        var $p5 = $('[name="cu_param5"]').closest('.form-group');
        $p5.find('.col-form-label').text(isExternal ? 'Max Call Length (seconds):' : 'Max Response Tokens:');
        $p5.find('.form-text').html(isExternal
            ? 'Hard ceiling on a single call. 600 (10 minutes) is a sensible default.'
            : 'Hard cap on how long each AI response can be. 100 is recommended to keep replies short and natural over a phone call.');

        // Keep the visual type cards in sync with the underlying select.
        $('.aia-type-cards .aia-type-card').each(function () {
            $(this).toggleClass('is-selected', $(this).data('value') === provider);
        });
    }

    // Voice <select> swapping ------------------------------------------------
    // cu_param12 holds the built-in voice ids for the PBX providers and a
    // platform voice UUID for the external one, so the option list is swapped
    // rather than duplicated into a second field.
    var _externalVoiceCache = null;

    // The renderer a field registered with the generic engine (voice avatars
    // for cu_param12), or the addon-wide icon template for anything else.
    function aiaTemplates(name) {
        var t = window.giantSelect2Templates && window.giantSelect2Templates[name];
        var g = window.giantIconOptionTemplate;
        var out = {};
        if ((t && t.result) || g)    out.templateResult    = (t && t.result) || g;
        if ((t && t.selection) || g) out.templateSelection = (t && t.selection) || g;
        return out;
    }

    function setVoiceOptions(map, selected) {
        var $sel = $('[name="cu_param12"]');
        if ($sel.length === 0) return;
        var hadSelect2 = !!$sel.data('select2');
        if (hadSelect2) { $sel.select2('destroy'); }

        var html = '';
        Object.keys(map).forEach(function (id) {
            html += '<option value="' + id + '">' + $('<div>').text(map[id]).html() + '</option>';
        });
        $sel.html(html);
        if (selected && map[selected]) { $sel.val(selected); }

        if (hadSelect2) {
            $sel.select2($.extend({ dropdownParent: $('#giantModal'), width: '100%' }, aiaTemplates($sel.attr('name'))));
        }
    }

    function restoreBuiltInVoices() {
        var $sel = $('[name="cu_param12"]');
        if ($sel.length === 0 || $sel.data('gv-voice-mode') !== 'external') return;
        $sel.data('gv-voice-mode', 'builtin');
        setVoiceOptions(VOICE_OPTIONS, $sel.data('gv-builtin-value') || 'alloy');
    }

    function loadExternalVoices() {
        var $sel = $('[name="cu_param12"]');
        if ($sel.length === 0) return;
        if ($sel.data('gv-voice-mode') === 'external') return;   // already swapped

        // Remember the built-in pick so switching back restores it.
        if ($sel.data('gv-voice-mode') !== 'external') {
            $sel.data('gv-builtin-value', $sel.val());
        }
        $sel.data('gv-voice-mode', 'external');

        var wanted = $sel.data('gv-external-value') || '';

        if (_externalVoiceCache) { setVoiceOptions(_externalVoiceCache, wanted); return; }

        setVoiceOptions({ '': 'Loading voices…' }, '');
        $.ajax({
            type: 'post', dataType: 'json',
            data: { pbxAction: 'getExternalVoiceOptions' },
            success: function (resp) {
                var map = {};
                ((resp && resp.voices) || []).forEach(function (v) { map[v.id] = v.label; });
                if (!Object.keys(map).length) { map = { '': 'No voices available' }; }
                _externalVoiceCache = map;
                setVoiceOptions(map, wanted);
            },
            error: function () { setVoiceOptions({ '': 'Could not load voices' }, ''); }
        });
    }

    // Rewire the model dropdown to only show models valid for the chosen
    // provider. Handles select2 destroy/re-init so the dropdown stays
    // searchable, and falls back to the first valid model when the current
    // selection becomes invalid. Also refreshes the comparison table and the
    // visibility of provider-specific fields.
    function refreshModelOptionsForProvider(provider) {

        var $select = $('[name="cu_param3"]');
        if ($select.length === 0) return;

        // No type yet (a new agent): lay the chrome out, but show only the
        // name and the type cards until one is picked.
        $('#giantModalAddForm').toggleClass('aia-no-type', !provider);
        if (!provider) {
            setupAiAgentFormChrome();
            return;
        }

        var hadSelect2 = !!$select.data('select2');
        var current    = $select.val();

        if (hadSelect2) {
            $select.select2('destroy');
        }

        $select.empty();

        var added = [];
        Object.keys(MODELS).forEach(function (value) {
            var m = MODELS[value];
            if (m.providers.indexOf(provider) === -1) return;
            $select.append('<option value="' + value + '">' + m.label + '</option>');
            added.push(value);
        });

        var nextVal = (added.indexOf(current) !== -1) ? current : (added[0] || '');
        $select.val(nextVal);

        if (hadSelect2) {
            $select.select2($.extend({
                dropdownParent: $('#giantModal'),
                width: '100%',
                placeholder: 'Search...',
                allowClear: true,
            }, aiaTemplates($select.attr('name'))));
        }

        // First call after form render is the right point to lay out the
        // chrome (cards, hidden model field, action footer) — by now select2
        // is initialised and all .form-group wrappers exist.
        setupAiAgentFormChrome();

        renderComparisonTable(provider, nextVal);
        applyProviderVisibility(provider);
    }

    function buildFields(includeId) {

        var fields = [];

        if (includeId) {
            fields.push({ name: "cu_id" });
        }

        fields.push(
            {
                name: "cu_name",
                display: "Agent Name",
                description: "A friendly label for this agent, e.g. 'AI Therapy' or 'Out-of-hours Receptionist'.",
            },
            {
                name: "cu_param1",
                display: "AI Type",
                description: "",
                // A new agent starts with no type: the customer picks a card
                // and the rest of the form appears. Editing keeps the saved type.
                options: includeId ? PROVIDER_OPTIONS : Object.assign({ "": "Choose how this agent works" }, PROVIDER_OPTIONS),
                default: includeId ? "ChatGPTRealtime" : "",
                onChange: function () {
                    refreshModelOptionsForProvider($(this).val());
                },
            },
            {
                name: "cu_param3",
                display: "Model",
                description: "Realtime models stream voice in and out; the rest are text-only and rely on the platform's TTS.",
                options: ALL_MODEL_OPTIONS,
                default: "gpt-realtime",
                onChange: function () {
                    var provider = $('[name="cu_param1"]').val();
                    renderComparisonTable(provider, $(this).val());
                },
            },
            {
                name: "cu_param2",
                display: "API Key",
                description: "Your provider API key (e.g. an OpenAI service-account key starting with 'sk-svcacct-').",
            },
            // Realtime-only: voice the AI speaks with.
            {
                name: "cu_param12",
                display: "Voice",
                description: "Voice the agent uses to speak.",
                options: VOICE_OPTIONS,
                default: "alloy",
            },
            // Realtime-only: turn-detection mode.
            {
                name: "cu_param13",
                display: "Turn Detection",
                description: "How the agent decides the caller has finished speaking. <b>Language-aware</b> listens to the words being spoken and waits for natural sentence breaks &mdash; better in noisy environments and recommended for most calls. <b>Energy / signal-based</b> watches the raw audio level and triggers when it drops below a threshold &mdash; faster, but can cut callers off mid-sentence in pauses.",
                options: VAD_OPTIONS,
                default: "semantic_vad",
            },
            // Speech-to-Text only: TTS voice used to synthesise the AI's
            // text reply back into audio. Server returns a curated list
            // under fieldName=cu_param7.
            {
                name: "cu_param7",
                display: "TTS Voice",
                description: "Voice used to speak the AI's reply back to the caller. Leave on System Default to follow the agent's language.",
                options: "dynamic",
            },
            {
                name: "cu_param6",
                display: "Language",
                description: "Spoken language for the agent.",
                options: LANGUAGE_OPTIONS,
                default: "en-GB",
            },
            {
                name: "cu_param4",
                display: "Temperature",
                description: "Creativity. Lower = precise and deterministic; higher = more varied and creative.",
                type: "range",
                min: 0,
                max: 1,
                step: 0.1,
                default: "0.8",
            },
            {
                name: "cu_param5",
                display: "Max Response Tokens",
                description: "Hard cap on how long each AI response can be. 100 is recommended to keep replies short and natural over a phone call.",
                type: "number",
                min: 1,
                default: "100",
            },
            {
                name: "cu_param8",
                display: "Min Silence (seconds)",
                description: "How long the caller must be silent before the agent treats them as having finished speaking. Higher values are more patient.",
                type: "number",
                min: 1,
                default: "2",
            },
            // Long-form behaviour fields. Stored separately in the
            // cb_customs_binary table because they can be quite long
            // (system prompts and tool definitions especially).
            {
                name: "systemContent",
                display: "System Prompt",
                description: "Instructions that shape the agent's role, tone, and behaviour. Written in plain English &mdash; e.g. <i>\"You are a friendly receptionist for Acme Ltd. Greet callers, answer FAQs about our services, and offer to take a message.\"</i>",
                type: "textarea",
                rows: 8,
            },
            {
                name: "greetingMessage",
                display: "Greeting Message",
                description: "The first thing the agent says when it answers the call.",
                type: "textarea",
                rows: 3,
            },
            {
                name: "userContent",
                display: "User Examples (advanced)",
                description: "Optional. Example caller messages to steer the agent &mdash; one per line.",
                type: "textarea",
                rows: 4,
            },
            {
                name: "assistantContent",
                display: "Assistant Examples (advanced)",
                description: "Optional. Example replies the agent should give in response to the user examples above &mdash; one per line, paired by order.",
                type: "textarea",
                rows: 4,
            },
            {
                name: "functionsContent",
                display: "Functions / Tools (advanced)",
                description: "Optional. JSON tool definitions the agent can call &mdash; e.g. to look up a booking or transfer the caller. Leave blank if not using.",
                type: "textarea",
                rows: 6,
            },
            // Hidden — preserved/applied by the platform.
            { name: "cu_param11", default: "AEAP" }
        );

        return fields;
    }

    window.addFormData.aiAgent  = buildFields(false);
    window.editFormData.aiAgent = buildFields(true);

    // Lay the form out the moment it renders — cards, fixed modal width,
    // provider-specific fields — instead of waiting for the first type click.
    window.giantFormRenderHooks = window.giantFormRenderHooks || {};
    window.giantFormRenderHooks.aiAgent = function () {
        var $type = $('[name="cu_param1"]');
        if (!$type.length) return;
        refreshModelOptionsForProvider($type.val() || "");
    };

    // ===== AI Conversations — chat-style transcript dialog ===============
    //
    // ai_talk in the DB is a stream of lines, where ">> ..." is the caller
    // and "<< ..." is the AI. Parse it into a structured list of messages,
    // then render as left/right bubbles so reading a long conversation is
    // pleasant rather than a wall of >> << markers.

    function parseTranscript(text) {
        var lines = String(text || '').split(/\r?\n/);
        var messages = [];
        var current  = null;

        for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            if (line.indexOf('>>') === 0) {
                if (current) messages.push(current);
                current = { role: 'user', text: line.replace(/^>>\s?/, '') };
            } else if (line.indexOf('<<') === 0) {
                if (current) messages.push(current);
                current = { role: 'ai', text: line.replace(/^<<\s?/, '') };
            } else if (current) {
                current.text += '\n' + line;
            }
        }
        if (current) messages.push(current);

        // Trim trailing whitespace on each message; drop fully empty ones.
        messages = messages
            .map(function (m) { m.text = m.text.replace(/\s+$/, ''); return m; })
            .filter(function (m) { return m.text !== ''; });

        return messages;
    }

    function renderChatHtml(messages) {
        if (!messages.length) {
            return '<div class="aia-chat-empty"><i class="fa-duotone fa-comment-slash" style="--fa-primary-color:#9ca3af; --fa-secondary-color:#d1d5db;"></i><p>No transcript was captured.</p></div>';
        }
        var html = '<div class="aia-chat">';
        messages.forEach(function (m) {
            var safe = escapeHtml(m.text).replace(/\n/g, '<br>');
            if (m.role === 'user') {
                html += '<div class="aia-msg aia-msg-user">' +
                            '<div class="aia-msg-avatar"><i class="fa-solid fa-user"></i></div>' +
                            '<div class="aia-msg-bubble">' + safe + '</div>' +
                        '</div>';
            } else {
                html += '<div class="aia-msg aia-msg-ai">' +
                            '<div class="aia-msg-bubble">' + safe + '</div>' +
                            '<div class="aia-msg-avatar"><i class="fa-brands fa-openai"></i></div>' +
                        '</div>';
            }
        });
        html += '</div>';
        return html;
    }

    function showAiLogTranscript(logId, meta) {
        meta = meta || {};

        $('#aiAgentTranscriptDialog').remove();
        var $dlg = $(
            '<div id="aiAgentTranscriptDialog" class="giant-confirm-overlay">' +
              '<div class="giant-confirm aia-chat-dialog" data-variant="primary">' +
                '<div class="giant-confirm-head">' +
                  '<div class="giant-confirm-icon"><i class="fa-duotone fa-comments" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i></div>' +
                  '<div>' +
                    '<div class="giant-confirm-title">Conversation</div>' +
                    (meta.subtitle ? '<div class="giant-transcript-subtitle">' + escapeHtml(meta.subtitle) + '</div>' : '') +
                  '</div>' +
                '</div>' +
                '<div class="giant-confirm-body aia-chat-body">' +
                  '<div class="aia-chat-loading">' +
                    '<i class="fa-duotone fa-spinner fa-spin-pulse fa-2xl" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i>' +
                    '<p>Loading transcript…</p>' +
                  '</div>' +
                '</div>' +
                '<div class="giant-confirm-actions">' +
                  '<button type="button" class="aia-chat-copy giant-confirm-cancel" style="display:none;"><i class="fa-solid fa-copy"></i> Copy text</button>' +
                  '<button type="button" class="giant-confirm-ok">Close</button>' +
                '</div>' +
              '</div>' +
            '</div>'
        );

        $('body').append($dlg);

        var close = function () { $(document).off('keydown.aiAgentTranscript'); $dlg.remove(); };
        $dlg.on('click', function (e) { if (e.target === this) close(); });
        $(document).on('keydown.aiAgentTranscript', function (e) { if (e.key === 'Escape') close(); });
        $dlg.find('.giant-confirm-ok').on('click', close);

        $.ajax({
            type: 'post',
            data: { pbxAction: 'getAiAgentLogTalk', itemId: logId },
            dataType: 'json',
        }).done(function (resp) {
            if (!resp || !resp.ok) {
                $dlg.find('.aia-chat-body').html(
                    '<div class="aia-chat-empty"><i class="fa-duotone fa-circle-info" style="--fa-primary-color:#9ca3af; --fa-secondary-color:#d1d5db;"></i><p>' + escapeHtml((resp && resp.error) || 'No transcript available.') + '</p></div>'
                );
                return;
            }

            var messages = parseTranscript(resp.text);
            $dlg.find('.aia-chat-body').html(renderChatHtml(messages));

            var $copy = $dlg.find('.aia-chat-copy').show();
            $copy.off('click').on('click', function () {
                var $btn = $(this);
                var orig = $btn.html();
                var done = function () {
                    $btn.html('<i class="fa-solid fa-check"></i> Copied');
                    setTimeout(function () { $btn.html(orig); }, 1500);
                };
                try {
                    navigator.clipboard.writeText(resp.text).then(done);
                } catch (e) {
                    var ta = document.createElement('textarea');
                    ta.value = resp.text;
                    document.body.appendChild(ta);
                    ta.select();
                    try { document.execCommand('copy'); } catch (ignored) {}
                    document.body.removeChild(ta);
                    done();
                }
            });
        }).fail(function () {
            $dlg.find('.aia-chat-body').html(
                '<div class="aia-chat-empty"><i class="fa-duotone fa-circle-exclamation" style="--fa-primary-color:#ef4444; --fa-secondary-color:#fca5a5;"></i><p>Failed to load transcript.</p></div>'
            );
        });
    }

    // ===== Row actions ===================================================
    //
    // The engine's row renderer calls `window.giantRowActions[tileName]` if
    // a function is registered, letting us add tile-specific buttons to the
    // actions cell without coupling the engine to this feature. For agents
    // we drop in a "View conversations" icon that jumps to the AI
    // Conversations tile filtered to that agent's cu_id.

    window.giantRowActions = window.giantRowActions || {};
    window.giantRowActions.aiAgent = function (data) {
        var cuId = data && (data.cu_id || data.cuId);
        if (!cuId) return '';
        var name = data && data.cu_name ? data.cu_name : '';
        var safeName = $('<div>').text(name).html();
        return '<button type="button" class="aia-view-convs giant-icon-btn"' +
               ' data-cu-id="' + cuId + '"' +
               ' data-agent-name="' + safeName + '"' +
               ' title="View conversations">' +
                 '<i class="fa-solid fa-comments"></i>' +
               '</button>';
    };

    // Navigate the existing #giantModal to a different tile in-place,
    // preserving the open-modal experience. Mirrors what the modal show
    // handler in index.js does for fresh tile openings.
    function navigateToTile(tileName, extraParams, titleOverride) {
        var modal = $('#giantModal');
        var tileButton = $('[data-name="' + tileName + '"]');
        if (tileButton.length === 0) return;

        var title = titleOverride || tileButton.html();
        modal.find("#giantModalTitle").html(title);
        modal.find("#giantModalDescription").html(window.modalDescriptions[tileName] || '');
        $('#giantModalAlertDiv').hide();

        // Reset width, then re-apply for tiles that need it.
        modal.find('.modal-dialog').removeClass('giant-modal-wide');
        var wide = ['callLog', 'smsLog', 'extension', 'phone', 'aiAgentLog'];
        if (wide.indexOf(tileName) > -1) {
            modal.find('.modal-dialog').addClass('giant-modal-wide');
        }

        if (typeof refreshList === 'function') {
            refreshList(tileName, extraParams || {});
        }
    }

    $(document).off('click.aiAgentViewConvs', '.aia-view-convs');
    $(document).on('click.aiAgentViewConvs', '.aia-view-convs', function (e) {
        e.preventDefault();
        e.stopPropagation();
        var $btn   = $(this);
        var cuId   = $btn.data('cu-id') || $btn.data('cuId');
        var name   = $btn.data('agent-name') || $btn.data('agentName') || '';
        if (!cuId) return;

        var titleHtml = '<i class="fa-duotone fa-comments fa-2xl" style="--fa-primary-color:#00d9a7; --fa-secondary-color:#99e15f;"></i>' +
                        '<span style="margin-left:8px;">AI Conversations' +
                        (name ? ' &mdash; <span style="color:#00d9a7;">' + $('<div>').text(name).html() + '</span>' : '') +
                        '</span>';

        navigateToTile('aiAgentLog', { aiCuId: cuId }, titleHtml);
    });

    // The AI conversations list is rendered by the generic engine; rows
    // include a `.aia-log-view` button server-side. Hook that here so the
    // chat dialog opens whenever the customer clicks one.
    $(document).off('click.aiAgentLog', '.aia-log-view');
    $(document).on('click.aiAgentLog', '.aia-log-view', function (e) {
        e.preventDefault();
        var logId = $(this).data('log-id') || $(this).data('logId');
        if (!logId) return;

        // Pull simple context out of the row for the dialog subtitle.
        var $row    = $(this).closest('tr');
        var cells   = $row.find('td');
        var when    = cells.eq(0).text().trim();
        var agent   = cells.eq(1).text().trim();
        var caller  = cells.eq(2).text().trim();
        var subtitle = [agent, caller, when].filter(function (x) { return x && x !== '—'; }).join(' · ');

        showAiLogTranscript(logId, { subtitle: subtitle });
    });

})();
