{* The addon's own client pages: the HTML is built by the addon; this is the frame. *}
<div class="resellervoip-page">
{$html}
</div>
