<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy3Ltdiu8oDymMzBMCcrG7Xg3RkbzoO0FToH9/cKkuYIHA5kDj+w/fV1rz7uXqkSvZs7bqZU
wvOh4etLUsoHrM9ziJ+Ru8iZRTIGKfOJLfjlvWe4yBYnC6/UtFLtWTGEOQCXvt9jBAjcgvTRZPLT
tXrLxlw9rJGH97m6vBdGYCTswvBfgeEB9DlxqI/X7HY6CP4sOlHUX4J67Hk6/RL45SvmIEcFI9TS
ZEO4tE0Tz/JalbrvfkPl/19OOgQQIvegxpKuwRaJRJ7HA2AY3AH3cWlTtPo8rnC4N/fmBBiQNkSK
HKn4KeBf4Wrd/uunWqzJzhgbObKW91GTz6OIabCZavosnNtS+KIY4jdqz9xQp132WrIQyPkdjOiI
8DxJwYhln7ovheL4VpXTGZueRL1QPrk6o2Nigq+iomRrq7wvoa2JameZKup87MnpP48nAni4gwfr
16Ikq756V+5eyDgWn3ly+5yspno1Kz/v08UfXJjVcRFtbnSwyPba6K6ctUTDErI8AcqVCVnvUQzq
4XFGjwSaMkzJraEyB725HuCKp7wYSpUB1sw0IgZhD17kxHqr++5jlsI/1RWZurk/yAJbfLE82qcz
nheahnvFlYY+YMeB3zWWj1uE23TQ9Ai023hMkXFGKxwOY1TUV5J/8HD1dHg6aEwiGKa/E9Rn7Q5F
zHZ3/eceadzS/117OUPx37Cl0Wp7NF59/oh+2F6tMb8MmRxW+3/ZCjuBCXM3hn14J1YeoWyNTlKZ
t5sYmkmLpphRQA5F8ZHXHH5hO5G94Cad72z6fzHkgSNBAqARSgfrz8VyxBfAB3sj+11alT0SggGo
Y+VXoFDE8p/tRvfz3M4rN149OZZeDlS46RvnraBsFQVHdKjFnjgWuBK4j8neETXZ9OzsWNSz51W8
QhiHG8Hg+3NAJHp8W6tuRMhcO0m0srv7FejgKAYC8Xev8Q8muznbBtbooM8xWo6SlnOuS7GcQs7Q
xVN1NO4lv5dQ1dOci+ySR8hDN5j9criKyD0PxvQlTeSBWj/OgidsPQCKS7nWicsKRb11MiL0JGTn
YLJvPzzERAwMlXWaFeWwZEeabEtnItdaKaefLFrdnKH04fk2mNsZFxynaiZxyxS7yAoGvegGBxvs
SuO8ZPYl5Lw4BQOFjiROXbTK84e20aT9OXHMmzfM2zcAs6brpvTYjYXNiPfiytHGoA0Zeb12Fj8=