<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmjKjsn2e0j37+uYJoh1bPBZhf4c4p71DFElI+eBjAJVudAlST8AWpzvpQ9EKfYcLf+uKIbt
AAl45FgdegpLPNPultxq0tpMN6S21l3JMBm3MLNlW5pja48SCr81gOgClE7jmAX36r23jByT9JXp
b1V4US3sgMxnHilStmpuu+lTcL0gOnUfPjhB4hK70TlOr7VR3SQLU/sFbnvUyGouAbAOOJt9FH/m
dUz6FeUJaiZ8qhooYxoX4/toRfQpdA1LYvHDtLeYmD4e8h4Cf4EQ2ztTd8ZN4mHVHcxCfq2t6wjQ
W+x/Cki83LLkd1J6Sy9ekJgOB/xJLIrWkR+0int+QoA/H2o2oreCdmrMYwa4bGmgZAqLeqYmDWa5
AYhRfsxU3UemutO/M15z3m4PVcqMwzYqaWAmE5yhyC/Z4voai7wqGrJCznd/jrWCLrVHC7GQyxCL
sDKbUM6LZmO3IGCWXh0b9HsCZTkBUIsLTc2jfsPuTmQDqRTxpZWdaoiDIqSYisEnqK+0e6c5Scfc
i22y2fjdYzC31fM7FMNoTE//6RknCD+JfP2LreHBsEpf0iFp4htRLDxlQEkpHyFM1/VXOO7dI0HP
ZIwhmumADmbzm1SmVIQCod5GJ+XHQ4DeH902KTJi6HryjCHtYoH4WuncJbHyIVytGH/mUzY9DcZX
dg5d09HxBPwKydM7Q6idqgtS0iODvYoBqg43r64slOFnIW4QWvJ1SepxeA2zDQw22419+JfnagDm
rynMKVnxpLTBLPXVBGSOZdKn++yf4fKA/sp/XHZSYAXkOzkgGcQfxtO5hvDQ8NyXuSYsp1SnTsNi
Tht5gE2ZUyApJUuUwtnuyKeeiriAqK+4todcjJxaHCq/8fbTTSV7/wVazVKCSqAmO3OupCec12eo
JBWdmK/AsA344T5hksrumkt+By4DRiLZ/szA6uA78QZZjeb6kJIo3vWMN778qdvZCe5DfHcDRgzo
3yuSJmC597RbEVPOemMjozvfVVQkUAg5fLiBmhHrTHsIfsQjR2L33P/cjaalrbJu0BMz/ggd1QfD
iYmWKwT745p/pDJ4abtgKhgQOnU0EaEnAgsqnZ+fJXZvRSjdbLniPnUalu1fwxMURLyBwlIAECkA
q2ecS9AJ2tkwoQ6myuktEIOGL+7s1D5MEfsaCYPSfO0zG+8=