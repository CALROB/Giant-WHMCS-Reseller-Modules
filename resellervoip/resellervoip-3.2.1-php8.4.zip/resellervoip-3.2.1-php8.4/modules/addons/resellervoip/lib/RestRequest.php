<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuYmIbNRX4+RfWhVTdC2Qh3cgLek1flTQhgypmlcZWwclKBtXbh07S7Hivdu6N3+weG3/md9
ebm3rULXcRAx1imXqWKUSdUHQLjSduWZJw3kGMCKG9WYRb+Q+hMc0k2bPv4N8boNZawJhz7+PHd2
3Hmtd4K8W4zaEKL96d/zrp52GdtYdaMK9tk4EXmEgUG+roeCIztNdkulRYMMeyTQBbFIz50dny6K
yFv17k4IkuXtOykVB7SvsP6MHBtmBWiv9N7/AfyRMd7JIW5DTGuRNEgNoV1KuykePy4juy9PyS3n
cgvIZRfhEJXhCo3KYdbyuuw2IXoK5TtKZykS2LfSTDydjuOADyDUYGiTYTlzesQKGmGDjirAu6Hl
bQUUZFIsw9bNB3UDIywUwgiLw2iz5t8aFfcDCx25Hch86rMSA6eOqZJaYqkIfDa2xMtQg+3JdABt
V4+/rkJ8+UoWZ6ySZhJf6Vw0zT7JW2w5/7ERX/t00+0roI9LfJDLB1Ijorbfe8TdZkqV43hLQqT6
dZ/g/AH7fyxMDYyXSQuANsZSnukBY1/55ANFl4HwMRn7q5Log8UpSrULsiXHvK7JrFNk517ahzg5
xl5x4yx9Uv1qzCddD0XkuX0chRlJ+OmnArLIiQoW3Inqk9iw+yt0/Dq6/+OUY9JopxW3H7rgTYDF
8BRn5Xe7nii5v5JnwVgutKmr6i0KTXRkB30o7toWHVGdhaUgKE0/AEhQfFXwveC6upksMg+MuefU
SnFmNhnW9Vo1o4iNKsnxMwA51gYmkYempUJSaRuR1HAaDPM1CNZsRtxUI7Q/Ety2LPb5DiC+QJ+m
kLhPVA8rqhMnGa+lkzIUGo9XT7FjUJYhOyzPW9N8XCafz8RBpuRFcm5A5uDQzAFCoOOvRN++R0zm
nAN9fn+itn8r1H62TaLrvvKthnYia48SBUpD4HdgMYYgC/b4pTR9qC3T15LTsIE/mmEZIP5M4WMi
Vqg3GsWwvEJxoY2DwLqtj9ZBX/uS/H+OHwogDO1dcDq8/V6BmkPAHSxw6QNuGFG131RSORqTOjpv
gb+vMXL2HRu/48PPt9sOU4gb21gWay1PoyRBYjQwFUJ1PIpxs0f7PkBgEGAo5WFEpJjOpVsBIJxD
QD0AyYdhABg6W72aFK5b6vuWuXyzeiIu+5RBOUxiO7kN2vYYQHxSg9Bc7MUK9+xeJRhA0UOScbjf
r5/KEr3/swkrlwgmi6DS0W==