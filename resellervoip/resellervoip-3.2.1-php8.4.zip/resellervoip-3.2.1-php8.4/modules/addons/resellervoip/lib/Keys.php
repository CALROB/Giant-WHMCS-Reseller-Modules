<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnIuYSG6W7BhsmuSvtTlODDXCluBjHRvoQ6yhiVS5kvvu1FKWxvaSnAuXvDuWMxArkaA5n0Y
Hgv0caIEy5sE9r+OpGWNj0AhLF3F/yoauGWdje+nocAURPSGOkEXWpFlweKmJiVowFr8XYgjjtHl
46Qo/EKFc/xT5nR08+stOqzn3yKk99vhUhZOrlVqeSixSkMFTE51INUQwTp4CwH2HcFUCZhci+2H
SdUGJ7uVYQ3YOK4BesNVKo8RKl35qDuIaW9rKmz2m77JIW5DTGuRNEgNoV1KuyjVRnyrsbJtCGkx
hkg22kVC5tlWfoyMyMB+IH5F7EDsY0qMAb2R/xTFnA5DxLUQGD3kNy0Vi5geGPYX83+J5bVPt97S
qyAkaTri8F5RFVFqxiavnWD185Hwwdxv91y8YBf6C4KN+DgHKoqrk3lB6yntKGp/coDWMWDeox05
O+uqhIemQvVFt404sMuVNEINpH23s9gJgCCvSULgKoGDpG7+4UpcXfpFG4HCXh2CHUVIhx5vVjlq
Ar4avOxCgysvluynCfUEiqTi/X8zwxjk3J+BgW/YQ2An122C1tvQq3XAG15Keoj7AlSo9r+HPGdn
mVhqWhUBQqI+UGBjFabyK6TZrVYutvoJxrCHsp2YzM2vgSn9OHbe8V3nQIh/GQiSN2AHJ/RBf6G4
4ilbalJ8Rh12X4f0nBjcPeXEJzsUiuWdyDKcQYBJg+x9T2BStVGTeY2ybAG/5j8ATL+QWAj7Yv9D
8HGbmG1iAWMHNhxHeFq7FghnfaXDQ1BKv9okYmjAiPSVtL0ab0ye5bWxwCn8kbESlQA5McNCZI4g
qrgk1kUt9zogRKoc7AxxYbTLBJzII0wfS+NTLqyRwl6DH8aFJw1v9TSEtjXSIb35Y8rZj512aLLQ
vtJWAbIJ74vL3fkM0wJpwy7Awr0zDjFzj7TJc8ryREDH3a/kYH86hPMv5fPc8jvU6RbrW4sKmnOJ
lhhn7XdoNgaLhvzd3IJQQaR5dq0JdyJqeLB0SJ7w7S0fp1Fw3tV/MlCGYDxLvvGHjwhUqQoddoJY
QiXABEGc+esxeBSxkGIFKS2fyFBT9Qt6BfdXKHHEea19gAyumkqoc+rQqpTn9s2nsPaeSZ11nk2n
3wZz06k/2Sw6Zf7bvUtvdlJcKLX8Mq5ofcC4ltyTQLNkuVz/VxpWuO30rebqIjDJN+3SGOYG9rzU
4a1Ay9zYwuoQp972+4y8YKHdwwO2MF3PKaj092uNElMTgsnd+zbOO/0R9kQJ0Dnw55mi/8XpLIqf
JHBqEAM4vLWa1q8Z//07vBUtXuLp6DQejxjws5NkSbJj7ZZ9gUboVBFfqeZE2VraOcolesAaaKIq
VKwCeCO2BSmVvpxMCKiUGOdIeU/sG+WkD3glreP4ahwuhGaliZb0V+erKugzaAUKAEoAqApT71A9
28faJwkl7hQoCwp29MgJ/VdV97A6JUktekOjeRwVscGHfRXvZTLOoKfX7Bcw0jIeV/SX7ISiTbFQ
m1m25ipi4pk32BgY3aeXLPTNn7Xq3e35CUEVNnonHWLqDOnF3ISJBnkoOsUkmZwR0UTYLEob8q0t
+tBPt+i1Y9cgG5mvOS4EYMBTrgZgghjHQG97AcQ/N9fhnuRFERFLgicHiic2mBRQKrUk7WABAnMj
/S1Tv8/3YZXvScGs4exkYRfc0RPZJxZhWbDVe+pupqQxIAKNIFIdDxK5GVvXATUXZ1EoZBycDHXJ
7D1u1ujVDCQ4vj1wBZ+l2S4uszyD/NV4mn6Pz5LGhMOWFVEV1/swLd95Ksk3pmklVR/UTqtmhzMi
cdTUl1esIQAOcr+4U3iBrP0H7S56gU7Ne1CFqiSA2/gx9gqdA/3BkVUBi8x21tvv9REl+AcAGmPD
6RdzEMk95J66efJkH1jza5RwmvtJblu5GbZ6gysQDAnT0CVpkhvd7tIlMM/cgtcyWZ00sh5wS14C
Ir3qfq4HiRwp+hN+vCVNyXtxyiJ6LnoX4/3uUlAbFcnaoJQqbcyOzdG+kXBlRyX5BuS3KJgyu+BD
C2xjQV7e0hEJ2MaecEtCcrSMBV4Y56gYZBysOvjQ+5yX29krKo1PgifF0sCJAh9b71eSDIUdvvTA
XR5ealxyF/IsXd14iGCLDF+a5qOdu6VoQvWA7ff2w2hpMqbZxQhgYGfLqCZRmslGTtxd+hNVkgLd
SbiFqTEfQ10HdHYTrXkVS1Rtb/y+ZNrxl6M9Mkh3RvjhmDCTaH08eSiE77IX+6tnY2ht1phgVE9N
scnIuXb7/cVoY7cn7BkgW+uU0m==