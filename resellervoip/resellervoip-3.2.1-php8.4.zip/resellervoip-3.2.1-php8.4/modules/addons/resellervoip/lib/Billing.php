<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv72b+4wAspMntS2mXLlvQo096Dw2gvj7yMdbcxQ5l/80jue/ut8++pA7yyjTf65vSnZ5Nux
6hWPsMJYv4mxuVns4xZjUqeJ+CmuRYZwuL3E5d6vrfcV3D5V8ZMSl0rWZVB2IQZz+bqWsMZxweqq
t9viKrlk2gCGq9O1dNLv9xgf+0Y+fmKm7N+IzxnX/21yISw2apcSSw3gqkLQQIy4S0jrfVKn/8e/
3Ut3Sp2WOvoXsGTRFzPc7fkBie3X9W8zTkI952ft01Dnqqe1JNKE6rpgbydmLEFBMsrFXBDZxhPS
xeGc6edZp7V/qL6eYfYR2WU5rtbQZ7RMJKstJmv9xxyqHdf6Ts43I6uYRn/a4LEgyomIuKqbRVFX
3HGmBVOwUu6gIjtKK+Hy9AsgD09+vX7rVN2Z4lEPKwLgK8e9Y/k1jUB/87CCNdNHdN4+7lpuRCT/
tKiOxbvPjHUa4qXPOBmNxX3T3ERzTmCUcRjxanzgdxM/aatrOzC5z5AL2V/nXEwKd14XM+LQQgmK
6id29Fjc/vLx1PQcoE5vrBhpILXk0UgaqZeSUXaQGW60M0gFyMurmAfhor7Y37aSHMvO8kbQyc8J
ugzLgCJVNF/7W+sIH75lo9QlQSJpuQQf+a4vvCMifunZkioqM//8hpYu2kTJj+ckBxZcay+Syayp
17zQFm10il8iln3Cy94bJQEmp6Ozt9izZZ8NQC7DKpjBAH8tLvHx9UrykembbR84zSerOsLZ0HEF
5b+FXr118IzH/NXo3+uqwuxY/YJ2mM89YDqBKuS6H2CFZ4AZjNRZuPY8a/Fb9T+vlr298yggdZN/
s9q5UXywTSCb9ATpEJQcJ3k/s0vpbFFkgvlAZ/jKP6sHuIlvZY6Nfr/+g+CzsYyazw3Zj11ZQZ9L
aG1qAhuMa5Qayf0GQBJ/hwa6UFVbb6PYG+6kjHiKtI7IvSoov1+rvxbmr53xVn3nc56i80NfBWsX
MZFiAFYAhc8b/nse1XIvuCnrK64K5CwbTLOZ9/lbp1xHN0BjTAFWp2SAVZWvfNluu6QpaUDeDm/Q
JBARYzdr/ii9y8VdaQUSWHTa8KWVO8TQVPq3wpN47bwDEWoectBQThcU2oMaXm97Hha0BFwbieqQ
Xwq1HRRyG/JaXVT+GOIT3MuFc6VwzPllx6AIAVokCZMwbDTnagOxpGXY52VIyqpJGSnSmO/8IRss
GzrrjIfT+MEDyshLLF0DkxE4x8S2IXl3AdRmXNy1LLVUFUjlRQ9KIclOAL0+EqhZks8ongSMjh06
vpRp5i1x6fudPUGvu2sXrDELFNTTrp3NuAwYonKH8q2v4mqKZNx/ncSIS/UGZyzEbAEiMUfg+eyF
VSBH9JfLAuN7aWDThnimzfZtIEemC8go8NLX//UImGKpGAxtyyFykoh/wfvN7Z7Vz27Nyo07Cjqs
ivoPU+1XZqUwOapEYL6fWmni+1sCI041WNSh0SUFTU+4ZV43gHpJU5/XNaX8C/T6W115jL79auBI
YX1Rsl0/1/Ow0uPT+8exoHOn/j6QZT1neJ0DHMfOFtLdtCh4GSb4D48Wg0f8EgYwe0eHqCZNYYYx
gGUEyfxPoSSacEu3/sWistjWAIXVoX+LakaZPvv4EVgCHkNC/hsfnBQrJANe4O5D3MTJ7aX9kw3g
qB/lEc2cUtcH4/xHsfFW3AS7jjuOnKDozID9ZOI14Z8tg68LBxatyLJvUO+77OAoiaPuIz4curei
tt2Yeb0htMGxOauFInrpb0QalHmPZN0uUQmFXzYdFYAJ/DV+zs9M2aSE9dTs/doXcAEHZJu6iUGN
iFjEwDDS6tLvv7LZggmMW1omcM/UVp4PMwq1fuOwgJ1b8cWcZ5Dir+iezT7/o9vooEJyIPOCn80a
69XthTaWG1+p8YHmd/5vwv02wsPifIES4m7OGBiai96hu4tgv9XvMktG9uuIX2fE5V5Qq84WQsq/
rvovC8JH+QGHa2cgYKac4ACj3LNbEjcCJI+ciD6t+s0mogkFZ9ETIq0Dz0e+W86eSFAXKfT80eHR
CFGgdsQWdciaRp9OIZ580H9hC1t2ira8l5LxUPzt/obOP4xQHd7nJCwpklYVjHJol5YXQ6i=