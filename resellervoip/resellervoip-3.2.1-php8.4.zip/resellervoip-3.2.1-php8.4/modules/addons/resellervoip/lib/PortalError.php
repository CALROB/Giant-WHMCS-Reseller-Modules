<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr7NdhQeFMEviM4BbMI6WFGNQz+QqZbphDqS4EMAhKoZcHRQTpdn4+00HSSaFPFfVuOcDDjf
djaGIksNaaFD6mBiCwyO9dUVbeoEB5JYjR9CnZXUnZ7InMm8o42XxmVdhhx2NKinn/Jov1EV05U9
E72Wtx6pbehxHWpZUuO6cTxatnpwu6BaqufSXLeoCUMv8uXGvQm+a5fp77cL/gsJ0ElXvMG3y8XG
p4F0UFwhHu8u5sIpIkRJJwodtL9GIUNfHEV2pk9dRdmXSTDA0Krr3XjSwfV9y5JZosHnpZTdRnsg
Vfv62BgEwCnwXrejgXShQj26B955OEWzjHVdi88fibFBIJuuE8+Q52zOvc83LAPAw9EwaodwBcKW
CPWKwAiagKthO5wPBONuq3xqkq0WPG5Shr9EMLGW1bngQE6K5jmgrTaOZl+qUjnb5F7rh9+if/JM
hoJTx0WbdWDTs3wo7jyRgg3DXEwctNLQFZxKP/OK99htA7Sa2i1xNSmvGQnPXNL3LYe3tWI+K/mq
CxUplTGXvwHeyZHNDka7OAxGERo8jW8VY3loR6yUA7QJ+kKlFhBCMmaoorPCby7NOVaQQUuOL5Yw
pbhwD0AS6JBA5RKzQu50klAtCJuWMG44livLSmIV1Pd2girFQ4sKbX3/S+JhipU46+a3Z6gfaYDt
zDYVr2DfrIS/3oaG2VHonVhWBmCL3Pp2HHdQvTw9kX8MhaLdng3omr0ZpT814z9nynQOpPJ2Xog3
gGD+v+UaMFlQy7Akj56W+zNSQmREX8q7kE/4jP1MGq1IP/3HkNvx4ZR4sQFJU8bcPb6txeJg99/8
4UHsJpbCvQcgNHzzN2hphXlAUstbeHAo/dlVveUBqsgKIcGxp+uufkihQPdnx0yFZ9TtH9bUooB1
UPTxQYIGybd4sYPqydV1DK5DO9AsouwDNlJFpXX1oHb9D+kle3+dyio5L5ovjpiB3bwdqiXtBx0L
vZ93LX2mGiG9kxh4BF/Hfy3EazE01F6FWdPGTJ+jVqTd/6gbgX77ZRwOv8S0bQQJTmwY3CCv1qfG
3s2n+a0Uo5/TgRJsxnRMB4J6iqELAxVuCEjbNC071bzyaCq7XOIGqJ977BoSzvmiVLfkoONd8i12
ei52Xr8o7Ht4VpqC3a/oKhx7SANmg+rGESN26nylX0xYdxDA8yJxiRPX3fpgFsGmX67SnS4xUI4A
OIR8Ruv7AHSTOmEqwavYrh0qUEsoAL+Z3gDFa7LpYTlk3P2tcZrmeFFHbI4MhzFK4+WHHZXsbWvu
lwh4FlvHH19LqC1q20Tc/ow72KCM7UpKIBhrSewrVPxiUFfhZXzgM8qJsN0Jzu1dwU24SNoUmBVV
wgzQJGppKDFtlGNMIdB+AMhUa4PXOekqU4JseXUULyr0lGbyxe/kqplsQ7klNKbMZe7XXCrbxtoN
NtVPrAkoRCT7U/gMRcOkIa6AzAHrKXfFkhcpkvMkG3MIVkpbWxCaRTMROekb6oVf/nup1Nd04I6E
uAFAbh49WBP15SiIAmOPp0FI/eDqWQHkuIuMrrqz0SkXL4wKPp7tvyhmiyEKyuLEheRGidFnlWUN
RnvS9LTvmCDawPuvUmXFBylby72wd12m71j8bvyDglQJGpGRAjbRxxo5TuSG15n+Ao7dw7VVGltf
NnnmNqPRb7qG2JGcVXl6WNbqD5N/rNdCijMiy4Y7vzwleiYqp9iVy8Oqhv4MOKJ0/Sq2te2gFK1P
DTQ8ugE3shxsDmRl6yRO9LetFhlsTt/ajUPnglU9uGbY01i/aIgXhg5KlEz9I5rBWDursGiH0VRg
MBrJsrSYBJqUepZ3546H7p4/dH0afi5LtNn7GR8Z4LtP7+6Mcqy+jhg/H3Q+WpBpvWPDPOL0B+bu
w+b5/6xKoyQthCVehBhmSoeCxgbLrpurIArVwEramS2NCZd+ypIobaKgNwaXh3RBtw2bY8hbtSLo
riOR2DptUHGpYrMfDoNr0wYTt64uYwogRM+7Alxi9hwR/QGfxDuvlIuFlcaAQEbxIqH/rOvJtn5N
aZ3nFW+5NbAcPg7LVOkkpjkvoP3ZqPEufYcB5oa0GKgifJhdSCN9CUHCLiGistFxwrvdUSn7/ny3
kO6n4el5TWoHEfBmGpHENZcCpwgMRJ2FTZAbtW76BwrbutXRdAPt4vUAu9gft7CbIDKB8Z9s89hd
B2foqUm/Ovj+BSxfx8mdlaeSe1jQ12PxDbb+vD9tg7gUtQAeDkT/qCF24612iYQuY4lguLEoVAgk
VnNKqQYQH03WwxvaOisnf4p3+Qtc0whOF+XJCo0zzKjJdlzsUt6+DL+Zq8R7/t5uYkFwAzYGy502
CzIr90cv00==