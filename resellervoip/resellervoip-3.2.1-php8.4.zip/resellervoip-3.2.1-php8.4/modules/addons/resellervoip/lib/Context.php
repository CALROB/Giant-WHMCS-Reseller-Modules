<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPotOatfJ/wLeVIvY1baGau7rBEPpBO3b7gIyO5zzi60S+9/akFx7dNjCY83aZbplPHNRVHWU
mEKivFWCt6cXrAf3yROw1IaXc3MRXiJ7t4j5Xg4HLb6JIhsMHxU05iTRnDmqK/8LD/CrbYFSh3fk
u3vlpXucZwOgA2v3HBLtItHy6YUApOjvhonSLnVTl6+XZ1WR/aS7l0b/gRyAbRqW7b+Fdo4X1mR9
+uxt2e4RmTyhmcoZCs6+k0j2qRqc/QKfhaJSgVEjrt7JIW5DTGuRNEgNoV1KuykNQ1973zr9B53t
HyYw3kJC3o9dhLniMJdE0EkxqfcsHh1sRIjfBvaPDPjiXxQ8HJO5bQsXZoj3buofEznlWNyEsHbO
yS4LXmhQ8v96HPosNLYFqh+uf4qDnPd9ud4MLx7B2jVk5dCwiyQ//FHSCKP+fDH/9g07Ev5wG6QU
sUiAbYDLjLhqBfac8XN2ymN8fW3kqIXbYLpv+CF5jVG8jWnnh/G2AFZw7NVw+rq94J2RlUhMrQdI
zQ5d8lB3QEF6yD828QWunIu3IqBxQbC56UE3XMT4LvNpt91zdUJtP2bw3XL93tNFxiMds+DSYtVp
0kCoVnYkDVewWnT4x/g8FdV0HulkSI6StllxPXl6uw8vs6ZsXef8ndyOcg0jPvr/bi+/dLYebkOD
16n3g/jHZ7aukGv9WV4XAeGg5Ww0sQZ4U8wpcqq5fl0ebSISJCMybSGEaD3Odz7U7abhOo3pflBD
dru9qAqChOqlHavGMIa7MTiDECJHsg/2tgeOAEbmojPd/TgsCCxd1lxmOK/oM70lL+gGpebRi/Vx
MZduFYdnyrIEu5KSOEuciDOMvwG2ubJXVRsO3craqaMkYRwiR1nQH3zs7xp23l4uut22NG9n7nSe
kwda5awLWfXAdADrVxinZSK2if9amcpZhSJZVsi7CB7PKxouthhPT/b+7qx4Edy0qvns8iQ1ulKB
NXuYfu/cdjna9q8mW6jIQ7YHsLkNSS9gcGy/nG/elocBApOZs6D0Re5sNiBsHXHLaEfnCkS/sGfx
BDyqn1GZx1gv1/maztuXDA4rAIdF4i4B8A1oaM+M+yyaDZ1f/2wtF/SgljUePhrdOP+2jonMPDoM
ncluj/stL9fck5rGx784EB+Mvfraac9YXN50RKilQKHJBYbNWVZHgTCki+WRaV8prgIiK/W2