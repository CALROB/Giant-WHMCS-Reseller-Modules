<?php //0032b
// Giant Reseller Phone System addon 3.2.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+CcbR6y0cw6lP00aWkIAxXYGT+RdS+IRRMyDU9BvMm+34YZZ+rRfbIm4rYluLSq0LxQY0sa
Bl1O49zpOwp/CaPTobPAu05e0pcDMi3NEnenn4I4Ki+SnOVNTb37N1RqpkRy4RQeAfBKfRJR8pLy
Zt0CMtkd/XhcYfmbfRL6htAarauScMyCvAnkWjlXYJXNqQTRjJFnNs6siH1U4kRvz7gNHiFG9j+Q
lxij5fDyseaD6bqu828GAACTbzeD2njvtI2+bvu7Yt7JIW5DTGuRNEgNoV1KuykoQ0PCqCLkx5Hm
x/DYYUVCJFyDVqux6ApUTmkXujR7nzTNDJvZUgXwAS/hK09PX6ej4RfEoufZQ1SA491Jd0Z12vWq
CIAWd6wriKYwv5ER1RIZbhynRN21FmglcnR25lgseMNcD4sNzsSmImj6xrxyJZS5LJK185jlOoTT
ZEpCe12PrRk7k6OBgHfvEveDzEnCOTAElSFOmgIvVsjTjx+KLyfocFNG3Ho11N6+aXXWvV6KPh8L
Y9GLofHUf3QUPBSd75L76y2nnhphx9gTKN/6NHhgOXHkUVOV/MFaYcOENXWmd8Wx45wgVs9zvb/I
YOzJHSkpIdnIW+5XU3qQq0/4Es0LQZCiX+5vN3j85TWP2YnEYa0kEQnlFemdRf/Hpo8n8iodvcS9
1guvyyRrGVPJEu6LtrklCPe68OfK+szz2Y2gmhDY0awNv87Rz7R39EWnm8uUi++o1yWz/VRWTBcp
uAGc6BTrB76A1QvIVDe+flJHMHGbOZ7Rkt7c4sR8xq7wuTLw9+UDCci6wxAX38Jy2F4rFKPn5qIt
BPOCy8v3R7Jpx+8Quu4Xzi/LLc7pMLQpfm0GBtiiUvh2hnwfiKENUDGjoFCfJRCAVO0fk/5HMYQT
wOWNRCN3dim6+YxBGLH2HU6tPcv5Kgi9wnCUvSUq8qdnciuAYrrYvIBR2a2jADeeU3f+G5ow0DkJ
opKrDunrce7KRJrQKtN2+h34P88O7swtG7ESkPd62/++gDbuQ4SRX6+E8sNc8RX7F/Dr1mvPUHlk
z3x2hd/Dk+7JjXLQDHcCyOVaJbpVj/B5YFj26Kd6WS9zSJwD1k+NDs5lAHcBdGq1f7+//usC4Has
gksxCWoWz6puhw2xK6PESyoGK4tfAUOwkZEtNZ9skQHxR666jsy5rrIxVB8dlzjuYsblvJYtc/ef
EPUcD8IA804qaGJI9U3aRbdnqMAl0NTjxjI3BSh/sR1c91cdTHug7mNSxJlGbbeZZtiNiuvI4hHF
5ELuDLznZsZOXUk+GzJHAB9pdmpCWSrJQwIPC3dKLqmg/br09dskKPch3ADQis3tIYnx8RsRoCd4
BU6dPisOTZycrEAbi/YB02X1mUfeQyoSlyr98OPYVRxB4l3heytZ5jnW8OPfpiRZYriREaTphhv1
KLROFS1zcXPE+4JRkvfqODvVQ7JgPyL7N3yWzusemyUfWe5R/njCP/24MayiluldLOXETWyqLdtE
r1S/iY/4xjlSdJ3i/y2tu9GQhTM72L030xd2RPe+dNjoWYCSZ0XYHVDB2j07FaMsx4cKTuyrP3Py
hch5XS7DzLq8abfQ6g6xKFa3Jotgccvj2L4hU1xIhLLASiAQcXpq9wdBf6Im6SIjmU8oZeAY0XNU
BU8vACFcslDb/5kv4qnFfgBRmdma/o1w1TUmq50HrilpLlNnG4YMphwaQQ4F4I5vOU+Pu1q+/8cS
+pPV/S56lDXtHuUlHINl0tBphX7e765S762kPQFNFS0YSMEsW3iUbdQI+mOxr5fLij+q+hULcLyK
MwtbwE9wkN3+kfZlSZrIZo1VhHMMO242inBQSCh5Pkgs0DB0fRst5qVwVzYnWIg+GtdL0G1eGc8K
Q+t1UiLVgibdjkTLzZaib2WSzwWhpPGpCjx0CTAgvNBE2digMyhUkUtZUjJgFtWL8X4dYexrh23V
m7i+9YG3cZ90qYObV+jW0b01we3OcGE1WXw1EClPk30jZcOU8bPajrB7J/ps0hDSH4qkA72XBJOF
UvplmfDEV/6ObTMh0yJzZs2Yr5GWnWjph92KqVuAFvxrkI89ULsfTerqUeIg4/M9i1x0lubTO728
JmupppGlL1PP+laenex1AKyr2C1IzyqhhIzZCBsTGcUWr9ekqyuwvoFFjCcNv012Q1craSg4E+xd
Rf3OsdwC8HamHnj3vemsj+gZreLQJRl0PhzGp+oDIf4b8jXfCyEE9fc7JA4hQq6myFGVmC2pNVYY
AUDhtJAQIreNXeQCYcfuCqc5TbUngZIpVtpDKT2E/8kQmbqp+m+5eCrQ3U+eIqu/ZcUa54Ufq1cT
ZC6fZDpT2EDkl9F1hDMFUswhKjf7evkkLf7HhFQ5T2IEurNaGPv09O/ul2pQi8/Cj6km8x/hMhNe
LSMcAIRPoFKIbFceJI6qZm==