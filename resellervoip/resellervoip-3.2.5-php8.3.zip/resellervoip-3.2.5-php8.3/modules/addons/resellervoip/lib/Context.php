<?php //0032b
// Giant Reseller Phone System addon 3.2.5 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrOlnT+u23uGGPLG/29XXtMdzarre5j/oe6yGfsk7N7IKgWReLO6yHjARdMKwu32f8DAnQe/
Eb7tgCAIsCiVqda5BcLYC1s9uA6UASgRwuFPilAQ0mMNhMmIt9Fbr6JekxAlHp21/Ru2l4TZNuFr
3j9230+EHypw2MYo1v2V41o7u8EKx9fhyPJlW9edgGqNUogZ+9mQT0DTQev7fqYYeTUiPYInwU/L
Hf8HhqH4kuU+/g1PxvQwg7pa4teX8eM8UOxjt9nZx/ElgmT82JIXdT8wZTMaujgCRe9K4MezDzBG
5JUxZEciG5YAWA7iBGLdf/4kobwZHMLfmxuI/zzZ8gMFiA184KptmUSKR0ss58O3UI+HrBJL/FRj
uviWAbK0xiXXrj5sWd5rFOe2qtZpiZOS6rjE4rF5ZhfcnsVqr46MW5vXfY5PUAi1sSS7Ig8/+dS7
73wmjbxVjkNMJCDpqDlRsIFgnvnsMy8LqBqR5IEfzLVFWhTfBXCQLhtu/RllobRwCM0AzE8q1S8W
YaLG8iWssXntOhaocteZ84W2jIyAfSuAyFZ0rcEpUL0DQxW6yVYh+hG3/9SnFlOMzvaz93TZa8wG
GRckBi9gE+XdbdHLpmqbO+VLQft25/1xV8X+i8k28WzMbZafyjO8cS/+v0QOZa5AWAfoJUcK5Ui9
3hjk/zYz6+F4zSCGdegERqexdHdl2TUVDap5wH4wNa5XGmxJs4Ks4SQ3Y3u909H/3NOwZj5imZHt
PXBH0oYX2FmmeRmOQJdAFVwH8crzRD/tVgFdBSijC5bgmF4GFjVbWXTKKxDzsEiZyfW6+RuWhjhR
ZaiugaJwL4VBUJLkK2RiiCVL1FjRxeZ1RK3ij8xz4ELKUTmaJ14u9YepMxcdEduEPa6FLcQNKbjf
J9F+Z2gOaUrvGZPTGE6kbmxihL1htMEIZxFleIKP9+DSZRW2923NyHtU/IcPr3LbLGhMbh9OA27J
zjh6moO4P98J54SK8qwULbzz79udzC/MtvGnvWebPi2U7F9boNwDd8DmW7RcXVWBmx2EzZgOigEZ
NOL7e8r6X+4I2udVswderORPrkvOJ4/xgvbVLLxizgVI8Al7hm2mELdhLonDLcwAY0mrAQK9MEzy
pBQlhCf5Cl0dCOQmxkl4CABxzz41aSSqtTlRIXoXuqO9Om==