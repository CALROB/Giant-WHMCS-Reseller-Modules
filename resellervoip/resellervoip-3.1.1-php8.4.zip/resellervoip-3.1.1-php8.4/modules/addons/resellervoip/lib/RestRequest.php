<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxnrw/Vtm+/uYiz+rFC9dvAy8sCs/CThOwAy1Y0LkL8ng4RNVECi0y02BWEiLJgvetXgI3Qq
PSrsUIoHgGgg9ux54QR4a6AwIiN2McPeeXm9ZeF2TfTphdF51KhbMjWQszLqK3e8L1Q7lBZ4W346
NZ7rfkXDbfiH6UI/WPOI8qVYnQ9q1yA440uEce/Vw5g48lDGHxqSIkscHOEuMdZK7gu/vmwBJqaa
TqenMrc8H0kuWAdVDuHnQB+3f0qBuQuMxsBkc8ExFMumA001o2XVdYWmgHjAk8q/PGcKWRL7Z7wt
eP9o15iiJFzCj6XGsbho3erOjVyNMxwTH3S3EBqsb6lmeuQOeD4AXiBnjmDnurjtKklzOyHwGuaG
w7FxSfsw+bxWvlnPv8U30dgf2YuKgv1fpQBacgB+j1SuQjJ1o1IvqRKpOHLd5ISh+HvV8GgMn7wJ
jvw+L8Aaex2w7+ktCo7TcvjqO1J/jB5T52U/7TC1B5VonqFEran0kXHQK1rFdZ6SmUnDU/yiSnfl
N0D5sycs+juG56Jy5fRQCeQ+8pauCeBNddeMwASXIJAe/ubJzyBpPYF0JZITIn2mge7otzPq9NaK
VoGDv7MkbwTD9aFMhxSYr+v+LkkCQpeqH2r97cxU8c2s68T//rjLWaQxZzboSCXhVMTL2R9qDFC3
+miVROBD3TPoAUHziR+cosJ7yxsSffJt1yrjWby7U/WFqExN3bmbJv4Qpp9+JDN60FmCzfAUeM83
Wn66JNa276dCeHPcrKmYFwj6tDtX2582UJXgbqNXZVF3IwNwxV/WhX5eFY6GSCmbScpYWr/v5jtK
O094FJ9yOmJg5e44M79aMdSrq1uv2Z8AtiUNM9DHM3aXwXT2ffnFZPbB4VwVYQaJhwFB9I5LqLsI
wdUdeoAk4JipG033JDKexkyIuHCWOODJR/I1cysQvgMcAKNZEI0vc6asbr7Xomh49uibbwoZkMtq
HbhcrUOHeIUUVcV75V4gw6GiSquBP0L35TMUcqZGn5dKcBFqZBoh0ruPUldlA0H5kT+nb6MdATcR
PyctSRnghiI6IvrlGATYHYzmHFJA0rwQDBOwutT8d4iWcMIzqfT95MCSJfUSo18BBKtk63TLOlY8
JTtl/f749R95zQMOAQnKjiO9x+tx8NBA/zq14Hhc9X2r0celY1wFyrvQhEABqxXwyJP8GX+7jcq2
YDUvlqsg/sK=