<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqZoErYuMO2VGKIkUwakUN6TozTelUZDdPsy56xqYl//omLKhc2jNFI6ZBcucCWwwXb38/s+
kF7XAiDtHACosLNq9rMmax/Rrszd7Giuheztusz5vNwulFk718O5RtLG7v/OuzYCS4aRu1yTOgzW
HA9ebYS8weRQeyFE+1VcYG3OhbDvqEdj9jyW/gQzmL4ptiFmpTUMv54VxHB2OCzvDG728JMPM+43
rRYL2fhTGfflNzKgIsIVq2egBaiUkPgxRMvXnRtcLsumA001o2XVdYWmgHjAk8rhRtJOUgAixDVe
iaToX8EDIStxbsv9b1PEBCRHt+bXmWdJDInnI34QetT0kfHRDkabnGarem3DO5XNPrieoU40Rg2s
RwsdK5fxweoIw9ZT7mxlHhIsNZaiGb3cDci6JsvLT84Jj3OKeGPj1xI6DOoE6oscL45Ka6W+rd/V
91fHAQRgDQsT9Txb1RAi91q+YZhXRR1Vr+GCmYYyOKEYSOCL2V8GQMYjc8MFbgjM30Xg9+m0RGG6
ktG5JbMdhx9YbNXwKUqlDg/b6b4ULDGxeFXVKQf66YA64CnLDspn8GJmYL1bCPD2j9eO5Ke1R1fA
2+9B2zo9n19LVJPWJE0SWuD+c2SiAuq78iZpRL+ZZdM0etNs2oOm78ldXa4OdXsztTranYBdljBP
TRrs9FWJXXNzc0wGdp3Y+8TqZ5hDK609FXPcyKRd17wOmQQ4mSbudxnZZtHLAaOKSeCqNuNF+ZMx
B+1fm/YdiIsAaHecAN1dQBqnEHgSRrsEU8zGC58iBG9ORezFYwK2Y1uTYg/HILnCR03bqMUXcJlc
LQv8iOMqwUwiWnMtmlyvcReHTkALlVa4LH306W2geNoJGXax5XnqHVx3s5RFfS4krxsBcu4atHqh
yYJ1huGGfgOrTA8RFj1r+zeniO4z0rjUvq6KImSOrl7Kq//1PrEhdtVz13U7bkXc5Mkmg++Ewp3I
xg8mVDoErv6qeUu7Nol/42+SOvNXiKujHG+uB+kQMbVCeGtP58KBghZYBBCwM/owu14lfhQFO6db
tdB6yDFJolJFOvuja3+F6tExZFq8tTK3Cy4lhEkQ2rPDHJxdQ5DZLBcexbXhSy0nJd5KUYynsvCB
8BqLPRMZzf5anEtz9NruIFENhEU7LRbKn6DSkVgdgKkLqnCdlsJOR+fEmOrIgzQHkvyqwIvCvwKd
ZNrlJ1UWk3kwx75QryTOdGT0L8Ss1VQAQDrDynhq5Qpn70dvqIEGGknsAWsKCioaLtYBWny2YW0G
UpUpyb7KxpzHrTH50EFLYcxOQ4JWfzyeEOvxN8Ybch+gSMDVdo6tdYAVLoOwDaF74L0jsjKiTUIP
qM6k+/j7DzXYVbh/2ax7g5xayWNiklrFrvT0STY5Cme25sfJLr2S8sHGWzQm9Zy6VZsSXLZdTd8s
v+6yNMa/ROKlMovzz7FPk5dxEbqkADXrgiHicXXJ/9Jqy4j4iXFuXIk/buIbc022K/8LBj4v9OMu
GP8pkKCWRqSgpDi6ScDq6O9ppPLY4D04b4Zo3XRcVx1kLdskMaQ61g8rp1UgvxIi+JAEFSWR8ys7
7hDHe1fATKzV4H2rjRw1x6/l5Cc+J+VuIL6gn90lnU0tThdG0a13pfrzqaQfTLrZU7N18OUjJGNQ
6deWmNzapbuIR0QkPfJuhOu+/tGdCs87cc33TgPqlCzxIRMybhvyKOjFvTKv8QexsxQG+7AgE+FB
fL1ofSaQ/NaJqWSCsS5qZtmnsEvym+/f002HYnbwB+HxgwAJDJx6ykhKxhV4Pb0mQP6dt+d1/vT6
+ZzdpQnq38SmfzAhofaUKx9iDgloJ68HaimrNYxhrgs19pr0YbZJPgQUomnr6DS33Fwfp9miy5tM
ndyL52Gg39cZ7suJDrv+mJX64cZlcBj8xoM1cYOj7Rz+ECI/utMO0ms02+cmSqC2fPC6RD5uAO0f
qAqSvaqH/6mb5klpZIb+ZmeeBYKCQxD0oDos2EfaFer6JAGTeyrICt4MpPBmP1P3a5fqXNniFz1o
zUIIIrrGa5UOk2CNT+6hIP8NCtGOPVwR6jJ9RePLE4gdMjYz/7JGPbg7GaRLVGmmTOUiGatLjMZk
JvOBCgI36Njua2lkD/9BCgcVA6DARGfSOoA7VxMEMZPYUjOJmmnpr7RVGlIzyEj8+ed8ES1M7/kA
jwgZrvjZaTerq/4RIE0wHHwaEUxJFvBAjq26/Rs95HHatpqsjU7n5SXH9aizwsPSTN1Vm/V2AqFF
XSMAESAOwv9UNaDhcU3XHeHPpWjUj8bl5yiuFdLDJxmWKGLnVFHfGfMjNYD0TBb8mlhtlPM/vvAt
BHOwieCCzmxEslQBhFBmUa582AR417gn7ZPI+tU+D8+ABpjlrxfaMW4PHxUYkq1y0zw5uRaOBCUR
bhar2MsdOmAoPhvMzoynH9fC/jXc5A+U3sn75UYc7hqYkFAfBStuXVIVJKq2GXCECydpSlPMPYel
PVifGhlyJBf65SsBxG2KSqrLb44k6XLqjN7Z6rnEMMqYMuHZUSa/HI2yrY+Vjm==