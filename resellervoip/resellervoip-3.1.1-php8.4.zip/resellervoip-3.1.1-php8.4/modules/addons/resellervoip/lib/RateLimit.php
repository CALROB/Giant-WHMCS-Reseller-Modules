<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyQvi1wUWWbHOmybFNbStv/djlKmHS0zQfkyWyupS0EReDjvwybdng0XElKmXgNn5KsnsGkd
JM3qFh/JJc7O0dwmmESdcVVicrqwFu/Zw5W6ctmOnxBE5I9I4vDg1J+rsj2qoGzd8SkeUESKPuMV
Hf/z1J4TQJTYLaiT2dNbHbtBo6OG/MAgWMOoj6riE1qYhCuALuDq2skeB+DRdFuhOJAAGJQyEBJL
8YKGrK4LU9IAuh8b/py4FJGrhywSZZHheUQSu3dVjMumA001o2XVdYWmgHjAk8rZPCVLq3Qq9qUn
jBOw08YD7F/EImfR7RuKpOTuMsE3Wcgjc+zbdQ4f6F0rXOjN4LBuCqlcaIrkOZLiMKISis5VyI5u
H0IFzD3Gxx9a/qZI2ZBs9djMs1CUAzDzZ3ry1oUkhQtY2yjQD1zdb2o0D61LaiCBFhINBx1lCkqH
tjqzggrmRUoV4WhVSLWBD671Zn1T0YEQt7g6VXSvbGjs3+UkCJS1340+0ORBkl+jRbJLMz+V8ssm
Wl2S8Bnz+MGzEIpdMrTu3jn24F/krdoATceYR51HqJEGq/6bXnali22IC6AJ1eJVS9d4bSVYpje6
GVszyKOo5eZ5jUzgnwfovCIsSPPANW1oQRYheBomWzEBycLIP6FaRV6Yjzxu7dfO+b5Y+htjuOLu
mNus2KkkROcc/GWkGEFLSxFkSbTaIsPQHfMVI0Lw9sFDxnJ2P9ZbnSUDygt7foonJEoefIkm+36N
Df0wQCcp2dtPRshHKXagt79WQr7bV0cIlZ8Cul4Zj9XHtruBS7Geae9MZVYi8AJSeDBGdkAeBqrZ
V6+Xrd6X2BKlJXtjvDq2pK1Cih5SUmATOzuBxKWKGJ3u2MagK0uaG66bdPzU6WXTdQ4qmYALCHzz
YBCk3evSUFuoeUqV2MVtE8JWIAzWhbA760aTiVIlXEPrVQRhHRv2pVnU3RphIW06CTxo3K+Coo4r
fL5FCCuQCFTdlXrQPbRZaTpv2COapv7kCPRsQEcB1JEvDpbw48r6Mu5ENUPnilb8QTGUReq6UKK0
b+NuC6FZnAbHKr2uC2k2DiQmcQQVKkiSOENY7ymzDh9OuoQXWWlTBxKo1PnmyDPcR9b2knhxTb/V
oa4qywG/r3VQVSNRh1B5LQ6jT7K/dxoyTCeZv5FHQ18Li3uXFGsQTj9aXeuOPS3r9f8DODyuYHgP
ed2zXGr2FKtPuKp+WPWnIqaGsTEqvE2uGrvimSE7td18WC+RBUM6ybQ62qErt1Wz9rNT6zRH6ERx
0aMboTEJ9KSInP3vjpAMz3aR9yZv4Rnoi4+nMVLyxq585oyQnYaVcb7HDfpkC/yVLaL3lL3a28QY
KK2kky54E0h820DsnAztcGUBAy4rIQPUGITVw6CsDk5a4R81xjRM5vcgD9lRxW8J+Tp/neYwLxrW
oPywbN/uxgjXX947IW1RXIxYKM7sTYUqidaWDtcfcaM8WATSSTrGIGD6BAJwkfWjUggQgYNBi5pQ
im7rQ7dyQwqgnFeY7keehzfa8vEKX7aTqB6rgQM3YJAuu873lkkaVFUb8Sb4V4BYQd3ZAEoQOIGH
1T1TDgTVLVK6si0dB7WoAupvAw2Li0E+MWoj4b+5KqMVHsBdDpuIV6FR/1yIFTEZX+jz72FKuw/j
FHwbPbgMtIW61dzd3uS2wDfqedZIEUQhFjyK/5Bj65ICySAXJ5/GCS0U3TQ/hFxTS8ib5HuHOd+T
9WWXCtxHbpiJ4eXUA5Bi5LPh5G93Sw7LOTutvu6MGWGDrJyzcFxmLt5kf4TStyd6nysP4uTId4lN
lQa/kN8GwvvhQCnWaVyxMsgwTHQe3+6UvSKF+jt6a4f+fo9ChHFV9G1xeb53DC7GEv7bi40b+NZ5
gXOAPU+28w6H7fJW45mD3yGETNvpFocUTYCYoCxxBsaLrG6KSFkfrI2BofLFlbvfVc1QZLTy97Yo
13jeQPGHLT6JPtxzOT/7n0MYE0iX5l4/97vdFX/8mkBqct1/6lfaJK5LyYG14QU0frk2+Grax5l4
RU5Ld9sx5fnhwUwQofenBi1T/q76Hby4SfNEdHuiAqsEHXVG27jVp/vpBg62MATWShjwtBeMuNK4
3tsTbSZHv3YOSFo4y13OMcZtxXsQEQX+CIRdmdWHKjbkJe7s1n4wiQt+MyHrsJ0S7U6KknBfljum
i/Zxtz47POqtdPlR2tm39oLU8nH4CdyrytJZXnMKS31N2n4EHT/+KMChCnKGqxfWMz5O1BsrYAMn
cMUDuW4pJjCs4u7hZFCJKNe0uAr8CdOpzK5gG33Stu3iYxmFeeqRXd2wVTEikSnK8r/7Usv18QFL
X0qCELrK3prUC5cHjYQ2371KqXplEGHUE2M6xvXH4+G/Rdpz4lmKU3fHy7mB0XnFHLHmfebXlb5f
LwQSNPLJjpO3phe=