<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnGrWVv90thn48yKtHU3p+FKeoaFv+dH4uwyJRSahS6ZxfhrQbPII9aomdQtjjCFM4nd5OVY
0KSEZwCVYMsxhK/LlWnWL1f/xOBu8MQ7RoofIgLkANWZxpR0JwOnoSuBkG96sHjxCTfJWlpNm3iU
ns32nZ1UehXJ8nh77RMZQIJ7SN38voj2wdfvbp7YryejsscbOukQdgq7Wpa9wI+r8MEBkHHGnUs0
vp1Zkb9u+xbQ+dVljp4i8dcxPrmKkEWr5EMiFMgSI6umA001o2XVdYWmgHjAk8tKPZ3leyNCpjfA
7sXQWOIDAFzLY02Dj2qnKgSHJUPwnOvB+LG0Iimp7wI9vo3tJKWB6AmfjOPBhvxYHUcFKCGLDkDR
qxCL38JcQcTES/bYkS5dUgf6Zb29WHzNqLht18hQgoHNx7rnxozvrizFcP22ompNFbB/vs0ac1ZR
083x2q9yb5N1wUdlGysTkT1/i+DjtUnvtzarrW9uvFV3Flc9uQn1GGijq7b2NirWo2yNykZ8ot1n
/YkR7iKdZwNh2fw6KS0OfoPMiBcwh2eWYol2qARHnCQBlo9dRMD2EwvdElWGvxetgxbCktroAE0E
UUnFBU3fNmDtxZ6jTUcyPbSHtj3FALzo8QBonmIJWvf1RZLVmcOVneRy3xyXdiR9KlBld3Rkl9rL
B999Az2rjHOncC2qQveo8QN0CKw97kF8q6wyOD45qvXzFyr7PO6tv/VK7JvPyH8e2QPfq2elYv9D
kQwpYClUebkvOFJ08F+wdw9s33NqNC/pwUaJWFDX1g5YoDMtwS6bqATCaGStwBkMjPFCUrlLPEii
3sl26GMxQGNj0WfF1KlMfD9aSWkalI07SbPlBkzanFnyCphDJg63dRXQbPUa8RX5f6hQ3S7IvtMX
dM0Gdx1EEyuGsZFSZYN+z9wecL1j2k6rX0m6gAUp60tw/O5ilGB/hy75nVBtcvNXqiSrz3IjUV4f
T3J+FlUjPge8I04E8P9LYFB8mcwZxYEM510PbdIW2mMuBxFbQOwYmOsmFvHnwReDkJUoOSh5YHRb
eTFMNhc8RJBauQ3S2s+7odgL5HgXjKue+qFude6SiKUkhadcPyQx+1N6SJKozTEyvv6fDOfw0vKU
uNjvLBsUgv7/vcgtnFkUHGlt7l9U2rK9W5H5kyQQW/+1fGfRIrgY0NBZc47LAwIjN62g