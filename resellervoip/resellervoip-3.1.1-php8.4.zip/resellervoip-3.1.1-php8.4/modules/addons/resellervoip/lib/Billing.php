<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn+kYxAOTd25OHiUaSj1cu0QgUneNmw8HDHVY/c5FTlrKiTqemJOvHKdgEmRSsVrzpSgszEO
NKnqHB+xV2rUijEkIzaCvNAbVfihOc7DC9fy6osa7Wruj13ETM7U0NucpRXM9309Ks5YQt7qlpC6
DhmDKBhztskM6XNsC+pFFgkH/qp2sulXprBH6OqdPOsXrXSvwIRDcy5qvrFgfRI9Er2IbOo8w5GY
+TQgs6xFYQWeR7rGsPsgI6paoFp+x7mac8KGWqqoeOfoRZ0e0078A5+UA32f6qguZQDhCftF5Gsq
drsLpy82X8rRXPQQ2nNC/IdaxxGw+l0eat5rii0J4T7ppZiSLKoy8H6eIR06aUAlTR3fLXXcWYE1
+wfmqPQzOdyuUfkWlwhr3VBgOpxfNXpWmiZXXzaU0nneKWFD9HXPmwa+XAtJb9xM99VtzGyAaTjf
Qi6KlMPdAOuoDm2ZD0p2VNDg5WtN6BnqBygaoOER+2b2lKlh0OR55eNTXG+e/k5HBy/JQli6Mk6O
/1sQ2lABbXzx3z8jnGfYIBjbhA2/67dXNv0rbK9v5tBdn2r4r/fg53qCYMXRDg4UXA0GZV8vzyTi
28pYnFuSLqAyow7v6WqbRVCHjB+JgmtCtifalZHLNhK4dd7D1dMIan1R8aF/SvBy5nwMxK/Eh7bN
keDAE6dqHGlGlA44+qHzSBo9sBkmaVc2JbapSc7s2e50uKo2WZS/Xkk2ULT2OWyrwX4cIw7uSohd
pqesllL70QVMcFcNu4Jf4GYpopEDDoR4pbqo/KJqXf3S7qevkG2BawNWBEFU+RU2H8kQ+UxW08CI
JvQdmHnp89yLjxfGHk4Gnb9Qd1/i5NdUAqD4qCnpcwnvIK9pY87hpZVFW56Pkga48u6b36WPG7lL
xvz/rpU1o607J/eZiBzOZAC77A/EQvAJf0ixCnC59aixqAVPqmMlaxNIavpColVQRMn3Vk8f+3Yr
3aMOCirKDNzAFVTcDyeNCl+yM3GxMZGYAZhxb490BGQdumU9yYOxQM8o7G/LPxCl8ZEoftBxbJuD
crCqccTJpwqNOfbes1fHb4i1kN9TRx5dK3+sb9UuxMlbnZ3p7Ln2au217GMnt6qOVZiEOHN/6KVf
miFccBVOEUpoUlHbHE/3yVm5L2J07md7145KytRZ6clBMkajWfVbLQYgUPPBC5Frg2vch0dAMAxW
tYu13jb/bpy/0cbgSVEAKHABVLoFchdwOnwLhT2MT1Al5OkCcETnCcOwfFUkqmAErxc4TGU+Rgcw
uPfbr8c5miFqsSdFVsbhqGCdnVUBg59z7Al5d5txkryptziWw4hlzvG0vsnD/u5OSmhxpe9UbJUh
7hABTY8RnQP+R6f8mM18lvxunmyrFM6kMYmSrqyY0J1LgKY2ypw7mA9V6qrGG3jNBEa0nQkGgBxk
gD+cJpDDoee/IIuj7KA0Zhy4VS5UkI7v7suKDnPf5ggx6L73Q7ltZDFl4wBHC2WZ5ZtICz6DjGfb
TX6H/bBzuilVYiwKw4Bv6rplKGNm0rlx1xLEXFYjKPUsAaFh4+Uceli9fVokoo8vJ0k71S8rZxvf
SiBOFvZiztzw9A1qaif1VnkjExXT947SUVfxtZ2D1PltFigZQToNWaJ4tJjn+QFl5OhGE482Navh
BNlk7Bb7p+1Lzum0OpGqzK5Z9cKS+Qp+MDPMwgmQUWy/Z2632DsPEIYn9PSb/EVv0KXYYdZVrkLW
bwzSxr02DjauZ7ULL7T6+4kJqQMA+MAShzzjyQ1uDaGSrq0a+Juo4XfCojzeTYXJgPm5hp46APAh
A3VTWODuDI85Fe3n2v8K9ayFha1fBEgPtqaxz3iO+txUdpbwEt1APbyV/oIov5rzs+R7n3CRg0x+
NAAZcEX2Es4WNOTMGwcjh6X0AFyj+/zekxMiENwJzPZyluTzyd5a0HtXm1R01pe+Y7oiSEc3WK3F
Flr/T3WA0s7QBW67ZanYA7rG2cUe4U2WuwmFsT3fZtMQaYgGUKhVqCXovkoNpFhjMFEnJGHKs5HP
H/LyJ2ldxP8H9F3Xh5sPkpK/RxP3sQtvGm2V7XUHXSzCpNph5D5SO/N8VcBYFHjDaeu157AfTwEu
YZHdjcpylL2O5bugNAq5jFkcdtW=