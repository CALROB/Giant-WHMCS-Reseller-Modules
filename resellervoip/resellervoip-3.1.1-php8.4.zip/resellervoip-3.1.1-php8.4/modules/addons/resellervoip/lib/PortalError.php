<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwjNtl4WlIB6EU5BqfL73y7ABzJITu+cSUgOyldL3g2+JJfGRnB7ifkM7KqAK9+P0Ji6p16f
v++MXrlnd2yYbR0B3TaCHU1ipX451bGJiUOYu9CwnZ29TgbIdUl86i4WFulblTFoNGFEtFBdGVD/
7NtSEEFAq/V1H7CMMPd3uwchO+HHjdKIHgmpYwIToEX6a80AKAEk2mkWKrhAJf01P/hJwpN1azXb
Ue4OOKNy/9ANvqBe1MCR+hengXrsCoKNW69dAme2E90iRZ0e0078A5+UA32f6qguZKjfOi/2EcDR
FHIbHi82YOruPEOziMSblNPsBswLS1cfyFwbrdn775z4I5nKJ+e38Y2hEnhxFhzTBfVgsBUNZbZ4
W/QPmtBxKh6RfMkkib0z/ReJheCDsKnpMf8nW2b7GyXXw+xE3KqYVannbnUPZNgbQtRMNikOtbr/
NqT44tV8zHHNmYjjriQgoBXgeS+m530QUeFb5vJosVe8+7+y5x2bxcpXiAgajy3q3DKgnY5sfWpl
NczgwU72+euYIpudlEDbaoX3vOqvANOa5TRVxsrGF+OG5iij6Z2/Dk5TJ8Oaa3SPw4v2iUE01Diu
Vc5kCMbhcfBn1U9JWPtHMXfiOu6f7WlCaj6te+cJdU1o3b42LQs7N7cKzY3/nF3xhgh8jtKgijsp
XYxYqtjKE6rJktuhwgoshtUS6QeuWALHbSeBOx7aGWtftOlMESDmqNcKSQE5roehdlT+hkG90aIf
R7+tpeTxtiVcTUTYxeE+1dh22kaBdUOR3Wpt0NTpTIWLTUCULwPFJafo3D1BwNSTt0irsUXZ6MJa
ResIpAEswoHakF7Bp3yEFZKBZFhejAXexEJx1KAEqdhHe0dOLUIh0uqcYXUOEtgBB2U0Gryotmdy
raosEvijlgPnTKgdxyQwZ2LDlQmoD4t/mKa2DTu2goM62rdtE6w2/0Y5KcdURgCjSLeXlbahbzQ5
lhOb1Uw21Vfxpa60h1LPHxi5n24aKI7OY1QToqbA0Ycix9vH3jJgv6gkGg4KJfE1XmK3ptgfK1G9
VMqYxCCosmKvmp2zSWf7fEdX/LUXa5iJs8fgXzxRmb2Ef4Ro40nu/fD3JtSHux9GVbN9ulMxE8Z/
jVgwzvHOWp6rXYnjm76kXd+4JiQ0Oh/mxm67yKTaWq/uE7WRSi/mdclsrvSGXqSjsvnUSj7lgf0V
DLxY7S3wlnJLvKqhxMK8aGkP2QjZE8jqVEW9kUh2X589XyugGrBjwtBs3g62GuBQ5XLX2+UeDVUx
BoLYzxS9nIxzFqVyFk6PkTS6dv57beXlOhXORAiSU0Vn0Nh9wnVyHlborHTDlOOc2GRhiHIF6iA1
geQdVPVBVv9o/4pLinzHjj/OHRs03pBjAanE2pMItDswisDvBfFzJqRCpPzoldH5GHd7fldjaMTw
6flUiX8abRmPY1MAJF2GQoM5l4ItoONfxA+0GyicvFhd5vh08iuhx1IKOcQ6CdfxJkuKw5xfzd/N
HA2FoGBGWCdMAUh3xLUVyBehJH9lqQKb5z0WZrXxqWC6UA7TiuYgmB9ldJX/NTFFIfJqBTRIWUI8
ABp2nydu/SqHo4YmD/C/Z4lb0ZcEE8Uz44AGTDvNskAylAfpm7Ne461ClLDwyYYPaEfWdgmjaZAf
R8o8+NI7pXySip5B180d+wXwaL3kutqB8K3/O0xM+siZHCTmv9AgHDonosTnKSnKd52v6VLI6+rX
g4ihLlE+p1QVNlDh2befc22W5QJ0D5VGndRCImmZfc6wQ2ZCtd7s0tshguIAV6i5hgUC/i+1Osau
f/LcAPmblM7dRQKnwJPCLwfb2XeMzJkFN8HMCP/XmSHZ+ygiXbJfdfk/JRy67TMUFVDWh4CxXllX
urUAvZP8MlEUnUrRhleNdntS1iJcfgWZh7Wcrkp596aYaEHMBo6Ck4ltWKLg8YBB0LLn4kNkZsri
9LfvvoRe3c0ZQfN42i+ZlRBEd1yAbB5BRbh3z8XJwwEmgwqG92UX3xmtwmdE8jHZNT9dK2xM5aHz
g0rwrp7pJi3DUQ+kRaOS+mWXXF3x9vgQ1wulfHeUvQ1fREIe+vY4kV9wZ+wJuTr/n30MY6hTnR/C
+S+gxw7lK6iSVfO88HjfY9BJ2/WgQUVyE8mqy3JWRIK5O8n4tvObcco1UnnCKmFy6/UdUZPplWLR
h41/lV4vruD7Jpz7yWmr+Rkf4B5FXDXO3XEESW5Lsl55cMnlBigJ7r2klzft6MhbioSz6bre9srt
jvP7VlXnNfnYMotIyNSIXXAFuD98kenlooE6XirEl3Db4OJpf4aZuNrWTqtrsiaAOVfQD63gYEgR
fLeD0QSIOGWpJOzEDiIW4B5x3/FP