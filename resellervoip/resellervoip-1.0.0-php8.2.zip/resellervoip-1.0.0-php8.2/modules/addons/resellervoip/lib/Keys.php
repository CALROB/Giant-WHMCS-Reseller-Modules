<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv9ezcwoiyf1JzvZJQYGw4cygjehB1X5BvYy+5S68CI33T+U6/DpmfqV6S2uE9U8Fi3cqZqP
+btGdHBU5J03YSuPV+f3jHy6VMP4Lcoysb59llGNyTL7X00qgAeGapAw36pjEqSZOrhumHQla7Ce
pn0O+pzo2WZUio7Vbs+5C61x0J2rjub/yc+TwqnXwdCkyw2bmXoduf8c6lzF8gMPGfEKdGAKICfv
VQ30AEwyxsdDdMIPmaEW57F8dxifOf9DTTnsjEpk4+BtFf723mCYfHx7+jisiu6SQem6yKd5zCo6
3wp2VISjGeBN3fQV9zYCXMdtOD6Ncksk8fBwIz92MpIjwkWaeWHrfcIDbrXoSPM+hbYy0MAMMEFJ
uEZE6gQwJGeJs2oQr4CsC/Eruj33L1YulpE8OXr+NWiJj483lAiUuPabHYwHhIedSoPIcy40t52W
5lEgiCbH7dQxwpblAWEKdE0r8ntnmYkvWayEVAtsBNdc4HArzi3pSmVeoJMY/751T/N1Fzu5VoDc
ntuAmUpdnbrpmOPUPdjOeLPbnAh5BdVRdfqhuqATjineZphJ2mQ1DjMUjCzOihWlXXczKh4ZJGru
0w6gzIYn3hhiPhGjchdALuA2i5PduyxYcOAmpZYsBzqHgQyA9zr0/rADIiw6TNfhR/kpPySeEonx
Z9XPYS5hxlVui4VMqSTM0HgUQM72pYjzH/t+ajPymZCki+il0z68RYiiZLD0DJl/pIrXlX5ykjzL
WE6tqwrjXAY7xNcGCUxKPcBGQ2PMpUCzrdY2PH+e+VjennSWMNUmT6hApk7XwzCn6V33l36m+yha
42brHrMivflKDcRGsEhiwUGWBg1uJCiEsdrRTfH+GCWwyxnWSBRYoHt7raC6ng4VKfggODCEqVaU
cELuAvKfhu3GlMBBVozO3m/yiKL1y+OAVOQibdh9V0xgOflk+Cn1u8fE4UwU1Lk2Vg1MGWEYc4uw
E2nzbO2bzPrhR1veDz4WpkmI4Ng5npethBMcH+DYk5iJkuZbe+DupfvBCaKoMN9aI8Dzx0zHD6Bm
t2BHGVV2CiWBA15vDBhntJcaKQ1N78YSkVHbWfkZV9F6pouYxQDPIiKGr6VIlbQx7RcCD+lMk/4R
N/cUidMM852aHkKrIpOkWSouGQ6T5ovjgzeFGrNscpJjktYrPHF7f7YjtOPJ9HzOQ385Sw+Jl5oj
inbooleZecZuPHRUZOUMcPEEJ1omZiK4qEYpQA07rtIpbph7+9WwBldLer2ax6BJGRcPvjvTHyav
byXXOfZUgeMHFXX1CvZEnZhG4oM0rjBaLQMQkhJ6mUKTRfZ6qbLj4Pr8MVyLlNo3Hje47JaoaWRu
Mwrn97ZBkEXV2LnFUlCLkp3A1VjsyRFU9+UGvtOOrH/UUwWC4bQHjk6+wvMsFSF8QSifay685GoU
tRTaR51FL6QS1lPQdn8fiubDcAF3HY4cNOlWG5s/9wVmUieeSsUhGlENmB3/wuhCqXutU30O4xkJ
pyVhOFIYZ5Y6ceiVl27wPF1tn78JIF3Zbghfm85Q/GqUAe7ym+f/3abWmzr5P8NGeR1ukXcW0mMb
q5sjXIceowo1JhBUwNMjrZjah8KqhU8EYyDljUA4K7MiEQ/7N8jxs9EIi7MA8fqjqJiF1hwf3dHq
IHyqI63Eb/jLXj5VyCTd/sE1AYcRSyBK1AKaDgQa/nmFktm3zF1muhOPSXPvaOG/mFF7lXREgEiD
64KgkVDbuq0o5QpKbpxIcXMZ5d8I8oPfDDfINmWwoEClwDOxVdguAfxNMuTdirgl31KahI95Q8Pu
yfYUY6HXoxlhbJ6dX8i8uAs/1t5A10VK4ZjTsl/z+ucg4PpupAXrT7xPN2/4Gu5eNfoP3zb1RL40
GMtPzEUYKBKdNqLDd4bqGt7tdw1XQ3sC6/g5/x1TjRMNbTXzRitI7h/sOzsJS4KbRf1zvEQm2p1t
+hMsk+LnMn5+oX346a7A2r6o8HwYCrCc0T0APJ4Sh6OAwaMZ1y5Po8zf5Mbo1XZkrq1+JEfllTWa
lHcrBNYi7kTChnf6hHaBHiS5gJBOX3QnwZHy/xsp/G5O+XRv8moDEV7Mzc4zITfodVoGTTXgfQXq
2uwjjw0CM4Jol9DcSJJa8p6zuZ5YIKcTnMMVzjCCRrd/K1vTsW1nqwrvmsDtYQH6GBp5Z5ZOqi9x
Sh5uY7/EXzCCo0oC+RaD6+kVUUp8JeZW1SUMZ8LcmKBFdsnCY+iiu8tiNFABkZu+DoqQBQPe+IYa
/u/q90K=