<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwFWae7PD6Use5e7ehvUCuHPR5+J5+U+AFCj0ip0uO+Ftcjkbj2hNe7gbdLKpKLGFu5ue2Te
7FCIoHdu4Oa1r2AWqfxmUIdzxGIwS0Vfl8cVyEVqx9kWv8qDLO4iDm81yr1VCtnS3rXD4r3QLWod
d8dvq7sKfeReBI/fpSu3CaX4ctzgvRRdc8MTyilmVqeaEbW7lGzC6cZFoQlkq1yWjBerLBoIfx3f
SrPRZrcvLDIqaG0825d8aiLVNRWaIVWp3hNXvEJNZW3SulS+aS8F0oAb7iVwspQpWPLk/ylMjH6M
qGtu2SBz92rS/rHQ2TiZwjsBKeW9/6qDq2vI1Tm6nsxJvM0Rhr9uokFLSmQLH2bJ4gQadspCdWUy
rJvizgzLUncYaAbxJKnF3BU6ARf8iRIkWPauEXDMXkHcMPCw9nT/GVMry13g5O+rKeYu81FlaAPM
ySCnMXxw9JlQuSSvYmPR+uZo/zExeH5jjFUozAjc+KTBlMZtlI6rTZqRvpZN4CTNBtHz/vrz82/I
9hSQNxr3q6KGB8pjaa5s/QoPsFvUaIjoiHkd/AzutSNy44sJa0uRiim9ginpy5RTKyq6BbZ4lFjf
1yBSu0Cuq2mXixG7ZRFVKJWzWxVq3A38PMxWHn1biaINkzX+nZB/PI290lhZ30UamdzZGqYZZUKj
SRfSg2L5bMqipAtT0hH6eMR2eu9zY87prc7kCyGQOsRyHk4XKr4NzDuihJJZjEdmwIUUGD2DEcu/
FkDoTZ3MQQYHevQtuHY1QChzNYtn59usvul5vXFKuAyGlVIBYyBcfFKcX44rnuI+cvYVVuoEj9oB
iiL1xKp50F8/mQLVh997YPrR9jFmKR0VXSBVzqu6HuGt0DZOJpFk0kkyFYafdCuRh4RGsz55cHMs
WRNBIyiBAkQnjio5FMoOtwNeAzDfBWO2Na0oJ/OUc6F5W3QzHZy4aHyBXjNP4WAIMgnKHnMtELcb
mnqLFT9fo9iP0fYS9AWzVXE5hbWDDJEwaP9aZ167ObjBW8ea8zqYQOMPZfBhLRURcQK1UWQUBOrN
zroi83Bhx/gpCH2Oo1gRI1PrdXypHz0xWcB4JLBsqnU+rcVnREvoYCXaVsu2zVfm7uS8t7UqSg/7
qx8BuvQCKrbJdafKLVgMWp1N4Ivp5aFllANgzTdyFzODgRfdEitMIHhowYZyyMxXzRk0KddG