<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuV2cUW8AsBFqNSComebCNpKuFBxOVhrEAUyfFStVUUE0IYazZLTVKhE5Jks2yS6Z7lsLtv8
iDwOZcxn+XQFWKvmqVYj1d1NRHiL6QC2Pm/KVRlZgznnRW/BhakGE1qH4c65JJURPXvZYgCD5Qbv
DdmUSW9ZVU6E+70AyhQPTlcknrxm82QzSLT602T93+4faYamoxwt5IIYKu/95GlQmvBK8iyQ908Z
nVSmKI8NuMwG0WPXHVGVumYtng6YbwLZqf1Iph6cJ+BtFf723mCYfHx7+jisiu4dPf2Tdbs3frft
mot2/ICj2F/u5YBQQiwu79H7+wqhGvvcA33ldDtV5xsYQMg1rSyroZjHHFd3t9RGk84qw3A6UGVR
uZfn6Oj12IfMG76ArBFSSGEANwuXivwLDXVW6RQBgtesmXN/wpELo3tw0A6uK0eGBwvoXOwFeDzl
ZXHJ6+pLKUK+0bwHKrNjOlfGvuUylsrohGjjt/P6Qa6KCudhge2bFjVJ4e0uJNgNjctDttubcBPu
Kx16wBr7IZrkZXLi0aaxkCKAU++43w6Ynr9p8MDlsE4fVvWcEWGpt+mztCLovkCNrPuuJ2sp3JOA
uDNfVBSWHdn+dZ2qbp80Wf6kBB3dsLkFVNxOlxC4auzUZnLb//CxKhcM+yTDb4Ehvbigi/4xe9gk
9weEm31pIe+S7e2QVozdlMShbaObP9cI664X4jGJ2Ooed0Inz7HAlC8Yuy5O51tliCilHbubW1Un
I5sMeG5uhAitCnly8U+qia6RYb3yKxLQvi0Okyt41Y+neYHYt7gjxDrwucImT3ySLmmpZuY8zY1Q
g11n2DzHE81F04BOIPBycRPQQZI0iNEMgOf+06jE1RQe2vz960OgKugJYGotCWIvKAfaPw5cvKii
7Ij8ueqdFloAgD0hkxs0/+vOxQMq4BRqCyRoQml9QCLNDm9ci/w9HFYjq6Xbf55lZ1VgQ9dxAl+0
Her1xvEcd1//69pbcoWZj7WocuFjzZQn/nLZZEji3jchOv/wNd7PABTvbub2vs6nSYIjhCwWRI6Z
xlaXG8SidMPYB0wwsdGmtpI470vg92h7BAjmGjr5w8ob3fngESPsYNcqYR0MvuYh3NUVSKHjz/aj
2Z3hlIm6Hu2kCHsvUk5Au5BKYZ/sPS0OiubOO4EBr/SFVQq1w1ZZVxHiqrW51v8XfhyOycw2fdJv
TRnjUDMz867uzISXnuBPZuI0JZ7OD36nh7jOSIgp52v7HM9m/AoTtM371GqAH226cEkDQkD+W5QC
AlinfuRIRX8BeQ0wIstGszjDfkgENAgCbOrcIDlLrZvmT0+mJa7UTWxOqnRcXZbQXqt8/JlOjbwf
tGDSO/M01DovBRbeNcGCGJD7FP5lldRY/RCUK6KL+9OcPwo/9pZxgBRXQTcOtOutKBsZXsOlww9j
KYo7pqzRuDE3YrRVN80u2QnjxXflSMVan0QT6s3lVMfGDE7QNv5L25OnONOHQM+xTNkW/UQUf8Ik
GQxdJn4UIzZj+NJtEqDG6DxkZSds4mMXMQeZDoujKM/URoQVhIygbDtZeNuSx/rZ2waw9WOu7L/5
OBiNrB5VLWX4bJ/H96R3vX7PzFJ3Jzhwo/bpoLKBym/9x8ERkToewwMUuH0AJH/RWC7PzaSqXz7t
jQ/GHJQoOU7XWj5U4Z0jVGc/2NLqLBZy6lX+fLXSRfvuQkm6raZFCO55q3EnLQv+lnycMLAlc1l0
N9rXHLvlUb7eqRjOSzPX02Wcyju9isug9qotXcIAXOdnuy27GanC1u0aQU4H2blkeQzSpJa6Nx10
aU0Zc3LVSYb9kWe5M17COpJuLLYodaimlxYbES0diyXkfl9WIfkJOSLQT8g3hl1vAtM0Y+9fE0bx
gt5NEM8j1TXi6f63WnRC+SO9VbXpl+1iKh9sErAxAjKRDCuvvUiT/dsN8uJTZNPH1vEOuMDEZWbN
gx5uJCuZyz0E+VW5lMwr4Uxv+c1Rhiibj0pjKeG2wVrRoQqKP7J7A5T//IueQ+JuhH+G6LX/Vv19
JwGteggAvYGECMr9ZlDkgx7KxT0lKw69B8CeFuuLJX0zBAvpisVw3qPJU4WQ6qOnecMPrXy=