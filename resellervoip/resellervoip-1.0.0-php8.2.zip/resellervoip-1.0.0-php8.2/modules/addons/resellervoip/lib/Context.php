<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw/REIIlFO8Bic6i1wUZhxGYnh5AOk3slgMyDo/9FK7x1v+dtYbLDnEfwcSB8Eh0T+esEfry
loEEjvBULWkSfz9PeCT9K3qK4XkEOSWeG4FTHvGDf4jpYVI3UP4Y9DGNNfbayqnde2A4rlvwpZsD
TWq/h8aMKtLFrbnKJ5w6LaTC6Df3V03HyB7iGyymSEdZWmHNQPn1nzf90PizUUcDavmkCLizoSuo
VbVZCDOq+EiZSyyZiQ8ATfA1g9FndjKv8jHOVskMaEBtFf723mCYfHx7+jisiu7/rsYnJ95HTwhh
5Yd2VISjL/+NJqNSHURQy01BpeI8tbDsl+bO0QioZ7trDmB/ur11QZymPyeUReE4nbhHNzU1UOst
kRWtjp2bDcar/lijOje6OxiSN0fmhaICvMCu2mh3tWioxW3yvPmu2qxLHvWuNUr3YBnE1x4pe+a8
Dz9R8thpp/NZmVbiq4D7ly9zNdtrgMhaMt+JputvxLBssSGW/oSbB51owpGgELHfCm66AJK2YcmX
xakPBkNikcT4dzT2N51zcdPf5I7gIgFkdpD6z1FEQlsZqyAyftx5jAcrug3mErhjy+6PpRha6BNK
PZeLseufyLgX/79Z+qiItzAdwZ4QEAwx3zPOLm+doOwP2GnEwI/85NMR93D4xPx6z82FsCHTKC0G
sQpVnkOwoxMYJu5qGW2jKDmO35aBOxKcafWPLwCfYR117d5hlYIhSOaZyBN0VWBWF/F3CCM3lIYY
nOYBNJumiVTT0PMDkgim6LAFmkIosquAEAsaxU+c/kWPUT05GkcNYHYxR5TtBbR1HRWf+w6Jxx7K
czT1BVYxU+06AyEzqRYx2pfWbYK/VeMSbFPO49CIl6jnRN2mJ5UuEXA054vhTuk+cGuEdcth358Z
B9ZJlOg1sUEFSnkAO0FocdttYv8ZtsOrKh8QVn6d3ERwUWrNGWhXyBxMZk1o5GwBWiSFHvpCKh9S
NnbOBwtGHyPC7MjzcpVjSSGLO5fSIO7skO3+uACBLLuknvBvDc4llcL7QMpW0Y5sB8ZJviSv9U0/
W45voTkY1BQh1UOvGFSAXL5vZxI+u1y7WOQBDZSMgdUAbZWAUvEKyk4VR1uiRNqGTfpqpX6v7QZH
rNj4HJvaJkcu2OxPHvKsIrZXnObWYdscuK4BY0==