<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPncRuiv3OTVX7YrtxTlUo7Es9GeWSBBjqPMyglO2dQE+sIw6Vz33YCSZOWw8eoa6jr3VdA4h
FpZOWBa0nYWJt/AYNIi2ff7ij7EHBMnPwq7QP96Hy9pB9NBJ76dG8zXDLipPBffM+MH/IVbPnN9v
mPM60dxO7aUwCUeDQjkNK6wzJGFK0SqH02KJOAs1G4tnbHUgiY8YhUjeUTQ3A9cKcFFJrBlz8Urc
quvvbRJkSjiPNVWGhA0XbcjvCBXTVdF4MsoqbySKY+BtFf723mCYfHx7+jisiu5sRkwXpV8hdtFb
3Fd2VICjU/2QRz3MqscgvFiJ9Co+zPYFdV88c5NREAf/pz5OgFp4JuBoZupt/38u8W0m36+qoy9Z
Ho7m1pdN6WDwgtjvrW2wd7oNoNVOC4fkXwX/I/gvyM7iVv0rZiNozqSJLIwl5YZ+eYSKlwLkjjeL
E/zlp/8xFe6UtpBW997XvrxTiNyKPAXiv3qOTtqtgL+FPaMsWUjtsubH3FPLE3+uB+uG4ujWxXjm
Sf649uXk/cX8U1pp1VQAnxUbR4NPXSMCVO0gvkWI+jjFx2/6LsKUO2QeVp2fuJ31GObS89KGY1Ju
xX3AFfeoyapzEOdEAQLRo4MfgTQRFsmEiNtwGcIVV0BMUbtQeAS/VopJvysWcSicppkMRNjvfhrA
oUuGLp1EIO1To2gfwp845qQeHl7g1UYlD9FHJbI37mo3AZvuakc/YdC66Zkltw1bWSJPjp+QObkb
UhB6NgTLNBov+49QwXw49W80Q6zi83wX98+9RnSwjIYzzm+Br1eqtdcqbmne+1UW38+ZWdoVQsf/
JmoS6U/UIvPF+t8D4+/8r6/h7pS0qKJ6yGPihvCWk3BKqizc1JRP6BRgAc0dSI1wU+Al6cdRi3h6
jX+D+IwikJcF4XmejmR/MHt+eNtDckOtkJsRhZFF2f5zrDTrB2JvMvTWPfHrNThvfswWPwEVsbsl
AqgVuNn5SC46vmahIZvlBX9//j8Cy/dLsADgqJg74JAZnnyUyB3egwR0ApN5ze17lM+8FoJhdTaO
3NxL0tra4JCUnlAwMEPN0KmUNj+yfjeKcrfrGp0J/stSsis4IrrhTuG835XXnl3eK1roDZ4aaX1E
6S09mJypbzR46sQZdia723Yl5Uf7k9x7XwuhB5N1n/gktA3SaaHqXJuaINYBxU3is+oDhKJhQp4M
mu785jnJ3EpLI3RMBTuVYwTOJ7BVADDLggX3ueRLcexxAQC71Dpae7NAR7gDn2hgVylnzdoegH7V
agq9DGod8E/Lrrr3bZeGzfCqpWuLuzJtCtValCck3QE6Ff4SfasOYbqCU8tCa1xwEUrIve1vP/+u
kHWMzsduDQYMp5r1JBJ8veV0BblLQ2qMcm2+uzK/BZNuKks7rIaQttbp7kCQOqpBjMTvvzbsouqG
NZwdf3HHK/ZEJ90ZKdYaGBCZarVQD5YualSD0k68JlZTrVe2/rFiVj3er+0Sd6uHMMzYV0/k5DM2
3dFpI8oIfQNgxw1cSro5vp7XX+6Is0804UOsAGByoqS5UPz/AxTlCjxMxzwTKjs8ItGwyLcODRhb
mWjMi5r+3v3hjwSRzgB24iGNrbI7bpbKLvjdq5z8ERoCTSlx9Bgv/bL4gt1d+Kdvxid3DEBJMb0q
mhUphzG09SeUOB4faS5zWNBxeyFrFgB68Xms68MLiUXsLQpVMKaXWtve59Pg7j1HeVu5UfONSePT
xlASR4FOzW8PFLhiE9COuMLwNE+/QclEfMZCDcKFKad/U2EKPJAZS6fsJ4JLo9mkkthY02bpaK3Q
YRNdWSUsSnUx4JDDQcn96t757T/aMZO+zYHQSn4WoCgopG2yNexosiQJEmqgrzbzqQa7yes3lOVG
H85kcbgMTAfC3TdnhBtOiXpL2v9e9LzyFbkQg+jgoFN2cI5/noApq0XFOByjNNKsJEop8mkyU1iU
qcscz+eHSYEILiKeuFK7ADaHzGpxhst9sRIn//zrMT7tuN9ki81smKYSgQBrAw38QyXshScXguJh
N+R93K7/Op/Rp25EdqwOPa23NxpbMVzWp8ATXbfgsDZeNW7hyHed2vM9Qv4sAas5m58FVaBwmEtv
x1EGVPhljIDbcBZUbccnWDluTm8c5mS2GeIVPp+RVO405R+6ZhgzooY85kn+himoQOuonIybsuXq
vauD3EfIUFhOS9Ni+pEDjmz91XWlJmJrLVD8NkWuDJLCyo3oEl6xGMw/Ua/4b7Ro2slgQuVNLfPR
Vh4h9gXdaW+zELVqE9QCzo0iZ4PElRCxn1xPluTmLHoL29eHu5yuJtFJyt28c0zoBZdSxhES8qiV
Y/xF5pl/M2m0ZEwC8zw8q3DOCh5vD+sXysDiAt0KCqZcK2IA0QUiu+aMc4ctye5PRZhJblztV6hS
qf24qy//++IPmuv0d72GAIfIzSxbo8OQbHtqw1R8GGidqfk+EusBqIxIoPY8w0fuYWmbHG1pYjzk
ia8VnY6fdcHy/q9YnWpV+BLq3bFekQ7EKQubtXW1NJIIhz69NMi7hvD9JRwfMfmA