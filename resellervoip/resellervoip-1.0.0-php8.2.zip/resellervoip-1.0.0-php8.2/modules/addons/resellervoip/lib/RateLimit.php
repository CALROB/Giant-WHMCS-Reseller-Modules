<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+DqXSYct7tlky8GwyS+mNW89ol3phTIDyQgiP0WZh876K2PdvOKonnaGOmARN2YaHD202Me
WVkOz05Wr6x9jPCRXJ/ER2SPxaId5RW6nFw0kiluULl5XrYVfLKMp/PJ5t0M2/M94CQfkX0B/O6k
hjoVkcp4N6jH1eTCmvYEhTVOmo9Zk1X+e+DVI0ZI+QgRWocF++ErGu1fvCUXHhT8MPuxvTddFRcZ
z/19aa9EvYq07jaWZvqJzHDogbclQT0MOeht6jYt4UhYzpwHmWy38gKUn/hRDhE1qsvpIrsOcE9h
re2bmlqXBLt/qmfjhl+j4WnEqnaCdenFzoB4PnstMqNAingFnXGf2XJAl5U0uqoFFXksga5hQs6O
cMcd0zhCeItoiO7wbyYX3HcTdhHlEmUGkSjy7HVQt9AB398RwwVfc8i+QgaRncu7PHf3W5WIUbpk
iUZpndIlR0DbW9JFwQ57qdFksc+0sj/xvLS0ucpqao2J10wIX4ej98S+Z/b7fml0CZ8xr355MD1i
9Icsxj0DjDqnZw/DgmHlYvFedsoBPT1iRZQNes1NrPQuSzWMcwkPiynGeUHFamNGs7w8CbuOavbC
vfnpEubtZl8zFMRvXeiJ9mjre2IIR2WznHp4fkZuU8IpvGoFQm5vYtS53ANw+w5kdv4LkpFAPuMC
8sWHb4lo4Y1poKz9q4Xm7nZUYpdl/FKGU2cRzFS2ltRBqlHQcPpeHXCcZ8VHFO0+DoD+LCmfXeAh
V/WCFxJZYwD/0WMas5GS/7ZgLhF+RWxe4WSlZI/zVokrlti/WWG9/iwpPF/55NWL5eE+M8Um7ARM
+4DRwlf2rxUldRlFGS0gILkHLeMr7friSwM2AADVINvu11iVh0b270z/2C+eUB5hlz4UdNvfZIoF
3P2uVO3GnJId0MFdkHk48OLHsoIst0cWHxnHWnHd2tI6x1Ow+kDqExo4p1cDJEWcxI5KiYA9DDTW
mBwqEz+cUK8aXeiKmFY/lG4I/r56klG+0qoR4M4vPTLbbnsfAzaqRJZ+Y0rHohj2QQdxyZIh/4ys
ER6+A6oDuSJV2xIHjatTZcPWRBjwr75kJ6FB5GS3CKTC6zdzWxMbaDFOfhLn4ARrAdZBDo+GUcHL
v27sSZNQRDHTV1QpWFtJbLevnadjVz2dQrp4g8Z6jPNARWCP4dfnS0SnfP+RBFO9XRKhgrvJIOIg
HUXXZiXToyk9c9+5twca0n3CDN+wQyXJ/eqDMrDumkmQbU8i9JPAPMwG2jt5r0E65rJ8ZKnqu0y1
lGYjADpRNBwuyFOjCYoMxnAHqDvyQ58FEjXMQcv53QxVEYmpq3DQUgJK5lOSLNGdmClgoIp4c7Sl
06p6LSKcvmSMbYhwkiIwvPv+OYaHVbCNv4whUDzAbFLH6ptiJPmPrOSjzJeHbEkAk9d0WizuB468
ybT5fv7O8JSLsERPzekvBOQjSwQfCDZWWHXaNqIZ+uJIDOWQYLAb2PHpA3AH7+dJW+UTxiLyz72Y
r/KsRIxBWMLA61z+syzKBkqlG9A0M3CkWaKGbv5CijVcbOef0M8Fz/2agBxM4x7tAvhFQNttOvzp
r8hvO44FWB2psSp/HoYHoDwtqu6zN1T0djJ7TkpKsUtaPIpAN9Mv90I85T6qz5y9CYfo5qUlpBQ0
FuXj5SKceMzb+nE85S92pQTAXI7sl87U3GVBwekBreSG0Fz749NLKwKH5ezH76/F8vVuhnyXS/7E
mdWnnbOR4jQvg9Q/0tPqAAd1+N0zGGp7ruHrIif2hS344z9FAigPEnO0XBkNX71DC/fepcA3ItXE
c93WGrLSt+CH/wXVKvdJnHiMXApe8Cy6eqNqUcbq2EkcBMOkGItN7s5A1AbV+8ab6u2+6oN2Zx/x
+YrSuQ0B8/NXG/PXiLjNZTcIoJLP3Aht12m6QdzZ2j64GC0aHvB+0bI5biR2KP+9qsLtiR4gfGTV
0ItvnLSitOvGORnKSQqxqmeSaCRCUTWULMcg2rL5LV2xtFOa33TWU6q2LBU6sscYAYlBIobiWbut
B4U9Svnk1SWviMC8ZfzrDcwDlfgbe0tecY7ysYCWssv1teRobfPdeuJVBblcOR4drDbwmUCqub7A
XVX/I8TY6tsOcCepafNvKxqI6L5eHFvfgdpvU8tW7itfp7WbUEvdbkur+3zoS1yaCWIz9WVozrsH
4lbS0fZrTJMxbvEJpXLTryiq7Yy54Pcp8MNb5YE7r3RtxJL7zvGSLv0azCMSJR+jAQODYz9pc8b+
PAecR8bIkYkBnk/6LLEcHaklr4rg/H4R7uOvDVLsEZ/Yob3l/nrKqdk6M2A97yG8vUaeiK/TV2u8
cTHskHkGe6++VANLxkM0k4wXICSWOiY6BsP4MLZ8RF8GuRgJPd44uBYx0c8TuFUnu3M40sNcJAel
Vm/XUWrCUr58xIYaTS9N7GYhGXbsb0==