<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.2. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx62ITM2QR8QNpJSzYyPUIfSjrg7+T18p9YyKTBpTOdNLxC3hFtnaZD7D/PKC76Pfm4VZ8Rt
lhXUZmJUFud9i/6XsCCYec5jWJMrxtaPmT5svN6Qhf9sQhTMbpzMQe6j0QZLQzafZHtqfedgz2aZ
uxx0cEBqY/2Gjm5lGcSFDxOu9YBxV+dVl1pVNAcXXeUvyD+CzG6AO334Ba3aN8CfcU+n8/vS2Bxt
5JId9CSOqcwrvA91BH92Ko5GADTrHqoXaguauYSvNEBtFf723mCYfHx7+jisiu52R+lRbZDB1pGl
0LR2/ISjK4PNc80Wkol+1O34WIxKPK2eOOQ+/CPfBoUI7R/nxdNMvEhoi0ECQnBvaKqLg9zHwB6Q
wQYl0+Ukgr3aFiTKrP4DBk7Q55u/aD1hXpehM4ZnDWDh3XvnpVua7IWkpmnTg3WZhRbcYO4+QGGn
Dv2L8S1ovK+eQnfkr02T4CE5ilCRDkpBGQf6HzxMo9DzmArl2pFvKAZN+IWxoP430UZUUeHhEdL5
qwZ5xH5DMaewokWhSdOoMhJzCJULO/Ar1P6CWV3CQaBrMxBwslzjSnWutbzQPOjz1Z1xKSNVp6Bg
u292gRSbjCKpi75AWVj1kgp/llRDwsL/aJjkmS3qFavN2TLJyPzx8NWWmgHA84rcwwFjEaDDyX2G
yM9y7jlWcSOTb6nejq56JZvVg+hzyBoD9NMpmExgc04/YgdLuwyT+lgR1W8RtJZk7GxRXTPnhAI9
Nf1lhZlTjXAiNZITt0qMFcq695Vsqvd7llzqTTOUmSLDs19ror51scfOPji3/v6KCFqTwwSwwExm
+6Lk0eHoFmm4jo/NGSfQvdemwmYaLyQY+HiRSn6dxD08RHNb2/LyqX+bbkzHZGY+vdaSGuoNjCpH
q7r5jQRoJARlWDfIErVvgrTpMJN/7NAO5ClRuZeuTI4QfzLSPHzSU0wPOsb22vJVOA0gUdbihcjE
4l52Nq3dt+5g3Q7wJRa5TG4N9VyFCdgvZH9t5K0wbWEW5OqVV465fI15x8MnrYu2QgZmSrdhHbQ0
NCr1X5lNVDc4Lr7eyVf6RQtkEV/gdK1YOyIInuStgFsmvNvwlnQz/ockq2zy647BU1gFO9qpixZe
JOiv7suKj9RFdGEuhh4//TceQ9++v0dFmiIZJd+RK1ry0hjqeDekh8XLhcNfNEhjNFJCqxw3HGit
mSYZvYS3CkSgIVoJ7A+w1Gc3QgasdqIpy4QgqeIPCDgpCGnxP9rImKv1gCZjKJHB3ieBOXWtVboU
CuJtsUxeLb33abB/ENK0N04PyVJcEYY8LAwslBpPxjOSo3QXqtAqdf0/Sn1lZnOij3k9srR5EioR
ZjqoYI2ZVP5k7NAV/aGP3IbdjER6rsK0auBnmqjIaJYS3or1mHMWUcFGn7kiJdoRRSoMyRkN/+bu
1QPgfhpnelwYkVN4iOUKAyB1mrmqnyMILkUMmlOYrCFZQMkoJF5CJIrFhENh2yysjyyIbp8tym/w
IH8/fcZKeWFv5KZmDscc6rWEfzn28Xf+kx+Lv+Qg1dhkoAE8xPpicOBYvpkc80yviiYYEPshz/tU
ouoFAahyArZ/wmIzfyjqaTz76n58UJbHXf51q/cX84EO+0SKS4xxPuWmctZLac6k9dQmoNVztDGl
bp2RhJleQWULcQejx64dwt1mDU9NvJt/1mEDkicP/yu7au2p/trdszo4vkPpSUZbztrVp4kP/Ki/
jq+Cx5rgzC+v8Wvq6mSf1AL7OUHY7YiJoXgvaA6IMoAfhahqMPgULuItXRt9ehIURuRfRFaCccAe
QuRqBqk54jqdb9QCud+I0ruTl/jrtMxBHcJv54xSlS1SCHxGJwD7kWr8HBGxXpzvucJvHkXbzSD5
ayMBa4JMfmJ1Uao6nYtIG3bYPifZZvxd9NpKy39vtu9e0gxwQXtjAJb0xNUN8qy+NR8XxuFm8FGG
fdFYqLQgTjK3LArkR9HvM1wJEtiUE0UGXP01xGcX7hhUWF0XPRxlCRs3Bdb50RQM3Uj/1Ww6lb16
clC5AL8iRtwSluR14XhrLzFpmC6p6NJYsnCFN/Evo15JFtVcQSssqP95DWQSk0y3tHIMu0QY+hmf
G8RB9pRfwc3Krrp5U8tSfYziIM8Y4pyQeGMZtYuwqxxiye2awJ7d8IV4bPBYbe+bjr7mIYl1p9FA
Oj4agDqH4HHTxy2bjn4d2V3QP7zoiIWw5gOKuw8/JX/5wH1H5z/pnnw02Qq2WVVFXKx2kiNacZ1D
Nq5lLSBSHMfFmWKsxsfBP7EffwNYW2oknzW/RqpcVN/cd1jDu0KSRJcAT7vpjsi8gYO=