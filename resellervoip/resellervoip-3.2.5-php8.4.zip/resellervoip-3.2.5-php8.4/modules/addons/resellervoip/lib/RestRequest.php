<?php //0032b
// Giant Reseller Phone System addon 3.2.5 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzOMBRdivfM+xQoucgjlRWiZ3XzZzUqnfxIyKwuFScoKZpIDk/FYyeIuSEeHbK7VytzC1Mx+
me+x5ATUSOpD03V99mIhV5hutltXpz2OaxJ/PSGj4HXlh4QVQVvwXxqua4Cnrr8Jwr+cJSVDZbOz
rrqM6TtItjGR/PI5IAurZA+vQYEcAi6Ewgixat6jzPGhqBTc4aehiqnujoBm5dCmQnzbvpLH4joh
srYdYKN6xjsPsI0lK4al3dkqIsxdqHt4a/VbEqX1NZ5chfVjC35vP1PodxxGZYtCRfljMOoCTbda
kwYyZjxbCVzXjA7QmKcrEmV80kcAmZvYj4VSB7Q5+2eEzYa6P0P7KqDE1YDDpXbWLcf66sC5TSXN
sbdu7uMkLRnptGFKCHpmi3gCceCfZRMyhDCKCltz6opMk5wbHwj7ryxTrmJcKsZzd5hQ041z+R6k
VpuK+CUtvSgVXfHqR3Mq7tGls6qo4VD9kuzVOF/weL/+TOMBtzQ8rcDIsyzA9Z3QQHY0mwhcSpsO
kiEA08fWqR2nNM9glm+T28DVa0SgH1JxPoLWQgjQkpdSh7JJBxhj7NQ6APLSNpZE2V45dlkBSo3I
h+aox5dMZuW7sShQ9OiMMjfjoWYLD9uWm+W4QS/CiUwKI9zC/nd7TYl6TnuWQf4jKx/OKvxE0d9P
5oSUhITrkzUlMpU2TckOlK5uK1A/mVDqvP1QfeFt0GxcMocVwDQikECi5dymjlFK3/ucTkv8Ogmf
mOpk1Uh+oV7454R+oRZM2gfrhRvgamDqaplk4Cz2gHXy6hDK/Trzz3S5QkSRaToIUsaLnqNcqHDy
wbzVYVk86acIOwN5jUz/RjuLukbxdevCkjNDIEfUtZwPrKMfDfxif3UQPsszU4ccfhEtyGfUO5YP
hfUgZ7KOKS+OMBpEaxVPcKwQ888OGaT4Zm698puHLpt7UBG+7d+vATsVCysOLPlhhNCgpCFsPbOt
4ARRMD8+DbkYptc7J8XILX//sXL6WiL69Cv0XxccvG/xcRMOQIoZNfUx5qv50uk8Hl3O944pNkoe
yVVXdy59cgj7vqTlAIe7lDV8VZOUX7DS9j/+HVmUlFTS/Wk7GNv/gE8dXSbRh/GRa+ON3KJxN8jU
njRwBPQbPc+iS0xLNQb8fox09tLqnKB4j9t1mzGhtBjLafhawh1x8uHJ8FxWxFfhS6o4aKhPgikN
k8bSuzq=