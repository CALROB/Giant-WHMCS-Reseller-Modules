<?php //0032b
// Giant Reseller Phone System addon 3.2.5 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv4kLGh13gujc9J0AJysOl9btdYNm2lwhw6yP0XuFg//oDslglxJjFGxd73YpjXws6vYVmAO
2qb22Erif1VM2aGxbWfYyMIIq76PspCloE73u7Y6yNGXUbB/FgYxHMudDKii6QS4Uy0L1tnESNCV
hUze4TbFmldrS0WvuEqDZl/zJIgWnj8YkNvaUEZ2RepjJQyxpM73cqozx6EcvWG7I3Xp3+DVMhl9
04L8kOqIJVjFBIateDVRRRk1ftI+JO3YyK2GhPotU35chfVjC35vP1PodxxGZYsDR138o/KYYQn/
5nniaENC7VyaYWs1W7rJbLdfgt9aJBnkTY/mHxjaVejBqaVF+jSijY/nWGcu7pv4fTA46i6/IwgI
Gk+WIJ1QdYqqPJC/qy69YGP4+Sv0yuhvAotCg85qtJvKYLp9/f8QLRTkcR9DSVSaViIWkrtRykAa
BpeM9Ek1BHYaIPKeVbGqyXKM7RY88YAizD1fmCqW1mYsRHZGgyj+kSNGJE/hJ4ro+68WfAnx1W4I
1MLOMYhDjCIObFA9pPvByagAf7JS75AoGaLxOML6HhNJjwUwjb0cmMAgSB+wHWVT+K4v/+Cqaw1N
vPsgaA1KRp5iwc2+wB6gL0+1caVZ+LX1PYbZZ3tdorttTvWhFyD23DSecLw0zEMcafjZPZAi7QA6
c9yQdmr30SELJesXvmtggRZo0OoYgwIgghiZM2+0WYnjXJE2aXJCtvLvg8jENRzwnJuZpkkboGH2
5/nxZYyN7BvVeU7TfNmvmZIi5wXoMEv52nTlwaLBgleO8oy3kvU66qCQjOo/iBMMhDFFbeQ5Ts00
zwyXfH3KIjKxcXx2WHbPViJW9YTMIlTwaAduGNlSrNqspYns79g8aFbNCHKh5V4sLC50g6VtoiXb
WnNfC45YXhvhXU8OajW+7jJq1J6tIkHjbFZSWWYwrCChoHkD7PYeCSC87gtlQZN/10llHMdvPwoD
ELGpMbCssLL5fGkHL2pecgmCmrdaOQaKhx96O4YA3paHRKmllXdRWb3WS9XYwZyZeBta5eWpm9ej
OVnpyh7iovDdQNMvn9dbKRwf6xNJtXt/y17ODMXEbl7kFyz2XCNSRcu9GSvWl5HkZ+EQtlkfz2Px
KOvCZSFwTMlF2IIfrbH4Bm/k+TLLLl+DTxUYW451qHXEx+sydcgpT5R6pwhhJflx