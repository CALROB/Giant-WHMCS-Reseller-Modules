{$paletteStyle}
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.5.0/chart.min.js"></script>
{literal}
<script>
// Token-aware colour helper for canvas charts. Mirrors index.js's
// gvColor — duplicated here because the Estate page doesn't pull
// the addon's main JS bundle. Resolves gv-system tokens at runtime
// (canvas APIs can't evaluate `var(--accent)` in a CSS string).
if (typeof window.gvColor !== 'function') {
    window.gvColor = function (token, alpha) {
        try {
            var raw = getComputedStyle(document.documentElement)
                .getPropertyValue('--' + token).trim();
            if (!raw) {
                var fb = {
                    accent: '0 217 167', 'accent-2': '11 132 87',
                    'accent-ink': '0 217 167', 'accent-contrast': '26 26 46',
                    text: '26 26 46', muted: '105 114 125',
                    bg: '255 255 255', surface: '247 249 242',
                    border: '232 236 240',
                    warn: '217 119 6', danger: '220 38 38'
                };
                raw = fb[token] || '0 217 167';
            }
            raw = raw.replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
            if (alpha != null && alpha !== 1) return 'rgb(' + raw + ' / ' + alpha + ')';
            return 'rgb(' + raw + ')';
        } catch (e) { return 'rgb(0 217 167)'; }
    };
}
if (typeof window.gvApplyChartDefaults !== 'function') {
    window.gvApplyChartDefaults = function () {
        if (typeof Chart === 'undefined' || !Chart.defaults) return;
        Chart.defaults.color = window.gvColor('muted');
        Chart.defaults.borderColor = window.gvColor('border');
        if (Chart.defaults.plugins && Chart.defaults.plugins.legend && Chart.defaults.plugins.legend.labels) {
            Chart.defaults.plugins.legend.labels.color = window.gvColor('text');
        }
        if (Chart.defaults.plugins && Chart.defaults.plugins.tooltip) {
            Chart.defaults.plugins.tooltip.backgroundColor = window.gvColor('text', .92);
            Chart.defaults.plugins.tooltip.titleColor = window.gvColor('bg');
            Chart.defaults.plugins.tooltip.bodyColor  = window.gvColor('bg');
            Chart.defaults.plugins.tooltip.borderColor = window.gvColor('border');
            Chart.defaults.plugins.tooltip.borderWidth = 1;
        }
    };
}
window.gvApplyChartDefaults();
// Re-paint when html.dark toggles. Iterates every live Chart.js
// instance — Chart 3.5 exposes them via Chart.instances.
(function () {
    if (typeof MutationObserver === 'undefined') return;
    var prev = document.documentElement.classList.contains('dark');
    new MutationObserver(function () {
        var now = document.documentElement.classList.contains('dark');
        if (now === prev) return;
        prev = now;
        window.gvApplyChartDefaults();
        if (typeof Chart !== 'undefined' && Chart.instances) {
            var insts = Chart.instances;
            (typeof insts.forEach === 'function'
                ? insts.forEach.bind(insts)
                : function (cb) { Object.keys(insts).forEach(function (k) { cb(insts[k]); }); }
            )(function (c) { try { c.update('none'); } catch (e) {} });
        }
    }).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
})();
</script>
{/literal}
<style>
/* Brand is green — never blue. Re-point gv-system's blue secondary accent to
   the same deep emerald used across the client area so estate charts/icons
   stay in the green family. */
:root { --accent-2: 11 132 87; }
.estate-page { max-width: 1200px; margin: 20px auto; }
.estate-hero {
    border:1px solid rgb(var(--border)); border-radius:10px; padding:22px 26px;
    background:rgb(var(--bg)); margin-bottom:20px;
}
.estate-hero h2 { margin:0 0 6px; font-size:22px; }
.estate-hero p.lede { color:rgb(var(--muted)); margin:0 0 18px; line-height:1.5; }

/* Hero header strip: title + lede on the left, health score gauge on
   the right. The gauge collapses below the title on narrow screens. */
.estate-hero-top {
    display:flex; align-items:flex-start; gap:24px;
    margin-bottom:6px;
}
.estate-hero-text { flex:1; min-width:0; }
.estate-hero-text p.lede { margin-bottom:0; }
.estate-hero-text h2 { margin-bottom:6px; }
@media (max-width: 700px) {
    .estate-hero-top { flex-direction:column; align-items:stretch; }
}

/* Score gauge — circular progress dial driven by --score (0..100) and
   --tone (good/ok/warn/poor). conic-gradient spins teal/amber/red
   round to <score>% of the circle, and a white inner disc creates the
   ring effect without needing SVG. */
.estate-health {
    flex:0 0 auto; min-width:200px;
    display:flex; align-items:center; gap:14px;
    padding:10px 14px; border:1px solid rgb(var(--border)); border-radius:10px;
    background:linear-gradient(135deg,rgb(var(--surface)) 0%,rgb(var(--bg)) 100%);
    cursor:help;
}
.estate-health-dial {
    --c: rgb(var(--accent));
    --pct: 0;
    width:62px; height:62px; border-radius:50%; flex:0 0 62px;
    background:
        conic-gradient(var(--c) calc(var(--pct) * 1%), rgb(var(--border)) 0);
    display:flex; align-items:center; justify-content:center;
    position:relative;
}
.estate-health-dial::before {
    content:""; position:absolute; inset:6px; border-radius:50%;
    background:rgb(var(--bg));
}
.estate-health-dial-num {
    position:relative; font-size:18px; font-weight:800; color:rgb(var(--text));
    line-height:1;
}
.estate-health-dial-num small { font-size:10px; color:rgb(var(--muted) / .75); font-weight:600; }
.estate-health-body { display:flex; flex-direction:column; min-width:0; }
.estate-health-label {
    font-size:10.5px; text-transform:uppercase; letter-spacing:.05em;
    color:rgb(var(--muted)); font-weight:700;
}
.estate-health-grade {
    display:inline-flex; align-items:center; gap:6px;
    font-size:13px; font-weight:700; color:rgb(var(--text)); margin-top:2px;
}
.estate-health-pill {
    display:inline-block; padding:1px 7px; border-radius:8px;
    font-size:10.5px; font-weight:800; letter-spacing:.05em;
}
.estate-health-headline {
    font-size:11.5px; color:rgb(var(--muted)); margin-top:3px; line-height:1.3;
}
/* Tone variants — drive both the dial colour and the grade pill. */
.estate-health.is-good .estate-health-dial    { --c:rgb(var(--accent)); }
.estate-health.is-good .estate-health-pill    { background:rgb(var(--accent) / .12); color:rgb(var(--accent-ink)); }
.estate-health.is-ok   .estate-health-dial    { --c:rgb(var(--accent)); }
.estate-health.is-ok   .estate-health-pill    { background:rgb(var(--accent) / .12); color:rgb(var(--accent-ink)); }
.estate-health.is-warn .estate-health-dial    { --c:rgb(var(--warn)); }
.estate-health.is-warn .estate-health-pill    { background:rgb(var(--warn) / .12); color:rgb(var(--warn)); }
.estate-health.is-poor .estate-health-dial    { --c:rgb(var(--danger)); }
.estate-health.is-poor .estate-health-pill    { background:rgb(var(--danger) / .12); color:rgb(var(--danger)); }

/* Tooltip-style breakdown shown on hover — lists the per-factor
   deductions so the customer can see what's pulling the score down. */
.estate-health-pop {
    position:absolute; z-index:60; right:0; top:calc(100% + 6px);
    width:300px; padding:12px 14px;
    background:rgb(var(--bg)); border:1px solid rgb(var(--border)); border-radius:10px;
    box-shadow:0 12px 32px rgb(0 0 0 / .08);
    display:none;
}
.estate-health-wrap { position:relative; }
.estate-health-wrap:hover .estate-health-pop,
.estate-health-wrap:focus-within .estate-health-pop { display:block; }
.estate-health-pop-title {
    font-size:11px; text-transform:uppercase; letter-spacing:.05em;
    color:rgb(var(--muted)); font-weight:700; margin-bottom:8px;
}
.estate-health-pop-row {
    display:flex; align-items:flex-start; justify-content:space-between;
    gap:8px; padding:5px 0; border-top:1px solid rgb(var(--surface));
    font-size:12px;
}
.estate-health-pop-row:first-of-type { border-top:0; }
.estate-health-pop-label  { color:rgb(var(--text)); font-weight:600; }
.estate-health-pop-detail { color:rgb(var(--muted) / .75); font-size:10.5px; margin-top:1px; }
.estate-health-pop-pts    {
    flex:0 0 auto; color:rgb(var(--muted)); font-weight:700; font-variant-numeric:tabular-nums;
}
.estate-health-pop-pts.is-loss { color:rgb(var(--danger)); }
.estate-health-pop-pts.is-zero { color:rgb(var(--muted) / .75); }

/* Stats strip — fixed 8-col grid at desktop so every card lines up
   evenly across one row instead of leaving orphans on a wrap. Drops to
   4 then 2 then 1 column at narrower widths. Cards are kept compact
   (icon inline with label so value can have full width) so 8 fit
   horizontally without crowding. */
.estate-stats {
    display:grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap:12px; margin-top:6px;
}
@media (max-width: 760px) { .estate-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
@media (max-width: 460px) { .estate-stats { grid-template-columns: 1fr; } }

.estate-stat {
    position:relative;
    background:rgb(var(--bg)); border:1px solid rgb(var(--border)); border-radius:10px;
    padding:14px 16px;
    transition: border-color .15s ease, transform .15s ease, box-shadow .15s ease;
    min-width:0;
}
.estate-stat:hover {
    border-color:rgb(var(--border));
    box-shadow:0 4px 12px rgb(0 0 0 / .04);
}
.estate-stat-head {
    display:flex; align-items:center; gap:8px; margin-bottom:6px;
}
.estate-stat-icon {
    width:26px; height:26px; border-radius:7px;
    display:inline-flex; align-items:center; justify-content:center;
    background:rgb(var(--accent) / .08); color:rgb(var(--accent)); font-size:13px;
    flex:0 0 26px;
}
.estate-stat-icon.is-spend  { background:rgb(var(--accent) / .08); color:rgb(var(--accent-ink)); }
.estate-stat-icon.is-fcast  { background:rgb(var(--warn) / .08); color:rgb(var(--warn)); }
.estate-stat-icon.is-saving { background:rgb(var(--accent) / .08); color:rgb(var(--accent-ink)); }
.estate-stat-label {
    font-size:11px; text-transform:uppercase; letter-spacing:.04em;
    color:rgb(var(--muted)); font-weight:700; line-height:1.2;
    flex:1; min-width:0;
}
.estate-stat-value  {
    font-size:22px; font-weight:700; color:rgb(var(--text)); line-height:1.15;
}
.estate-stat-sub    {
    font-size:11.5px; color:rgb(var(--muted) / .75); margin-top:4px; line-height:1.3;
}
.estate-stat.is-money  .estate-stat-value { color:rgb(var(--accent-ink)); }
.estate-stat.is-saving .estate-stat-value { color:rgb(var(--accent-ink)); }

/* Optimisation cards — clickable, teal-bordered, feel like CTAs. */
.estate-stat.is-action {
    cursor:pointer; border-color:rgb(var(--accent) / .35); background:rgb(var(--accent) / .08);
    text-decoration:none; color:inherit; display:block;
}
.estate-stat.is-action:hover {
    border-color:rgb(var(--accent)); background:rgb(var(--accent) / .08); transform:translateY(-1px);
    box-shadow:0 6px 14px rgb(var(--accent) / .12);
    text-decoration:none;
}
.estate-stat.is-action.is-zero {
    cursor:default; background:rgb(var(--bg));
}
.estate-stat.is-action.is-zero:hover { transform:none; box-shadow:none; }

/* Trend hint chip on the Forecast card */
.estate-stat-delta {
    display:inline-flex; align-items:center;
    font-size:10px; font-weight:700;
    padding:1px 5px; border-radius:5px;
    background:rgb(var(--warn) / .12); color:rgb(var(--warn));
    margin-left:4px; vertical-align:middle;
}
.estate-stat-delta.is-down { background:rgb(var(--accent) / .12); color:rgb(var(--accent-ink)); }

.estate-toolbar {
    display:flex; gap:10px; align-items:center; margin-bottom:14px; flex-wrap:wrap;
}
.estate-search { position:relative; }
.estate-search input {
    padding:6px 30px 6px 32px; border:1px solid rgb(var(--border)); border-radius:6px;
    font-size:13px; width:280px; background:rgb(var(--bg));
}
.estate-search input:focus { outline:none; border-color:rgb(var(--accent)); box-shadow:0 0 0 3px rgb(var(--accent) / .18); }
.estate-search > .fa { position:absolute; left:11px; top:50%; transform:translateY(-50%); color:rgb(var(--muted) / .75); font-size:12px; pointer-events:none; }
.estate-search-clear {
    position:absolute; right:6px; top:50%; transform:translateY(-50%);
    background:none; border:none; color:rgb(var(--muted) / .75); cursor:pointer; font-size:14px;
    padding:2px 6px; display:none; line-height:1;
}
.estate-search.has-value .estate-search-clear { display:block; }

.estate-export {
    display:inline-flex; align-items:center; gap:6px; padding:6px 12px;
    border:1px solid rgb(var(--border)); border-radius:6px; background:rgb(var(--bg));
    color:rgb(var(--muted)); font-size:12.5px; font-weight:600; cursor:pointer;
    text-decoration:none;
}
.estate-export:hover {
    border-color:rgb(var(--accent)); color:rgb(var(--accent)); background:rgb(var(--accent) / .08);
    text-decoration:none;
}

/* Export dropdown menu */
.estate-export-menu { position:relative; display:inline-block; }
.estate-export-dropdown {
    position:absolute; top:calc(100% + 4px); right:0; z-index:50;
    min-width:280px; padding:6px;
    background:rgb(var(--bg)); border:1px solid rgb(var(--border)); border-radius:8px;
    box-shadow:0 8px 24px rgb(0 0 0 / .08);
    display:none;
}
.estate-export-dropdown.is-open { display:block; }
.estate-export-section-label {
    padding:8px 10px 4px; font-size:10px;
    text-transform:uppercase; letter-spacing:.05em;
    color:rgb(var(--muted) / .75); font-weight:700;
}
.estate-export-item {
    display:flex; align-items:center; gap:10px; padding:8px 10px;
    border-radius:6px; color:inherit; text-decoration:none;
    font-size:12.5px;
}
.estate-export-item:hover {
    background:rgb(var(--accent) / .08); color:rgb(var(--accent-ink)); text-decoration:none;
}
.estate-export-item > i {
    font-size:14px; color:rgb(var(--accent)); flex:0 0 16px;
}
.estate-export-item > div { line-height:1.3; }
.estate-export-item small {
    display:block; color:rgb(var(--muted) / .75); font-size:11px; font-weight:400;
    margin-top:1px;
}

.estate-table {
    width:100%; border-collapse:collapse; background:rgb(var(--bg));
    border:1px solid rgb(var(--border)); border-radius:8px; overflow:hidden;
}
.estate-table th, .estate-table td {
    padding:11px 14px; text-align:left; border-bottom:1px solid rgb(var(--surface));
    font-size:13px; vertical-align:middle;
}
.estate-table thead th {
    background:rgb(var(--surface)); font-size:11px; text-transform:uppercase;
    letter-spacing:.04em; color:rgb(var(--muted)); font-weight:700;
}
.estate-table tbody tr { cursor:pointer; transition:background .12s ease; }
.estate-table tbody tr:hover { background:rgb(var(--surface)); }

.estate-tenant-name { font-weight:600; color:rgb(var(--text)); }
.estate-tenant-code { font-size:11.5px; color:rgb(var(--muted)); font-family:monospace; }
.estate-product { font-size:12px; color:rgb(var(--muted)); }
.estate-num     { font-family:monospace; font-weight:600; color:rgb(var(--text)); }
.estate-money   { font-family:monospace; color:rgb(var(--text)); font-weight:600; }
.estate-money.is-bill { color:rgb(var(--accent-ink)); }
.estate-empty   { color:rgb(var(--muted) / .75); font-style:italic; font-size:12px; }

.estate-status-pill {
    display:inline-block; padding:2px 8px; border-radius:10px;
    font-size:10.5px; font-weight:700; letter-spacing:.04em;
    text-transform:uppercase;
}
.estate-status-Active     { background:rgb(var(--accent) / .12); color:rgb(var(--accent-ink)); }
.estate-status-Pending    { background:rgb(var(--warn) / .12); color:rgb(var(--warn)); }
.estate-status-Suspended  { background:rgb(var(--danger) / .12); color:rgb(var(--danger)); }

/* Insights — KPI cards above the toolbar */
.estate-insights {
    display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap:12px; margin-bottom:18px;
}
.estate-insight-card {
    background:rgb(var(--bg)); border:1px solid rgb(var(--border)); border-radius:10px;
    padding:14px 16px; display:flex; align-items:center; gap:12px;
    cursor:pointer; transition: all .15s ease; text-decoration:none; color:inherit;
}
.estate-insight-card:hover {
    border-color:rgb(var(--accent)); transform: translateY(-1px);
    box-shadow: 0 4px 12px rgb(var(--accent) / .12);
    text-decoration:none; color:inherit;
}
.estate-insight-card.is-active {
    border-color:rgb(var(--text));
    box-shadow: 0 0 0 2px rgb(0 0 0 / .08);
}
.estate-insight-icon {
    width:42px; height:42px; border-radius:10px;
    display:inline-flex; align-items:center; justify-content:center;
    flex:0 0 42px; font-size:18px;
}
.estate-insight-icon.is-spend  { background:rgb(var(--accent) / .08); color:rgb(var(--accent-ink)); }
.estate-insight-icon.is-spike  { background:rgb(var(--warn) / .12); color:rgb(var(--warn)); }
.estate-insight-icon.is-calls  { background:rgb(var(--accent-2) / .12); color:rgb(var(--accent-2)); }
.estate-insight-icon.is-anom   { background:rgb(var(--danger) / .12); color:rgb(var(--danger)); }
.estate-insight-body { min-width:0; flex:1; }
.estate-insight-label {
    font-size:11px; text-transform:uppercase; letter-spacing:.05em;
    color:rgb(var(--muted)); font-weight:700; margin-bottom:2px;
}
.estate-insight-value { font-size:15px; font-weight:700; color:rgb(var(--text)); line-height:1.25; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.estate-insight-sub   { font-size:11.5px; color:rgb(var(--muted)); margin-top:2px; }

/* Charts panel — two stacked rows so the time-series chart can take
   full width on its own line (much more readable for trend-spotting),
   while the bar + doughnut share a row above. */
.estate-charts {
    display:grid;
    grid-template-columns: 1.4fr 1fr;
    grid-auto-rows: auto;
    gap:14px; margin-bottom:18px;
}
.estate-charts .estate-chart-card.is-wide { grid-column: 1 / -1; }
@media (max-width: 700px) { .estate-charts { grid-template-columns: 1fr; } }
.estate-chart-card {
    background:rgb(var(--bg)); border:1px solid rgb(var(--border)); border-radius:10px;
    padding:14px 16px;
}
.estate-chart-card h3 {
    margin:0 0 8px; font-size:12px; text-transform:uppercase;
    letter-spacing:.05em; color:rgb(var(--muted)); font-weight:700;
}
/* Chart.js with `maintainAspectRatio: false` needs the canvas's
   parent to have an explicit height — otherwise the canvas
   collapses to 0px and looks like a blank white box. */
.estate-chart-wrap { position:relative; height:260px; }

/* Sparkline + anomaly */
.estate-spark { display:inline-block; vertical-align:middle; }
.estate-spark svg { display:block; }
.estate-anomaly-pill {
    display:inline-flex; align-items:center; gap:4px;
    padding:1px 6px; border-radius:8px;
    background:rgb(var(--warn) / .12); color:rgb(var(--warn)); border:1px solid rgb(var(--warn) / .35);
    font-size:10.5px; font-weight:700; margin-left:6px;
    cursor:help; line-height:1.4;
}
.estate-anomaly-pill i { font-size:10px; }
/* Clickable variant — drilldown pill on the row. Reset button styles. */
.estate-anomaly-pill-btn {
    cursor:pointer; font-family:inherit;
    transition: background .15s ease, transform .15s ease;
}
.estate-anomaly-pill-btn:hover {
    background:rgb(var(--warn) / .35); transform:translateY(-1px);
}

/* Anomaly drill-down dialog. Reuses the .estatev-* viewer chrome but
   adds a focused chart-first layout — daily-bars at the top, top-day
   highlights below, comparison strip on the side. */
.estate-anom-summary {
    display:grid; grid-template-columns: repeat(4, 1fr);
    gap:10px; margin-bottom:14px;
}
@media (max-width: 700px) { .estate-anom-summary { grid-template-columns: repeat(2, 1fr); } }
.estate-anom-stat {
    background:rgb(var(--surface)); border:1px solid rgb(var(--border)); border-radius:8px;
    padding:10px 12px;
}
.estate-anom-stat-label {
    font-size:10px; text-transform:uppercase; letter-spacing:.04em;
    color:rgb(var(--muted)); font-weight:700;
}
.estate-anom-stat-value {
    font-size:18px; font-weight:700; color:rgb(var(--text));
    margin-top:3px; line-height:1.15;
}
.estate-anom-stat.is-anom .estate-anom-stat-value { color:rgb(var(--warn)); }
.estate-anom-stat.is-down .estate-anom-stat-value { color:rgb(var(--accent-ink)); }
.estate-anom-stat-sub {
    font-size:10.5px; color:rgb(var(--muted) / .75); margin-top:2px;
}

.estate-anom-chart-wrap { height:200px; margin-bottom:14px; }

.estate-anom-table { width:100%; border-collapse:collapse; }
.estate-anom-table th,
.estate-anom-table td {
    padding:6px 10px; font-size:12.5px; border-bottom:1px solid rgb(var(--surface));
}
.estate-anom-table thead th {
    background:rgb(var(--surface)); font-size:10.5px; text-transform:uppercase;
    color:rgb(var(--muted)); font-weight:700; letter-spacing:.04em;
}
.estate-anom-table .is-spike td:nth-child(2),
.estate-anom-table .is-spike td:nth-child(3),
.estate-anom-table .is-spike td:nth-child(4) {
    color:rgb(var(--warn)); font-weight:700;
}
.estate-anom-table td.num { font-family:monospace; text-align:right; }

/* "No numbers" badge on tenant cell when didsCount is 0 */
.estate-no-numbers {
    display:inline-flex; align-items:center; gap:4px;
    padding:1px 7px; border-radius:8px;
    background:rgb(var(--danger) / .12); color:rgb(var(--danger)); border:1px solid rgb(var(--danger) / .35);
    font-size:10.5px; font-weight:700; margin-top:3px;
    cursor:help; line-height:1.4;
}
.estate-no-numbers i { font-size:10px; }

/* "Idle" badge — active service but no call activity in 30 days */
.estate-zombie {
    display:inline-flex; align-items:center; gap:4px;
    padding:1px 7px; border-radius:8px;
    background:rgb(var(--surface)); color:rgb(var(--muted)); border:1px solid rgb(var(--border));
    font-size:10.5px; font-weight:700; margin-top:3px; margin-left:4px;
    cursor:help; line-height:1.4;
}
.estate-zombie i { font-size:10px; }

/* "Consider upgrade" badge — soft mint so it reads as opportunity,
   not warning. Triggered when a tenant is at or over their inclusive
   minute cap on at least one prefix group AND a higher tier exists. */
.estate-upsell {
    display:inline-flex; align-items:center; gap:4px;
    padding:1px 7px; border-radius:8px;
    background:rgb(var(--accent) / .08); color:rgb(var(--accent-ink)); border:1px solid rgb(var(--accent) / .35);
    font-size:10.5px; font-weight:700; margin-top:3px; margin-left:4px;
    cursor:help; line-height:1.4;
}
.estate-upsell i { font-size:10px; }

/* "Possible duplicate" badge — amber so it reads as something that
   needs review without alarming the customer. Tooltip lists every
   tenant flagged as a likely match. */
.estate-duplicate {
    display:inline-flex; align-items:center; gap:4px;
    padding:1px 7px; border-radius:8px;
    background:rgb(var(--warn) / .08); color:rgb(var(--warn)); border:1px solid rgb(var(--warn) / .35);
    font-size:10.5px; font-weight:700; margin-top:3px; margin-left:4px;
    cursor:help; line-height:1.4;
}
.estate-duplicate i { font-size:10px; }

/* Port-attempt status pips — small tinted chips next to the count */
.estate-ports-mini {
    display:inline-flex; gap:3px; margin-top:3px; justify-content:flex-end;
}
.estate-ports-pip {
    display:inline-flex; align-items:center; justify-content:center;
    min-width:18px; padding:0 5px; height:14px; border-radius:7px;
    font-size:9.5px; font-weight:700; line-height:1;
    cursor:help;
}
.estate-ports-pip.is-ok      { background:rgb(var(--accent) / .12); color:rgb(var(--accent-ink)); }
.estate-ports-pip.is-pending { background:rgb(var(--warn) / .12); color:rgb(var(--warn)); }
.estate-ports-pip.is-fail    { background:rgb(var(--danger) / .12); color:rgb(var(--danger)); }

/* Optimisation wizard launch button — strong teal CTA so it reads as
   the headline action in the toolbar. Inline savings chip nudges the
   customer with the concrete number. */
.estate-wizard-btn {
    display:inline-flex; align-items:center; gap:8px;
    padding:7px 14px; border:0; border-radius:8px;
    background:linear-gradient(135deg,rgb(var(--accent)),rgb(var(--accent)));
    color:rgb(var(--bg)); font-size:13px; font-weight:700; cursor:pointer;
    box-shadow:0 4px 10px rgb(var(--accent) / .25);
    transition: transform .15s ease, box-shadow .15s ease;
}
.estate-wizard-btn:hover {
    transform:translateY(-1px); box-shadow:0 6px 16px rgb(var(--accent) / .32);
}
.estate-wizard-btn i { font-size:14px; }
.estate-wizard-savings {
    background:rgb(var(--bg) / .22); padding:1px 7px; border-radius:10px;
    font-size:11px; font-weight:700; letter-spacing:.02em;
}

/* Wizard dialog — reuses the .estatev-overlay viewer chrome but adds
   a step rail at the top, candidate list with checkboxes, and an
   impact summary footer. */
.estate-wiz-steps {
    display:flex; align-items:center; gap:0; margin-bottom:14px;
    padding:0 4px;
}
.estate-wiz-step {
    display:flex; align-items:center; gap:8px;
    flex:1; min-width:0;
}
.estate-wiz-step-num {
    width:26px; height:26px; border-radius:50%;
    background:rgb(var(--border)); color:rgb(var(--muted)); font-size:12px; font-weight:700;
    display:inline-flex; align-items:center; justify-content:center;
    flex:0 0 26px;
}
.estate-wiz-step-label {
    font-size:11.5px; color:rgb(var(--muted) / .75); font-weight:600;
    overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
}
.estate-wiz-step-bar {
    flex:1; height:2px; background:rgb(var(--border)); margin:0 8px;
}
.estate-wiz-step.is-active .estate-wiz-step-num { background:rgb(var(--accent)); color:rgb(var(--bg)); }
.estate-wiz-step.is-active .estate-wiz-step-label { color:rgb(var(--text)); }
.estate-wiz-step.is-done .estate-wiz-step-num { background:rgb(var(--accent-ink)); color:rgb(var(--bg)); }
.estate-wiz-step.is-done .estate-wiz-step-label { color:rgb(var(--muted)); }
.estate-wiz-step.is-done + .estate-wiz-step-bar,
.estate-wiz-step.is-active + .estate-wiz-step-bar { background:rgb(var(--accent)); }

/* Candidate list rows */
.estate-wiz-pick {
    display:flex; align-items:center; gap:12px;
    padding:10px 12px; border:1px solid rgb(var(--border)); border-radius:8px;
    background:rgb(var(--bg)); margin-bottom:8px;
    transition: border-color .12s ease, background .12s ease;
}
.estate-wiz-pick:hover { border-color:rgb(var(--accent)); background:rgb(var(--accent) / .08); }
.estate-wiz-pick.is-checked { border-color:rgb(var(--accent)); background:rgb(var(--accent) / .08); }
.estate-wiz-pick input[type=checkbox] { width:16px; height:16px; cursor:pointer; flex:0 0 16px; }
.estate-wiz-pick-body { flex:1; min-width:0; display:grid; grid-template-columns: 1.6fr 1fr 0.7fr; gap:10px; align-items:center; }
@media (max-width: 720px) { .estate-wiz-pick-body { grid-template-columns: 1fr; } }
.estate-wiz-pick-tenant { font-weight:600; color:rgb(var(--text)); font-size:13px; }
.estate-wiz-pick-current { font-size:11.5px; color:rgb(var(--muted)); margin-top:2px; }
.estate-wiz-pick-arrow {
    font-size:13px; color:rgb(var(--muted) / .75); text-align:center;
}
.estate-wiz-pick-target { font-size:13px; font-weight:600; color:rgb(var(--text)); }
.estate-wiz-pick-target-sub { font-size:11.5px; color:rgb(var(--muted)); margin-top:2px; }
.estate-wiz-pick-saving {
    text-align:right; font-size:13px; font-weight:700; color:rgb(var(--accent-ink));
    font-variant-numeric:tabular-nums;
}
.estate-wiz-pick-saving small { display:block; font-size:10.5px; font-weight:600; color:rgb(var(--muted) / .75); }

/* Toolbar / select-all row + impact footer */
.estate-wiz-toolbar {
    display:flex; align-items:center; gap:10px; margin-bottom:8px;
    font-size:12px; color:rgb(var(--muted));
}
.estate-wiz-toolbar .est-spacer { flex:1; }
.estate-wiz-toolbar a {
    color:rgb(var(--accent-ink)); cursor:pointer; text-decoration:none; font-weight:600;
}
.estate-wiz-toolbar a:hover { text-decoration:underline; }

.estate-wiz-impact {
    display:grid; grid-template-columns: repeat(3, 1fr); gap:10px;
    padding:12px 14px; margin-top:6px;
    background:rgb(var(--surface)); border:1px solid rgb(var(--border)); border-radius:8px;
}
.estate-wiz-impact-stat-label {
    font-size:10.5px; text-transform:uppercase; letter-spacing:.04em;
    color:rgb(var(--muted)); font-weight:700;
}
.estate-wiz-impact-stat-value { font-size:17px; font-weight:700; color:rgb(var(--text)); line-height:1.15; margin-top:3px; }
.estate-wiz-impact-stat.is-saving .estate-wiz-impact-stat-value { color:rgb(var(--accent-ink)); }
.estate-wiz-impact-stat.is-cost   .estate-wiz-impact-stat-value { color:rgb(var(--warn)); }

/* Confirm / submit / results notes */
.estate-wiz-notes {
    background:rgb(var(--warn) / .08); border:1px solid rgb(var(--warn) / .35); border-radius:8px;
    padding:12px 14px; font-size:12.5px; color:rgb(var(--warn)); line-height:1.5;
    margin-bottom:14px;
}
.estate-wiz-notes strong { color:rgb(var(--warn)); }

.estate-wiz-result-row {
    display:flex; align-items:center; gap:10px;
    padding:10px 12px; border:1px solid rgb(var(--border)); border-radius:8px;
    background:rgb(var(--bg)); margin-bottom:6px;
    font-size:12.5px;
}
.estate-wiz-result-row.is-success { border-color:rgb(var(--accent) / .35); background:rgb(var(--accent) / .08); }
.estate-wiz-result-row.is-failure { border-color:rgb(var(--danger) / .35); background:rgb(var(--danger) / .08); }
.estate-wiz-result-row .icon { width:20px; flex:0 0 20px; text-align:center; }
.estate-wiz-result-row.is-success .icon { color:rgb(var(--accent-ink)); }
.estate-wiz-result-row.is-failure .icon { color:rgb(var(--danger)); }
.estate-wiz-result-row .body { flex:1; min-width:0; }
.estate-wiz-result-row .label { font-weight:600; color:rgb(var(--text)); }
.estate-wiz-result-row .meta  { font-size:11px; color:rgb(var(--muted)); margin-top:2px; }
.estate-wiz-result-row a.invoice-link {
    background:rgb(var(--accent)); color:rgb(var(--bg)); padding:4px 10px; border-radius:6px;
    font-size:12px; font-weight:600; text-decoration:none;
    flex:0 0 auto;
}
.estate-wiz-result-row a.invoice-link:hover { background:rgb(var(--accent-ink)); text-decoration:none; }

.estate-wiz-empty {
    text-align:center; padding:30px 20px; color:rgb(var(--muted));
}
.estate-wiz-empty i { font-size:32px; color:rgb(var(--border)); margin-bottom:10px; }

/* Active-filter chips banner — shows below the toolbar whenever any
   filter is applied so customers know what they're looking at. */
.estate-active-filters {
    display:none; align-items:center; gap:8px; flex-wrap:wrap;
    padding:8px 12px; margin-bottom:12px;
    background:rgb(var(--surface)); border:1px solid rgb(var(--border)); border-radius:8px;
    font-size:12.5px;
}
.estate-active-filters.is-visible { display:flex; }
.estate-active-label {
    color:rgb(var(--muted)); font-weight:600;
}
.estate-filter-chip {
    display:inline-flex; align-items:center; gap:6px;
    padding:3px 6px 3px 10px; background:rgb(var(--bg));
    border:1px solid rgb(var(--border)); border-radius:14px;
    color:rgb(var(--text)); font-size:12px;
}
.estate-filter-chip button {
    background:none; border:0; padding:1px 4px;
    color:rgb(var(--muted)); cursor:pointer; font-size:11px; line-height:1;
    border-radius:50%;
}
.estate-filter-chip button:hover { background:rgb(var(--surface)); color:rgb(var(--danger)); }
.estate-clear-filters {
    margin-left:auto; background:none; border:0; padding:4px 8px;
    color:rgb(var(--muted)); cursor:pointer; font-size:12px; font-weight:600;
    border-radius:6px;
}
.estate-clear-filters:hover { background:rgb(var(--bg)); color:rgb(var(--text)); }

/* Pagination footer */
.estate-pagination {
    display:none; align-items:center; gap:14px; flex-wrap:wrap;
    padding:10px 14px; margin-top:14px;
    background:rgb(var(--bg)); border:1px solid rgb(var(--border)); border-radius:8px;
    font-size:12.5px;
}
.estate-pagination.is-visible { display:flex; }
.estate-page-size-wrap {
    display:inline-flex; align-items:center; gap:6px;
    color:rgb(var(--muted));
}
.estate-page-size-wrap select {
    padding:4px 8px; border:1px solid rgb(var(--border)); border-radius:6px;
    font-size:12.5px; background:rgb(var(--bg)); color:rgb(var(--text));
}
.estate-page-info { color:rgb(var(--muted)); }
.estate-page-info strong { color:rgb(var(--text)); }
.estate-page-controls {
    margin-left:auto; display:inline-flex; align-items:center; gap:4px;
}
.estate-page-btn {
    display:inline-flex; align-items:center; justify-content:center;
    min-width:32px; height:30px; padding:0 8px;
    border:1px solid rgb(var(--border)); background:rgb(var(--bg)); color:rgb(var(--muted));
    border-radius:6px; font-size:12.5px; font-weight:600; cursor:pointer;
    transition: all .12s ease;
}
.estate-page-btn:hover:not(:disabled) {
    border-color:rgb(var(--accent)); color:rgb(var(--accent)); background:rgb(var(--accent) / .08);
}
.estate-page-btn.is-active {
    background:rgb(var(--text)); color:rgb(var(--bg)); border-color:rgb(var(--text));
}
.estate-page-btn:disabled {
    opacity:.5; cursor:not-allowed;
}
.estate-page-ellipsis {
    color:rgb(var(--muted) / .75); padding:0 4px;
}

.estate-row-highlight { animation: estateHighlight 1.4s ease; }
@keyframes estateHighlight {
    0%   { background:rgb(var(--warn) / .12); }
    100% { background:transparent; }
}

/* Filter pills (status) — same shape as the toolbar exports */
.estate-filter-pills { display:flex; gap:6px; flex-wrap:wrap; }
.estate-filter-pill {
    padding:5px 11px; border-radius:14px; font-size:12px;
    border:1px solid rgb(var(--border)); background:rgb(var(--bg)); cursor:pointer;
    color:rgb(var(--muted)); user-select:none;
    transition: all .12s ease;
}
.estate-filter-pill:hover { border-color:rgb(var(--border)); }
.estate-filter-pill.is-active { background:rgb(var(--text)); color:rgb(var(--bg)); border-color:rgb(var(--text)); }

/* Sortable headers */
.estate-table th.is-sortable {
    cursor:pointer; user-select:none;
    transition: color .12s ease;
}
.estate-table th.is-sortable:hover { color:rgb(var(--text)); }
.estate-table th.is-numeric { text-align:right; }
.estate-table th .estate-sort-arrow {
    display:inline-block; width:10px; margin-left:6px; color:rgb(var(--border));
}
.estate-table th.is-sort-asc  .estate-sort-arrow::before { content:'\25B2'; color:rgb(var(--text)); }
.estate-table th.is-sort-desc .estate-sort-arrow::before { content:'\25BC'; color:rgb(var(--text)); }

.estate-empty-state {
    text-align:center; padding:40px 20px; color:rgb(var(--muted));
    background:rgb(var(--bg)); border:1px dashed rgb(var(--border)); border-radius:8px;
}

.estate-empty-search {
    text-align:center; padding:30px 20px; color:rgb(var(--muted));
    background:rgb(var(--bg)); border:1px dashed rgb(var(--border)); border-radius:8px;
    margin-top:10px;
}
.estate-result-count { font-size:12.5px; color:rgb(var(--muted)); margin-top:8px; }
.estate-result-count strong { color:rgb(var(--text)); }
mark.estate-hl { background:rgb(var(--accent) / .35); color:inherit; padding:0 1px; border-radius:2px; }

/* Drill-down modal */
.estatev-overlay {
    position:fixed; inset:0; background:rgb(var(--text) / .55); z-index:9000;
    display:flex; align-items:center; justify-content:center; padding:20px;
}
.estatev-dialog {
    background:rgb(var(--bg)); border-radius:10px; max-width:760px; width:100%;
    max-height:92vh; display:flex; flex-direction:column; overflow:hidden;
    box-shadow:0 10px 40px rgb(0 0 0 / .3);
}
.estatev-head {
    padding:16px 22px; border-bottom:1px solid rgb(var(--border));
    display:flex; align-items:center; gap:12px;
}
.estatev-head h4 { margin:0; font-size:18px; color:rgb(var(--text)); }
.estatev-head .sub { font-size:12.5px; color:rgb(var(--muted)); margin-top:2px; }
.estatev-head .close {
    margin-left:auto; background:none; border:none; font-size:24px;
    color:rgb(var(--muted) / .75); cursor:pointer; line-height:1;
}
.estatev-head .close:hover { color:rgb(var(--text)); }
.estatev-body {
    padding:18px 22px; overflow-y:auto; flex:1;
}
.estatev-foot {
    padding:12px 22px; border-top:1px solid rgb(var(--border)); background:rgb(var(--surface));
    display:flex; align-items:center; gap:10px;
}
.estatev-pdf {
    display:inline-flex; align-items:center; gap:6px;
    padding:6px 12px; border:1px solid rgb(var(--border)); border-radius:6px;
    background:rgb(var(--bg)); color:rgb(var(--muted)); font-size:12.5px; font-weight:600;
    text-decoration:none;
}
.estatev-pdf:hover {
    border-color:rgb(var(--danger)); color:rgb(var(--danger)); background:rgb(var(--danger) / .08);
    text-decoration:none;
}
.estatev-pdf i { color:rgb(var(--danger)); }

.estatev-section { margin-bottom:18px; }
.estatev-section h5 {
    margin:0 0 8px; font-size:12px; text-transform:uppercase; letter-spacing:.05em;
    color:rgb(var(--muted)); font-weight:700;
}
.estatev-grid {
    width:100%; border-collapse:collapse; font-size:13px;
}
.estatev-grid th, .estatev-grid td {
    padding:7px 10px; border-bottom:1px solid rgb(var(--surface)); text-align:left;
}
.estatev-grid thead th {
    background:rgb(var(--surface)); font-size:11px; text-transform:uppercase;
    letter-spacing:.04em; color:rgb(var(--muted)); font-weight:700;
}
.estatev-grid td.num { font-family:monospace; font-weight:600; color:rgb(var(--text)); }
.estatev-grid td.money { font-family:monospace; color:rgb(var(--accent-ink)); }

/* Upgrade-recommendation panel inside the drill-down modal */
.estatev-upgrade {
    display:flex; gap:14px; padding:14px 16px; margin-bottom:16px;
    background: linear-gradient(135deg, rgb(var(--accent) / .08) 0%, rgb(var(--accent) / .08) 100%);
    border:1px solid rgb(var(--accent) / .35); border-radius:10px;
}
.estatev-upgrade-icon {
    flex:0 0 38px; width:38px; height:38px; border-radius:50%;
    display:inline-flex; align-items:center; justify-content:center;
    background:rgb(var(--bg)); color:rgb(var(--accent-ink)); border:1px solid rgb(var(--accent) / .35);
    font-size:16px;
}
.estatev-upgrade-body { flex:1; }
.estatev-upgrade-title {
    font-size:11px; text-transform:uppercase; letter-spacing:.05em;
    color:rgb(var(--accent-ink)); font-weight:700; margin-bottom:2px;
}
.estatev-upgrade-headline {
    font-size:14px; font-weight:600; color:rgb(var(--accent-ink)); margin-bottom:4px;
}
.estatev-upgrade-product {
    font-size:13px; color:rgb(var(--accent-ink)); margin-bottom:8px;
}
.estatev-upgrade-savings {
    display:flex; gap:14px; flex-wrap:wrap;
}
.estatev-saving {
    background:rgb(var(--bg)); border:1px solid rgb(var(--accent) / .35); border-radius:8px;
    padding:8px 12px; min-width:130px;
}
.estatev-saving-label {
    font-size:10.5px; text-transform:uppercase; letter-spacing:.04em;
    color:rgb(var(--accent-ink)); font-weight:700; margin-bottom:2px;
}
.estatev-saving-value {
    font-size:18px; font-weight:700; color:rgb(var(--accent-ink)); line-height:1;
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
}

/* Drill-down stats row (avg / max / total / trend) */
.estatev-stats {
    display:grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap:8px; margin-bottom:10px;
}
.estatev-stat {
    background:rgb(var(--surface)); border:1px solid rgb(var(--border)); border-radius:8px;
    padding:8px 10px;
}
.estatev-stat-label {
    font-size:10.5px; text-transform:uppercase; letter-spacing:.05em;
    color:rgb(var(--muted)); font-weight:700; margin-bottom:2px;
}
.estatev-stat-value { font-size:14px; font-weight:700; color:rgb(var(--text)); line-height:1.25; }
.estatev-stat-spark .estatev-stat-value { padding-top:2px; }

.estatev-loading {
    text-align:center; padding:30px 20px; color:rgb(var(--muted) / .75);
}
</style>

<div class="estate-page">
    <div class="estate-hero">
        <div class="estate-hero-top">
            <div class="estate-hero-text">
                <h2><i class="fa-duotone fa-server" style="--fa-primary-color:rgb(var(--accent));--fa-secondary-color:rgb(var(--accent) / .55);"></i> VoIP Estate</h2>
                <p class="lede">Every tenant on your account at a glance &mdash; numbers, extensions, last bill, and recurring charge. Click any row for the full breakdown, or export the lot to CSV.</p>
            </div>
            {if $health.score !== null}
            <div class="estate-health-wrap">
                <div class="estate-health is-{$health.tone}" tabindex="0" aria-label="Estate health score">
                    <div class="estate-health-dial" style="--pct: {$health.score};">
                        <span class="estate-health-dial-num">{$health.score}<small>/100</small></span>
                    </div>
                    <div class="estate-health-body">
                        <div class="estate-health-label">Estate Health</div>
                        <div class="estate-health-grade">
                            <span class="estate-health-pill">Grade {$health.grade}</span>
                        </div>
                        <div class="estate-health-headline">{$health.headline|escape}</div>
                    </div>
                </div>
                <div class="estate-health-pop" role="tooltip">
                    <div class="estate-health-pop-title">Score breakdown</div>
                    {foreach $health.factors as $f}
                        <div class="estate-health-pop-row">
                            <div>
                                <div class="estate-health-pop-label">{$f.label|escape}</div>
                                <div class="estate-health-pop-detail">{$f.detail|escape}</div>
                            </div>
                            <div class="estate-health-pop-pts {if $f.pts > 0}is-loss{else}is-zero{/if}">
                                {if $f.pts > 0}-{$f.pts}{else}0{/if}
                            </div>
                        </div>
                    {/foreach}
                </div>
            </div>
            {/if}
        </div>

        <div class="estate-stats">
            <div class="estate-stat">
                <div class="estate-stat-head">
                    <div class="estate-stat-icon"><i class="fa-duotone fa-server"></i></div>
                    <div class="estate-stat-label">Tenants</div>
                </div>
                <div class="estate-stat-value" id="estateStatTenants">{$totals.tenants}</div>
            </div>
            <div class="estate-stat">
                <div class="estate-stat-head">
                    <div class="estate-stat-icon"><i class="fa-duotone fa-phone"></i></div>
                    <div class="estate-stat-label">Numbers</div>
                </div>
                <div class="estate-stat-value" id="estateStatDids">{$totals.dids}</div>
            </div>
            <div class="estate-stat">
                <div class="estate-stat-head">
                    <div class="estate-stat-icon"><i class="fa-duotone fa-headset"></i></div>
                    <div class="estate-stat-label">Extensions</div>
                </div>
                <div class="estate-stat-value" id="estateStatExtensions">{$totals.extensions}</div>
            </div>
            <div class="estate-stat is-money">
                <div class="estate-stat-head">
                    <div class="estate-stat-icon is-spend"><i class="fa-duotone fa-rotate"></i></div>
                    <div class="estate-stat-label">Recurring / month</div>
                </div>
                <div class="estate-stat-value" id="estateStatRecurring">£{$totals.currentRecurringMonthly|number_format:2}</div>
                <div class="estate-stat-sub">Normalised across cycles</div>
            </div>
            <div class="estate-stat is-money">
                <div class="estate-stat-head">
                    <div class="estate-stat-icon is-spend"><i class="fa-duotone fa-calendar"></i></div>
                    <div class="estate-stat-label">This Month</div>
                </div>
                <div class="estate-stat-value" id="estateStatCurrentMonth">£{$totals.currentMonth|number_format:2}</div>
                <div class="estate-stat-sub">Billed since the 1st</div>
            </div>
            <div class="estate-stat is-money">
                <div class="estate-stat-head">
                    <div class="estate-stat-icon is-fcast"><i class="fa-duotone fa-chart-line-up"></i></div>
                    <div class="estate-stat-label">Forecast</div>
                </div>
                <div class="estate-stat-value" id="estateStatForecast">£{$totals.forecast|number_format:2}{if $totals.forecastDeltaPct > 0}<span class="estate-stat-delta" title="Projected to finish above current spend">+{$totals.forecastDeltaPct}%</span>{elseif $totals.forecastDeltaPct < 0}<span class="estate-stat-delta is-down" title="Projected to finish below current spend">{$totals.forecastDeltaPct}%</span>{/if}</div>
                <div class="estate-stat-sub">Projected end of month</div>
            </div>
            <div class="estate-stat is-money">
                <div class="estate-stat-head">
                    <div class="estate-stat-icon is-spend"><i class="fa-duotone fa-receipt"></i></div>
                    <div class="estate-stat-label">Last 90 Days</div>
                </div>
                <div class="estate-stat-value" id="estateStatLast90">£{$totals.last90|number_format:2}</div>
                <div class="estate-stat-sub">Usage charges</div>
            </div>
            {if $insights.upsellSavings > 0}
            <a href="#" class="estate-stat is-action is-saving" data-filter-upsell="1" title="Show upgrade candidates">
                <div class="estate-stat-head">
                    <div class="estate-stat-icon is-saving"><i class="fa-duotone fa-piggy-bank"></i></div>
                    <div class="estate-stat-label">Potential Savings (90d)</div>
                </div>
                <div class="estate-stat-value">£{$insights.upsellSavings|number_format:2}</div>
                <div class="estate-stat-sub">Across {$insights.upsellCount} upgrade {if $insights.upsellCount == 1}candidate{else}candidates{/if}</div>
            </a>
            {else}
            <div class="estate-stat is-action is-zero">
                <div class="estate-stat-head">
                    <div class="estate-stat-icon is-saving"><i class="fa-duotone fa-piggy-bank"></i></div>
                    <div class="estate-stat-label">Potential Savings (90d)</div>
                </div>
                <div class="estate-stat-value" style="color:rgb(var(--muted) / .75);">—</div>
                <div class="estate-stat-sub">No upgrade savings identified</div>
            </div>
            {/if}
        </div>
    </div>

    {if $tenants|@count > 0}
    <div class="estate-insights">
        {if $insights.topSpender}
            <a href="#" class="estate-insight-card" data-jump-to="{$insights.topSpender.tenantId}">
                <span class="estate-insight-icon is-spend"><i class="fa-duotone fa-wallet"></i></span>
                <div class="estate-insight-body">
                    <div class="estate-insight-label">Top Spender (90d)</div>
                    <div class="estate-insight-value">{$insights.topSpender.tenantName|escape}</div>
                    <div class="estate-insight-sub">£{$insights.topSpender.last90Total|number_format:2}</div>
                </div>
            </a>
        {/if}
        {if $insights.topSpike}
            <a href="#" class="estate-insight-card" data-jump-to="{$insights.topSpike.tenantId}">
                <span class="estate-insight-icon is-spike"><i class="fa-duotone fa-arrow-trend-up"></i></span>
                <div class="estate-insight-body">
                    <div class="estate-insight-label">Biggest Spike</div>
                    <div class="estate-insight-value">{$insights.topSpike.tenantName|escape}</div>
                    <div class="estate-insight-sub">{$insights.topSpike.anomaly.ratio}× their average</div>
                </div>
            </a>
        {/if}
        {if $insights.topCalls}
            <a href="#" class="estate-insight-card" data-jump-to="{$insights.topCalls.tenantId}">
                <span class="estate-insight-icon is-calls"><i class="fa-duotone fa-phone-volume"></i></span>
                <div class="estate-insight-body">
                    <div class="estate-insight-label">Most Talkative (90d)</div>
                    <div class="estate-insight-value">{$insights.topCalls.tenantName|escape}</div>
                    <div class="estate-insight-sub">{$insights.topCalls.callMinutes90} minutes</div>
                </div>
            </a>
        {/if}
        <a href="#" class="estate-insight-card" data-filter-anomaly="1">
            <span class="estate-insight-icon is-anom"><i class="fa-duotone fa-triangle-exclamation"></i></span>
            <div class="estate-insight-body">
                <div class="estate-insight-label">Anomalies</div>
                <div class="estate-insight-value">{$insights.anomalyCount} {if $insights.anomalyCount == 1}tenant{else}tenants{/if}</div>
                <div class="estate-insight-sub">Last bill ≥ 1.5× their average</div>
            </div>
        </a>
        <a href="#" class="estate-insight-card" data-filter-empty="1">
            <span class="estate-insight-icon is-anom"><i class="fa-duotone fa-phone-slash"></i></span>
            <div class="estate-insight-body">
                <div class="estate-insight-label">No Numbers</div>
                <div class="estate-insight-value">{$insights.emptyCount} {if $insights.emptyCount == 1}tenant{else}tenants{/if}</div>
                <div class="estate-insight-sub">Tenants without any DIDs</div>
            </div>
        </a>
        <a href="#" class="estate-insight-card" data-filter-zombie="1">
            <span class="estate-insight-icon is-anom"><i class="fa-duotone fa-ghost"></i></span>
            <div class="estate-insight-body">
                <div class="estate-insight-label">Idle Tenants</div>
                <div class="estate-insight-value">{$insights.zombieCount} {if $insights.zombieCount == 1}tenant{else}tenants{/if}</div>
                <div class="estate-insight-sub">Active service, no calls in 30 days</div>
            </div>
        </a>
        <a href="#" class="estate-insight-card" data-filter-upsell="1">
            <span class="estate-insight-icon is-spend"><i class="fa-duotone fa-arrow-up-right-dots"></i></span>
            <div class="estate-insight-body">
                <div class="estate-insight-label">Consider Upgrade</div>
                <div class="estate-insight-value">{$insights.upsellCount} {if $insights.upsellCount == 1}tenant{else}tenants{/if}</div>
                <div class="estate-insight-sub">{if $insights.upsellSavings > 0}Up to £{$insights.upsellSavings|number_format:2} savings (90d){else}Near or over inclusive minute cap{/if}</div>
            </div>
        </a>
        {if $insights.duplicateCount > 0}
        <a href="#" class="estate-insight-card" data-filter-duplicate="1">
            <span class="estate-insight-icon is-anom"><i class="fa-duotone fa-clone"></i></span>
            <div class="estate-insight-body">
                <div class="estate-insight-label">Potential Duplicates</div>
                <div class="estate-insight-value">{$insights.duplicateCount} {if $insights.duplicateCount == 1}tenant{else}tenants{/if}</div>
                <div class="estate-insight-sub">{$insights.duplicateGroups} {if $insights.duplicateGroups == 1}group{else}groups{/if} with similar names</div>
            </div>
        </a>
        {/if}
    </div>

    <div class="estate-charts">
        <div class="estate-chart-card">
            <h3>Top Spenders &mdash; Last 90 Days (£)</h3>
            <div class="estate-chart-wrap"><canvas id="estateChartTop"></canvas></div>
        </div>
        {if $productSpend.labels|@count > 0}
        <div class="estate-chart-card">
            <h3>Spend by Product &mdash; Last 90 Days</h3>
            <div class="estate-chart-wrap"><canvas id="estateChartProduct"></canvas></div>
        </div>
        {/if}
        <div class="estate-chart-card is-wide">
            <h3>Estate Spend by Month (£)</h3>
            <div class="estate-chart-wrap"><canvas id="estateChartMonthly"></canvas></div>
        </div>
    </div>
    {/if}

    <div class="estate-toolbar">
        <div class="estate-search">
            <i class="fa fa-search"></i>
            <input type="search" id="estateSearch" placeholder="Search tenant, service, product…" autocomplete="off">
            <button type="button" class="estate-search-clear" title="Clear">&times;</button>
        </div>
        <div class="estate-filter-pills" id="estateFilterPills">
            <span class="estate-filter-pill is-active" data-filter="all">All</span>
            <span class="estate-filter-pill" data-filter="Active">Active</span>
            <span class="estate-filter-pill" data-filter="Pending">Pending</span>
            <span class="estate-filter-pill" data-filter="Suspended">Suspended</span>
        </div>
        <span style="margin-left:auto;"></span>
        {if $insights.upsellCount > 0}
        <button type="button" class="estate-wizard-btn" id="estateWizardOpen">
            <i class="fa-duotone fa-wand-magic-sparkles"></i>
            Optimise estate
            {if $insights.upsellSavings > 0}<span class="estate-wizard-savings">save up to £{$insights.upsellSavings|number_format:2}</span>{/if}
        </button>
        {/if}
        <div class="estate-export-menu">
            <button type="button" class="estate-export" id="estateExportToggle">
                <i class="fa-duotone fa-download"></i> Export
                <i class="fa-solid fa-chevron-down" style="margin-left:4px; font-size:9px;"></i>
            </button>
            <div class="estate-export-dropdown" id="estateExportDropdown">
                <div class="estate-export-section-label">CSV</div>
                <a href="index.php?m=resellervoip&action=estateExportTenants"   class="estate-export-item"><i class="fa-duotone fa-table"></i><div><div>Tenants summary</div><small>One row per tenant</small></div></a>
                <a href="index.php?m=resellervoip&action=estateExportDids"      class="estate-export-item"><i class="fa-duotone fa-list-tree"></i><div><div>Numbers</div><small>Every DID, flattened</small></div></a>
                <a href="index.php?m=resellervoip&action=estateExportExtensions" class="estate-export-item"><i class="fa-duotone fa-headset"></i><div><div>Extensions</div><small>Every extension, flattened</small></div></a>
                <a href="index.php?m=resellervoip&action=estateExportDaily"      class="estate-export-item"><i class="fa-duotone fa-calendar-days"></i><div><div>Daily activity</div><small>Tenant × date, last 90 days</small></div></a>
                <div class="estate-export-section-label">PDF</div>
                <a href="index.php?m=resellervoip&action=estateExportPdfSummary"      class="estate-export-item"><i class="fa-duotone fa-file-pdf"></i><div><div>Executive summary</div><small>1–2 page overview</small></div></a>
                <a href="index.php?m=resellervoip&action=estateExportPdfOptimisation" class="estate-export-item"><i class="fa-duotone fa-magnifying-glass-chart"></i><div><div>Optimisation report</div><small>Savings + cleanup actions</small></div></a>
            </div>
        </div>
    </div>

    <div id="estateActiveFilters" class="estate-active-filters">
        <span class="estate-active-label"><i class="fa-solid fa-filter"></i> Active filters:</span>
        <span class="estate-active-chips" id="estateActiveChips"></span>
        <button type="button" id="estateClearFilters" class="estate-clear-filters">Clear all</button>
    </div>

    <div id="estateTableWrap">
        {if $tenants|@count > 0}
            <table class="estate-table" id="estateTable">
                <thead>
                    <tr>
                        <th class="is-sortable" data-sort-key="tenant">Tenant<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable" data-sort-key="service">Service<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable" data-sort-key="status">Status<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable is-numeric" data-sort-key="dids">Numbers<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable is-numeric" data-sort-key="exts">Extensions<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable is-numeric" data-sort-key="ports">Ports<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable is-numeric" data-sort-key="recurring">Recurring<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable is-numeric" data-sort-key="lastbill">Last Bill<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable is-numeric" data-sort-key="month">This Month<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable is-numeric" data-sort-key="forecast">Forecast<span class="estate-sort-arrow"></span></th>
                        <th class="is-sortable is-numeric" data-sort-key="last90">Last 90 days<span class="estate-sort-arrow"></span></th>
                        <th>Trend</th>
                    </tr>
                </thead>
                <tbody id="estateTableBody">
                    {foreach $tenants as $t}
                        {assign var=searchText value="`$t.tenantName` `$t.tenantCode` `$t.serviceLabel` `$t.productName`"}
                        <tr data-tenant-id="{$t.tenantId}" data-status="{$t.serviceStatus|escape}" data-anomaly="{if $t.anomaly.isAnomaly}1{else}0{/if}" data-empty="{if $t.didsCount == 0}1{else}0{/if}" data-zombie="{if $t.isZombie}1{else}0{/if}" data-upsell="{if $t.upsell.suggested}1{else}0{/if}" data-duplicate="{if $t.duplicates && $t.duplicates|@count > 0}1{else}0{/if}"{if $t.upsell.suggested} data-upsell-product="{$t.upsell.upgrade.productName|escape}" data-upsell-state="{$t.upsell.state|escape}" data-upsell-pct="{$t.upsell.pct}" data-upsell-group="{$t.upsell.groupLabel|escape}"{if $t.upsell.savings} data-upsell-saved-90="{$t.upsell.savings.savings90|number_format:2:'.':''}" data-upsell-saved-month="{$t.upsell.savings.savingsMonthly|number_format:2:'.':''}" data-upsell-extra="{$t.upsell.savings.extraPerMonth|number_format:2:'.':''}"{/if}{/if} data-spark="{','|implode:$t.sparkline}" data-search="{$searchText|strtolower|escape:'html'}">
                            <td data-sort-value="{$t.tenantName|strtolower|escape:'html'}">
                                <div class="estate-tenant-name">{if $t.tenantName}{$t.tenantName|escape}{else}&mdash;{/if}</div>
                                <div class="estate-tenant-code">{$t.tenantCode|escape}</div>
                                {if $t.didsCount == 0}
                                    <span class="estate-no-numbers" title="This tenant has no telephone numbers configured"><i class="fa-solid fa-circle-exclamation"></i> No numbers</span>
                                {/if}
                                {if $t.isZombie}
                                    <span class="estate-zombie" title="No call activity in the last 30 days"><i class="fa-solid fa-ghost"></i> Idle</span>
                                {/if}
                                {if $t.upsell.suggested}
                                    {if $t.upsell.state == 'payg'}
                                        {assign var=upTitle value="On a pay-as-you-go plan — switching to a bundle would save money"}
                                    {else}
                                        {assign var=upTitle value="`$t.upsell.groupLabel` usage at `$t.upsell.pct`% of cap"}
                                    {/if}
                                    {if $t.upsell.upgrade && $t.upsell.upgrade.productName}{assign var=upTitle value="`$upTitle`. Consider upgrading to `$t.upsell.upgrade.productName`."}{/if}
                                    {if $t.upsell.savings && $t.upsell.savings.savings90 > 0}
                                        {assign var=upTitle value="`$upTitle` Could have saved up to £`$t.upsell.savings.savings90|number_format:2` over the last 90 days."}
                                        <span class="estate-upsell" title="{$upTitle|escape}"><i class="fa-solid fa-arrow-up-right-dots"></i> Save £{$t.upsell.savings.savings90|number_format:2}</span>
                                    {else}
                                        <span class="estate-upsell" title="{$upTitle|escape}"><i class="fa-solid fa-arrow-up-right-dots"></i> Consider upgrade</span>
                                    {/if}
                                {/if}
                                {if $t.duplicates && $t.duplicates|@count > 0}
                                    {assign var=dupTitle value="Possible duplicate of: "}
                                    {foreach $t.duplicates as $d name=dups}
                                        {if $d.match == 'sameTenant'}{assign var=dupKind value="same tenant"}{else}{assign var=dupKind value="same name"}{/if}
                                        {assign var=dupTitle value="`$dupTitle``$d.name` (`$dupKind`)"}
                                        {if !$smarty.foreach.dups.last}{assign var=dupTitle value="`$dupTitle`, "}{/if}
                                    {/foreach}
                                    <span class="estate-duplicate" title="{$dupTitle|escape}"><i class="fa-solid fa-clone"></i> Possible duplicate</span>
                                {/if}
                            </td>
                            <td data-sort-value="{$t.serviceLabel|strtolower|escape:'html'}">
                                <div>
                                    {if $t.hostingId}
                                        <a href="clientarea.php?action=productdetails&id={$t.hostingId}">{$t.serviceLabel|escape}</a>
                                    {else}
                                        {$t.serviceLabel|escape}
                                    {/if}
                                </div>
                                <div class="estate-product">{$t.productName|escape}</div>
                            </td>
                            <td data-sort-value="{$t.serviceStatus|escape}">
                                <span class="estate-status-pill estate-status-{$t.serviceStatus|escape}">{$t.serviceStatus|escape}</span>
                            </td>
                            <td style="text-align:right;" data-sort-value="{$t.didsCount}"><span class="estate-num">{$t.didsCount}</span></td>
                            <td style="text-align:right;" data-sort-value="{$t.extensionsCount}"><span class="estate-num">{$t.extensionsCount}</span></td>
                            <td style="text-align:right;" data-sort-value="{$t.ports.total}">
                                {if $t.ports.total > 0}
                                    {assign var=portsTitle value="`$t.ports.total` total · `$t.ports.success` successful · `$t.ports.inProgress` in progress · `$t.ports.failed` failed"}
                                    <span class="estate-num" title="{$portsTitle|escape}">{$t.ports.total}</span>
                                    <div class="estate-ports-mini">
                                        {if $t.ports.success > 0}<span class="estate-ports-pip is-ok"   title="{$t.ports.success} successful">{$t.ports.success}</span>{/if}
                                        {if $t.ports.inProgress > 0}<span class="estate-ports-pip is-pending" title="{$t.ports.inProgress} in progress">{$t.ports.inProgress}</span>{/if}
                                        {if $t.ports.failed > 0}<span class="estate-ports-pip is-fail" title="{$t.ports.failed} failed">{$t.ports.failed}</span>{/if}
                                    </div>
                                {else}
                                    <span class="estate-empty">&mdash;</span>
                                {/if}
                            </td>
                            <td style="text-align:right;" data-sort-value="{$t.recurringAmount}">
                                <span class="estate-money">£{$t.recurringAmount|number_format:2}</span>
                                <div class="estate-product">{$t.billingCycle|escape}</div>
                            </td>
                            <td style="text-align:right;" data-sort-value="{if $t.lastBillAmount !== null}{$t.lastBillAmount}{else}-1{/if}">
                                {if $t.lastBillAmount !== null}
                                    <span class="estate-money is-bill">£{$t.lastBillAmount|number_format:2}</span>
                                    {if $t.anomaly.isAnomaly}
                                        <button type="button" class="estate-anomaly-pill estate-anomaly-pill-btn" data-anomaly-tenant="{$t.tenantId}" title="{$t.anomaly.reason|escape}"><i class="fa-solid fa-triangle-exclamation"></i> {$t.anomaly.ratio}× <i class="fa-solid fa-chevron-right" style="font-size:8px; margin-left:2px;"></i></button>
                                    {/if}
                                    <div class="estate-product">{$t.lastBillFrom|escape}</div>
                                {else}
                                    <span class="estate-empty">No bill yet</span>
                                {/if}
                            </td>
                            <td style="text-align:right;" data-sort-value="{$t.currentMonth}">
                                {if $t.currentMonth > 0}
                                    <span class="estate-money is-bill">£{$t.currentMonth|number_format:2}</span>
                                {else}
                                    <span class="estate-empty">&mdash;</span>
                                {/if}
                            </td>
                            <td style="text-align:right;" data-sort-value="{$t.forecast}">
                                {if $t.forecast > 0}
                                    <span class="estate-money is-bill">£{$t.forecast|number_format:2}</span>
                                {else}
                                    <span class="estate-empty">&mdash;</span>
                                {/if}
                            </td>
                            <td style="text-align:right;" data-sort-value="{$t.last90Total}">
                                {if $t.last90Total > 0}
                                    <span class="estate-money is-bill">£{$t.last90Total|number_format:2}</span>
                                    {if $t.callMinutes90 > 0}
                                        <div class="estate-product">{$t.callMinutes90} min</div>
                                    {/if}
                                {else}
                                    <span class="estate-empty">&mdash;</span>
                                {/if}
                            </td>
                            <td><span class="estate-spark" data-tenant-id="{$t.tenantId}"></span></td>
                        </tr>
                    {/foreach}
                </tbody>
            </table>
            <div class="estate-result-count" id="estateResultCount">
                Showing <strong>{$tenants|@count}</strong> {if $tenants|@count == 1}tenant{else}tenants{/if}
            </div>

            <div class="estate-pagination" id="estatePagination">
                <span class="estate-page-size-wrap">
                    Show
                    <select id="estatePageSize">
                        <option value="25">25</option>
                        <option value="50" selected>50</option>
                        <option value="100">100</option>
                        <option value="0">All</option>
                    </select>
                    per page
                </span>
                <span class="estate-page-info" id="estatePageInfo"></span>
                <span class="estate-page-controls">
                    <button type="button" class="estate-page-btn" id="estatePagePrev" title="Previous page">&lsaquo; Prev</button>
                    <span id="estatePageNumbers"></span>
                    <button type="button" class="estate-page-btn" id="estatePageNext" title="Next page">Next &rsaquo;</button>
                </span>
            </div>
        {else}
            <div class="estate-empty-state">
                <i class="fa-duotone fa-server fa-3x" style="--fa-primary-color:rgb(var(--border));--fa-secondary-color:rgb(var(--border)); margin-bottom:14px;"></i>
                <p style="font-size:15px; font-weight:600; color:rgb(var(--text)); margin:0 0 6px;">No VoIP tenants on your account</p>
                <p style="font-size:13px; color:rgb(var(--muted)); margin:0;">Once a VoIP service is provisioned it'll show here automatically.</p>
            </div>
        {/if}
    </div>
</div>

{literal}
<script>
(function () {
    var $tableBody = document.getElementById('estateTableBody');
    var $search    = document.getElementById('estateSearch');
    var $clear     = document.querySelector('.estate-search-clear');
    var $resultCount = document.getElementById('estateResultCount');
    var $table     = document.getElementById('estateTable');
    var $pills     = document.getElementById('estateFilterPills');

    var currentFilter = 'all';
    var anomaliesOnly = false;
    var noNumbersOnly = false;
    var zombieOnly    = false;
    var upsellOnly    = false;
    var duplicateOnly = false;
    var currentPage   = 1;
    var pageSize      = 50;
    // Cached visibility per row — avoids reading style.display (which
    // can force layout) and skipping redundant DOM writes on sort/page
    // changes. The big win is that after a sort, ~80% of rows remain
    // visible/hidden in the same state, so we only touch the diff.
    var rowVisibility = new WeakMap();

    function escHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    // ---------- Filters → pagination ----------
    //
    // Two-pass approach: first determine which rows match every active
    // filter (search + status pill + anomaly + no-numbers), then slice
    // the matched array to the current page and toggle row visibility
    // accordingly. Sorting reorders the underlying tbody, so calling
    // applyFilters() after a sort re-paginates against the new order.
    function applyFilters() {
        if (!$tableBody) return;
        var q = $search ? ($search.value || '').toLowerCase().trim() : '';
        var rows = Array.prototype.slice.call($tableBody.children);

        var matched = [];
        rows.forEach(function (row) {
            var hay        = row.getAttribute('data-search')   || '';
            var status     = row.getAttribute('data-status')   || '';
            var isAnomaly  = row.getAttribute('data-anomaly')   === '1';
            var isEmpty    = row.getAttribute('data-empty')     === '1';
            var isZombie   = row.getAttribute('data-zombie')    === '1';
            var isUpsell   = row.getAttribute('data-upsell')    === '1';
            var isDup      = row.getAttribute('data-duplicate') === '1';
            if (q && hay.indexOf(q) === -1)                        return;
            if (currentFilter !== 'all' && status !== currentFilter) return;
            if (anomaliesOnly && !isAnomaly)                        return;
            if (noNumbersOnly && !isEmpty)                          return;
            if (zombieOnly && !isZombie)                            return;
            if (upsellOnly && !isUpsell)                            return;
            if (duplicateOnly && !isDup)                            return;
            matched.push(row);
        });

        // Compute the page slice. pageSize === 0 means "All" — show
        // every match without paginating.
        var totalMatched = matched.length;
        var effectivePageSize = pageSize > 0 ? pageSize : totalMatched;
        var totalPages = Math.max(1, Math.ceil(totalMatched / Math.max(1, effectivePageSize)));
        if (currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1)          currentPage = 1;

        var sliceStart = (currentPage - 1) * (pageSize > 0 ? pageSize : totalMatched);
        var sliceEnd   = pageSize > 0 ? sliceStart + pageSize : totalMatched;
        var visibleSet = new Set(matched.slice(sliceStart, sliceEnd));

        // One pass to set display state — only TOUCH rows that need
        // to change. With ~444 rows and SVG sparklines per row, naive
        // `style.display = ...` on every row triggers a noticeable
        // layout pass; the cache + diff makes sort/page changes
        // sub-frame fast.
        rows.forEach(function (row) {
            var shouldShow = visibleSet.has(row);
            var prevShown  = rowVisibility.get(row);
            if (prevShown !== shouldShow) {
                row.style.display = shouldShow ? '' : 'none';
                rowVisibility.set(row, shouldShow);
            }
        });

        renderActiveFilters(q);
        renderPagination(totalMatched, totalPages, sliceStart, sliceEnd);

        if ($search) {
            var $wrap = $search.parentElement;
            if (q) $wrap.classList.add('has-value');
            else   $wrap.classList.remove('has-value');
        }

        if ($resultCount) {
            var bits = ['Showing <strong>' + visibleSet.size + '</strong> of <strong>' + totalMatched + '</strong> ' + (totalMatched === 1 ? 'tenant' : 'tenants')];
            if (q) { bits.push('matching <strong>"' + escHtml(q) + '"</strong>'); }
            if (currentFilter !== 'all') { bits.push('with status <strong>' + escHtml(currentFilter) + '</strong>'); }
            if (anomaliesOnly) { bits.push('<strong>(anomalies only)</strong>'); }
            if (noNumbersOnly) { bits.push('<strong>(no-number tenants only)</strong>'); }
            $resultCount.innerHTML = bits.join(' ');
        }
    }

    // Page numbers: always show first + last, plus a window around the
    // current page. Ellipses fill the gaps so the row never grows
    // beyond ~9 buttons regardless of total page count.
    function buildPageNumbers(totalPages, current) {
        if (totalPages <= 1) return [];
        var nums = new Set([1, totalPages, current, current - 1, current + 1]);
        // Edges always show 1, 2 + last-1, last for nicer reading.
        if (totalPages >= 2) nums.add(2).add(totalPages - 1);
        var sorted = Array.from(nums).filter(function (n) { return n >= 1 && n <= totalPages; }).sort(function (a, b) { return a - b; });
        var out = [];
        for (var i = 0; i < sorted.length; i++) {
            if (i > 0 && sorted[i] - sorted[i - 1] > 1) out.push('…');
            out.push(sorted[i]);
        }
        return out;
    }

    function renderPagination(totalMatched, totalPages, sliceStart, sliceEnd) {
        var $pag    = document.getElementById('estatePagination');
        var $info   = document.getElementById('estatePageInfo');
        var $nums   = document.getElementById('estatePageNumbers');
        var $prev   = document.getElementById('estatePagePrev');
        var $next   = document.getElementById('estatePageNext');
        if (!$pag) return;

        // Hide pagination entirely when there's nothing to page.
        if (totalMatched === 0) {
            $pag.classList.remove('is-visible');
            return;
        }
        $pag.classList.add('is-visible');

        var displayedFrom = totalMatched === 0 ? 0 : sliceStart + 1;
        var displayedTo   = Math.min(sliceEnd, totalMatched);
        if ($info) {
            $info.innerHTML = 'Showing <strong>' + displayedFrom + '–' + displayedTo + '</strong> of <strong>' + totalMatched + '</strong>';
        }

        if ($prev) $prev.disabled = currentPage <= 1;
        if ($next) $next.disabled = currentPage >= totalPages;

        if ($nums) {
            $nums.innerHTML = buildPageNumbers(totalPages, currentPage).map(function (n) {
                if (n === '…') return '<span class="estate-page-ellipsis">…</span>';
                var isActive = (n === currentPage);
                return '<button type="button" class="estate-page-btn' + (isActive ? ' is-active' : '') + '" data-page="' + n + '">' + n + '</button>';
            }).join('');
        }
    }

    // ---------- Active filters banner ----------
    function renderActiveFilters(q) {
        var $banner = document.getElementById('estateActiveFilters');
        var $chips  = document.getElementById('estateActiveChips');
        if (!$banner || !$chips) return;

        var chips = [];
        if (q && q.length) {
            chips.push({ kind: 'search', label: 'Search: "' + q + '"' });
        }
        if (currentFilter !== 'all') {
            chips.push({ kind: 'status', label: 'Status: ' + currentFilter });
        }
        if (anomaliesOnly) {
            chips.push({ kind: 'anomaly', label: 'Anomalies only' });
        }
        if (noNumbersOnly) {
            chips.push({ kind: 'empty', label: 'No-number tenants only' });
        }
        if (zombieOnly) {
            chips.push({ kind: 'zombie', label: 'Idle tenants only' });
        }
        if (upsellOnly) {
            chips.push({ kind: 'upsell', label: 'Upgrade candidates only' });
        }
        if (duplicateOnly) {
            chips.push({ kind: 'duplicate', label: 'Potential duplicates only' });
        }

        if (chips.length === 0) {
            $banner.classList.remove('is-visible');
            return;
        }
        $banner.classList.add('is-visible');
        $chips.innerHTML = chips.map(function (c) {
            return '<span class="estate-filter-chip" data-clear="' + c.kind + '">' +
                       escHtml(c.label) +
                       '<button type="button" title="Remove filter" aria-label="Remove">&times;</button>' +
                   '</span>';
        }).join('');
    }

    function clearOneFilter(kind) {
        switch (kind) {
            case 'search':
                if ($search) { $search.value = ''; }
                break;
            case 'status':
                currentFilter = 'all';
                if ($pills) {
                    $pills.querySelectorAll('.estate-filter-pill').forEach(function (p) {
                        p.classList.toggle('is-active', p.getAttribute('data-filter') === 'all');
                    });
                }
                break;
            case 'anomaly':
                anomaliesOnly = false;
                document.querySelectorAll('.estate-insight-card[data-filter-anomaly]').forEach(function (c) {
                    c.classList.remove('is-active');
                });
                break;
            case 'empty':
                noNumbersOnly = false;
                document.querySelectorAll('.estate-insight-card[data-filter-empty]').forEach(function (c) {
                    c.classList.remove('is-active');
                });
                break;
            case 'zombie':
                zombieOnly = false;
                document.querySelectorAll('.estate-insight-card[data-filter-zombie]').forEach(function (c) {
                    c.classList.remove('is-active');
                });
                break;
            case 'upsell':
                upsellOnly = false;
                document.querySelectorAll('.estate-insight-card[data-filter-upsell]').forEach(function (c) {
                    c.classList.remove('is-active');
                });
                break;
            case 'duplicate':
                duplicateOnly = false;
                document.querySelectorAll('.estate-insight-card[data-filter-duplicate]').forEach(function (c) {
                    c.classList.remove('is-active');
                });
                break;
        }
        // Caller is responsible for resetting page + calling applyFilters()
        // — lets us batch multiple `clearOneFilter` calls in "Clear all"
        // without re-running applyFilters once per filter cleared.
    }

    document.addEventListener('click', function (e) {
        var chip = e.target.closest('.estate-filter-chip[data-clear]');
        if (chip) {
            e.preventDefault();
            clearOneFilter(chip.getAttribute('data-clear'));
            currentPage = 1;
            applyFilters();
            return;
        }
        if (e.target.id === 'estateClearFilters') {
            e.preventDefault();
            ['search', 'status', 'anomaly', 'empty', 'zombie', 'upsell', 'duplicate'].forEach(clearOneFilter);
            currentPage = 1;
            applyFilters();
        }
    });

    // Helper: any filter change resets us to page 1 — otherwise the
    // user can be stranded on page 5 of a list that just shrank to 1.
    function applyFiltersResetPage() { currentPage = 1; applyFilters(); }

    if ($search) {
        $search.addEventListener('input',  applyFiltersResetPage);
        $search.addEventListener('search', applyFiltersResetPage);
    }
    if ($clear) {
        $clear.addEventListener('click', function () {
            $search.value = '';
            applyFiltersResetPage();
            $search.focus();
        });
    }
    if ($pills) {
        $pills.addEventListener('click', function (e) {
            var pill = e.target.closest('.estate-filter-pill');
            if (!pill) return;
            $pills.querySelectorAll('.estate-filter-pill').forEach(function (p) { p.classList.remove('is-active'); });
            pill.classList.add('is-active');
            currentFilter = pill.getAttribute('data-filter') || 'all';
            applyFiltersResetPage();
        });
    }

    // Pagination — page-size selector, prev/next, numbered buttons.
    var $pageSize   = document.getElementById('estatePageSize');
    var $pagePrev   = document.getElementById('estatePagePrev');
    var $pageNext   = document.getElementById('estatePageNext');
    var $pageNums   = document.getElementById('estatePageNumbers');

    if ($pageSize) {
        $pageSize.addEventListener('change', function () {
            pageSize    = parseInt(this.value, 10) || 0;
            currentPage = 1;
            applyFilters();
        });
    }
    if ($pagePrev) {
        $pagePrev.addEventListener('click', function () {
            if (currentPage > 1) { currentPage--; applyFilters(); window.scrollTo({ top: 0, behavior: 'smooth' }); }
        });
    }
    if ($pageNext) {
        $pageNext.addEventListener('click', function () {
            currentPage++; applyFilters(); window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
    if ($pageNums) {
        $pageNums.addEventListener('click', function (e) {
            var btn = e.target.closest('.estate-page-btn[data-page]');
            if (!btn) return;
            var n = parseInt(btn.getAttribute('data-page'), 10) || 1;
            currentPage = n;
            applyFilters();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // ---------- Column sort ----------
    //
    // Performance notes:
    //   - extract sort keys ONCE per row up front (otherwise the
    //     comparator re-reads `getAttribute` O(n log n) times)
    //   - decide numeric vs string mode once for the whole column
    //   - detach the tbody during reorder so we get one reflow at the
    //     end, not one per appendChild
    function sortRows(columnIndex, direction) {
        if (!$tableBody) return;

        var rows = Array.prototype.slice.call($tableBody.children);
        var n = rows.length;
        if (n < 2) return;

        var keyed = new Array(n);
        var allNumeric = true;
        for (var i = 0; i < n; i++) {
            var cell = rows[i].cells[columnIndex];
            var raw  = cell ? (cell.getAttribute('data-sort-value') || '') : '';
            var num  = parseFloat(raw);
            var isNum = !isNaN(num) && raw !== '';
            if (!isNum) allNumeric = false;
            keyed[i] = { row: rows[i], num: num, str: raw.toLowerCase(), isNum: isNum };
        }

        var dir = direction === 'asc' ? 1 : -1;
        keyed.sort(allNumeric
            ? function (a, b) { return (a.num - b.num) * dir; }
            : function (a, b) {
                if (a.str === b.str) return 0;
                return (a.str < b.str ? -1 : 1) * dir;
            }
        );

        // Detach so reordering doesn't trigger a reflow per appendChild.
        var parent  = $tableBody.parentNode;
        var sibling = $tableBody.nextSibling;
        parent.removeChild($tableBody);
        for (var j = 0; j < n; j++) {
            $tableBody.appendChild(keyed[j].row);
        }
        parent.insertBefore($tableBody, sibling);
    }

    if ($table) {
        $table.querySelectorAll('thead th.is-sortable').forEach(function (th) {
            th.addEventListener('click', function () {
                var current = th.classList.contains('is-sort-asc') ? 'asc'
                            : th.classList.contains('is-sort-desc') ? 'desc'
                            : null;
                var next = (current === 'asc') ? 'desc' : 'asc';
                $table.querySelectorAll('thead th').forEach(function (other) {
                    other.classList.remove('is-sort-asc', 'is-sort-desc');
                });
                th.classList.add(next === 'asc' ? 'is-sort-asc' : 'is-sort-desc');
                sortRows(th.cellIndex, next);
                // Sort changed the order — re-apply pagination so the
                // first page reflects the new top of the list.
                currentPage = 1;
                applyFilters();
            });
        });
    }

    // Initial pagination pass on page load — without this the table
    // renders with every row visible until the user touches a filter.
    applyFilters();

    // ---------- Drill-down modal ----------
    // Build the optional "Upgrade Recommendation" panel from row data
    // attributes. Returns an empty string when the tenant isn't a
    // candidate (no panel rendered).
    function buildUpgradePanel(row) {
        if (!row || row.getAttribute('data-upsell') !== '1') return '';
        var product   = row.getAttribute('data-upsell-product')      || '';
        var state     = row.getAttribute('data-upsell-state')        || '';
        var saved90   = parseFloat(row.getAttribute('data-upsell-saved-90'))    || 0;
        var savedMo   = parseFloat(row.getAttribute('data-upsell-saved-month')) || 0;
        var extra     = parseFloat(row.getAttribute('data-upsell-extra'))       || 0;
        var pct       = parseInt(row.getAttribute('data-upsell-pct'), 10)       || 0;
        var group     = row.getAttribute('data-upsell-group')        || '';

        var headline = state === 'payg'
            ? 'On a pay-as-you-go plan'
            : (group ? group + ' usage at ' + pct + '% of cap' : 'Approaching inclusive minute cap');

        var html = '<div class="estatev-upgrade">';
        html +=     '<div class="estatev-upgrade-icon"><i class="fa-duotone fa-arrow-up-right-dots"></i></div>';
        html +=     '<div class="estatev-upgrade-body">';
        html +=         '<div class="estatev-upgrade-title">Upgrade recommendation</div>';
        html +=         '<div class="estatev-upgrade-headline">' + escHtml(headline) + '</div>';
        if (product) {
            html +=     '<div class="estatev-upgrade-product">Switch to <strong>' + escHtml(product) + '</strong>';
            if (extra > 0) { html += ' (+£' + extra.toFixed(2) + '/month).'; } else { html += '.'; }
            html +=     '</div>';
        }
        if (saved90 > 0 || savedMo > 0) {
            html +=     '<div class="estatev-upgrade-savings">';
            if (saved90 > 0) {
                html +=     '<div class="estatev-saving"><div class="estatev-saving-label">Could have saved (90d)</div><div class="estatev-saving-value">£' + saved90.toFixed(2) + '</div></div>';
            }
            if (savedMo > 0) {
                html +=     '<div class="estatev-saving"><div class="estatev-saving-label">Could save this month</div><div class="estatev-saving-value">£' + savedMo.toFixed(2) + '</div></div>';
            }
            html +=     '</div>';
        }
        html +=     '</div>';
        html += '</div>';
        return html;
    }

    function openDrillDown(tenantId, tenantName, tenantCode) {
        document.querySelectorAll('.estatev-overlay').forEach(function (el) { el.remove(); });

        var dlg = document.createElement('div');
        dlg.className = 'estatev-overlay';
        dlg.innerHTML =
            '<div class="estatev-dialog">' +
                '<div class="estatev-head">' +
                    '<div>' +
                        '<h4>' + escHtml(tenantName || 'Tenant') + '</h4>' +
                        '<div class="sub">' + escHtml(tenantCode || ('#' + tenantId)) + '</div>' +
                    '</div>' +
                    '<button type="button" class="close" aria-label="Close">&times;</button>' +
                '</div>' +
                '<div class="estatev-body">' +
                    '<div class="estatev-loading"><i class="fa-duotone fa-spinner fa-spin-pulse fa-2xl" style="--fa-primary-color:rgb(var(--accent));--fa-secondary-color:rgb(var(--accent) / .55);"></i><p style="margin-top:10px;font-size:13px;">Loading tenant detail…</p></div>' +
                '</div>' +
                '<div class="estatev-foot">' +
                    '<a href="index.php?m=resellervoip&action=estateExportPdfTenant&tenantId=' + encodeURIComponent(tenantId) + '"' +
                       ' class="btn btn-default btn-sm estatev-pdf" target="_blank" rel="noopener">' +
                        '<i class="fa-duotone fa-file-pdf"></i> Download PDF report' +
                    '</a>' +
                    '<span style="flex:1"></span>' +
                    '<button type="button" class="btn btn-primary btn-sm estatev-close">Close</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(dlg);

        var close = function () {
            document.removeEventListener('keydown', escClose);
            dlg.remove();
        };
        var escClose = function (e) { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', escClose);
        dlg.addEventListener('click', function (e) { if (e.target === dlg) close(); });
        dlg.querySelectorAll('.close, .estatev-close').forEach(function (btn) {
            btn.addEventListener('click', close);
        });

        // Fetch tenant detail
        var fd = new FormData();
        fd.append('tenantId', tenantId);
        fetch('index.php?m=resellervoip&action=estateTenantDetail', {
            method:      'POST',
            body:        fd,
            credentials: 'same-origin',
        }).then(function (r) { return r.json(); }).then(function (resp) {
            var $body = dlg.querySelector('.estatev-body');
            if (!resp || !resp.ok) {
                $body.innerHTML = '<div class="estatev-loading"><p>' + escHtml((resp && resp.error) || 'Failed to load tenant detail.') + '</p></div>';
                return;
            }

            var html = '';

            // Upgrade recommendation — shown first when the row is
            // flagged as an upsell candidate so it leads the customer's
            // attention. Pulls savings figures off the row's data-*
            // attributes (no extra round-trip).
            var sourceRow = document.querySelector('#estateTableBody tr[data-tenant-id="' + tenantId + '"]');
            html += buildUpgradePanel(sourceRow);

            // Numbers section
            html += '<div class="estatev-section">';
            html += '<h5>Numbers (' + (resp.dids ? resp.dids.length : 0) + ')</h5>';
            if (resp.dids && resp.dids.length) {
                html += '<table class="estatev-grid"><thead><tr><th>Number</th><th>Comment</th><th style="text-align:right;">Recording</th></tr></thead><tbody>';
                resp.dids.forEach(function (d) {
                    var combined = (d.country || '') + (d.area || '') + (d.number || '');
                    html += '<tr>';
                    html += '<td class="num">' + escHtml(combined) + '</td>';
                    html += '<td>' + escHtml(d.comment || '') + '</td>';
                    html += '<td style="text-align:right;">' + (d.recording === 'yes' ? 'On' : 'Off') + '</td>';
                    html += '</tr>';
                });
                html += '</tbody></table>';
            } else {
                html += '<p class="estate-empty" style="margin:4px 0 0;">No numbers on this tenant yet.</p>';
            }
            html += '</div>';

            // Extensions section
            html += '<div class="estatev-section">';
            html += '<h5>Extensions (' + (resp.extensions ? resp.extensions.length : 0) + ')</h5>';
            if (resp.extensions && resp.extensions.length) {
                html += '<table class="estatev-grid"><thead><tr><th>Ext</th><th>Name</th></tr></thead><tbody>';
                resp.extensions.forEach(function (e) {
                    html += '<tr>';
                    html += '<td class="num">' + escHtml(e.number || '') + '</td>';
                    html += '<td>' + escHtml(e.name || '') + '</td>';
                    html += '</tr>';
                });
                html += '</tbody></table>';
            } else {
                html += '<p class="estate-empty" style="margin:4px 0 0;">No extensions configured.</p>';
            }
            html += '</div>';

            // Recent bills section — header carries quick stats
            // (avg, max, total, trend sparkline) so the customer sees
            // the shape of usage without scanning the full table.
            html += '<div class="estatev-section">';
            html += '<h5>Recent Bills (' + (resp.bills ? resp.bills.length : 0) + ')</h5>';
            if (resp.bills && resp.bills.length) {
                var amounts = resp.bills.map(function (b) { return parseFloat(b.amount) || 0; });
                var sumAmt  = amounts.reduce(function (a, b) { return a + b; }, 0);
                var avgAmt  = sumAmt / amounts.length;
                var maxAmt  = Math.max.apply(null, amounts);
                var totalCalls = resp.bills.reduce(function (sum, b) { return sum + (parseInt(b.callsLength, 10) || 0); }, 0);

                html += '<div class="estatev-stats">';
                html +=     '<div class="estatev-stat"><div class="estatev-stat-label">Average</div><div class="estatev-stat-value">£' + avgAmt.toFixed(2) + '</div></div>';
                html +=     '<div class="estatev-stat"><div class="estatev-stat-label">Highest</div><div class="estatev-stat-value">£' + maxAmt.toFixed(2) + '</div></div>';
                html +=     '<div class="estatev-stat"><div class="estatev-stat-label">Total</div><div class="estatev-stat-value">£' + sumAmt.toFixed(2) + '</div></div>';
                html +=     '<div class="estatev-stat"><div class="estatev-stat-label">Total Calls</div><div class="estatev-stat-value">' + Math.round(totalCalls / 60) + ' min</div></div>';
                html +=     '<div class="estatev-stat estatev-stat-spark"><div class="estatev-stat-label">Trend</div><div class="estatev-stat-value" id="estatevStatSpark"></div></div>';
                html += '</div>';

                html += '<table class="estatev-grid"><thead><tr><th>Period</th><th style="text-align:right;">Calls</th><th style="text-align:right;">Amount</th></tr></thead><tbody>';
                resp.bills.forEach(function (b) {
                    var period = (b.dateFrom || '') + (b.dateTo ? ' → ' + b.dateTo : '');
                    var amt = (typeof b.amount === 'number') ? b.amount.toFixed(2) : '0.00';
                    var mins = Math.round((parseInt(b.callsLength, 10) || 0) / 60);
                    var amtClass = (parseFloat(b.amount) || 0) >= avgAmt * 1.5 ? ' style="color:rgb(var(--warn)); font-weight:700;"' : '';
                    html += '<tr>';
                    html += '<td>' + escHtml(period) + '</td>';
                    html += '<td style="text-align:right;">' + mins + ' min</td>';
                    html += '<td class="money" style="text-align:right;"' + amtClass + '>£' + amt + '</td>';
                    html += '</tr>';
                });
                html += '</tbody></table>';
            } else {
                html += '<p class="estate-empty" style="margin:4px 0 0;">No bills tracked yet.</p>';
            }
            html += '</div>';

            $body.innerHTML = html;

            // After the markup lands, fill the sparkline placeholder.
            // Bills come newest-first; reverse so the line reads
            // chronologically left → right.
            var sparkHolder = $body.querySelector('#estatevStatSpark');
            if (sparkHolder && resp.bills && resp.bills.length > 1) {
                var pts = resp.bills.map(function (b) { return parseFloat(b.amount) || 0; }).reverse();
                drawSparkline(sparkHolder, pts);
            }
        }).catch(function () {
            var $body = dlg.querySelector('.estatev-body');
            if ($body) $body.innerHTML = '<div class="estatev-loading"><p>Network error — please try again.</p></div>';
        });
    }

    if ($tableBody) {
        $tableBody.addEventListener('click', function (e) {
            // Anomaly pill takes precedence — opens the spike drilldown
            // rather than the full tenant viewer.
            var pill = e.target.closest('.estate-anomaly-pill-btn[data-anomaly-tenant]');
            if (pill) {
                e.preventDefault();
                e.stopPropagation();
                var row = pill.closest('tr[data-tenant-id]');
                var tName = (row && row.querySelector('.estate-tenant-name') || {}).textContent || '';
                openAnomalyDrilldown(pill.getAttribute('data-anomaly-tenant'), tName.trim());
                return;
            }

            var row = e.target.closest('tr[data-tenant-id]');
            if (!row) return;
            // Don't intercept clicks on links (e.g. service link).
            if (e.target.closest('a')) return;
            var tenantId   = row.getAttribute('data-tenant-id');
            var tenantName = (row.querySelector('.estate-tenant-name') || {}).textContent || '';
            var tenantCode = (row.querySelector('.estate-tenant-code') || {}).textContent || '';
            openDrillDown(tenantId, tenantName.trim(), tenantCode.trim());
        });
    }

    // ---------- Optimisation Wizard ----------
    //
    // Multi-step modal that walks the customer through:
    //   1. REVIEW   — list of upgrade picks, all pre-checked, customer
    //                 can deselect any they don't want.
    //   2. CONFIRM  — summary of what will happen + caveat copy about
    //                 prorated invoices being generated.
    //   3. SUBMIT   — fires UpgradeProduct LocalAPI per selected row.
    //   4. RESULTS  — successes (with invoice links) and failures.
    //
    // The dialog is built fresh each open + torn down on close so we
    // don't leak state between sessions.
    var $wizardOpen = document.getElementById('estateWizardOpen');
    if ($wizardOpen) {
        $wizardOpen.addEventListener('click', openOptimisationWizard);
    }

    function openOptimisationWizard() {
        var dlg = document.createElement('div');
        dlg.className = 'estatev-overlay';
        dlg.innerHTML =
            '<div class="estatev-dialog" role="dialog" aria-modal="true" style="max-width:880px;">' +
                '<div class="estatev-head">' +
                    '<div>' +
                        '<div class="estatev-title"><i class="fa-duotone fa-wand-magic-sparkles" style="color:rgb(var(--accent));"></i> Optimise estate</div>' +
                        '<div class="estatev-sub">Switch eligible tenants to better-fit plans in a few clicks. Each upgrade goes through the standard checkout — prorated invoices will be generated for you to pay.</div>' +
                    '</div>' +
                    '<button type="button" class="close" aria-label="Close">&times;</button>' +
                '</div>' +
                '<div class="estatev-body"><div class="estatev-loading"><i class="fa-duotone fa-spinner fa-spin"></i><p>Loading recommendations…</p></div></div>' +
                '<div class="estatev-foot" id="estateWizFoot">' +
                    '<button type="button" class="btn btn-default btn-sm estatev-close">Cancel</button>' +
                    '<span style="flex:1"></span>' +
                    '<button type="button" class="btn btn-primary btn-sm" id="estateWizPrimary" disabled>Continue</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(dlg);

        var step = 'review';
        var picks = [];           // server-returned picks, full list
        var selected = {};        // hostingId -> bool (kept across step transitions)
        var totals = {};          // server-returned totals

        var close = function () {
            document.removeEventListener('keydown', escClose);
            dlg.remove();
        };
        var escClose = function (e) { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', escClose);
        dlg.addEventListener('click', function (e) { if (e.target === dlg) close(); });
        dlg.querySelectorAll('.close, .estatev-close').forEach(function (btn) { btn.addEventListener('click', close); });

        var $body    = dlg.querySelector('.estatev-body');
        var $primary = dlg.querySelector('#estateWizPrimary');

        function stepRail(active) {
            var labels = ['Review', 'Confirm', 'Apply', 'Done'];
            var html = '<div class="estate-wiz-steps">';
            for (var i = 0; i < labels.length; i++) {
                var cls = i < active ? 'is-done' : (i === active ? 'is-active' : '');
                html += '<div class="estate-wiz-step ' + cls + '">';
                html +=     '<div class="estate-wiz-step-num">' + (i < active ? '✓' : (i + 1)) + '</div>';
                html +=     '<div class="estate-wiz-step-label">' + labels[i] + '</div>';
                html += '</div>';
                if (i < labels.length - 1) html += '<div class="estate-wiz-step-bar"></div>';
            }
            html += '</div>';
            return html;
        }

        function selectedPicks() {
            return picks.filter(function (p) { return selected[p.hostingId]; });
        }

        function renderImpact() {
            var sel = selectedPicks();
            var savings90 = 0, savingsMonthly = 0, extraPerMonth = 0;
            sel.forEach(function (p) {
                savings90      += p.savings90 || 0;
                savingsMonthly += p.savingsMonthly || 0;
                extraPerMonth  += p.extraPerMonth || 0;
            });
            return '<div class="estate-wiz-impact">' +
                '<div class="estate-wiz-impact-stat is-saving"><div class="estate-wiz-impact-stat-label">90d call savings</div><div class="estate-wiz-impact-stat-value">£' + savings90.toFixed(2) + '</div></div>' +
                '<div class="estate-wiz-impact-stat is-saving"><div class="estate-wiz-impact-stat-label">Monthly call savings</div><div class="estate-wiz-impact-stat-value">£' + savingsMonthly.toFixed(2) + '</div></div>' +
                '<div class="estate-wiz-impact-stat is-cost"><div class="estate-wiz-impact-stat-label">Extra recurring / month</div><div class="estate-wiz-impact-stat-value">£' + extraPerMonth.toFixed(2) + '</div></div>' +
            '</div>';
        }

        function renderReview() {
            if (!picks.length) {
                $body.innerHTML = stepRail(0) +
                    '<div class="estate-wiz-empty"><i class="fa-duotone fa-circle-check"></i><p>No upgrade candidates right now &mdash; the estate looks well-fit. Come back when usage patterns change.</p></div>';
                $primary.disabled = true;
                $primary.textContent = 'Continue';
                return;
            }

            var html = stepRail(0);
            html += '<div class="estate-wiz-toolbar">' +
                        '<span><strong>' + picks.length + '</strong> candidate' + (picks.length === 1 ? '' : 's') + ' &mdash; tick the ones you want to upgrade.</span>' +
                        '<span class="est-spacer"></span>' +
                        '<a data-wiz-act="all">Select all</a> · <a data-wiz-act="none">Clear</a> · <a data-wiz-act="best5">Top 5 only</a>' +
                    '</div>';
            html += '<div id="estateWizList">';
            picks.forEach(function (p) {
                var label = p.tenantName || p.tenantCode || ('Service #' + p.hostingId);
                var checked = selected[p.hostingId] ? 'checked' : '';
                html += '<label class="estate-wiz-pick ' + (selected[p.hostingId] ? 'is-checked' : '') + '" data-host="' + p.hostingId + '">';
                html +=     '<input type="checkbox" ' + checked + ' data-host="' + p.hostingId + '">';
                html +=     '<div class="estate-wiz-pick-body">';
                html +=         '<div>' +
                                    '<div class="estate-wiz-pick-tenant">' + escHtml(label) + '</div>' +
                                    '<div class="estate-wiz-pick-current">on <em>' + escHtml(p.currentProduct || '') + '</em> · £' + (p.currentRecurring || 0).toFixed(2) + ' / ' + escHtml(p.billingCycle || '') + '</div>' +
                                '</div>';
                html +=         '<div>' +
                                    '<div class="estate-wiz-pick-target">→ ' + escHtml(p.newProductName || '') + '</div>' +
                                    '<div class="estate-wiz-pick-target-sub">' + (p.state === 'payg' ? 'Currently pay-as-you-go' : (p.pct + '% of inclusive minutes used')) + '</div>' +
                                '</div>';
                html +=         '<div class="estate-wiz-pick-saving">' +
                                    'Save £' + (p.savings90 || 0).toFixed(2) +
                                    '<small>over last 90 days</small>' +
                                '</div>';
                html +=     '</div>';
                html += '</label>';
            });
            html += '</div>';
            html += renderImpact();
            $body.innerHTML = html;

            // Wire selection toggles
            $body.querySelectorAll('input[type=checkbox][data-host]').forEach(function (input) {
                input.addEventListener('change', function () {
                    selected[input.getAttribute('data-host')] = input.checked;
                    var pick = input.closest('.estate-wiz-pick');
                    if (pick) pick.classList.toggle('is-checked', input.checked);
                    refreshImpact();
                });
            });
            // Toolbar shortcuts
            $body.querySelectorAll('a[data-wiz-act]').forEach(function (a) {
                a.addEventListener('click', function (e) {
                    e.preventDefault();
                    var act = a.getAttribute('data-wiz-act');
                    selected = {};
                    if (act === 'all')   { picks.forEach(function (p) { selected[p.hostingId] = true; }); }
                    if (act === 'best5') { picks.slice(0, 5).forEach(function (p) { selected[p.hostingId] = true; }); }
                    renderReview();
                });
            });

            $primary.textContent = 'Continue';
            refreshPrimary();
        }

        function refreshImpact() {
            var slot = $body.querySelector('.estate-wiz-impact');
            if (slot) slot.outerHTML = renderImpact();
            refreshPrimary();
        }

        function refreshPrimary() {
            $primary.disabled = selectedPicks().length === 0;
        }

        function renderConfirm() {
            var sel = selectedPicks();
            var html = stepRail(1);
            var consolidatedNote = sel.length >= 2
                ? ' Once they\'re generated you\'ll get a single "Pay all" button that consolidates them into one combined invoice for checkout.'
                : '';
            html += '<div class="estate-wiz-notes">' +
                        '<strong>What happens next:</strong> a prorated upgrade order is created for each selected service through the standard WHMCS checkout.' + consolidatedNote +
                        ' The new plan takes effect once the invoice is paid &mdash; nothing changes on your service before then.' +
                    '</div>';
            html += '<div style="font-size:13px; color:rgb(var(--muted)); margin-bottom:8px;">You\'re upgrading <strong>' + sel.length + '</strong> ' + (sel.length === 1 ? 'service' : 'services') + ':</div>';
            html += '<div>';
            sel.forEach(function (p) {
                var label = p.tenantName || p.tenantCode || ('Service #' + p.hostingId);
                html += '<div class="estate-wiz-result-row">' +
                            '<div class="icon"><i class="fa-duotone fa-arrow-right-arrow-left"></i></div>' +
                            '<div class="body">' +
                                '<div class="label">' + escHtml(label) + '</div>' +
                                '<div class="meta">' + escHtml(p.currentProduct) + ' → <strong>' + escHtml(p.newProductName) + '</strong></div>' +
                            '</div>' +
                            '<div class="estate-wiz-pick-saving">Save £' + (p.savings90 || 0).toFixed(2) + '<small>90d</small></div>' +
                        '</div>';
            });
            html += '</div>';
            html += renderImpact();
            $body.innerHTML = html;

            $primary.disabled = false;
            $primary.textContent = sel.length === 1
                ? 'Generate 1 invoice'
                : 'Generate ' + sel.length + ' upgrade orders';
        }

        function renderApplying(progress) {
            progress = progress || { done: 0, total: 0 };
            var pctText = progress.total > 0
                ? (' (' + progress.done + ' / ' + progress.total + ')')
                : '';
            $body.innerHTML = stepRail(2) +
                '<div class="estatev-loading">' +
                    '<i class="fa-duotone fa-spinner fa-spin"></i>' +
                    '<p>Submitting upgrade orders to WHMCS' + escHtml(pctText) + '&hellip; large batches are sent in chunks of 50 to keep things responsive.</p>' +
                '</div>';
            $primary.disabled = true;
            $primary.textContent = 'Working…';
        }

        function renderResults(combined) {
            var s = combined.successes || [];
            var f = combined.failures  || [];
            var invoiceIds = s.map(function (r) { return r.invoiceId; }).filter(function (id) { return !!id; });

            var html = stepRail(3);

            if (s.length) {
                html += '<div style="font-size:13px; color:rgb(var(--accent-ink)); margin:6px 0 10px;">' +
                            '<i class="fa-solid fa-circle-check"></i> ' + s.length + ' upgrade order' + (s.length === 1 ? '' : 's') + ' generated.' +
                        '</div>';

                // Mass Pay CTA — when there are 2+ invoices, WHMCS can
                // consolidate them into a single invoice via its built-in
                // mass-pay flow. Saves customers with 100s of tenants from
                // having to pay each upgrade separately.
                //
                // The form itself is built via DOM at click-time rather
                // than rendered as HTML — WHMCS's CSRF middleware
                // regex-injects a hidden token input into any literal
                // POST form tag it sees in the response, which would
                // break the JS string by inserting a raw newline.
                if (invoiceIds.length >= 2) {
                    html += '<button type="button" class="btn btn-primary estate-wiz-masspay" style="width:100%; padding:12px; font-size:14px; background:rgb(var(--accent)); border-color:rgb(var(--accent)); margin-bottom:14px;" data-invoice-ids="' + invoiceIds.join(',') + '">' +
                                '<i class="fa-duotone fa-credit-card"></i>&nbsp; ' +
                                'Pay all ' + invoiceIds.length + ' invoices with one combined invoice' +
                            '</button>' +
                            '<div style="font-size:12px; color:rgb(var(--muted)); margin-bottom:14px; text-align:center;">' +
                                'WHMCS will roll the ' + invoiceIds.length + ' upgrade invoices into a single consolidated invoice you can pay in one go.' +
                            '</div>' +
                            '<details style="margin-bottom:14px;">' +
                                '<summary style="cursor:pointer; font-size:12.5px; color:rgb(var(--muted)); font-weight:600;">Show individual invoices (' + s.length + ')</summary>' +
                                '<div style="margin-top:8px;" id="estateWizSuccessList"></div>' +
                            '</details>';
                }

                var listHtml = '';
                s.forEach(function (r) {
                    listHtml += '<div class="estate-wiz-result-row is-success">' +
                                    '<div class="icon"><i class="fa-solid fa-circle-check"></i></div>' +
                                    '<div class="body">' +
                                        '<div class="label">' + escHtml(r.label || ('Service #' + r.hostingId)) + '</div>' +
                                        '<div class="meta">Order #' + (r.orderId || '—') + (r.invoiceId ? ' · Invoice #' + r.invoiceId : '') + '</div>' +
                                    '</div>' +
                                    (r.invoiceId ? '<a href="viewinvoice.php?id=' + r.invoiceId + '" target="_blank" class="invoice-link">Pay invoice</a>' : '') +
                                '</div>';
                });
                // When mass-pay isn't surfaced (single invoice or none),
                // render the list inline; otherwise it sits inside the
                // <details> drawer above.
                if (invoiceIds.length < 2) {
                    html += listHtml;
                }
            }

            if (f.length) {
                html += '<div style="font-size:13px; color:rgb(var(--danger)); margin:14px 0 8px;">' +
                            '<i class="fa-solid fa-triangle-exclamation"></i> ' + f.length + ' upgrade' + (f.length === 1 ? '' : 's') + ' couldn\'t be applied. ' +
                            'Try again, or get in touch and we\'ll sort it.' +
                        '</div>';
                f.forEach(function (r) {
                    html += '<div class="estate-wiz-result-row is-failure">' +
                                '<div class="icon"><i class="fa-solid fa-circle-xmark"></i></div>' +
                                '<div class="body">' +
                                    '<div class="label">' + escHtml(r.label || ('Service #' + r.hostingId)) + '</div>' +
                                    '<div class="meta">' + escHtml(r.error || 'Unknown error') + '</div>' +
                                '</div>' +
                            '</div>';
                });
            }
            if (!s.length && !f.length) {
                html += '<div class="estate-wiz-empty"><i class="fa-duotone fa-circle-info"></i><p>No upgrades were processed.</p></div>';
            }
            $body.innerHTML = html;

            // Mass-pay button → build the form via DOM and submit. The
            // form is created here (not as HTML in the response) so the
            // WHMCS CSRF middleware doesn't intercept it and inject a
            // token <input> into the middle of a JS string literal.
            var $massBtn = $body.querySelector('.estate-wiz-masspay');
            if ($massBtn) {
                $massBtn.addEventListener('click', function () {
                    var ids = ($massBtn.getAttribute('data-invoice-ids') || '').split(',').filter(Boolean);
                    if (!ids.length) return;
                    var form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'viewinvoice.php';
                    form.target = '_blank';
                    var actInput = document.createElement('input');
                    actInput.type = 'hidden'; actInput.name = 'action'; actInput.value = 'masspay';
                    form.appendChild(actInput);
                    var idsInput = document.createElement('input');
                    idsInput.type = 'hidden'; idsInput.name = 'invoiceids'; idsInput.value = ids.join(',');
                    form.appendChild(idsInput);
                    document.body.appendChild(form);
                    form.submit();
                    document.body.removeChild(form);
                });
            }

            // Populate the collapsible detail drawer if we used mass-pay.
            var $detailList = $body.querySelector('#estateWizSuccessList');
            if ($detailList) {
                var listHtml2 = '';
                s.forEach(function (r) {
                    listHtml2 += '<div class="estate-wiz-result-row is-success">' +
                                     '<div class="icon"><i class="fa-solid fa-circle-check"></i></div>' +
                                     '<div class="body">' +
                                         '<div class="label">' + escHtml(r.label || ('Service #' + r.hostingId)) + '</div>' +
                                         '<div class="meta">Order #' + (r.orderId || '—') + (r.invoiceId ? ' · Invoice #' + r.invoiceId : '') + '</div>' +
                                     '</div>' +
                                     (r.invoiceId ? '<a href="viewinvoice.php?id=' + r.invoiceId + '" target="_blank" class="invoice-link">Pay invoice</a>' : '') +
                                 '</div>';
                });
                $detailList.innerHTML = listHtml2;
            }

            $primary.disabled = false;
            $primary.textContent = 'Done';
        }

        // Async/await chunking — sends batches of 50 sequentially so a
        // 500-tenant batch never hits one PHP timeout, with progress
        // updates between chunks. Linear shape (no closures-in-closures)
        // — easier on parsers and on us.
        async function applySelectedChunked(sel) {
            var CHUNK_SIZE = 50;
            var combined = { successes: [], failures: [] };
            var done = 0;

            for (var start = 0; start < sel.length; start += CHUNK_SIZE) {
                var batch = sel.slice(start, start + CHUNK_SIZE);
                renderApplying({ done: done, total: sel.length });

                var fd = new FormData();
                var picks = batch.map(function (p) {
                    return {
                        hostingId: p.hostingId,
                        newProductId: p.newProductId,
                        label: p.tenantName || p.tenantCode
                    };
                });
                fd.append('picks', JSON.stringify(picks));

                var resp = null;
                try {
                    var r = await fetch('index.php?m=resellervoip&action=estateOptimisationApply', {
                        method: 'POST', body: fd, credentials: 'same-origin'
                    });
                    resp = await r.json();
                } catch (e) {
                    resp = null;
                }

                if (!resp || !resp.ok) {
                    var errMsg = (resp && resp.error) || 'Failed to submit upgrade.';
                    for (var i = 0; i < batch.length; i++) {
                        combined.failures.push({
                            hostingId: batch[i].hostingId,
                            label: batch[i].tenantName || batch[i].tenantCode,
                            error: errMsg
                        });
                    }
                } else {
                    combined.successes = combined.successes.concat(resp.successes || []);
                    combined.failures  = combined.failures.concat(resp.failures  || []);
                }
                done += batch.length;
            }

            step = 'results';
            renderResults(combined);
        }

        function nextStep() {
            if (step === 'review' && selectedPicks().length > 0) {
                step = 'confirm'; renderConfirm(); return;
            }
            if (step === 'confirm') {
                step = 'applying';
                applySelectedChunked(selectedPicks());
                return;
            }
            if (step === 'applying' || step === 'results') {
                close();
                window.location.reload();
                return;
            }
        }
        $primary.addEventListener('click', nextStep);

        // Kick things off — fetch candidates.
        fetch('index.php?m=resellervoip&action=estateOptimisationStart', {
            method: 'POST', credentials: 'same-origin',
        }).then(function (r) { return r.json(); }).then(function (resp) {
            if (!resp || !resp.ok) {
                $body.innerHTML = '<div class="estate-wiz-empty"><i class="fa-solid fa-circle-xmark" style="color:rgb(var(--danger));"></i><p>' + escHtml((resp && resp.error) || 'Failed to load upgrade candidates.') + '</p></div>';
                return;
            }
            picks  = resp.picks || [];
            totals = resp.totals || {};
            // Default selection: every candidate ticked. Customer can
            // deselect anything they don't want.
            picks.forEach(function (p) { selected[p.hostingId] = true; });
            renderReview();
        }).catch(function () {
            $body.innerHTML = '<div class="estate-wiz-empty"><i class="fa-solid fa-circle-xmark" style="color:rgb(var(--danger));"></i><p>Network error &mdash; please try again.</p></div>';
        });
    }

    // Anomaly drill-down dialog — chart-first view of the daily activity
    // for the bill period that triggered the spike, with a comparison
    // against the same span just before. Lets the customer see *which*
    // days drove the spike rather than just "your last bill was 2x".
    function openAnomalyDrilldown(tenantId, tenantName) {
        var dlg = document.createElement('div');
        dlg.className = 'estatev-overlay';
        dlg.innerHTML =
            '<div class="estatev-dialog estatev-anomaly" role="dialog" aria-modal="true">' +
                '<div class="estatev-head">' +
                    '<div>' +
                        '<div class="estatev-title"><i class="fa-solid fa-triangle-exclamation" style="color:rgb(var(--warn));"></i> Spend Spike &mdash; ' + escHtml(tenantName) + '</div>' +
                        '<div class="estatev-sub">Daily breakdown of the bill period that flagged as anomalous.</div>' +
                    '</div>' +
                    '<button type="button" class="close" aria-label="Close">&times;</button>' +
                '</div>' +
                '<div class="estatev-body"><div class="estatev-loading"><i class="fa-duotone fa-spinner fa-spin"></i><p>Loading…</p></div></div>' +
                '<div class="estatev-foot">' +
                    '<span style="flex:1"></span>' +
                    '<button type="button" class="btn btn-primary btn-sm estatev-close">Close</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(dlg);

        var close = function () {
            document.removeEventListener('keydown', escClose);
            dlg.remove();
        };
        var escClose = function (e) { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', escClose);
        dlg.addEventListener('click', function (e) { if (e.target === dlg) close(); });
        dlg.querySelectorAll('.close, .estatev-close').forEach(function (btn) { btn.addEventListener('click', close); });

        var fd = new FormData();
        fd.append('tenantId', tenantId);
        fetch('index.php?m=resellervoip&action=estateAnomalyDetail', {
            method: 'POST', body: fd, credentials: 'same-origin',
        }).then(function (r) { return r.json(); }).then(function (resp) {
            var $body = dlg.querySelector('.estatev-body');
            if (!resp || !resp.ok) {
                $body.innerHTML = '<div class="estatev-loading"><p>' + escHtml((resp && resp.error) || 'Failed to load anomaly detail.') + '</p></div>';
                return;
            }

            var latest = resp.latest || { days: [] };
            var prior  = resp.prior  || { days: [] };
            var anom   = resp.anomaly || {};
            var days   = latest.days || [];

            // Spike threshold for highlighting individual days — anything
            // ≥ 1.5× the period's daily average AND > £0.50 in absolute
            // terms. Mirrors the bill-level detector so the rules feel
            // consistent across the dashboard.
            var avgDay = days.length ? (latest.total / days.length) : 0;
            var deltaTotal = (latest.total || 0) - (prior.total || 0);
            var deltaPct = prior.total > 0 ? Math.round((deltaTotal / prior.total) * 100) : 0;

            var html = '';

            // Summary tiles
            html += '<div class="estate-anom-summary">';
            html +=     '<div class="estate-anom-stat is-anom"><div class="estate-anom-stat-label">Bill total</div><div class="estate-anom-stat-value">£' + (latest.total || 0).toFixed(2) + '</div><div class="estate-anom-stat-sub">' + escHtml(latest.from) + ' &rarr; ' + escHtml(latest.to) + '</div></div>';
            html +=     '<div class="estate-anom-stat"><div class="estate-anom-stat-label">Prior period</div><div class="estate-anom-stat-value">£' + (prior.total || 0).toFixed(2) + '</div><div class="estate-anom-stat-sub">' + escHtml(prior.from) + ' &rarr; ' + escHtml(prior.to) + '</div></div>';
            html +=     '<div class="estate-anom-stat ' + (deltaTotal > 0 ? 'is-anom' : 'is-down') + '"><div class="estate-anom-stat-label">vs Prior</div><div class="estate-anom-stat-value">' + (deltaTotal >= 0 ? '+' : '') + '£' + Math.abs(deltaTotal).toFixed(2) + '</div><div class="estate-anom-stat-sub">' + (deltaPct >= 0 ? '+' : '') + deltaPct + '%</div></div>';
            html +=     '<div class="estate-anom-stat is-anom"><div class="estate-anom-stat-label">Ratio</div><div class="estate-anom-stat-value">' + (anom.ratio || 0).toFixed(2) + '×</div><div class="estate-anom-stat-sub">vs 6-bill average £' + (anom.avg || 0).toFixed(2) + '</div></div>';
            html += '</div>';

            // Bar chart of daily amounts
            html += '<div class="estate-anom-chart-wrap"><canvas id="estateAnomChart"></canvas></div>';

            // Daily breakdown table — spike days highlighted in amber.
            html += '<div class="estatev-section">';
            html +=     '<h5>Daily breakdown</h5>';
            if (days.length) {
                html += '<table class="estate-anom-table"><thead><tr><th>Date</th><th class="num">Calls</th><th class="num">Minutes</th><th class="num">Amount</th></tr></thead><tbody>';
                days.forEach(function (d) {
                    var calls = (d.inboundCalls || 0) + (d.outboundCalls || 0);
                    var mins = Math.round((d.callsLength || 0) / 60);
                    var isSpike = avgDay > 0 && (d.amount || 0) >= avgDay * 1.5 && (d.amount || 0) > 0.5;
                    html += '<tr class="' + (isSpike ? 'is-spike' : '') + '">';
                    html +=     '<td>' + escHtml(d.date) + (isSpike ? ' <i class="fa-solid fa-triangle-exclamation" title="Above the period average" style="color:rgb(var(--warn)); font-size:10px;"></i>' : '') + '</td>';
                    html +=     '<td class="num">' + calls + '</td>';
                    html +=     '<td class="num">' + mins + '</td>';
                    html +=     '<td class="num">£' + (d.amount || 0).toFixed(2) + '</td>';
                    html += '</tr>';
                });
                html += '</tbody></table>';
            } else {
                html += '<p class="estate-empty" style="margin:4px 0 0;">No daily activity recorded for this period.</p>';
            }
            html += '</div>';

            $body.innerHTML = html;

            // Render the bar chart now that the canvas exists in the DOM.
            var canvas = $body.querySelector('#estateAnomChart');
            if (canvas && days.length && typeof Chart !== 'undefined') {
                var labels  = days.map(function (d) { return d.date.slice(5); });   // MM-DD
                var amounts = days.map(function (d) { return d.amount || 0; });
                // Highlight spike days in amber, regular days in teal.
                var bg = amounts.map(function (a) {
                    return (avgDay > 0 && a >= avgDay * 1.5 && a > 0.5) ? window.gvColor('warn') : window.gvColor('accent', .65);
                });
                var border = amounts.map(function (a) {
                    return (avgDay > 0 && a >= avgDay * 1.5 && a > 0.5) ? window.gvColor('warn') : window.gvColor('accent-ink');
                });
                new Chart(canvas.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{ data: amounts, backgroundColor: bg, borderColor: border, borderWidth: 1.2, borderRadius: 3 }]
                    },
                    options: {
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                callbacks: {
                                    label: function (c) { return '£' + (c.raw || 0).toFixed(2); },
                                    afterLabel: function (c) {
                                        var d = days[c.dataIndex] || {};
                                        var calls = (d.inboundCalls || 0) + (d.outboundCalls || 0);
                                        return calls + ' calls · ' + Math.round((d.callsLength || 0) / 60) + ' min';
                                    }
                                }
                            }
                        },
                        scales: {
                            x: { ticks: { font: { size: 10 } }, grid: { display: false } },
                            y: { ticks: { callback: function (v) { return '£' + v; }, font: { size: 10 } }, grid: { color: window.gvColor('border') } },
                        },
                        maintainAspectRatio: false,
                    }
                });
            }
        }).catch(function () {
            var $body = dlg.querySelector('.estatev-body');
            if ($body) $body.innerHTML = '<div class="estatev-loading"><p>Network error &mdash; please try again.</p></div>';
        });
    }

    // ---------- Insight cards (clickable) ----------
    function jumpToTenant(tenantId) {
        var row = document.querySelector('#estateTableBody tr[data-tenant-id="' + tenantId + '"]');
        if (!row) return;
        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
        row.classList.remove('estate-row-highlight');
        // Force reflow so the highlight animation re-fires on repeat clicks.
        void row.offsetWidth;
        row.classList.add('estate-row-highlight');
    }

    // Potential Savings stat card mirrors the upsell filter — clicking
    // it scrolls down to the table and shows only upgrade candidates.
    var $savingsCard = document.querySelector('.estate-stat.is-action[data-filter-upsell]');
    if ($savingsCard) {
        $savingsCard.addEventListener('click', function (e) {
            e.preventDefault();
            upsellOnly = !upsellOnly;
            document.querySelectorAll('.estate-insight-card[data-filter-upsell]').forEach(function (c) {
                c.classList.toggle('is-active', upsellOnly);
            });
            applyFiltersResetPage();
            // Smooth-scroll to the table so the filter result is visible.
            var $tableWrap = document.getElementById('estateTableWrap');
            if ($tableWrap && upsellOnly) { $tableWrap.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
        });
    }

    document.querySelectorAll('.estate-insight-card').forEach(function (card) {
        card.addEventListener('click', function (e) {
            e.preventDefault();
            var jumpId = card.getAttribute('data-jump-to');
            if (jumpId) { jumpToTenant(jumpId); return; }
            if (card.getAttribute('data-filter-anomaly') === '1') {
                anomaliesOnly = !anomaliesOnly;
                card.classList.toggle('is-active', anomaliesOnly);
                applyFiltersResetPage();
                return;
            }
            if (card.getAttribute('data-filter-empty') === '1') {
                noNumbersOnly = !noNumbersOnly;
                card.classList.toggle('is-active', noNumbersOnly);
                applyFiltersResetPage();
                return;
            }
            if (card.getAttribute('data-filter-zombie') === '1') {
                zombieOnly = !zombieOnly;
                card.classList.toggle('is-active', zombieOnly);
                applyFiltersResetPage();
                return;
            }
            if (card.getAttribute('data-filter-upsell') === '1') {
                upsellOnly = !upsellOnly;
                card.classList.toggle('is-active', upsellOnly);
                applyFiltersResetPage();
                return;
            }
            if (card.getAttribute('data-filter-duplicate') === '1') {
                duplicateOnly = !duplicateOnly;
                card.classList.toggle('is-active', duplicateOnly);
                applyFiltersResetPage();
            }
        });
    });

    // Export dropdown — open/close + click-outside-to-close.
    var $exportToggle = document.getElementById('estateExportToggle');
    var $exportMenu   = document.getElementById('estateExportDropdown');
    if ($exportToggle && $exportMenu) {
        $exportToggle.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $exportMenu.classList.toggle('is-open');
        });
        document.addEventListener('click', function (e) {
            if ($exportMenu.classList.contains('is-open') && !$exportMenu.contains(e.target) && e.target !== $exportToggle) {
                $exportMenu.classList.remove('is-open');
            }
        });
        // Each item is just a normal link — close after navigation.
        $exportMenu.addEventListener('click', function (e) {
            if (e.target.closest('.estate-export-item')) {
                $exportMenu.classList.remove('is-open');
            }
        });
    }

    // ---------- Sparklines (per-row) ----------
    function drawSparkline(container, points) {
        var w = 70, h = 22;
        if (!points || points.length < 2) {
            container.innerHTML = '<span style="color:rgb(var(--border)); font-size:11px;">—</span>';
            return;
        }
        var min   = Math.min.apply(null, points);
        var max   = Math.max.apply(null, points);
        var range = (max - min) || 1;
        var step  = w / (points.length - 1);
        var pad   = 2;
        var ih    = h - (pad * 2);
        var coords = points.map(function (p, i) {
            var x = i * step;
            var y = pad + (ih - ((p - min) / range) * ih);
            return x.toFixed(2) + ',' + y.toFixed(2);
        });
        var lastY  = parseFloat(coords[coords.length - 1].split(',')[1]);
        // Trend colour: rising = warm amber, flat/falling = brand teal.
        var trend  = points[points.length - 1] - points[0];
        var stroke = trend > 0 ? window.gvColor('warn') : window.gvColor('accent-ink');
        var fill   = trend > 0 ? window.gvColor('warn', .10) : window.gvColor('accent', .10);
        var areaPts = '0,' + h + ' ' + coords.join(' ') + ' ' + w + ',' + h;
        container.innerHTML =
            '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none" aria-hidden="true">' +
                '<polygon points="' + areaPts + '" fill="' + fill + '"></polygon>' +
                '<polyline points="' + coords.join(' ') + '" fill="none" stroke="' + stroke + '" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"></polyline>' +
                '<circle cx="' + w.toFixed(2) + '" cy="' + lastY.toFixed(2) + '" r="2" fill="' + stroke + '"></circle>' +
            '</svg>';
    }

    document.querySelectorAll('#estateTableBody tr[data-tenant-id]').forEach(function (row) {
        var raw = row.getAttribute('data-spark') || '';
        var pts = raw === '' ? [] : raw.split(',').map(function (n) { return parseFloat(n) || 0; });
        var holder = row.querySelector('.estate-spark');
        if (holder) drawSparkline(holder, pts);
    });

    // ---------- Charts (Chart.js v3.5 already loaded by index.tpl) ----------
    if (typeof Chart !== 'undefined') {

        // Top spenders — pull straight from the rendered table so the
        // chart always matches what the user can see and sort. We look
        // up the column by its data-sort-key on the header rather than
        // hardcoding an index, otherwise adding/removing a column (eg.
        // Ports) silently breaks the chart by reading the wrong cell.
        var headerCells = $table ? Array.prototype.slice.call($table.querySelectorAll('thead th')) : [];
        var last90Index = -1;
        for (var hi = 0; hi < headerCells.length; hi++) {
            if (headerCells[hi].getAttribute('data-sort-key') === 'last90') { last90Index = hi; break; }
        }

        var topRows = last90Index < 0 ? [] :
            Array.prototype.slice.call(document.querySelectorAll('#estateTableBody tr'))
                .map(function (row) {
                    var cell   = row.cells[last90Index];
                    var amount = parseFloat(cell ? (cell.getAttribute('data-sort-value') || '0') : '0') || 0;
                    var name   = (row.querySelector('.estate-tenant-name') || {}).textContent || '';
                    return { name: name.trim(), amount: amount };
                })
                .filter(function (r) { return r.amount > 0; })
                .sort(function (a, b) { return b.amount - a.amount; })
                .slice(0, 10);

        var topCanvas = document.getElementById('estateChartTop');
        if (topCanvas && topRows.length) {
            new Chart(topCanvas.getContext('2d'), {
                type: 'bar',
                data: {
                    labels:   topRows.map(function (r) { return r.name; }),
                    datasets: [{
                        data:            topRows.map(function (r) { return r.amount; }),
                        backgroundColor: window.gvColor('accent', .55),
                        borderColor:     window.gvColor('accent-ink'),
                        borderWidth:     1.5,
                        borderRadius:    4,
                    }]
                },
                options: {
                    indexAxis: 'y',
                    plugins:   {
                        legend: { display: false },
                        tooltip: { callbacks: { label: function (c) { return '£' + (c.raw || 0).toFixed(2); } } }
                    },
                    scales: {
                        x: { ticks: { callback: function (v) { return '£' + v; }, font: { size: 11 } }, grid: { color: window.gvColor('border') } },
                        y: { ticks: { font: { size: 11 } }, grid: { display: false } },
                    },
                    maintainAspectRatio: false,
                }
            });
        }

        var monthlyCanvas = document.getElementById('estateChartMonthly');
        var monthlyLabels = {/literal}{$monthly.labels|@json_encode}{literal};
        var monthlyData   = {/literal}{$monthly.totals|@json_encode}{literal};
        if (monthlyCanvas && monthlyLabels && monthlyData && monthlyLabels.length) {
            new Chart(monthlyCanvas.getContext('2d'), {
                type: 'line',
                data: {
                    labels:   monthlyLabels,
                    datasets: [{
                        data:                  monthlyData,
                        borderColor:           window.gvColor('accent'),
                        backgroundColor:       window.gvColor('accent', .15),
                        fill:                  true,
                        tension:               0.35,
                        pointRadius:           3,
                        pointBackgroundColor:  window.gvColor('accent'),
                        pointBorderColor:      window.gvColor('bg'),
                        pointBorderWidth:      1.5,
                        borderWidth:           2,
                    }]
                },
                options: {
                    plugins: {
                        legend: { display: false },
                        tooltip: { callbacks: { label: function (c) { return '£' + (c.raw || 0).toFixed(2); } } }
                    },
                    scales: {
                        x: { ticks: { font: { size: 11 } }, grid: { display: false } },
                        y: { ticks: { callback: function (v) { return '£' + v; }, font: { size: 11 } }, grid: { color: window.gvColor('border') } },
                    },
                    maintainAspectRatio: false,
                }
            });
        }

        // Spend-by-product doughnut. Teal-only palette per the brand
        // rule — same hue staircased through saturation/lightness so
        // each slice is distinguishable without breaking palette.
        var productCanvas = document.getElementById('estateChartProduct');
        var productLabels = {/literal}{$productSpend.labels|@json_encode}{literal};
        var productData   = {/literal}{$productSpend.totals|@json_encode}{literal};
        if (productCanvas && productLabels && productData && productLabels.length) {
            var palette = [window.gvColor('accent'),window.gvColor('accent'),window.gvColor('accent'),window.gvColor('accent', .55),window.gvColor('accent'),window.gvColor('accent', .55),window.gvColor('border')];
            new Chart(productCanvas.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels:   productLabels,
                    datasets: [{
                        data:            productData,
                        backgroundColor: productLabels.map(function (_, i) { return palette[i % palette.length]; }),
                        borderColor:     window.gvColor('bg'),
                        borderWidth:     2,
                    }]
                },
                options: {
                    cutout: '58%',
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: { font: { size: 10.5 }, boxWidth: 10, boxHeight: 10, padding: 8 }
                        },
                        tooltip: {
                            callbacks: {
                                label: function (c) {
                                    var total = c.dataset.data.reduce(function (s, v) { return s + v; }, 0);
                                    var pct   = total > 0 ? Math.round((c.raw / total) * 100) : 0;
                                    return c.label + ': £' + (c.raw || 0).toFixed(2) + '  (' + pct + '%)';
                                }
                            }
                        }
                    },
                    maintainAspectRatio: false,
                }
            });
        }
    }
})();
</script>
{/literal}
