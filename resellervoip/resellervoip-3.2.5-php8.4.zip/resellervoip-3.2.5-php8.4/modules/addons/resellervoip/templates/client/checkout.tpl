{$paletteStyle}
<style>
/* ===== Theme-independent palette and card =====
   The styles below use colour variables (R G B triplets) that the portal
   they were written for defines in its theme. They are defined here, on the
   picker itself, so it looks the same on any WHMCS theme and never changes
   the theme's own. */
.rv-picker, .rv-cart-999, .rv-minutes {
  --accent: 42 120 214; --accent-2: 16 150 120; --accent-ink: 24 86 160; --accent-contrast: 255 255 255;
  --bg: 255 255 255; --surface: 248 249 251; --border: 229 231 235; --text: 26 26 46; --muted: 107 114 128;
  --warn: 217 119 6; --danger: 220 38 38; --font-display: inherit; --font-mono: ui-monospace, Menlo, Consolas, monospace;
}
html.dark .rv-picker, html.dark .rv-cart-999, html.dark .rv-minutes {
  --bg: 15 23 42; --surface: 30 41 59; --border: 51 65 85; --text: 226 232 240; --muted: 148 163 184;
}
.rv-picker {
  display: block; margin: 20px 0; padding: 18px; background: rgb(var(--bg)); color: rgb(var(--text));
  border: 1px solid rgb(var(--border)); border-radius: 12px; box-shadow: 0 1px 2px rgba(0,0,0,.04);
}
.rv-picker > .panel-body { padding: 0; }
.rv-picker .panel-body { padding: 0; }
.rv-picker h4.title { color: rgb(var(--text)); }
/* Solid controls whatever the theme does with selects and Bootstrap-select buttons. */
.rv-picker select.form-control,
.rv-picker .bootstrap-select > .dropdown-toggle,
.rv-picker .bootstrap-select > .btn,
.rv-picker input[type="text"] {
  background: rgb(var(--bg)) !important; color: rgb(var(--text)) !important;
  border: 1.5px solid rgb(var(--border)) !important; border-radius: 8px !important; box-shadow: none !important;
  min-height: 42px; text-align: left;
}
.rv-picker .bootstrap-select > .dropdown-toggle .filter-option { color: rgb(var(--text)); }
.rv-picker .bootstrap-select .dropdown-menu { background: rgb(var(--bg)); color: rgb(var(--text)); border: 1px solid rgb(var(--border)); }
.rv-picker .bootstrap-select .dropdown-menu li a, .rv-picker .bootstrap-select .dropdown-menu .dropdown-item { color: rgb(var(--text)); }
.rv-picker .bootstrap-select .dropdown-menu li a:hover, .rv-picker .bootstrap-select .dropdown-menu .dropdown-item:hover { background: rgb(var(--surface)); }
.rv-picker .bootstrap-select .bs-searchbox input { background: rgb(var(--bg)) !important; color: rgb(var(--text)) !important; }
.rv-picker .phone-filter-group > label { color: rgb(var(--muted)); }
.rv-picker .quality-toggle label { background: rgb(var(--bg)); }
.rv-picker a { color: rgb(var(--accent-ink)); }

/* ===== PHONE NUMBER SELECTOR - MODERN REDESIGN =====
   Tiles share the chosen-pill DNA: 999px pill radius, 1.5px accent
   border, accent text on transparent bg when idle, flip to solid
   accent fill + contrast text when selected. No flag — region is
   already conveyed by the dropdown header. */

.phoneItem > span {
  position: relative;
  display: flex;
  width: 100%;
  height: 44px;
  border-radius: 999px;
  font-weight: 700;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  align-items: center;
  justify-content: flex-start;
  margin: 0;
  cursor: pointer;
  border: 1.5px solid rgb(var(--accent));
  background: rgb(var(--bg));
  color: rgb(var(--accent-ink));
  user-select: none;
  transition: background .15s ease, border-color .15s ease, color .15s ease, box-shadow .15s ease;
  padding: 0 14px;
  gap: 6px;
}
html.dark .phoneItem > span {
  color: rgb(var(--accent));
}

.phoneItem > span:hover {
  background: rgb(var(--accent) / .08);
  box-shadow: 0 2px 8px rgb(var(--accent) / .15);
}

.phoneItem.selected > span {
  border-color: rgb(var(--accent)) !important;
  background-color: rgb(var(--accent)) !important;
  color: rgb(var(--accent-contrast)) !important;
}

/* Grid tile: × badge on selected numbers in the grid (the upper
   "All Numbers" area). Stays as a small corner indicator. */
.phoneItem.selected > span::after {
  position: absolute;
  content: '\d7';
  font-size: 11px;
  color: rgb(var(--bg));
  display: flex;
  align-items: center;
  justify-content: center;
  height: 16px;
  width: 16px;
  background: rgb(var(--danger));
  top: -6px;
  right: -6px;
  border-radius: 50%;
  font-weight: 700;
}

/* Chosen Phone Numbers chips — the CANONICAL pill style. Solid
   accent background, contrast text, 999px radius, body + explicit
   × on the right. This is the template every other pill in the
   picker (grid tile + count chip) is now styled to match. */
.selectedPhoneItem {
  position: relative;
  display: inline-flex !important;
  align-items: stretch;
  border-radius: 999px;
  border: 1.5px solid rgb(var(--accent));
  background-color: rgb(var(--accent));
  overflow: visible;
}
.selectedPhoneItem-body {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px 8px 14px;
  font-weight: 700;
  font-size: 12.5px;
  color: rgb(var(--accent-contrast));
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.selectedPhoneItem-body small {
  font-size: 10.5px;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
  opacity: .9;
}
.selectedPhoneItem-star {
  font-size: 12px;
  line-height: 1;
  margin-right: 1px;
}
.selectedPhoneItem-remove {
  background: rgb(var(--accent-contrast) / .18);
  border: 0;
  color: rgb(var(--accent-contrast));
  padding: 0 12px;
  font-size: 13px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: background .15s ease, color .15s ease;
  border-left: 1px solid rgb(var(--accent-contrast) / .2);
}
.selectedPhoneItem-remove:hover,
.selectedPhoneItem-remove:focus-visible {
  background: rgb(var(--danger));
  color: #fff;
  outline: none;
}

#selectedPhones {
  display: flex !important;
  flex-wrap: wrap !important;
  gap: 8px !important;
}
#selectedPhones .selectedPhoneItem {
  flex: 0 0 auto !important;
  width: auto !important;
  margin: 0 !important;
  float: none !important;
}

/* Gold variant — solid warn instead of accent. */
.selectedGold {
  border-color: rgb(var(--warn)) !important;
  background-color: rgb(var(--warn)) !important;
}
.selectedGold .selectedPhoneItem-body {
  color: rgb(var(--accent-contrast));
}

.custom-disable {
  background-color: rgb(var(--surface)) !important;
  opacity: 1;
  cursor: not-allowed;
  pointer-events: none;
}

.custom-disable::-webkit-outer-spin-button,
.custom-disable::-webkit-inner-spin-button {
  -webkit-appearance: none;
}

/* Section titles */
.title {
  margin-top: 20px;
  margin-bottom: 12px;
  color: rgb(var(--text));
  font-size: 16px;
  font-weight: 700;
}

#phonesContent > .selected > span {
  border-color: rgb(var(--accent));
  background-color: rgb(var(--accent) / .08);
}

/* Override Bootstrap `.row` negative margins — they were pushing
   the grid 15px wider than the surrounding hero / filter bar /
   header strip and adding a horizontal scrollbar. Switching to a
   proper flex grid with `gap` aligns the canvas edges with the
   rest of the cart UI. */
#phonesContent.row,
#phonesContent {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin: 0;
  padding: 4px 0;
  min-height: 300px;
  overflow-x: hidden;
  overflow-y: auto;
  box-sizing: border-box;
  width: 100%;
}

#phonesContent .phoneItem {
  /* Drop the Bootstrap col padding — gap above handles spacing. */
  padding: 0;
  margin: 0;
  flex: 0 0 calc(25% - 6px);
  max-width: calc(25% - 6px);
  box-sizing: border-box;
}

/* Empty-state panels ("No numbers…" / "No gold numbers…") are .col-12 inside the
   flex grid — force them full-width so their centred content actually centres
   instead of shrinking to content width and pinning to the left. */
#phonesContent .col-12 {
  flex: 1 0 100%;
  max-width: 100%;
  width: 100%;
}
/* Centre the empty-state icon. It carries an inline display:block, but the
   FontAwesome kit renders it as an <svg> (a block replaced element ignores
   text-align, so it pinned left). Force inline-block so the parent's
   text-align:center centres it — works for both the <i> and <svg> forms. */
#phonesContent .col-12 > i,
#phonesContent .col-12 > svg {
  display: inline-block !important;
  float: none;
}
/* Tablet — 3 per row */
@media (max-width: 1199px) {
  #phonesContent .phoneItem {
    flex: 0 0 calc(33.333% - 6px);
    max-width: calc(33.333% - 6px);
  }
}

/* Bootstrap select fixes */
.lagom .bootstrap-select .dropdown-menu .inner.show { overflow-x: hidden; }
.lagom .bootstrap-select .dropdown-menu:not(.show) { display: none; }
.lagom .form-control.dropdown-toggle {
  background: url('./templates/lagom2/assets/img/arrow-drop.svg');
  background-position-y: 50%;
  background-position-x: calc(100% - 11px);
  background-repeat: no-repeat;
}

/* Loader */
#phonesContentWrap { position: relative; }

.phones-loader {
  position: absolute;
  inset: 0;
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 10;
  background: rgb(var(--bg) / .7);
  border-radius: 12px;
}

.phones-loader::after {
  content: "";
  width: 48px;
  height: 48px;
  border-radius: 50%;
  border: 3px solid rgb(var(--border));
  border-top-color: rgb(var(--accent));
  animation: spin .8s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }

/* ===== GOLD NUMBER STYLES =====
   Idle: warn-tinted bg, warn border, warn text + ★ prefix.
   Hover: deeper warn bg. Selected: solid warn fill + contrast text. */
.phoneItem.gold-number > span {
  background-color: rgb(var(--warn) / .08);
  border-color: rgb(var(--warn));
  color: rgb(var(--warn));
  padding-left: 28px;
}

.phoneItem.gold-number > span::before {
  content: '\2605';
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: rgb(var(--warn));
  font-size: 12px;
}

.phoneItem.gold-number > span:hover {
  background: rgb(var(--warn) / .15);
  box-shadow: 0 2px 8px rgb(var(--warn) / .18);
}

.phoneItem.gold-number.selected > span,
#phonesContent .phoneItem.selected.gold-number span {
  background-color: rgb(var(--warn)) !important;
  border-color: rgb(var(--warn)) !important;
  color: rgb(var(--accent-contrast)) !important;
}

.phoneItem.gold-number.selected > span::before { color: rgb(var(--accent-contrast)); }

.gold-fee-badge {
  position: absolute;
  top: -8px;
  left: 50%;
  transform: translateX(-50%);
  background: rgb(var(--warn));
  color: rgb(var(--bg));
  font-size: 8px;
  font-weight: 700;
  padding: 2px 6px;
  border-radius: 8px;
  white-space: nowrap;
  letter-spacing: 0.3px;
}

/* Per-number monthly price chip pinned to the right of each tile.
   Same idiom as the +VAT gold badge but bottom-right and using the
   mono token + accent so the recurring cost reads at a glance. */
/* Priced tiles reserve room on the right for the /mo chip so the
   digits and chip can't collide. White-space:nowrap keeps the
   formatted number on a single line. */
.phoneItem.phoneItem--priced > span {
  padding-right: 64px;
  white-space: nowrap;
}
/* The per-number monthly chip: a flex item after the number (never over it),
   shown only when the grid is wide enough for it to fit beside the number. */
#phonesContent { container-type: inline-size; }
.phoneItem-mo {
  display: none;
  position: static;
  margin-left: auto;
  transform: none;
  font-family: var(--font-mono, 'JetBrains Mono', monospace);
  font-weight: 800;
  font-size: 10.5px;
  letter-spacing: .04em;
  color: rgb(var(--accent-ink));
  background: transparent;
  padding: 0;
  white-space: nowrap;
  pointer-events: none;
  font-variant-numeric: tabular-nums;
  opacity: .65;
}
@container (min-width: 760px) {
  .phoneItem-mo { display: inline; }
}
html.dark .phoneItem-mo {
  color: rgb(var(--accent));
}
.phoneItem.selected .phoneItem-mo {
  color: rgb(var(--accent-contrast));
  opacity: .9;
}
.phoneItem.gold-number .phoneItem-mo {
  color: rgb(var(--warn));
  opacity: .85;
}
.phoneItem.gold-number.selected .phoneItem-mo {
  color: rgb(var(--accent-contrast));
}

/* gv-system clamps `.panel { overflow:hidden }` so the brutalist
   rounded corners stay clean. That same rule clips the
   bootstrap-select Area Code dropdown when it opens. Allow overflow
   on this specific panel chain so the menu can escape downwards. */
.panel.panel-form,
.panel.panel-form > .panel-body,
.phone-filters,
.phone-filter-group {
  overflow: visible !important;
}
/* Make sure the open bootstrap-select dropdown floats above
   downstream toolbars / chip rows. */
.phone-filter-group .bootstrap-select.open,
.phone-filter-group .bootstrap-select .dropdown-menu {
  z-index: 1050;
}

/* bootstrap-select with data-container="body" detaches the menu and
   appends it to <body>, so the column-level .phone-filter-group
   selector above can no longer reach it. Style the detached menu
   directly via the data-id attribute the plugin stamps on it. */
.bootstrap-select .dropdown-menu,
body > .bootstrap-select .dropdown-menu,
body > .dropdown.bootstrap-select .dropdown-menu {
  z-index: 1060;
  background: rgb(var(--bg));
  border: 1px solid rgb(var(--border));
  border-radius: 12px;
  box-shadow: 0 8px 30px -8px rgb(0 0 0 / .25);
  padding: 6px;
  /* Don't let the menu force itself outside the viewport on mobile;
     cap min-width to the trigger but allow growing to fit option
     text when the container is wider than 280px. */
  min-width: 100% !important;
  max-width: calc(100vw - 24px);
}
.bootstrap-select .dropdown-menu li > a {
  border-radius: 8px;
  padding: 8px 12px;
  white-space: normal !important; /* allow option text to wrap on mobile */
  color: rgb(var(--text));
}
.bootstrap-select .dropdown-menu li.active > a,
.bootstrap-select .dropdown-menu li > a:hover,
.bootstrap-select .dropdown-menu li > a:focus {
  background: rgb(var(--accent) / .12) !important;
  color: rgb(var(--accent-ink)) !important;
}
html.dark .bootstrap-select .dropdown-menu li.active > a,
html.dark .bootstrap-select .dropdown-menu li > a:hover,
html.dark .bootstrap-select .dropdown-menu li > a:focus {
  color: rgb(var(--accent)) !important;
}
.bootstrap-select .bs-searchbox input {
  background: rgb(var(--bg));
  color: rgb(var(--text));
  border: 1px solid rgb(var(--border));
  border-radius: 8px;
}
.bootstrap-select .bs-searchbox input:focus {
  border-color: rgb(var(--accent));
  box-shadow: 0 0 0 3px rgb(var(--accent) / .15);
  outline: none;
}

@media (max-width: 600px) {
  /* On phones the visible button label was being chopped because the
     parent column shrunk to viewport width minus padding. Allow it
     to wrap and grow on small screens so the customer can read the
     full "Geographic (Local) — e.g. 0113, 0207" label. */
  .phone-filter-group .bootstrap-select > .dropdown-toggle {
    white-space: normal !important;
    text-align: left;
    height: auto !important;
    min-height: 44px;
    padding: 10px 36px 10px 14px;
    line-height: 1.3;
  }
  .phone-filter-group .bootstrap-select > .dropdown-toggle .filter-option {
    white-space: normal !important;
    overflow: visible !important;
    text-overflow: clip !important;
    line-height: 1.3;
  }
  /* Same wrap-vs-truncate fix for the native Number Type <select>. */
  #numbertype {
    height: auto;
    min-height: 44px;
    padding: 10px 32px 10px 12px;
    line-height: 1.3;
    white-space: normal;
  }
}

/* ===== FILTER BAR ===== */
.phone-filters {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  /* Align by the top so the dropdowns line up; the hint sitting
     under the Number Type select no longer drags the Area Code
     dropdown down with `flex-end`. */
  align-items: flex-start;
  padding: 16px 20px;
  background: rgb(var(--surface));
  border-radius: 14px;
  border: 1px solid rgb(var(--border));
  margin-bottom: 16px;
}

.phone-filter-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
  flex: 1;
  min-width: 0;
}

.phone-filter-group label {
  font-size: 11px;
  font-weight: 700;
  color: rgb(var(--muted));
  text-transform: uppercase;
  letter-spacing: 0.3px;
  margin: 0;
}

/* Custom down-chevron used on both the plain <select> and the
   bootstrap-select widget so they look identical and the caret never
   flips up when the menu opens. SVG is inlined to avoid a request and
   to side-step Lagom's own arrow asset path. */
.phone-filter-group select {
  border: 1.5px solid rgb(var(--border));
  border-radius: 10px;
  padding: 8px 32px 8px 12px;
  font-size: 13px;
  background: rgb(var(--bg)) url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path d='M1 1l4 4 4-4' stroke='%2364748b' stroke-width='1.5' fill='none' stroke-linecap='round' stroke-linejoin='round'/></svg>") no-repeat right 12px center;
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
  min-width: 160px;
}

/* bootstrap-select renders a button wrapped in a .bootstrap-select
   .btn-group, with the original <select> hidden. Without these
   overrides we get a "box in a box" effect — outer Lagom .form-control
   border plus the inner .dropdown-toggle button border — and the
   selected label is anchored top-left rather than centred. */
.phone-filter-group .bootstrap-select,
.phone-filter-group .bootstrap-select.form-control,
.phone-filter-group .bootstrap-select.show-tick {
  width: 100% !important;
  min-width: 160px;
  border: 0 !important;
  background: transparent !important;
  padding: 0 !important;
  height: auto !important;
  box-shadow: none !important;
  border-radius: 0 !important;
}
.phone-filter-group .bootstrap-select > .dropdown-toggle {
  width: 100%;
  height: 38px;
  display: flex;
  align-items: center;
  border: 1.5px solid rgb(var(--border));
  border-radius: 10px;
  padding: 0 32px 0 12px;
  font-size: 13px;
  background: rgb(var(--bg)) url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path d='M1 1l4 4 4-4' stroke='%2364748b' stroke-width='1.5' fill='none' stroke-linecap='round' stroke-linejoin='round'/></svg>") no-repeat right 12px center;
  color: rgb(var(--text));
  box-shadow: none;
}
.phone-filter-group .bootstrap-select > .dropdown-toggle:focus,
.phone-filter-group .bootstrap-select > .dropdown-toggle:hover {
  border-color: rgb(var(--accent));
  outline: none;
  box-shadow: none;
}
.phone-filter-group .bootstrap-select > .dropdown-toggle .filter-option {
  display: flex;
  align-items: center;
  line-height: 1;
  padding: 0;
}
.phone-filter-group .bootstrap-select > .dropdown-toggle .filter-option-inner-inner {
  text-align: left;
}
/* Hide bootstrap-select's own bs-caret triangle — our inline SVG above
   replaces it. Without this the button shows two carets when open. */
.phone-filter-group .bootstrap-select > .dropdown-toggle .bs-caret { display: none !important; }

/* Quality toggle */
.quality-toggle {
  display: flex;
  border-radius: 10px;
  overflow: hidden;
  border: 1.5px solid rgb(var(--border));
  background: rgb(var(--bg));
  gap: 0;
}

.quality-toggle input[type="radio"] { display: none; }

.quality-toggle label {
  padding: 10px 16px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  margin: 0;
  color: rgb(var(--muted));
  transition: all 0.15s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  border-right: 1px solid rgb(var(--border));
  flex: 1;
}

.quality-toggle label:last-of-type { border-right: none; }

.quality-toggle input:checked + label,
.rv-picker .quality-toggle input:checked + label {
  background: rgb(var(--accent));
  color: rgb(var(--accent-contrast));
  font-weight: 700;
}

.quality-toggle input[value="gold"]:checked + label,
.rv-picker .quality-toggle input[value="gold"]:checked + label {
  background: linear-gradient(135deg, rgb(var(--warn)), rgb(var(--warn)));
  color: rgb(var(--accent-contrast));
}

/* Setup fee display */
.gold-setup-total {
  font-size: 13px;
  font-weight: 700;
  color: rgb(var(--warn));
}

/* Hide billing cycle if £0 */
.billing-cycle-free { display: none !important; }

#numberFilter:focus {
  border-color: rgb(var(--accent));
  outline: none;
  box-shadow: 0 0 0 3px rgb(var(--accent) / .10);
}

/* Mobile: stack filters vertically + bigger tap targets */
@media (max-width: 991px) {
  /* Below `md`, the dense 3-column grid is still cramped on a
     small laptop / tablet. Drop to 2-up and grow the tap target. */
  #phonesContent .phoneItem {
    flex: 0 0 calc(50% - 4px) !important;
    max-width: calc(50% - 4px) !important;
  }
  .phoneItem > span {
    height: 52px;          /* 44 → 52, easier touch */
    font-size: 14px;
  }
  .quality-toggle label {
    padding: 14px 16px;    /* taller tabs on touch */
    font-size: 14px;
  }
  .selectedPhoneItem-body {
    padding: 10px 12px 10px 30px;
    font-size: 13px;
  }
  .selectedPhoneItem-remove {
    padding: 0 14px;
    font-size: 14px;
  }
}
@media (max-width: 600px) {
  .phone-filters { flex-direction: column; }
  .phone-filter-group { min-width: 100% !important; }
  .quality-toggle { min-width: 100% !important; flex-direction: column; }
  .quality-toggle label { justify-content: center; border-right: none; border-bottom: 1px solid rgb(var(--border)); }
  .quality-toggle label:last-of-type { border-bottom: none; }
  /* On true phone widths even 2-up is tight when the number is
     11 digits — drop to single column. */
  #phonesContent .phoneItem {
    flex: 0 0 100% !important;
    max-width: 100% !important;
  }
}

/* Belt-and-braces: pin the panel container to the rest of the
   cart UI width too. The panel-body owns the horizontal padding so
   the inner toolbar / hero / search bar / grid all share the same
   left and right edge. */
.panel.panel-form { overflow-x: hidden; }
.panel.panel-form > .panel-body { box-sizing: border-box; }

/* ===== Reseller layout: a self-sizing grid of square tiles =====
   The tiles fill whatever width the page gives them (as many per row as
   fit, never cramped), with rounded corners instead of pills, the gold
   fee written inside the tile on its own line, and the chosen-number
   chips to match. Later in the sheet, so it wins over the pill styles. */
#phonesContent.row, #phonesContent {
  display: grid !important;
  grid-template-columns: repeat(auto-fill, minmax(172px, 1fr));
  gap: 10px;
  margin: 0;
  padding: 4px 2px 8px;
  max-height: 540px;
  overflow-y: auto;
}
#phonesContent > .phoneItem { width: auto; max-width: none; flex: none; padding: 0; margin: 0; float: none; }
#phonesContent > .col-12 { grid-column: 1 / -1; }
.phoneItem > span {
  height: auto;
  min-height: 46px;
  border-radius: 10px;
  padding: 9px 12px 9px 14px;
  font-size: 13px;
  flex-wrap: wrap;
  row-gap: 1px;
  box-shadow: 0 1px 2px rgba(0,0,0,.04);
}
.phoneItem > span:hover { box-shadow: 0 2px 8px rgb(var(--accent) / .15); }
.phoneItem.gold-number > span { padding-top: 7px; padding-bottom: 7px; }
.gold-fee-badge {
  position: static;
  transform: none;
  order: 10;
  width: 100%;
  margin: 0;
  padding: 0;
  background: transparent;
  color: rgb(var(--warn));
  font-size: 10.5px;
  letter-spacing: .02em;
  text-align: left;
}
.phoneItem.gold-number.selected > span .gold-fee-badge { color: rgb(var(--accent-contrast)); opacity: .9; }
.phoneItem.selected > span::after { top: 6px; right: 6px; }
.phoneItem-mo { font-size: 10px; }
.selectedPhoneItem { border-radius: 10px; }
.selectedPhoneItem-body { padding: 8px 12px; }
.selectedPhoneItem-remove { border-radius: 0 8px 8px 0; }
#selectedCountChip { border-radius: 10px !important; }
.quality-toggle, .quality-toggle label { border-radius: 0; }
.quality-toggle { border-radius: 10px; }

/* Three or more tiles per row in a typical content column (150px minimum per tile). */
#phonesContent.row, #phonesContent { grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); }

/* The two filters stacked, full width, with controls of one height, so
   the plain select and the Bootstrap-select button line up. */
.rv-picker .phone-filters { flex-direction: column; gap: 12px; }
.rv-picker .phone-filter-group { flex: 1 1 100%; width: 100%; }
.rv-picker .phone-filter-group select.form-control,
.rv-picker .phone-filter-group .bootstrap-select > .dropdown-toggle,
.rv-picker .phone-filter-group .bootstrap-select > .btn { min-height: 44px; height: 44px; width: 100%; }
.rv-picker .phone-filter-group .bootstrap-select { width: 100% !important; }

/* Themes style labels in the configure form by id, which outranks a class
   rule: the active filter's text is forced readable. */
.rv-picker .quality-toggle input:checked + label { color: #fff !important; background: rgb(var(--accent)) !important; }
.rv-picker .quality-toggle input[value="gold"]:checked + label { background: rgb(var(--warn)) !important; color: #fff !important; }
.rv-picker .quality-toggle label { color: rgb(var(--muted)); }
</style>
<!--
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>


<script>
    let phoneInput;
    let networkPhoneInput;
    let maxPhonesInput;
    let goldPhonesInput;
    let customFieldId;
    let configurableOptionId;
    let goldConfigOptionId;
    let phones;

    // Per-number recurring (monthly) price + currency prefix/suffix
    // pulled from tblpricing in hooks.php. Used to render the
    // "+£X/mo" chip on each tile and the running selection note.
    var phoneRecurringMonthly = parseFloat('{$phoneRecurringMonthly|default:0}') || 0;
    // "+VAT", "inc. VAT" or '' from the reseller's tax settings (Tax::plus).
    var taxLabel = '{$taxLabel|escape:'javascript'}';
    var taxSuffix = taxLabel ? ' ' + taxLabel : '';
    var phoneRecurringPrefix  = '{$currencyPrefix|default:"£"|escape:"javascript"}';
    var phoneRecurringSuffix  = '{$currencySuffix|default:""|escape:"javascript"}';
    // Bare amount with the chosen currency mark — prefix wins over
    // suffix so a `prefix="£" suffix=" GBP"` combo collapses to
    // "£1.00" rather than "£1.00 GBP". Everywhere a price renders
    // (tile chip, count chip, recurring note) flows through this
    // so the display stays consistent.
    function fmtAmount(amount) {
        var p = phoneRecurringPrefix || '';
        var s = phoneRecurringSuffix || '';
        if (p && s) { s = ''; }
        return p + amount.toFixed(2) + s;
    }
    function fmtPerMonth(amount) {
        if (!amount || amount <= 0) return '';
        return fmtAmount(amount) + '/mo';
    }

    // Format an 11-digit UK number as "0NNN NNN NNNN" (4-3-4) —
    // matches how UK businesses print their landlines (e.g.
    // "0151 280 6408", "0330 043 0056"). 10-digit shorts get
    // "0NNN NNN NNN". Anything else is returned untouched so we
    // don't mangle weird inputs.
    //
    // The AJAX phone records include a "-source" suffix (e.g.
    // "01133500910-network") because that lets us route the
    // order back to the right carrier later. The suffix never
    // belongs in the display, so we lop everything from the first
    // hyphen off before measuring length.
    function formatUKNumber(raw) {
        var d = String(raw == null ? '' : raw)
            .split('-')[0]
            .replace(/\s+/g, '');
        if (d.length === 11) {
            return d.substr(0, 4) + ' ' + d.substr(4, 3) + ' ' + d.substr(7, 4);
        }
        if (d.length === 10) {
            return d.substr(0, 4) + ' ' + d.substr(4, 3) + ' ' + d.substr(7, 3);
        }
        return d;
    }

    // Area code names from the backend come like "(1134) - Leeds"
    // or "(333)" — drop the missing leading 0 in so they read the
    // way customers see them on bills ("0113", "0333"). Only
    // touches names that start with a non-zero digit inside the
    // first paren — already-prefixed names pass through.
    function prefixAreaZero(name) {
        return String(name || '').replace(/^\((?=[1-9])/, '(0');
    }

    let tenantNameCustomFieldId;
    let addonProduct;
    let tenantNameOptions;


    $(document).ready(function () {
        // Reset gold fee session on fresh page load
        $.ajax({ type: 'post', url: '{$endpoint}', data: { pbxAction: 'setGoldFee', numbers: '', token: (window.csrfToken || '') }, async: false });

        customFieldId = '{$customFieldId}';
        configurableOptionId = '{$configurableOptionId}';
        goldConfigOptionId = '{$goldConfigOptionId}';
        maxPhonesInput = $("input[name='configoption[" + configurableOptionId + "]']");
        if (!maxPhonesInput.length && configurableOptionId) {
            // The numbers option is hidden in WHMCS, so it is not on the form: post its quantity ourselves.
            var $cfgForm = $('#frmConfigureProduct');
            if (!$cfgForm.length) { $cfgForm = $('form').has("[name^='customfield'], [name^='configoption']").first(); }
            if ($cfgForm.length) {
                $cfgForm.append("<input type='hidden' name='configoption[" + configurableOptionId + "]' value='0'>");
                maxPhonesInput = $cfgForm.find("input[name='configoption[" + configurableOptionId + "]']");
            }
        }
        maxPhonesInput.addClass("custom-disable");
        maxPhonesInput.attr('readonly', true);
        maxPhonesInput.blur();
        maxPhonesInput.val(0);

        // Hide the whole "Telephone Number(s)" configurable-option field (its
        // label AND the quantity input) — numbers are chosen in the selector
        // below, so this raw quantity row is redundant. Walk up from the input to
        // the field wrapper that also carries the option's own label: the option
        // name appears there twice (the label + the "x … £" text beside the
        // input), and that wrapper holds only this one configoption control.
        (function () {
            if (!maxPhonesInput.length) { return; }
            var reCount = /telephone number|phone numbers/gi;
            var reTest  = /telephone number|phone numbers/i;
            var $b = maxPhonesInput.parent(), done = false;
            for (var i = 0; i < 8 && $b.length && !$b.is('form, body'); i++) {
                var hits = (String($b.text()).match(reCount) || []).length;
                if (hits >= 2 && $b.find("[name^='configoption']").length <= 1) {
                    $b.hide(); done = true; break;
                }
                $b = $b.parent();
            }
            if (!done) {
                // Fallback: hide the nearest control block (only this option's
                // input) plus a preceding label/eyebrow if it names the option.
                var $wrap = maxPhonesInput.closest('.form-group, .row, tr, li, div').filter(function () {
                    return $(this).find("[name^='configoption']").length <= 1;
                }).first();
                if ($wrap.length) {
                    $wrap.hide();
                    var $prev = $wrap.prev();
                    if ($prev.length && reTest.test($prev.text())) { $prev.hide(); }
                }
            }
        })();

        // Hide gold numbers config option — pricing handled by OrderProductPricingOverride hook
        if (goldConfigOptionId) {
            var $goldEl = $("[name='configoption[" + goldConfigOptionId + "]']");
            if ($goldEl.length) {
                $goldEl.val(0);
                $goldEl.closest('.form-group, .row, tr, div').filter(function() {
                    return $(this).find('[name]').length <= 2;
                }).first().hide();
            }
        }

        // Hide billing cycle selector if price is £0.00
        $('select[name="billingcycle"] option, #inputBillingcycle option').each(function() {
            if ($(this).text().indexOf('0.00') > -1 && $(this).is(':selected')) {
                $(this).closest('.form-group, .row, div').filter(function() {
                    return $(this).find('select[name="billingcycle"], #inputBillingcycle').length > 0;
                }).first().hide();
            }
        });

        phoneInput = $("textarea[name='customfield[" + customFieldId + "]']");
        phoneInput.closest('div').hide();
        phoneInput.val('');
        
        addonProduct = '{$addonProduct}';
        if(addonProduct) {
            tenantNameCustomFieldId = '{$tenantNameCustomFieldId}';
            tenantNameOptions = "{$tenantNameOptions}";
            $("input[name='customfield[" + tenantNameCustomFieldId + "]']").replaceWith("<select name='customfield[" + tenantNameCustomFieldId + "]' id='giantTenantSelect' class='selectpicker' data-live-search='true' data-width='100%' data-size='8' data-container='body' data-style='form-control' title='Select a service…'>"+tenantNameOptions+"</select>");
            // Pretty + searchable via the theme's bootstrap-select; falls back to
            // the (CSS-styled) native select if it isn't loaded.
            if ($.fn.selectpicker) { $('#giantTenantSelect').selectpicker(); }
        }

        // Hide the "Configurable Options" step when the product genuinely has none
        // to configure (e.g. Add Numbers — chosen above, not here), so the empty
        // panel doesn't show. Best-effort: hides the section wrapper, else the
        // container + its heading.
        setTimeout(function () {
            var $co = $('#productConfigurableOptions');
            if (!$co.length) { $co = $('.product-configurable-options').first(); }
            if (!$co.length) { return; }
            var visible = $co.find('select, textarea, input').filter(function () {
                return this.type !== 'hidden' && $(this).is(':visible');
            }).length;
            if (visible > 0) { return; }

            var $section = $co.closest('.panel, .card, .order-section, section').first();
            if ($section.length && $section.find('form').length === 0) {
                $section.hide();
            } else {
                $co.hide();
                $co.prevAll('h1,h2,h3,h4,h5,legend,.title,[class*="head"],[class*="title"]').filter(function () {
                    return /configurable option/i.test($(this).text()) && $(this).text().length < 160;
                }).first().hide();
            }
        }, 350);

        phones = JSON.parse('{json_encode($phones)}') || [];

        $(document).on('click', '.phoneItem', function () {
            if ($(this).hasClass('selected')) {
                $(this).removeClass('selected');
            } else {
                $(this).addClass('selected');
            }

            updateCustomField($(this).data('phone'));
        })

        // Only the explicit × removes — clicking the chip body is a
        // no-op so customers don't accidentally delete a number while
        // scrolling.
        $(document).on('click', '.selectedPhoneItem-remove', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var phone = $(this).data('phone') || $(this).closest('.selectedPhoneItem').data('phone');
            if (!phone) return;
            updateCustomField(phone.toString());
            updatePhones();
        });

        $(document).on('change', "input[name='configoption[" + configurableOptionId + "]']", function () {
            $('.phoneItem').each(function () {
                $(this).removeClass('selected');
            });

            $('#selectedPhones').html('');
            phoneInput.val('');
        });


        buildMainContent();

        $(document).on('change', "#numbertype", function () {
            updateNumberTypeHint();
            updatePhonesAndAreaCodes();
        });
        // Seed the hint on first paint so the customer sees the
        // explainer even before they touch the dropdown.
        function updateNumberTypeHint() {
            var t = $("#numbertype").val();
            var $hint = $("#numberTypeHint");
            if (!$hint.length) return;
            if (t === 'uk-wide') {
                $hint.html('UK-wide numbers have no area association &mdash; ideal for nationwide brands and routing across multiple offices.');
            } else {
                $hint.html('Local numbers display the area dialling code &mdash; useful for building trust with customers in that region.');
            }
        }
        updateNumberTypeHint();

        $(document).on('change', "input[name='goldFilter']", function () {
            cache = [];
            updatePhones();
        });

        $(document).on('change', "#areacode", function () {
            $('#numberFilter').val('');
            updatePhones();
        });

        // Empty-state action buttons (rendered when an area code has
        // no free numbers). Three routes home: next area, alt type,
        // or show-all when only the gold filter came up dry.
        // selectpicker('val', x) sets the underlying <option> but the
        // change event isn't reliably fired across bootstrap-select
        // versions — explicitly trigger it so updatePhones() runs and
        // the loader spins while the new area is fetched.
        $(document).on('click', '#emptyNextArea', function () {
            var $sel = $('#areacode');
            var $opts = $sel.find('option');
            var idx = $opts.index($opts.filter(':selected'));
            if (idx < 0) idx = 0;
            var $next = $opts.eq((idx + 1) % $opts.length);
            if (!$next.length || !$next.val()) { return; }
            $sel.val($next.val());
            try { $sel.selectpicker('refresh'); } catch (e) {}
            $sel.trigger('change');
        });
        $(document).on('click', '#emptyAltType', function () {
            var target = $(this).data('target');
            if (target) {
                $('#numbertype').val(target).trigger('change');
            }
        });
        $(document).on('click', '#emptyShowAll', function () {
            $('#gfBoth').prop('checked', true).trigger('change');
        });

        $(document).on('keyup', '#numberFilter', function() {
            var val = this.value.replace(/\s/g, '').toLowerCase();
            $('#phonesContent .phoneItem').each(function() {
                var num = $(this).find('span').text().replace(/\s/g, '').toLowerCase();
                $(this).toggle(num.indexOf(val) > -1);
            });
        });

        $(document).on('click', '.lagom .bootstrap-select .dropdown-menu .dropdown-item', function(){
            let dropdown = $(this).closest('.bootstrap-select').find('.dropdown-toggle');
            dropdown.dropdown('toggle')
        });

        recalctotals();
    });


    function canSelectMore() {
        let maxPhonesCount = parseInt(maxPhonesInput.val());
        let phones = phoneInput.val().split(',');
        phones = phones.filter(function (p) {
            return p.length > 0;
        });

        return phones.length < maxPhonesCount;
    }

    function updateCustomField(phone) {
        phone = phone.toString();
        let selectedList = phoneInput.val().split(',');
        if (selectedList.includes(phone)) {
            selectedList = selectedList.filter(function (p) {
                return p !== phone;
            });
        } else {
            selectedList.push(phone);
        }

        selectedList = selectedList.filter(function (p) {
            return p.length > 0;
        });


        let content = "";
        selectedList.forEach(function (selectedPhone) {
            let split        = selectedPhone.split("-");
            let phoneDisplay = formatUKNumber(split[0]);

            // Check gold status from the phones data array (persists across area code changes)
            var isGold = false;
            var fee = 0;
            phones.forEach(function(p) {
                var fullNum = p.fullNumber ? ('0' + p.fullNumber) : ('0' + p.di_area + p.di_number);
                if (fullNum === selectedPhone && p.gold) {
                    isGold = true;
                    fee = parseFloat(p.setup_fee || 0);
                }
            });

            var goldLabel = isGold && fee ? ' <small style="opacity:0.9;">(+&pound;' + fee.toFixed(2) + ' ' + taxLabel + ')</small>' : '';
            var goldStar = isGold ? '<span class="selectedPhoneItem-star">&#9733;</span> ' : '';

            var selectedClass = isGold ? 'selectedPhoneItem selectedGold' : 'selectedPhoneItem';
            // Two parts: the chip body (display only — clicking does
            // nothing dangerous) and an explicit × remove button.
            // The old "click chip to remove" behaviour was a hidden
            // gesture customers found scary; the × makes intent
            // unambiguous.
            content += "<div data-phone='" + selectedPhone + "' class='" + selectedClass + "'>";
            content += "<span class='selectedPhoneItem-body'>" + goldStar + phoneDisplay + goldLabel + "</span>";
            content += "<button type='button' class='selectedPhoneItem-remove' data-phone='" + selectedPhone + "' aria-label='Remove number'><i class='fa-solid fa-xmark'></i></button>";
            content += "</div>";
        });

        $("#selectedPhones").html(content);
        $("#noSelectedMsg").toggle(selectedList.length === 0);

        phoneInput.val(selectedList.join(','));
        maxPhonesInput.val(selectedList.length);
        maxPhonesInput.value = selectedList.length;
        recalctotals();

        // Re-apply filter after selection change
        var _fv = document.getElementById('numberFilter');
        if (_fv && _fv.value) { $(_fv).trigger('keyup'); }
        // Update gold setup fee display
        setTimeout(updateGoldSetupTotal, 100);
    }

    function buildPhonesContent(code) {
        let phonesContent = '';
        var mo = fmtPerMonth(phoneRecurringMonthly);
        var moChip = mo ? '<span class="phoneItem-mo">' + mo + '</span>' : '';
        var pricedClass = mo ? ' phoneItem--priced' : '';
        phones.forEach(function (phone) {
            let fullNumber = phone.di_area + phone.di_number;
            let fullNumberWithZero = "0" + fullNumber;
            if ((fullNumber).indexOf(code) === 0) {
                var goldClass = phone.gold ? ' gold-number' : '';
                var feeBadge  = phone.gold && phone.setup_fee
                    ? '<span class="gold-fee-badge">+&pound;' + parseFloat(phone.setup_fee).toFixed(2) + taxSuffix + '</span>'
                    : '';
                var displayNum = formatUKNumber(fullNumberWithZero);
                phonesContent += "<div class='phoneItem col-xs-12 col-sm-6 col-md-4 col-lg-3 cp-xlg-3" + goldClass + pricedClass + "' data-phone=" + fullNumberWithZero + " data-gold='" + (phone.gold ? '1' : '0') + "' data-fee='" + (phone.setup_fee || 0) + "'><span>" + feeBadge + displayNum + moChip + "</span></div>";
            }
        });

        if (phonesContent.length === 0) {
            phonesContent = renderEmptyState();
        }

        return phonesContent;
    }

    // Empty-state for when an area code has no spare numbers. Gives
    // the customer two actionable routes instead of a dead end: jump
    // to a different code in the same type, or switch to the
    // alternative number type entirely.
    function renderEmptyState() {
        var altLabel = ($("#numbertype").val() === 'uk-wide')
            ? 'Geographic (Local)' : 'Non-Geographic (UK-Wide)';
        var altValue = ($("#numbertype").val() === 'uk-wide') ? 'local' : 'uk-wide';
        var html = '<div class="col-12" style="text-align:center; padding:40px 20px;">';
        html += '<i class="fa-duotone fa-phone-xmark fa-3x" style="color:rgb(var(--muted) / .55); margin-bottom:14px; display:block;"></i>';
        html += '<p style="font-size:16px; font-weight:800; color:rgb(var(--text)); margin:0 0 6px; font-family:var(--font-display, \'Inter\', sans-serif); letter-spacing:-.01em;">No numbers free in this area code</p>';
        html += '<p style="font-size:13px; color:rgb(var(--muted)); margin:0 0 16px;">Pick a different area code, or try a different number type.</p>';
        html += '<div style="display:inline-flex; flex-wrap:wrap; gap:8px; justify-content:center;">';
        html += '<button type="button" class="giant-empty-action" id="emptyNextArea" style="background:rgb(var(--accent)); color:rgb(var(--accent-contrast)); border:1px solid rgb(var(--accent)); border-radius:999px; padding:9px 18px; font-family:var(--font-display, \'Inter\', sans-serif); font-weight:800; font-size:13px; cursor:pointer; box-shadow:0 4px 0 -2px rgb(var(--accent));"><i class="fa-solid fa-arrow-right" style="margin-bottom:0;"></i> Try the next area code</button>';
        html += '<button type="button" class="giant-empty-action" id="emptyAltType" data-target="' + altValue + '" style="background:rgb(var(--bg)); color:rgb(var(--text)); border:1px solid rgb(var(--border)); border-radius:999px; padding:9px 18px; font-family:var(--font-display, \'Inter\', sans-serif); font-weight:700; font-size:13px; cursor:pointer;"><i class="fa-solid fa-right-left" style="margin-bottom:0;"></i> Switch to ' + altLabel + '</button>';
        html += '</div></div>';
        return html;
    }

    function buildMainContent() {
        let container = $('#productConfigurableOptions');

        let areaCodesContent = '';
        let numberType = $('#numbertype').val();
        let code = 0;
        let name = '';

        if (numberType == 'local' || numberType == undefined) {
            let areaCodes = JSON.parse('{$areaCodesJson}');
            areaCodes.forEach(function (area) {
                var displayName = prefixAreaZero(area.name);
                if (code === 0) {
                    code = area.code;
                    name = displayName;
                }
                areaCodesContent += "<option value='" + area.code + "' data-source='" + area.source + "'>" + displayName + "</option>";
            });
        } else {
            // Hardcoded 0333 / 0845 are the canonical non-geo
            // prefixes — keep them as the first picks so a fresh
            // UK-Wide switch always lands on a meaningful option
            // even if the backend `areaCodesNg` feed is polluted
            // with local codes. data-source='api' on each so
            // updatePhones() takes the AJAX path and shows the
            // spinner.
            areaCodesContent = "<option value='333' data-source='api'>(0333)</option><option value='845' data-source='api'>(0845)</option>";
            code = '333';
            name = '(0333)';
            let areaCodes = JSON.parse('{$areaCodesNgJson}');
            areaCodes.forEach(function (area) {
                areaCodesContent += "<option value='" + area.code + "' data-source='" + area.source + "'>" + prefixAreaZero(area.name) + "</option>";
            });
        }

        let phonesContent = buildPhonesContent(code);
        let headerContent = `Standard {literal}${name}{/literal} Phone Numbers`;
        let content = `
        <div class="rv-picker panel panel-default panel-form">
        	<div class="panel-body">
			<!-- Phone Number Selector -->
			<div style="display:flex; flex-direction:column; gap:10px; padding:18px 20px; margin-bottom:18px; border:1px solid rgb(var(--border)); border-radius:14px; background:rgb(var(--bg)); box-shadow:0 6px 0 -2px rgb(var(--accent));">
				<div style="font-family:var(--font-mono,'JetBrains Mono',monospace); font-weight:800; font-size:11px; letter-spacing:.14em; text-transform:uppercase; color:rgb(var(--accent));">
					<i class="fa-solid fa-hashtag" style="margin-bottom:0;"></i> Phone numbers &mdash; optional
				</div>
				<div style="font-family:var(--font-display,'Inter',sans-serif); font-weight:900; font-size:24px; letter-spacing:-.025em; line-height:1.15; color:rgb(var(--text));">
					Pick a new number, or skip and port one in later
				</div>
				<div style="font-size:13.5px; line-height:1.55; color:rgb(var(--muted));">
					Every number below is a <strong style="color:rgb(var(--text));">live UK carrier number</strong>, ready to use within minutes of order completion. Add as many as you like, mix and match areas, then continue to checkout.
				</div>
				<div style="display:flex; flex-wrap:wrap; gap:10px; margin-top:6px;">
					<div style="flex:1; min-width:240px; padding:10px 12px; border:1px solid rgb(var(--accent) / .35); background:rgb(var(--accent) / .06); border-radius:10px; font-size:12.5px; line-height:1.45; color:rgb(var(--text));">
						<strong style="color:rgb(var(--accent-ink)); display:block; font-family:var(--font-mono,'JetBrains Mono',monospace); font-weight:800; font-size:10.5px; letter-spacing:.12em; text-transform:uppercase; margin-bottom:4px;">
							<i class="fa-solid fa-circle-check" style="margin-bottom:0;"></i> Pick now
						</strong>
						Filter by area code, click any number to add it. Gold (memorable) numbers have a one-off setup fee; standard numbers are included with the package.
					</div>
					<div style="flex:1; min-width:240px; padding:10px 12px; border:1px solid rgb(var(--accent-2) / .35); background:rgb(var(--accent-2) / .06); border-radius:10px; font-size:12.5px; line-height:1.45; color:rgb(var(--text));">
						<strong style="color:rgb(var(--accent-2)); display:block; font-family:var(--font-mono,'JetBrains Mono',monospace); font-weight:800; font-size:10.5px; letter-spacing:.12em; text-transform:uppercase; margin-bottom:4px;">
							<i class="fa-solid fa-right-left" style="margin-bottom:0;"></i> Porting in?
						</strong>
						Skip this whole section &mdash; submit your port request from the service panel after checkout. We'll keep your existing number(s).
					</div>
				</div>
			</div>
			<div class="phone-filters">
				<div class="phone-filter-group">
					<label>Number Type <span style="color:rgb(var(--muted)); font-weight:600; text-transform:none; letter-spacing:0; font-size:10.5px;">&mdash; what your callers see</span></label>
					<select id="numbertype" class="form-control">
						<option value="local">Geographic (Local) &mdash; e.g. 0113, 0207</option>
						<option value="uk-wide">Non-Geographic (UK-Wide) &mdash; e.g. 0333, 0845</option>
					</select>
					<small id="numberTypeHint" style="font-size:11.5px; color:rgb(var(--muted)); margin-top:4px; line-height:1.4; display:block;"></small>
				</div>
				<div class="phone-filter-group">
					<label>Area Code <span style="color:rgb(var(--muted)); font-weight:600; text-transform:none; letter-spacing:0; font-size:10.5px;">&mdash; pick by location</span></label>
					<select id="areacode" class="form-control selectpicker" data-live-search="true" data-container="body" data-width="100%" data-dropdown-align-right="auto">
					{literal}${areaCodesContent}{/literal}
					</select>
				</div>
			</div>
			<div style="margin-bottom:16px;">
				<div class="quality-toggle">
					<input type="radio" name="goldFilter" id="gfBoth" value="both" checked><label for="gfBoth">All Numbers</label>
					<input type="radio" name="goldFilter" id="gfGold" value="gold"><label for="gfGold">&#9733; Gold Numbers</label>
					<input type="radio" name="goldFilter" id="gfStd" value="standard"><label for="gfStd">Standard Numbers</label>
				</div>
			</div>

			<div style="display:flex; flex-direction:column; gap:10px; margin-bottom:14px; padding:12px 14px; background:rgb(var(--surface)); border-radius:12px; border:1px solid rgb(var(--border));">
				<div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
					<h4 id="phoneHeader" class="title" style="margin:0; flex:1; min-width:200px; font-size:15px;">{literal}${headerContent}{/literal}</h4>
					<span class="gold-setup-total" id="goldSetupTotal" style="white-space:nowrap;"></span>
				</div>
				<div style="position:relative;">
					<i class="fa-solid fa-magnifying-glass" style="position:absolute; left:14px; top:50%; transform:translateY(-50%); color:rgb(var(--muted)); font-size:13px; pointer-events:none;"></i>
					<input type="text" id="numberFilter" placeholder="Search numbers &mdash; e.g. 5555, 8888, or last 4 digits" autocomplete="off" style="width:100%; box-sizing:border-box; border-radius:10px; border:1.5px solid rgb(var(--border)); padding:10px 14px 10px 40px; font-size:13.5px; background:rgb(var(--bg)); color:rgb(var(--text));">
				</div>
			</div>

			<div id="phonesContentWrap">
				<div id="phonesContent" class="row" style="max-height:500px; overflow-y:auto; gap:8px 0;">
					{literal}${phonesContent}{/literal}
				</div>
				<div class="phones-loader" id="phonesLoader" aria-hidden="true"></div>
			</div>

			<div style="margin-top:20px; padding:18px; background:rgb(var(--surface)); border-radius:14px; border:1px solid rgb(var(--border));">
				<div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:12px;">
					<h4 class="title" style="margin:0; font-size:15px; flex:1; min-width:160px;">Chosen Phone Numbers</h4>
					<span id="selectedCountChip" style="display:none; align-items:center; gap:8px; padding:8px 14px; border-radius:999px; background:rgb(var(--accent)); border:1.5px solid rgb(var(--accent)); color:rgb(var(--accent-contrast)); font-family:var(--font-mono, 'JetBrains Mono', monospace); font-weight:800; font-size:11px; letter-spacing:.12em; text-transform:uppercase; font-variant-numeric:tabular-nums;">
						<i class="fa-solid fa-circle" style="font-size:6px; margin-bottom:0; color:rgb(var(--accent-contrast));"></i>
						<span id="selectedCountChipText">0 selected</span>
					</span>
				</div>
				<div id="selectedPhones"></div>
				<div id="noSelectedMsg" style="color:rgb(var(--muted)); font-size:13px; padding:10px 0;">No numbers selected yet. Click on a number above to add it &mdash; or skip this step entirely if you're porting in.</div>
				<div id="goldSetupSummary" style="margin-top:12px;"></div>
				<div id="selectedRecurringNote" style="display:none; margin-top:12px; padding:10px 14px; background:rgb(var(--bg)); border:1px solid rgb(var(--border)); border-radius:10px; font-size:12.5px; line-height:1.5; color:rgb(var(--muted));">
					<i class="fa-solid fa-circle-info" style="color:rgb(var(--accent)); margin-bottom:0;"></i>
					<span id="selectedRecurringDetail" style="color:rgb(var(--text));"></span>
				</div>
			</div>
    </div>
  </div>`;
        // Place the number picker at the very TOP of the configuration — above
        // the first step card (e.g. "Billable resources"). Fallbacks keep it as
        // high as possible if the card wrapper isn't found.
        var $cards  = $('.gc-config-card');
        var $anchor = container.closest('.gc-config-card');
        if ($cards.length)       { $cards.first().before(content); }
        else if ($anchor.length) { $anchor.before(content); }
        else                     { container.before(content); }
    }
	
function showPhonesLoader() {
  $("#phonesLoader").css("display", "flex").attr("aria-hidden", "false");
}
function hidePhonesLoader() {
  $("#phonesLoader").css("display", "none").attr("aria-hidden", "true");
}



    function updatePhonesAndAreaCodes() {
        let numberType = $("#numbertype").val();
        let name = ''
        let areaCodesContent = '';

        if (numberType == 'local' || numberType == undefined) {

            let areaCodes = JSON.parse('{$areaCodesJson}');
            areaCodes.forEach(function (area) {
                var displayName = prefixAreaZero(area.name);
                if (name.length === 0) {
                    name = displayName;
                }
                areaCodesContent += "<option value='" + area.code + "' data-source='" + area.source + "'>" + displayName + "</option>";
            });
        } else {
            // Hardcoded 0333 / 0845 stay as the first picks for
            // UK-Wide. The backend `areaCodesNg` feed sometimes
            // returns local codes (e.g. 1963) which would shadow
            // the real non-geo prefixes if we let them auto-select.
            // data-source='api' makes the AJAX fetch + spinner
            // run on first selection.
            areaCodesContent = "<option value='333' data-source='api'>(0333)</option><option value='845' data-source='api'>(0845)</option>";
            name = '(0333)';
            let areaCodes = JSON.parse('{$areaCodesNgJson}');
            areaCodes.forEach(function (area) {
                areaCodesContent += "<option value='" + area.code + "' data-source='" + area.source + "'>" + prefixAreaZero(area.name) + "</option>";
            });
        }

        $("#phoneHeader").html("Standard " + name + " Phone Numbers");
        $("#areacode").html(areaCodesContent);

        $.fn.selectpicker.Constructor.DEFAULTS.styleBase = 'form-control';
        $.fn.selectpicker.Constructor.DEFAULTS.style = '';
        $("#areacode").selectpicker('refresh');

        // Auto-select first area code and trigger fetch
        var firstVal = $("#areacode option").first().val();
        if (firstVal) {
            $("#areacode").selectpicker('val', firstVal);
        }

        cache = [];
        updatePhones();
    }
    
    let cache = [];
    function updatePhones() {
  let numberType  = $("#numbertype").val();
  let areaCode    = $("#areacode").val();
  let areaName    = $("#areacode option:selected").text();
  let areaSource  = $("#areacode option:selected").data("source");

  // Every area is searched through the API (the internal portal only fetched for carrier-backed areas).
  if (areaCode) {

    var goldFilter = $('input[name="goldFilter"]:checked').val() || 'both';
    var includeGold = (goldFilter === 'both' || goldFilter === 'gold') ? '1' : '0';
    var cacheKey = areaCode + '_' + includeGold;

    if (!cache[cacheKey]) {
      showPhonesLoader();

      $.ajax({
        type: 'get',
        url: '{$endpoint}',
        data: { pbxAction: "getPhones", areaCode: areaCode, includeGold: includeGold },
        success: function(responseJson) {
          var failed = false;
          try {
            // The endpoint answers real JSON, so jQuery may already have parsed it.
            var response = (typeof responseJson === 'string') ? jQuery.parseJSON(responseJson) : responseJson;
            if (response && !Array.isArray(response) && (response.error || response.message)) {
              // Refused, or the search failed: say why where the numbers would be.
              failed = true;
              console.error('Number search:', response.error || response.message);
              $("#phonesContent").html('<div class="col-12" style="text-align:center; padding:40px 20px;">' +
                '<p style="font-size:16px; font-weight:800; color:rgb(var(--text)); margin:0 0 6px;">Couldn&rsquo;t load numbers</p>' +
                '<p style="font-size:13px; color:rgb(var(--muted)); margin:0;">' + $('<i>').text(response.error || response.message).html() + '</p></div>');
            }
            if (Array.isArray(response)) {
              response.forEach(function(numberData){
                if (numberData.number) {
                  // The API gives national numbers with their leading 0; the script keeps them without it and adds the 0 itself.
                  var national = String(numberData.number).replace(/\D/g, '').replace(/^0/, '');
                  // Skip if already in the list
                  var exists = phones.some(function(p) {
                    return p.fullNumber === (national + "-" + numberData.ref);
                  });
                  if (exists) return;
                  phones.push({
                    di_id: 0,
                    di_di_country: numberData.country_code,
                    di_area: areaCode,
                    fullNumber: national + "-" + numberData.ref,
                    source: numberData.ref,
                    gold: numberData.gold || false,
                    setup_fee: numberData.setup_fee || 0
                  });
                }
              });
            }
            cache[cacheKey] = true;
          } catch(e) {
            console.error("Phone parse error:", e);
          } finally {
            if (!failed) { displayPhones(areaCode, areaName); }
            hidePhonesLoader();   // <-- always stop
          }
        },
        error: function() {
          // Centred panel, consistent with the empty states (the .col-12 rule
          // makes it fill the flex row so it actually centres).
          var errHtml = '<div class="col-12" style="text-align:center; padding:40px 20px;">';
          errHtml += '<i class="fa-duotone fa-triangle-exclamation fa-3x" style="color:rgb(var(--warn)); margin-bottom:14px; display:block;"></i>';
          errHtml += '<p style="font-size:16px; font-weight:800; color:rgb(var(--text)); margin:0 0 6px; font-family:var(--font-display, \'Inter\', sans-serif); letter-spacing:-.01em;">Couldn&rsquo;t load numbers</p>';
          errHtml += '<p style="font-size:13px; color:rgb(var(--muted)); margin:0;">Please try again in a moment, or pick a different area code.</p>';
          errHtml += '</div>';
          $("#phonesContent").html(errHtml);
          hidePhonesLoader();     // <-- stop on error
        }
      });

    } else {
      displayPhones(areaCode, areaName);
    }

  } else {
    displayPhones(areaCode, areaName);
  }
}

    
    function displayPhones(areaCode, areaName) {

        let phonesContent = '';
        let selectedPhones = phoneInput.val().split(',');
        let goldFilter = $('input[name="goldFilter"]:checked').val() || 'both';

        // Sort: standard numbers first, gold numbers last
        let sortedPhones = phones.slice().sort(function(a, b) {
            if (a.gold && !b.gold) return 1;
            if (!a.gold && b.gold) return -1;
            return 0;
        });

        sortedPhones.forEach(function (phone) {
            let fullNumber = "";
            if(phone.fullNumber) {
                fullNumber = phone.fullNumber;
            } else {
                fullNumber = phone.di_area + phone.di_number;
            }
            let fullNumberWithZero = "0" + fullNumber;

            let subNumber   = fullNumber.substring(areaCode.length);
            let split       = subNumber.split("-");
            subNumber       = split[0];

            // Apply gold filter
            if (goldFilter === 'gold' && !phone.gold) return;
            if (goldFilter === 'standard' && phone.gold) return;

            let divClass = 'phoneItem col-xs-12 col-sm-6 col-md-4 col-lg-3 cp-xlg-3'
            if (selectedPhones.includes(fullNumberWithZero)) {
                divClass = 'phoneItem col-xs-12 col-sm-6 col-md-4 col-lg-3 cp-xlg-3 selected';
            }

            if ((fullNumber).indexOf(areaCode) === 0) {
                var goldClass = phone.gold ? ' gold-number' : '';
                var feeBadge = phone.gold && phone.setup_fee ? '<span class="gold-fee-badge">+&pound;' + parseFloat(phone.setup_fee).toFixed(2) + taxSuffix + '</span>' : '';
                var moStr = fmtPerMonth(phoneRecurringMonthly);
                var moChip = moStr ? '<span class="phoneItem-mo">' + moStr + '</span>' : '';
                var pricedClass = moStr ? ' phoneItem--priced' : '';
                var displayNum = formatUKNumber(fullNumberWithZero);
                phonesContent += "<div class='" + divClass + goldClass + pricedClass + "' data-phone=" + fullNumberWithZero + " data-source=" + phone.source + " data-gold='" + (phone.gold ? '1' : '0') + "' data-fee='" + (phone.setup_fee || 0) + "'><span>" + feeBadge + displayNum + moChip + "</span></div>";
            }
        });

        if (phonesContent.length === 0) {
            if (goldFilter === 'gold') {
                // Gold filter has its own actionable empty state: most
                // valuable nudge is "show me all numbers so I can
                // still complete this purchase".
                var goldEmpty = '<div class="col-12" style="text-align:center; padding:40px 20px;">';
                goldEmpty += '<i class="fa-duotone fa-star fa-3x" style="color:rgb(var(--warn)); margin-bottom:14px; display:block;"></i>';
                goldEmpty += '<p style="font-size:16px; font-weight:800; color:rgb(var(--text)); margin:0 0 6px; font-family:var(--font-display, \'Inter\', sans-serif); letter-spacing:-.01em;">No gold numbers free in this area</p>';
                goldEmpty += '<p style="font-size:13px; color:rgb(var(--muted)); margin:0 0 16px;">Standard numbers are still available for this area code.</p>';
                goldEmpty += '<button type="button" id="emptyShowAll" style="background:rgb(var(--accent)); color:rgb(var(--accent-contrast)); border:1px solid rgb(var(--accent)); border-radius:999px; padding:9px 18px; font-family:var(--font-display, \'Inter\', sans-serif); font-weight:800; font-size:13px; cursor:pointer; box-shadow:0 4px 0 -2px rgb(var(--accent));"><i class="fa-solid fa-list" style="margin-bottom:0;"></i> Show all numbers</button>';
                goldEmpty += '</div>';
                phonesContent = goldEmpty;
            } else {
                phonesContent = renderEmptyState();
            }
        }

        var headerPrefix = goldFilter === 'gold' ? 'Gold' : (goldFilter === 'standard' ? 'Standard' : '');
        $("#phoneHeader").html(`{literal}${headerPrefix} ${areaName}{/literal} Phone Numbers`);
        $("#phonesContent").html(phonesContent);
        updateGoldSetupTotal();
        // Auto-focus the filter once we've got enough numbers to make
        // scanning hard. Doesn't grab focus if it'd scroll the page or
        // an empty-state was rendered.
        if ($("#phonesContent .phoneItem").length >= 50) {
            var f = document.getElementById('numberFilter');
            if (f && document.activeElement !== f) { try { f.focus({ preventScroll: true }); } catch (e) { f.focus(); } }
        }
    }

    function updateGoldSetupTotal() {
        var totalSetup = 0;
        var goldCount = 0;
        var selectedNumbers = phoneInput.val().split(',').filter(function(p) { return p.length > 0; });

        // Check each selected number against the phones array for gold status
        selectedNumbers.forEach(function(selectedNum) {
            phones.forEach(function(phone) {
                var fullNum = '';
                if (phone.fullNumber) {
                    fullNum = '0' + phone.fullNumber;
                } else {
                    fullNum = '0' + phone.di_area + phone.di_number;
                }
                if (fullNum === selectedNum && phone.gold) {
                    totalSetup += parseFloat(phone.setup_fee || 0);
                    goldCount++;
                }
            });
        });

        if (totalSetup > 0) {
            var summaryHtml = '<div style="width:100%; box-sizing:border-box; padding:14px 18px; background:rgb(var(--warn) / .1); border:1.5px solid rgb(var(--warn)); border-radius:12px; display:flex; align-items:center; gap:14px;">';
            summaryHtml += '<span style="color:rgb(var(--warn)); font-size:26px; line-height:1; flex:0 0 auto;">&#9733;</span>';
            summaryHtml += '<div style="flex:1 1 auto; min-width:0;">';
            summaryHtml += '<div style="color:rgb(var(--warn)); font-family:var(--font-mono, \'JetBrains Mono\', monospace); font-weight:800; letter-spacing:.08em; text-transform:uppercase; font-size:11px; margin-bottom:2px;">' + goldCount + ' Gold Number' + (goldCount > 1 ? 's' : '') + '</div>';
            summaryHtml += '<div style="font-size:13px; color:rgb(var(--muted));">One-time setup fee</div>';
            summaryHtml += '</div>';
            summaryHtml += '<div style="flex:0 0 auto; text-align:right; color:rgb(var(--warn)); font-weight:800; font-family:var(--font-mono, \'JetBrains Mono\', monospace); font-size:18px; white-space:nowrap;">&pound;' + totalSetup.toFixed(2) + ' <span style="font-size:11px; font-weight:600;">' + taxLabel + '</span></div>';
            summaryHtml += '</div>';
            $('#goldSetupSummary').html(summaryHtml);
            $('#goldSetupTotal').html('&#9733; Setup: &pound;' + totalSetup.toFixed(2));
        } else {
            $('#goldSetupSummary').html('');
            $('#goldSetupTotal').html('');
        }

        // Drive the live selection summary chip + recurring-impact
        // note. We know the per-unit monthly price (phoneRecurringMonthly)
        // so the count chip can show the real /mo impact, not just a
        // count.
        var totalSelected = selectedNumbers.length;
        var $countChip = $('#selectedCountChip');
        if (totalSelected > 0) {
            var label = totalSelected + ' selected';
            if (phoneRecurringMonthly > 0) {
                label += ' &middot; +' + fmtPerMonth(totalSelected * phoneRecurringMonthly);
            }
            if (goldCount > 0) {
                label += ' &middot; ' + goldCount + ' gold';
            }
            $('#selectedCountChipText').html(label);
            $countChip.css('display', 'inline-flex');

            var detailParts = [];
            if (phoneRecurringMonthly > 0) {
                detailParts.push('Adds <strong>' + fmtPerMonth(totalSelected * phoneRecurringMonthly) + '</strong> to your recurring total (' + fmtAmount(phoneRecurringMonthly) + ' per number).');
            }
            if (goldCount > 0) {
                detailParts.push('One-time setup of <strong>&pound;' + totalSetup.toFixed(2) + taxSuffix + '</strong> for ' + goldCount + ' gold number' + (goldCount > 1 ? 's' : '') + '.');
            }
            $('#selectedRecurringDetail').html(detailParts.length ? ' ' + detailParts.join(' ') : '');
            $('#selectedRecurringNote').css('display', 'block');
        } else {
            $countChip.hide();
            $('#selectedRecurringNote').hide();
            $('#selectedRecurringDetail').html('');
        }
        // Store actual gold fee total in session, then recalculate
        $.ajax({
            type: 'post',
            url: '{$endpoint}',
            data: { pbxAction: 'setGoldFee', numbers: phoneInput.val(), token: (window.csrfToken || '') },
            success: function() {
                recalctotals();
            }
        });
    }

    $(document).ready(function() {
        updatePhonesAndAreaCodes();
    }
	);


</script>