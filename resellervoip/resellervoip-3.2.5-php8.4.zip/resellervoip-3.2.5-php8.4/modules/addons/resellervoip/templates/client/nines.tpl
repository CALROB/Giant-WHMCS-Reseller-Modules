{$paletteStyle}
<style>
/* All colours through gv-system tokens. Brand palette is teal only —
   bar fills and score numbers use accent / warn / danger semantically.  */
.nines-page { max-width: 1100px; margin: 20px auto; color: rgb(var(--text)); }
.nines-hero {
    border: 1px solid rgb(var(--border));
    border-radius: 18px;
    padding: 22px 26px;
    background: rgb(var(--bg));
    box-shadow: 0 8px 0 -2px rgb(var(--accent));
    margin-bottom: 20px;
}
.nines-hero h2 { margin: 0 0 6px; font-size: 22px; font-weight: 800; letter-spacing: -0.01em; }
.nines-hero p.lede { color: rgb(var(--muted)); margin: 0 0 18px; line-height: 1.5; }

.nines-score-row { display: flex; align-items: center; gap: 18px; flex-wrap: wrap; }
.nines-score-num {
    font-family: var(--font-display, 'Inter', sans-serif);
    font-size: 40px;
    font-weight: 900;
    line-height: 1;
    min-width: 90px;
    font-variant-numeric: tabular-nums;
    letter-spacing: -0.03em;
}
.nines-score-num.is-excellent { color: rgb(var(--accent-ink)); }
html.dark .nines-score-num.is-excellent { color: rgb(var(--accent)); }
.nines-score-num.is-good      { color: rgb(var(--accent)); }
.nines-score-num.is-fair      { color: rgb(var(--warn)); }
.nines-score-num.is-poor      { color: rgb(var(--danger)); }
.nines-score-num.is-none      { color: rgb(var(--muted)); }
.nines-score-meta { flex: 1; min-width: 240px; }
.nines-score-meta .nines-score-msg { font-weight: 700; color: rgb(var(--text)); margin-bottom: 4px; font-size: 15px; }
.nines-score-meta .nines-score-counts {
    font-family: var(--font-mono, 'JetBrains Mono', monospace);
    font-weight: 700;
    font-size: 11px;
    letter-spacing: .12em;
    text-transform: uppercase;
    color: rgb(var(--muted));
}

.nines-bar {
    height: 14px; border-radius: 999px;
    background: rgb(var(--surface));
    overflow: hidden;
    border: 1px solid rgb(var(--border));
    margin-top: 12px;
}
.nines-bar-fill { height: 100%; transition: width .4s ease; }
.nines-bar-fill.is-excellent { background: rgb(var(--accent)); }
.nines-bar-fill.is-good      { background: rgb(var(--accent) / .80); }
.nines-bar-fill.is-fair      { background: rgb(var(--warn)); }
.nines-bar-fill.is-poor      { background: rgb(var(--danger)); }

.nines-importance {
    background: rgb(var(--warn) / .12);
    border: 1px solid rgb(var(--warn));
    color: rgb(var(--text));
    padding: 14px 18px; border-radius: 12px; margin: 18px 0;
    font-size: 13.5px; line-height: 1.55;
}
.nines-importance strong { color: rgb(var(--warn)); }

.nines-toolbar { display: flex; gap: 10px; align-items: center; margin-bottom: 14px; flex-wrap: wrap; }
.nines-toolbar .text-muted { font-size: 12.5px; color: rgb(var(--muted)); }

.nines-pill {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 999px;
    font-family: var(--font-mono, 'JetBrains Mono', monospace);
    font-size: 10.5px;
    font-weight: 800;
    letter-spacing: .12em;
    text-transform: uppercase;
    line-height: 1.6;
    border: 1px solid currentColor;
    white-space: nowrap;
}
.nines-pill.is-set        { background: rgb(var(--accent) / .12);  color: rgb(var(--accent-ink)); border-color: rgb(var(--accent)); }
html.dark .nines-pill.is-set { color: rgb(var(--accent)); }
.nines-pill.is-incomplete { background: rgb(var(--warn) / .12);    color: rgb(var(--warn));   border-color: rgb(var(--warn)); }
.nines-pill.is-missing    { background: rgb(var(--danger) / .12);  color: rgb(var(--danger)); border-color: rgb(var(--danger)); }
.nines-pill.is-noCarrier  { background: rgb(var(--accent-2) / .12); color: rgb(var(--accent-2)); border-color: rgb(var(--accent-2)); }

.nines-table {
    width: 100%; border-collapse: separate; border-spacing: 0;
    background: rgb(var(--bg));
    border: 1px solid rgb(var(--border));
    border-radius: 14px; overflow: hidden;
}
.nines-table th, .nines-table td {
    padding: 12px 14px;
    text-align: left;
    border-bottom: 1px solid rgb(var(--border));
    font-size: 13px; vertical-align: middle;
    color: rgb(var(--text));
}
.nines-table thead th {
    background: rgb(var(--surface));
    font-family: var(--font-mono, 'JetBrains Mono', monospace);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: .12em;
    color: rgb(var(--muted));
    font-weight: 700;
}
.nines-table tbody tr:hover td { background: rgb(var(--accent) / .06); }
.nines-table .num {
    font-family: var(--font-mono, 'JetBrains Mono', monospace);
    font-weight: 700;
    color: rgb(var(--text));
    font-variant-numeric: tabular-nums;
}
.nines-table .missing { font-size: 11.5px; color: rgb(var(--warn)); }
.nines-table .empty   { color: rgb(var(--muted)); font-style: italic; }
.nines-table .actions a { font-size: 12px; }

.nines-empty {
    text-align: center; padding: 40px 20px; color: rgb(var(--muted));
    background: rgb(var(--bg));
    border: 1px dashed rgb(var(--border));
    border-radius: 14px;
}

.nines-filter-pills { display: flex; gap: 6px; flex-wrap: wrap; }
.nines-filter-pill {
    padding: 5px 12px;
    border-radius: 999px;
    font-family: var(--font-mono, 'JetBrains Mono', monospace);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: .12em;
    text-transform: uppercase;
    border: 1px solid rgb(var(--border));
    background: rgb(var(--surface));
    cursor: pointer;
    color: rgb(var(--muted));
}
.nines-filter-pill.is-active {
    background: rgb(var(--text));
    color: rgb(var(--bg));
    border-color: rgb(var(--text));
}

.nines-search { position: relative; }
.nines-search input {
    padding: 6px 30px 6px 32px;
    border: 1px solid rgb(var(--border));
    border-radius: 10px;
    font-size: 13px; width: 240px;
    background: rgb(var(--bg));
    color: rgb(var(--text));
}
.nines-search input:focus {
    outline: none;
    border-color: rgb(var(--accent));
    box-shadow: 0 0 0 3px rgb(var(--accent) / .15);
}
.nines-search > .fa { position: absolute; left: 11px; top: 50%; transform: translateY(-50%); color: rgb(var(--muted)); font-size: 12px; pointer-events: none; }
.nines-search-clear {
    position: absolute; right: 6px; top: 50%; transform: translateY(-50%);
    background: none; border: none; color: rgb(var(--muted));
    cursor: pointer; font-size: 14px;
    padding: 2px 6px; display: none; line-height: 1;
}
.nines-search.has-value .nines-search-clear { display: block; }

.nines-empty-search {
    text-align: center; padding: 30px 20px; color: rgb(var(--muted));
    background: rgb(var(--bg));
    border: 1px dashed rgb(var(--border));
    border-radius: 14px;
    margin-top: 10px;
}

.nines-result-count { font-size: 12.5px; color: rgb(var(--muted)); margin-top: 8px; }
.nines-result-count strong { color: rgb(var(--text)); }
mark.nines-hl { background: rgb(var(--warn) / .35); color: inherit; padding: 0 1px; border-radius: 3px; }

/* View modal */
.ninesv-overlay {
    position: fixed; inset: 0;
    background: rgb(var(--text) / .55);
    z-index: 9000;
    display: flex; align-items: center; justify-content: center;
    padding: 20px;
}
.ninesv-dialog {
    background: rgb(var(--bg));
    border: 1px solid rgb(var(--border));
    border-radius: 18px;
    max-width: 680px; width: 100%;
    max-height: 92vh;
    display: flex; flex-direction: column;
    overflow: hidden;
    box-shadow: 0 1px 2px rgb(0 0 0 / .05), 0 16px 40px -12px rgb(0 0 0 / .25);
}
.ninesv-head {
    padding: 16px 22px;
    border-bottom: 1px solid rgb(var(--border));
    display: flex; align-items: center; gap: 12px;
}
.ninesv-head h4 { margin: 0; font-size: 18px; font-weight: 800; color: rgb(var(--text)); }
.ninesv-head .close {
    margin-left: auto; background: none; border: none; font-size: 24px;
    cursor: pointer; color: rgb(var(--muted));
    padding: 0 6px; line-height: 1;
}
.ninesv-body { padding: 18px 22px; overflow: auto; color: rgb(var(--text)); }
.ninesv-foot {
    padding: 12px 22px;
    border-top: 1px solid rgb(var(--border));
    background: rgb(var(--surface));
    display: flex; gap: 8px; align-items: center;
}
.ninesv-foot .spacer { flex: 1; }
.ninesv-meta { font-size: 13px; color: rgb(var(--muted)); line-height: 1.55; margin-bottom: 14px; }
.ninesv-meta strong { color: rgb(var(--text)); }
.ninesv-grid { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 13.5px; }
.ninesv-grid th, .ninesv-grid td {
    padding: 10px 14px;
    border-bottom: 1px solid rgb(var(--border));
    text-align: left;
    vertical-align: top;
    color: rgb(var(--text));
}
.ninesv-grid th {
    width: 38%;
    color: rgb(var(--muted));
    font-family: var(--font-mono, 'JetBrains Mono', monospace);
    font-weight: 700;
    font-size: 11px;
    letter-spacing: .12em;
    text-transform: uppercase;
    background: rgb(var(--surface));
}
.ninesv-grid td .empty { color: rgb(var(--muted)); font-style: italic; }
.ninesv-grid td.required-missing {
    background: rgb(var(--warn) / .12);
    color: rgb(var(--warn));
    font-weight: 700;
}
.ninesv-grid .req { color: rgb(var(--danger)); }
.ninesv-status-line { margin-bottom: 12px; }
</style>

<div class="nines-page">
    <div class="nines-hero">
        <h2><i class="fa-duotone fa-shield-halved" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i> 999 Records</h2>
        <p class="lede">When somebody on one of your numbers dials 999, the emergency services hear the address registered against that number. <strong>Outdated information delays response when seconds matter.</strong> Keep this list current — especially after a move, a new tenant on a line, or an office change.</p>

        <div class="nines-score-row" id="ninesScoreRow">
            {if $score.percent !== null}
                <div class="nines-score-num is-{$score.band}" id="ninesScoreNum">{$score.percent}%</div>
            {else}
                <div class="nines-score-num is-none" id="ninesScoreNum">&mdash;</div>
            {/if}
            <div class="nines-score-meta">
                <div class="nines-score-msg" id="ninesScoreMsg">{$score.message}</div>
                <div class="nines-score-counts" id="ninesScoreCounts">
                    {if $score.total > 0}
                        <strong>{$score.set}</strong> set
                        &middot; <strong>{$score.incomplete}</strong> incomplete
                        &middot; <strong>{$score.missing}</strong> missing
                        {if $score.noCarrier > 0} &middot; <strong>{$score.noCarrier}</strong> not on a managed carrier{/if}
                        &middot; total <strong>{$score.total}</strong>
                    {/if}
                </div>
                <div class="nines-bar" {if $score.percent === null}style="display:none;"{/if}>
                    <div class="nines-bar-fill is-{$score.band}" id="ninesBarFill" style="width:{if $score.percent !== null}{$score.percent}{else}0{/if}%;"></div>
                </div>
            </div>
        </div>

        <div class="nines-importance">
            <strong>Why this matters.</strong> 999 records are pulled live by emergency dispatchers. If the address is wrong, ambulances and fire crews end up at the wrong place. Records aren't updated automatically when you move &mdash; review them after every move or new line activation, and keep at least a name + full address on file. We&rsquo;ll prompt you to fix anything missing.
        </div>
    </div>

    <div class="nines-toolbar">
        <button type="button" class="btn btn-primary btn-sm" id="ninesRefreshBtn">
            <i class="fa fa-sync-alt"></i> Refresh from carrier
        </button>
        <div class="nines-search">
            <i class="fa fa-search"></i>
            <input type="search" id="ninesSearch" placeholder="Search number, service, missing fields…" autocomplete="off">
            <button type="button" class="nines-search-clear" title="Clear">&times;</button>
        </div>
        <div class="nines-filter-pills" id="ninesFilterPills">
            <span class="nines-filter-pill is-active" data-filter="all">All</span>
            <span class="nines-filter-pill" data-filter="set">Set</span>
            <span class="nines-filter-pill" data-filter="incomplete">Incomplete</span>
            <span class="nines-filter-pill" data-filter="missing">Missing</span>
            <span class="nines-filter-pill" data-filter="noCarrier">No carrier</span>
        </div>
        <span class="text-muted" style="margin-left:auto;">Refreshes nightly. Click <strong>Refresh</strong> for an on-demand check (up to 100 numbers per click).</span>
    </div>

    <div id="ninesTableWrap">
        {if $rows|@count > 0}
            <table class="nines-table">
                <thead>
                    <tr>
                        <th>Number</th>
                        <th>Service</th>
                        <th>Status</th>
                        <th>Missing fields</th>
                        <th>Last checked</th>
                        <th style="width:170px;">Actions</th>
                    </tr>
                </thead>
                <tbody id="ninesTableBody">
                    {foreach $rows as $r}
                        {assign var=searchText value="`$r.numberDisplay` `$r.numberE164` `$r.productName` `$r.serviceLabel` `','|implode:$r.missingFields` `$r.status`"}
                        <tr data-status="{$r.status}" data-search="{$searchText|strtolower|escape:'html'}">
                            <td><span class="num">{$r.numberDisplay}</span></td>
                            <td>
                                {if $r.serviceId}
                                    <a href="clientarea.php?action=productdetails&id={$r.serviceId}">
                                        {$r.productName|escape}{if $r.serviceLabel} &middot; {$r.serviceLabel|escape}{/if}
                                    </a>
                                {else}
                                    <span class="empty">&mdash;</span>
                                {/if}
                            </td>
                            <td>
                                {assign var=label value=""}
                                {if $r.status eq "set"}{assign var=label value="999 Set"}
                                {elseif $r.status eq "incomplete"}{assign var=label value="Incomplete"}
                                {elseif $r.status eq "missing"}{assign var=label value="Missing"}
                                {elseif $r.status eq "noCarrier"}{assign var=label value="Not managed"}
                                {/if}
                                <span class="nines-pill is-{$r.status}">{$label}</span>
                            </td>
                            <td>
                                {if $r.missingFields|@count > 0}
                                    <span class="missing">{','|implode:$r.missingFields}</span>
                                {else}
                                    <span class="empty">&mdash;</span>
                                {/if}
                            </td>
                            <td>
                                {if $r.lastChecked}{$r.lastChecked|substr:0:16|replace:"T":" "}{else}<span class="empty">&mdash;</span>{/if}
                            </td>
                            <td class="actions">
                                <a href="#" class="nines-view-btn" data-e164="{$r.numberE164|escape}">
                                    <i class="fa fa-eye"></i> View
                                </a>
                                {if $r.serviceId}
                                    &nbsp;<a href="clientarea.php?action=productdetails&id={$r.serviceId}">
                                        Manage <i class="fa fa-arrow-right"></i>
                                    </a>
                                {/if}
                            </td>
                        </tr>
                    {/foreach}
                </tbody>
            </table>
            <div id="ninesEmptySearch" class="nines-empty-search" style="display:none;">
                <i class="fa fa-search fa-2x" style="margin-bottom:10px; color: rgb(var(--muted) / .55);"></i>
                <p>No numbers match your search.</p>
            </div>
            <div id="ninesResultCount" class="nines-result-count"></div>
        {else}
            <div class="nines-empty">
                <i class="fa fa-inbox fa-2x" style="margin-bottom:10px; color: rgb(var(--muted) / .55);"></i>
                <p>No phone numbers on your account yet.</p>
            </div>
        {/if}
    </div>
</div>

<script>
{literal}
$(document).ready(function () {
    var STATUS_LABEL = {
        set: '999 Set', incomplete: 'Incomplete', missing: 'Missing', noCarrier: 'Not managed'
    };

    function escHtml(s) { return $('<div>').text(s == null ? '' : String(s)).html(); }

    function renderRows(rows) {
        var $body = $('#ninesTableBody');
        if (!$body.length) return;
        $body.empty();
        rows.forEach(function (r) {
            var svcCell = r.serviceId
                ? '<a href="clientarea.php?action=productdetails&id=' + r.serviceId + '">' +
                    escHtml(r.productName) + (r.serviceLabel ? ' &middot; ' + escHtml(r.serviceLabel) : '') +
                  '</a>'
                : '<span class="empty">&mdash;</span>';
            var missingCell = r.missingFields && r.missingFields.length
                ? '<span class="missing">' + r.missingFields.map(escHtml).join(', ') + '</span>'
                : '<span class="empty">&mdash;</span>';
            var checkedCell = r.lastChecked
                ? r.lastChecked.replace('T', ' ').substring(0, 16)
                : '<span class="empty">&mdash;</span>';
            var actionsCell = '<a href="#" class="nines-view-btn" data-e164="' + escHtml(r.numberE164) + '"><i class="fa fa-eye"></i> View</a>';
            if (r.serviceId) {
                actionsCell += '&nbsp;<a href="clientarea.php?action=productdetails&id=' + r.serviceId + '">Manage <i class="fa fa-arrow-right"></i></a>';
            }

            // Same data-search payload as the server-rendered rows so the
            // search filter works identically after a Refresh.
            var searchText = [
                r.numberDisplay, r.numberE164, r.productName, r.serviceLabel,
                (r.missingFields || []).join(','), r.status
            ].join(' ').toLowerCase();

            $body.append(
                '<tr data-status="' + r.status + '" data-search="' + escHtml(searchText) + '">' +
                  '<td><span class="num">' + escHtml(r.numberDisplay) + '</span></td>' +
                  '<td>' + svcCell + '</td>' +
                  '<td><span class="nines-pill is-' + r.status + '">' + (STATUS_LABEL[r.status] || r.status) + '</span></td>' +
                  '<td>' + missingCell + '</td>' +
                  '<td>' + checkedCell + '</td>' +
                  '<td class="actions">' + actionsCell + '</td>' +
                '</tr>'
            );
        });
        applyFilter();
    }

    function renderScore(score) {
        var $num   = $('#ninesScoreNum');
        var $msg   = $('#ninesScoreMsg');
        var $count = $('#ninesScoreCounts');
        var $bar   = $('#ninesBarFill');

        $num.removeClass('is-excellent is-good is-fair is-poor is-none').addClass('is-' + score.band);
        $bar.removeClass('is-excellent is-good is-fair is-poor');
        if (score.percent !== null) {
            $num.text(score.percent + '%');
            $bar.addClass('is-' + score.band).css('width', score.percent + '%').parent().show();
        } else {
            $num.text('—');
            $bar.parent().hide();
        }
        $msg.text(score.message);
        if (score.total > 0) {
            var counts = '<strong>' + score.set + '</strong> set' +
                         ' &middot; <strong>' + score.incomplete + '</strong> incomplete' +
                         ' &middot; <strong>' + score.missing + '</strong> missing';
            if (score.noCarrier > 0) counts += ' &middot; <strong>' + score.noCarrier + '</strong> not on a managed carrier';
            counts += ' &middot; total <strong>' + score.total + '</strong>';
            $count.html(counts);
        } else {
            $count.html('');
        }
    }

    function applyFilter() {
        var f = $('.nines-filter-pill.is-active').data('filter') || 'all';
        var q = String($('#ninesSearch').val() || '').trim().toLowerCase();
        var totalRows = 0, shownRows = 0;
        $('#ninesTableBody tr').each(function () {
            totalRows++;
            var s    = $(this).data('status');
            var text = String($(this).data('search') || '');
            var statusOk = (f === 'all' || s === f);
            var searchOk = (q === '' || text.indexOf(q) !== -1);
            var visible  = statusOk && searchOk;
            $(this).toggle(visible);
            if (visible) shownRows++;
        });

        var hasQuery = q !== '' || f !== 'all';
        var $emptySearch = $('#ninesEmptySearch');
        if (totalRows > 0 && shownRows === 0 && hasQuery) {
            $emptySearch.show();
        } else {
            $emptySearch.hide();
        }

        var $count = $('#ninesResultCount');
        if (hasQuery && totalRows > 0) {
            $count.html('Showing <strong>' + shownRows + '</strong> of <strong>' + totalRows + '</strong> numbers');
        } else {
            $count.html('');
        }
    }

    $('.nines-filter-pill').on('click', function () {
        $('.nines-filter-pill').removeClass('is-active');
        $(this).addClass('is-active');
        applyFilter();
    });

    // Search input — debounce slightly so a fast typer isn't pegging the CPU.
    var searchTimer = null;
    $('#ninesSearch').on('input', function () {
        var $wrap = $(this).closest('.nines-search');
        $wrap.toggleClass('has-value', String($(this).val() || '').length > 0);
        clearTimeout(searchTimer);
        searchTimer = setTimeout(applyFilter, 60);
    });
    $('.nines-search-clear').on('click', function () {
        $('#ninesSearch').val('').trigger('input').focus();
    });

    // Esc clears search when the input is focused
    $('#ninesSearch').on('keydown', function (e) {
        if (e.key === 'Escape' && $(this).val()) {
            $(this).val('').trigger('input');
            e.preventDefault();
        }
    });

    $('#ninesRefreshBtn').on('click', function () {
        var $b = $(this);
        var orig = $b.html();
        $b.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Checking with carriers…');
        $.ajax({
            type: 'post',
            url:  'index.php?m=resellervoip&action=ninesRefresh',
            dataType: 'json'
        }).done(function (resp) {
            if (!resp || !resp.ok) {
                alert((resp && resp.error) || 'Refresh failed.');
                return;
            }
            renderRows(resp.rows || []);
            renderScore(resp.score || {});
            var msg = 'Refreshed ' + resp.checked + ' numbers';
            if (resp.errors)    msg += ' (' + resp.errors + ' errors)';
            if (resp.remaining) msg += '. ' + resp.remaining + ' more to refresh — click again to continue.';
            else                msg += '.';
            alert(msg);
        }).fail(function () {
            alert('Network error. Try again.');
        }).always(function () {
            $b.prop('disabled', false).html(orig);
        });
    });

    // ── View modal — read-only inspect of the carrier's current 999 record ──
    var FIELDS = [
        { key: 'title',        label: 'Title',          required: false },
        { key: 'forename',     label: 'Forename',       required: false },
        { key: 'name',         label: 'Name / Surname', required: true  },
        { key: 'honours',      label: 'Honours',        required: false },
        { key: 'bussuffix',    label: 'Business suffix',required: false },
        { key: 'premises',     label: 'Premises',       required: true  },
        { key: 'thoroughfare', label: 'Street',         required: true  },
        { key: 'locality',     label: 'Town / City',    required: true  },
        { key: 'postcode',     label: 'Postcode',       required: true  }
    ];
    var STATUS_PILLS = {
        set: '<span class="nines-pill is-set">999 Set</span>',
        incomplete: '<span class="nines-pill is-incomplete">Incomplete</span>',
        missing: '<span class="nines-pill is-missing">Missing</span>',
        noCarrier: '<span class="nines-pill is-noCarrier">Not on a managed carrier</span>'
    };

    function statusFromResp(d) {
        if (!d.on_carrier)  return 'noCarrier';
        if (!d.has_data)    return 'missing';
        if (!d.complete)    return 'incomplete';
        return 'set';
    }

    function renderViewModal($ov, d) {
        var status = statusFromResp(d);
        var meta = '<div class="ninesv-meta">' +
                     '<div class="ninesv-status-line">Status: ' + (STATUS_PILLS[status] || '') + '</div>';
        if (d.last_checked) {
            meta += '<div>Last checked: <strong>' + escHtml(d.last_checked.replace('T', ' ').substring(0, 16)) + '</strong></div>';
        }
        meta += '</div>';

        var grid = '<table class="ninesv-grid">';
        FIELDS.forEach(function (f) {
            var v = d.emergency ? (d.emergency[f.key] || '') : '';
            var missing = f.required && !v;
            grid += '<tr>' +
                      '<th>' + escHtml(f.label) + (f.required ? ' <span class="req">*</span>' : '') + '</th>' +
                      '<td' + (missing ? ' class="required-missing"' : '') + '>' +
                        (v ? escHtml(v) : '<span class="empty">empty</span>') +
                      '</td>' +
                    '</tr>';
        });
        grid += '</table>';

        if (d.merged_address) {
            grid += '<div class="ninesv-meta" style="margin-top:14px;"><strong>Address read out to dispatchers:</strong> ' + escHtml(d.merged_address) + '</div>';
        }
        if (status === 'missing' || status === 'incomplete') {
            grid += '<div class="nines-importance" style="margin-top:14px;">' +
                      '<strong>Action needed.</strong> ' +
                      (status === 'missing'
                        ? 'No 999 record is on file for this number. Dispatchers won\'t have an address if someone here dials 999.'
                        : 'Required fields are missing. Click <em>Manage</em> to fix the record before someone needs it.') +
                    '</div>';
        }

        var foot = '';
        if (d.service && d.service.service_id) {
            foot = '<a href="clientarea.php?action=productdetails&id=' + d.service.service_id + '" class="btn btn-primary btn-sm">Manage on service page <i class="fa fa-arrow-right"></i></a>';
        }
        foot += '<span class="spacer"></span><button type="button" class="btn btn-default btn-sm ninesv-close">Close</button>';

        $ov.find('.ninesv-body').html(meta + grid);
        $ov.find('.ninesv-foot').html(foot);
    }

    function openViewModal(e164) {
        $('.ninesv-overlay').remove();
        var $ov = $(
            '<div class="ninesv-overlay">' +
              '<div class="ninesv-dialog">' +
                '<div class="ninesv-head">' +
                  '<h4><i class="fa-duotone fa-shield-halved" style="--fa-primary-color: rgb(var(--accent)); --fa-secondary-color: rgb(var(--accent) / .55);"></i> 999 Record &mdash; <span class="ninesv-num"></span></h4>' +
                  '<button type="button" class="close ninesv-close">&times;</button>' +
                '</div>' +
                '<div class="ninesv-body"><div style="text-align:center; padding:30px; color: rgb(var(--muted));"><i class="fa fa-spinner fa-spin"></i> Loading carrier record…</div></div>' +
                '<div class="ninesv-foot"><span class="spacer"></span><button type="button" class="btn btn-default btn-sm ninesv-close">Close</button></div>' +
              '</div>' +
            '</div>'
        ).appendTo('body');

        $ov.on('click', '.ninesv-close', function () { $ov.remove(); });
        $ov.on('click', function (e) { if (e.target === $ov[0]) $ov.remove(); });
        $(document).on('keydown.ninesv', function (e) {
            if (e.key === 'Escape') { $ov.remove(); $(document).off('keydown.ninesv'); }
        });

        $.ajax({
            type: 'post',
            url:  'index.php?m=resellervoip&action=ninesView',
            data: { numberE164: e164 },
            dataType: 'json'
        }).done(function (resp) {
            if (!resp || !resp.ok) {
                $ov.find('.ninesv-body').html('<div class="alert alert-danger">' + escHtml((resp && resp.error) || 'Could not load record.') + '</div>');
                return;
            }
            $ov.find('.ninesv-num').text(resp.numberDisplay);
            renderViewModal($ov, resp);
        }).fail(function () {
            $ov.find('.ninesv-body').html('<div class="alert alert-danger">Network error loading record.</div>');
        });
    }

    $(document).on('click', '.nines-view-btn', function (e) {
        e.preventDefault();
        openViewModal($(this).data('e164'));
    });
});
{/literal}
</script>
