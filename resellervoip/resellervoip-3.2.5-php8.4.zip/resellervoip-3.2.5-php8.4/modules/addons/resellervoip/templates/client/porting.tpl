<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
{$paletteStyle}
<link rel="stylesheet" href="modules/addons/resellervoip/templates/client/js/jquery-ui/jquery-ui.min.css">
<link rel="stylesheet" href="modules/addons/resellervoip/templates/client/css/index.css?v=313">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<link rel="stylesheet" href="modules/addons/resellervoip/templates/client/css/pbx-shim.css">
{literal}
<style>
/* All colours through gv-system tokens; the brand palette is teal only. */
.porting-page { margin: 16px 0 0; color: rgb(var(--text)); }   /* full width, in line with the page title */
.porting-hero {
    border: 1px solid rgb(var(--border));
    border-radius: 18px;
    padding: 22px 26px;
    background: rgb(var(--bg));
    box-shadow: 0 8px 0 -2px rgb(var(--accent));
    margin-bottom: 20px;
}
.porting-hero h2 { margin: 0 0 6px; font-size: 22px; font-weight: 800; letter-spacing: -0.01em; }
.porting-hero p.lede { color: rgb(var(--muted)); margin: 0 0 14px; line-height: 1.5; max-width: 70ch; }
.porting-prices { display: flex; flex-wrap: wrap; gap: 8px; }
.porting-price {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 4px 12px; border-radius: 999px;
    background: rgb(var(--surface)); border: 1px solid rgb(var(--border));
    font-size: 12px; color: rgb(var(--muted));
}
.porting-price b { color: rgb(var(--text)); font-weight: 700; }

.porting-step {
    border: 1px solid rgb(var(--border));
    border-radius: 16px;
    background: rgb(var(--surface));
    padding: 20px 22px;
    margin-bottom: 16px;
}
.porting-step[hidden] { display: none !important; }
.porting-step-head { display: flex; align-items: flex-start; gap: 14px; margin-bottom: 14px; }
.porting-step-num {
    flex: 0 0 auto; width: 30px; height: 30px; border-radius: 50%;
    display: inline-flex; align-items: center; justify-content: center;
    background: rgb(var(--accent)); color: rgb(var(--accent-contrast));
    font-weight: 800; font-size: 13px;
}
.porting-step-head h3 { margin: 0 0 3px; font-size: 16px; font-weight: 800; }
.porting-step-head p { margin: 0; color: rgb(var(--muted)); font-size: 13px; line-height: 1.45; }
.porting-step-target {
    display: inline-flex; align-items: center; gap: 6px;
    margin-left: 6px; padding: 2px 10px; border-radius: 999px;
    background: rgb(var(--accent) / .14); color: rgb(var(--accent-ink));
    font-size: 12px; font-weight: 700; vertical-align: middle;
}
.porting-fallback {
    border: 1px solid rgb(var(--warn)); background: rgb(var(--warn) / .1);
    border-radius: 12px; padding: 10px 14px; margin-bottom: 14px; font-size: 13px; color: rgb(var(--text));
}
.porting-fallback[hidden] { display: none !important; }

/* Step 1: which service — cards for a few, a searchable picker for many */
.porting-services { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 12px; }
.porting-service {
    position: relative; display: flex; flex-direction: column; gap: 4px;
    padding: 14px 16px 14px 44px; margin: 0;
    border: 1.5px solid rgb(var(--border)); border-radius: 14px;
    background: rgb(var(--bg)); cursor: pointer;
    font-family: inherit; font-weight: 400; text-transform: none; letter-spacing: 0;   /* not the theme's label styling */
    transition: border-color .15s ease, box-shadow .15s ease;
}
.porting-service:hover { border-color: rgb(var(--accent)); }
.porting-service.is-on { border-color: rgb(var(--accent)); box-shadow: 0 0 0 3px rgb(var(--accent) / .18); }
.porting-service input { position: absolute; left: 16px; top: 18px; margin: 0; accent-color: rgb(var(--accent)); }
.porting-service-name { font-weight: 700; font-size: 14px; color: rgb(var(--text)); }
.porting-service-sub { font-size: 12px; color: rgb(var(--muted)); }
.porting-service-meta { display: flex; align-items: center; gap: 8px; margin-top: 4px; font-size: 12px; color: rgb(var(--muted)); }
.porting-service-meta i { color: rgb(var(--accent-ink)); }
.porting-badge {
    display: inline-block; padding: 1px 8px; border-radius: 999px;
    font-size: 10px; font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
    background: rgb(var(--border) / .6); color: rgb(var(--muted));
}
.porting-badge.is-active { background: rgb(var(--accent) / .16); color: rgb(var(--accent-ink)); }
.porting-badge.is-pending { background: rgb(var(--warn) / .16); color: rgb(var(--warn)); }
.porting-badge.is-suspended { background: rgb(var(--danger) / .14); color: rgb(var(--danger)); }
.porting-badge.is-progress { background: rgb(var(--warn) / .16); color: rgb(var(--warn)); }
.porting-badge.is-done { background: rgb(var(--accent) / .16); color: rgb(var(--accent-ink)); }
.porting-badge.is-failed { background: rgb(var(--danger) / .14); color: rgb(var(--danger)); }
.porting-picker { max-width: 640px; }
.porting-picker-hint { margin: 8px 0 0; font-size: 12px; color: rgb(var(--muted)); }
.porting-picker .select2-container { width: 100% !important; }
.porting-picker .select2-container--default .select2-selection--single {
    height: 46px; border: 1.5px solid rgb(var(--border)); border-radius: 12px; background: rgb(var(--bg));
}
.porting-picker .select2-container--default .select2-selection--single .select2-selection__rendered { line-height: 44px; padding-left: 14px; color: rgb(var(--text)); }
.porting-picker .select2-container--default .select2-selection--single .select2-selection__arrow { height: 44px; right: 8px; }
.porting-picker .select2-container--default.select2-container--focus .select2-selection--single,
.porting-picker .select2-container--default.select2-container--open .select2-selection--single { border-color: rgb(var(--accent)); box-shadow: 0 0 0 3px rgb(var(--accent) / .18); }
.porting-opt { display: flex; flex-direction: column; gap: 2px; padding: 2px 0; font-family: inherit; text-transform: none; letter-spacing: 0; }
.porting-opt-name { font-weight: 700; font-size: 13px; }
.porting-opt-sub { font-size: 11.5px; color: #64748b; display: flex; flex-wrap: wrap; align-items: center; gap: 8px; }
.select2-container--default .select2-results__option--highlighted[aria-selected] .porting-opt-sub { color: inherit; opacity: .85; }
.porting-opt-sel { display: inline-flex; align-items: center; gap: 8px; }
.porting-opt-sel .porting-badge { vertical-align: middle; }

/* Step 2: which kind of number */
.porting-types { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px; }
.porting-type {
    display: flex; align-items: center; gap: 14px; text-align: left;
    padding: 16px 18px; border: 1.5px solid rgb(var(--border)); border-radius: 14px;
    background: rgb(var(--bg)); color: rgb(var(--text)); cursor: pointer;
    transition: border-color .15s ease, box-shadow .15s ease;
}
.porting-type:hover { border-color: rgb(var(--accent)); }
.porting-type.is-on { border-color: rgb(var(--accent)); box-shadow: 0 0 0 3px rgb(var(--accent) / .18); }
.porting-type-ico {
    flex: 0 0 auto; width: 42px; height: 42px; border-radius: 12px;
    display: inline-flex; align-items: center; justify-content: center;
    background: rgb(var(--accent) / .14); color: rgb(var(--accent-ink)); font-size: 18px;
}
.porting-type-text { display: block; }
.porting-type-title { display: block; font-size: 14px; font-weight: 700; }
.porting-type-sub { display: block; font-size: 12px; color: rgb(var(--muted)); margin-top: 2px; }

/* Step 3: the form (the service page's own, loaded in place) */
#portingFormHost { position: relative; min-height: 80px; }
#portingFormHost .giant-port-form { max-width: none !important; margin: 0; }   /* the service page centres it at 720px; here it fills the step */
.porting-spinner { text-align: center; padding: 30px 0; color: rgb(var(--muted)); font-size: 13px; }
.porting-spinner i { font-size: 22px; color: rgb(var(--accent)); display: block; margin-bottom: 8px; }
.porting-alert {
    border: 1px solid rgb(var(--danger)); background: rgb(var(--danger) / .08);
    border-radius: 12px; padding: 12px 14px; margin-bottom: 14px; color: rgb(var(--text)); font-size: 13px;
}
.porting-alert .porting-alert-title { font-weight: 700; color: rgb(var(--danger)); margin-bottom: 4px; }
.porting-done { text-align: center; padding: 26px 10px; }
.porting-done i { font-size: 40px; color: rgb(var(--accent)); display: block; margin-bottom: 10px; }
.porting-done h4 { margin: 0 0 6px; font-size: 18px; font-weight: 800; }
.porting-done p { color: rgb(var(--muted)); margin: 0 0 16px; font-size: 13px; }
.porting-done .btn + .btn { margin-left: 8px; }
#giantModalAddForm .form-group label { font-weight: 600; }
.porting-mobile-note {
    border: 1px solid rgb(var(--border)); background: rgb(var(--bg));
    border-radius: 12px; padding: 12px 14px; margin-bottom: 16px; font-size: 13px; color: rgb(var(--muted)); line-height: 1.5;
}
.porting-mobile-note b { color: rgb(var(--text)); }

/* The account's port requests */
.porting-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.porting-table th {
    text-align: left; padding: 8px 10px; font-size: 10.5px; letter-spacing: .12em; text-transform: uppercase;
    color: rgb(var(--muted)); border-bottom: 1px solid rgb(var(--border));
}
.porting-table td { padding: 10px; border-bottom: 1px solid rgb(var(--border) / .6); vertical-align: middle; }
.porting-table td.num { font-family: var(--font-mono, 'JetBrains Mono', monospace); font-weight: 700; white-space: nowrap; }
.porting-table td .muted { color: rgb(var(--muted)); font-size: 12px; }
.porting-empty { color: rgb(var(--muted)); font-size: 13px; padding: 10px 0; }
.porting-table-wrap { overflow-x: auto; }
@media (max-width: 640px) {
    .porting-step { padding: 16px; }
    .porting-hero { padding: 18px; }
}
</style>
{/literal}

<div class="porting-page">
    <div class="porting-hero">
        <h2>Bring your numbers to us</h2>
        <p class="lede">Move a landline, business or mobile number onto any of your VoIP services. Choose the service it should join, tell us about the number, and we take it from there &mdash; you'll hear from us as the port progresses.</p>
        <div class="porting-prices">
            {if $prices.geographic}<span class="porting-price"><i class="fa-solid fa-phone"></i> <b>Landline</b> {$prices.geographic|escape} {$taxSuffix|escape}</span>{/if}
            {if $prices.nonGeographic}<span class="porting-price"><i class="fa-solid fa-building"></i> <b>Non-geographic</b> {$prices.nonGeographic|escape} {$taxSuffix|escape}</span>{/if}
            {if $prices.mobile}<span class="porting-price"><i class="fa-solid fa-mobile-screen"></i> <b>Mobile</b> {$prices.mobile|escape} {$taxSuffix|escape}</span>{/if}
        </div>
    </div>

    {if $services|@count == 0}
    <div class="porting-step">
        <div class="porting-step-head">
            <span class="porting-step-num"><i class="fa-solid fa-phone-slash"></i></span>
            <div>
                <h3>No VoIP service to port onto yet</h3>
                <p>A number has to join one of your VoIP services. Once you have one, come back here to bring your numbers across.</p>
            </div>
        </div>
    </div>
    {else}

    <div class="porting-step" id="portingStep1">
        <div class="porting-step-head">
            <span class="porting-step-num">1</span>
            <div>
                <h3>Which service should the number join?</h3>
                <p>When the port completes, the number appears on this service, ready to route.</p>
            </div>
        </div>
        {if $services|@count > 3}
        <div class="porting-picker">
            <select id="portingServiceSelect" class="form-control">
                <option value="">Search your services&hellip;</option>
                {foreach $services as $s}
                <option value="{$s.hostingId}" data-name="{$s.displayName|escape}" data-product="{$s.productName|escape}" data-tenant="{$s.tenantName|escape}" data-numbers="{$s.numbers}" data-status="{$s.serviceStatus|escape}" data-statuskey="{$s.statusKey|escape}"{if $s.hostingId == $preselect} selected{/if}>{$s.displayName|escape} &mdash; {$s.productName|escape}</option>
                {/foreach}
            </select>
            <p class="porting-picker-hint"><i class="fa-solid fa-magnifying-glass"></i> Type a name, number or product to find it &mdash; {$services|@count} services on your account.</p>
        </div>
        {else}
        <div class="porting-services">
            {foreach $services as $s}
            <label class="porting-service{if $s.hostingId == $preselect} is-on{/if}">
                <input type="radio" name="portingService" value="{$s.hostingId}" data-name="{$s.displayName|escape}"{if $s.hostingId == $preselect} checked{/if}>
                <span class="porting-service-name">{$s.displayName|escape}</span>
                <span class="porting-service-sub">{$s.productName|escape}{if $s.tenantName && $s.tenantName != $s.displayName} &middot; {$s.tenantName|escape}{/if}</span>
                <span class="porting-service-meta">
                    <span><i class="fa-solid fa-phone"></i> {$s.numbers} number{if $s.numbers != 1}s{/if}</span>
                    <span class="porting-badge is-{$s.statusKey|escape}">{$s.serviceStatus|escape}</span>
                </span>
            </label>
            {/foreach}
        </div>
        {/if}
    </div>

    <div class="porting-step" id="portingStep2"{if !$preselect} hidden{/if}>
        <div class="porting-fallback" id="portingFallback" hidden><i class="fa-solid fa-triangle-exclamation"></i> This page's scripts haven't started. If the buttons don't respond, use the Port tile on the service page instead, or refresh and try again.</div>
        <div class="porting-step-head">
            <span class="porting-step-num">2</span>
            <div>
                <h3>What kind of number is it?</h3>
                <p>Landline and business numbers port through a signed authority; mobiles need the PAC from your current provider.</p>
            </div>
        </div>
        <div class="porting-types">
            <button type="button" class="porting-type" data-type="landline">
                <span class="porting-type-ico"><i class="fa-solid fa-phone"></i></span>
                <span class="porting-type-text"><span class="porting-type-title">Landline or business number</span><span class="porting-type-sub">01, 02, 03 and 08 numbers, single lines or whole ranges</span></span>
            </button>
            <button type="button" class="porting-type" data-type="mobile">
                <span class="porting-type-ico"><i class="fa-solid fa-mobile-screen"></i></span>
                <span class="porting-type-text"><span class="porting-type-title">Mobile number</span><span class="porting-type-sub">07 numbers &mdash; text PAC to 65075 for your code first</span></span>
            </button>
        </div>
    </div>

    <div class="porting-step" id="portingStep3" hidden>
        <div class="porting-step-head">
            <span class="porting-step-num">3</span>
            <div>
                <h3>Tell us about the number <span class="porting-step-target" id="portingTarget"></span></h3>
                <p id="portingStep3Hint">The same details the service page asks for &mdash; sent to the service you chose above.</p>
            </div>
        </div>
        <div id="portingFormHost">
            <div id="giantModalSpinnerDiv" class="giantModalPanel porting-spinner" style="display:none;"><i class="fa-solid fa-spinner fa-spin"></i>One moment&hellip;</div>
            <div id="giantModalAlertDiv" class="giantModalPanel porting-alert" style="display:none;">
                <div class="porting-alert-title"><i class="fa-solid fa-triangle-exclamation"></i> That didn't go through</div>
                <div id="giantModalAlert"></div>
            </div>
            <div id="portingDone" class="giantModalPanel porting-done" style="display:none;">
                <i class="fa-solid fa-circle-check"></i>
                <h4>Port request submitted</h4>
                <p>It's listed below. We'll email you as it moves along, and the number will appear on the service once the port completes.</p>
                <button type="button" class="btn btn-primary" id="portingAnother"><i class="fa-solid fa-plus"></i> Port another number</button>
                <a class="btn btn-default" id="portingSeeService" href="#"><i class="fa-solid fa-arrow-right"></i> Open the service page</a>
            </div>
            <div id="giantModalAddFormDiv" class="giantModalPanel" style="display:none;">
                <form id="giantModalAddForm" class="modalForm" method="post"></form>
            </div>
        </div>
    </div>

    <div class="porting-step porting-history" id="portingHistory">
        <div class="porting-step-head">
            <span class="porting-step-num"><i class="fa-solid fa-clock-rotate-left"></i></span>
            <div>
                <h3>Your port requests</h3>
                <p>Every request across your services. For live carrier updates and the paperwork on a request, open it on its service page.</p>
            </div>
        </div>
        <div class="porting-table-wrap">
            <table class="porting-table" id="portingTable">
                <thead><tr><th>Number</th><th>Service</th><th>Type</th><th>Requested</th><th>Port date</th><th>Status</th><th></th></tr></thead>
                <tbody id="portingRows"></tbody>
            </table>
            <div class="porting-empty" id="portingEmpty" style="display:none;">No port requests yet. Your first one will show here as soon as it's submitted.</div>
        </div>
    </div>
    {/if}
</div>

<script type="application/json" id="portingRowsJson">{$rowsJson|replace:'</':'<\/'}</script>
<script>
var portingPreselect = {$preselect};
var portingPresetType = "{$presetType|escape:'javascript'}";
</script>
<script>window.pbxConfig = {$pbxConfig};</script>
<script src="modules/addons/resellervoip/templates/client/js/pbx-shim.js?v=3"></script>
<script src="modules/addons/resellervoip/templates/client/js/porting.js?v=3"></script>
