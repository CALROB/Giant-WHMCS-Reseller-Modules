<?php //0032b
// Giant Reseller Phone System addon 3.2.5 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo8pccPU1Nz98uaFHJ2OBa0Ng+CaBbsW7hwySk3mSZgLb+xN7WaJIgE+GKOSQ+iTlTDVQ63k
QSfkv1w5ayml+89FvobXonUYEBfrLxUbZbvLKudKpgOdWeIQSi+/ZE0Uy7jasoppDfcrx+ZTiD/P
uggG2F+nGPdYNYFMgxVujQRjLNddg/jj6GxzgmWhxxP4I3AOMbwUv/Ce39BnE4h8OgAImDm8Rykc
xp65QAJPsAe6khmjNTqXKpqnuWA/THNuDHE9CzyAlWmlE5uExeXUya5jNGnyfueYR1tRcs8Gzhdc
7fAn+bs7JV/0oTck8YSON92QaIU4fdjWSFb2oL8kiFxWEW7ca10T86vrPU/FAtmSublI3uUALNBg
Ub5COkijbAKC0v84nK5wariotAW4LRrlCiuNQNpPjLKQeJFCuSrcEbK4skoKpEuJo0qu6a/sAyhP
NTks3IRPFXK5vvsCYcmZhzBaA/roaX8Fk4xwQmRkKR8Leqmlq6k9atclnHuo+s2M9pFSTwQSCDFk
8HhBQlyTBBiemrBYhmLCk1ljIy4UYePkYAznzl8VKJ59dsiGutWexWY+cWaSmoWMbnuhIscMcNeR
CQEcJ4rB8bo5gL94MT7KDTUV5ELvfb+JeiEosMar7gaDpmGG5qn0kd9fe71RN0rr8UI8cLGbw0QZ
hQD7a0LGvskcxCXwjtyXGSvJDnZ5H635zDOgKU0WUZMxA22QfW7KJdh88EByOPgGVmJ4TCl7FQFf
rDoDvYXG7Pnp0CJJQbHsPQFtsm5Z4LdH2zVRdFTK6cqooFPRrnXmmF5PfHKzj2D1GcNS5/tXWCYe
Sm7X7zgbRi6/h1mHgBfJUCnEdDV8Wjf/xCeD6K1D7uGB2JsTmU3gPVbvwaq4Zd7vxrzo5/EdhZJs
3o5OYId98O4xaEeEagcsxBUK+a89GEm996VYvHaBLVXxP/ONXbhCHK5YlLHuxZqdTg6qsftNREK0
ZdnsLPkpzOZMSbIP8ZG9KAJwna7WtcoD97N2ngsFCxgmrR6NjX4mirpB1azCnxPslWOYxyRb1Py+
OLzyxQb+2G1eNb+6mjgUMGWaVexv/7p03rWkfzbwWvSRAhMPSzGAN0HguaXyUrCC+Y02kKWYAKZQ
ek1n7pwasuNTgfVCrD3S3IIb0P++jcgK0CuFVWvk6CmzWrKapMht6MBE1PwO71ZghsMmiOD6528=