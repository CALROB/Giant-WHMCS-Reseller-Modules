<?php //0032b
// Giant Reseller Phone System addon 3.2.5 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz2cFyWCTeJlpHogwpNTOIiLUHwy8E3IHvixm8b5vOrrouR14BuTeo+PuTiQQkOAFnCULv/j
SU/Fhky8TTZ5lvdUHMhi/C+DcvF222uAzDFlwod6ZRRj0S/wPF6MDJZdrSO+9sMkqC/VER7zPUCa
m4dSSge8fh5UEsKe7iiUkUt5d7JwsB5JiOt14ZZgzPzei3wkQq2dPLGtsP9pWb0jj0JqvOGsaUTH
V8OEsCLS95VpwO9OPTwgDjUTAhV3mqIj6izg/09qoFyT5I0CBpXU3kw8Nl91RLqCVAUAZdFlbo6E
PTPDC/IQuG1gRNd/sgDJqFamWHIYSJVebVO2hVUcgiowCIgRejlaXtrhBBJM1EQEeIoBKalapHdU
kUAuJ7bTbP2oapjfOYvFkwDGQrcy8eQ5fcH3wkoEtshKcgHmCTXtyVTxdaJHR7HO/5oZltyhls+N
WTL2B4USnsTpAguglbHlbWwCF++r9qomDIsVIC/OTiIzPx0YevnJ9GlKo+LAo02csbhJaTws6P8j
gCg4eXnWi5DecNfd7rEipPXcRQBb9oVufNYTGlgryRO0ov2lGF+SdI4FjSXk/4dvNMGhbz2Qop0O
Fb+Xcyrsswy7+SvLDCtbu5Oa+FlUUVqVY/XHavV56olaNyc/9xMG1FybGyBdWCFW1yNEFWtZGKxx
aS1p/6wceLow9/7PynNq9UA/t01h0ibHYGTnmgVxLDkzYmKsw4TplSDdqYAVSMJ/6Xhe2fUOE3Lt
usyVGlNKU8mt6khhghhBPLExAgy/Xsq8s/oPKg35rUfz8vsNZnVPfk3t9qBBFL4o5LA7OUiuJac0
Aq/33DTCFtXmlc0xuoxHg/p7V+hCTotsuxHqxs9nCszig6cNN/OQjNIWvSy86hCAf0r3Z+c76uNJ
jsp+7pEGMqjm1JeWsE7i8pD9H/ykYxN1IxozLKLXdqJcIy/SjdpsA+55JCfS3Hr1X7PwQn0Y44hr
Lal27XjrqUtxOYS1V7LA1GwKf9xVyJ7bqn3vQwMgmhs7Nu5R+H+wnyTuq2Z9bqsSezNDfTBZLca+
wIZwQNjaKMStW145HRmamJCJ8F6jvdLZ0jObxCytm+HQhYexhVXzIRbl+Obu26g3s5YKOLbEMtHm
ynGDXm+27mJ8X4MkHNVbWOpYPj9OvkIfYKsesm==