<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzVAurKs8jYQot1sTX0xPcQuPeQSJzVQFwEy9XGV46edrLvHOmV2BcFZD4krDcIxfScqzLnm
O/O8KkLRNHLEPC2GGzc41h8dwe+3Gup1fdqj82EmoSRXfEj19DxEiPykRwDdyAIUjy3edy6RnFif
KTMtvkdxy29I7TPhbzfu/wkzVCu+vvLhraHDlQBsZd4HwoQEIjgd618liB1+NjMyn4pn80suWozk
iXsQZqVsD9KredQnfycZde0jZriPSOZHxcPRDLSNA+rVzPU/ZJvBV0Va1yGNwhrLRxLavxL5RpsK
L+stRerjL/yCo9ebXhdEFkZRAoeDqpHK/iS5CefH3R6OuxP85fKwaRCoGKg+qNjYinRjuxuIusLv
w4i1ihOMS+oSP6q57y5k0IzrfcyP/B+Z6oIq6lMjUn65BkIXByqYdoYaZbv/lwe1YmlScew+EpNU
QFaX9gKiygRv1BTttvZqaAguwKDbaNQd/M4jwoNGuCPMcsARq6wGxBkufcDJM7m7gzyVqzvFiv2L
Xp6uO8m83Sqr8pwLdWw2tAIWaxv4HuzcDGfLYrfazEqOb0V/V4c1VtRxSfR0trXqySxaqek+OYoA
D22XofmwOXA3TLtiMAyM65LeoOQ+pkVfP7fehpZlDsTgoDzgbsfRcvk9vVbkroqjezoMNyN/eerm
ezbkUbYcnCNQzdQoLNLoceQM7igzb+twjifXtMs9ZXeH0+jzxdXG0NoXVLC3D3vrLXgZBmagwNnk
7t8FOiVsi+d+cx53eVQ9oHQCndb6vrkAEQk38/NgqzByjLkUm1fs5tsHEv637jxpVLZzvn2I21wk
PQEJb0xfBWisoTymkN0uAHoAU6jd6PGk8KqVtM5JPrtTm36BBie2uozpPv0UvY/TPPlCc8jpMOcY
AuxRv7Ym8vWmEaSLBLGr3cDTisFyMztuQhtE580i3k6GByjT0oMeaCWqgFBypo2/c0mIhySjb5NU
Ojrtmh8IHZa7m3ryaiVGt9QuKchowJh5Rkx3zcegTOcgvY3Ay8tcSeIqJAkPhPEN+aj7GFr9Gdm9
9lgiokm5P3IqN3c/BGiVGby7Ub7QXbrFnhCisZakb0rWRDm7MuXs7qnna9i6E4F6KMivKuCjaTl/
2BKU/ZUlsFYoTbLf7au/V4WUQkAcKxqvGkUv