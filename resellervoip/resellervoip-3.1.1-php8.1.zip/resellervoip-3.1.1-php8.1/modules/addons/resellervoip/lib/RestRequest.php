<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+53r+0AbIlNr/b2m/pzcDcknaE1tnzWOR+yj+00zeBTESreBU2LpOJfwW7OMX2i0Yb0HTc0
CbvyEWjg7RXHk+GFYZMXQkbO0W663vKTrvVKxtmLpogl/aeoHYc6wbKA8mJZMsJN8EVXv/KHr55x
6TaUWtlHXOuw6zS/KKNw0F4wWrUsAWT2y7j0QNKN+GZkYwZMrbqImFJWbNBKJwYl39SK7SWsk95w
h2vdNA9HjY//5NL2vLzOyj14krT0c2c7rp70PtypbkrVzPU/ZJvBV0Va1yGNwhsZQuqWIg4xdLil
o0NFSPHjAHUetBU3GMsDyap/iBhga2KDsjCxZBZ5nubNGpXbsc4tUNwQ7XqlkMzKxGEf8E/fIIzB
UxSV5+FpISfmNtd34BwroDN7hkSvE7rzwDPUkn19asvVOODx5WkUULtiRb8KBZwKAfPPAwBHVny6
csbulw2dEwj2POTD97IKXXE7FQ4dEpLyQ/YwKTsisoL8eqFC3J7EW7iDjt+i4C+z0VA1G+VW5HTG
w1S5QM7H05wN6w8M8mJeLCs9nxN67ues30jKSrdR1v5mkh4g4b5boWxgWofItNFHfx3YDhPOHLfr
E56f4n//hW30MlPcM5zL2sjOHCFGHcdMIcuCJLHTVzaarNjfQlBzfz52ReyD/zicmVSR8pbTpvL0
if39Blc8VSU9E7gk4p/4/Y3yBkSmp7WF51il8iXYXDzgmm3IwD9RnDn7gj/IsQTrQ8BuPe/aY+lM
hdk8bD1zHgQjtzdE+YwIrLMQyNXgzVqQX1ESgt6+tNsX5Us5x2EuFpQwCFOBl5lM4vKjEBEmX9T6
legUeoUlDAgPDa9PqSKKIji1cjNFW+UK2WF/QpUG+GZP9c9JN5tn6uP4+azlXD1pLqX/lS9d9p12
Mh50vpLrwXqhoPuiGQvC0yqtT6aAXAIMOyiPzEMeCzFS9fiImOOYuTMrnyEJx05sS3KZOO+zwFwn
yNpDg1QTFXpG9OCOxv9VTpvRmccvcUlG7wq/7pTSCFAdX9ErPrUoVVk+u0JuxyNh7g3yfoRxdgjA
xUsVPYXXoN35H/4LNZ58hLibgWGWI35jUJbNZPQZIbAZtiqDsKCgpd9fPigMQ0Gl1tugmvvOQpsA
24X6s8fvx9IILoZGGsyF8k2pGk/SbWKvQruHXoOEAyBi7QriQEyat0lPD6Q7tD3jQkNaKlhAdypx
XUbPjiDI4ja=