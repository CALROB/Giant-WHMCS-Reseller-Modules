<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwIDZFOJQdNvxZWPrVjPyAV5Hzdkye0myRgypdxIITq8ncqtWPHXtZ8JbLgs0jip78JHtbPf
MrhNLAFjbgpZGuTrEdSiS1gZ/UuOzdk4aQ7Uth2W32BH2lSCkcEcBCt/mHjmKSlg4GDU/Pycx6Zv
s0ts/a8mnqAm2FD6Ni7zNi9Rb9QSZ58FD6oJW5l7u0kATzsFzp2Fp0ERofjaiy1S4wAhrNbqZIb1
3h/20BKEZ8SlIlNkRzZrlRb7hQNQo/5C/4kUx8lF3+rVzPU/ZJvBV0Va1yGNwhsSTBWrwH8qd+oh
IPLVyezjFI4CQqpOsUX0eu10zVuzIP0xGlCnm0I4B1j75sLyHZ2N+agTIdLEVGu0VqqD2lvWgmLB
j2uSqvJyhcnDA9Cm7t+iSTatsahkpjsx5/ru8uTXZXhKtQzeqZl0ON8rS1zVH0IBdPeCyjeVPiVR
JydGTHBz2zolbJe/V0iFW1cigBrqGSD2qIbkCANaTz1fUaJu3GmbV0+EyXuPGA2m8nb/W5nHCrbT
CJBba9DMtisHnLskU2tyV8CJQep3XFMMV4fAfcTMvukc6meudgPxk/0eBNcgt3f70Wz2kFwi5I2R
BWaRkcdWJJxa4mB/XU8fctwHQ6MalcoV1oOHYEqI0qI2f962bsCu9OacU9v3CpjQPXUA2UzhMgIp
Xme4xgNSl9C7pvNiYAerDRC+ZNBEtxfldIanE1Oq2hUWRJsycrMPIOCj7il4uF7+b9szz8AhGVU6
MjAILfSWPNv+llJlpAo1v73tsfyL0SU+woEzUTPs8mlrXwZzM5givaRKOURZgSOc69fFH6qSwpWS
foeinAgEQP0HCSgvk+sc1pfu8AQ4nIIsumG/vz9bPCy5in4Pwnpa07N5n3hl/JXkAYizfo7IlaYc
3FqGtEY484gG2Lu1jnwMQUlI3tcA7ZJOuGykhRNq+0mSIup86B3LDP2Y0CFTJk7sGjwkbC+RBWbc
E4tWURrme27zhc/iewibNVxzPY5MA/qVoRssjtxy/zVeXegemPPbpjy6ju4AIhRhaQSIDMlsib32
Qzi9V55KFZaHMFqQPuaFUpcjlajsCkGBGpjebtp1QA5bSq9JM8Bo7w1X+oTgNrRAxR21y4MByUk2
2f8Rs0ym2ITtmd3k3FdZ3LSq+ALvnPEVb6Q9425LYeFhhUzxYBChLodcrTRkRQUAeBjvt7PHzKFf
nQXOIM88GmYeciN+VMpuIDJbZzVe+EQEZFUfLYD1uCHAGAx4hUou0RtcqIuAAAkuaxeKi5ThBJFb
xF5Dhp2YyOnC4o1OT7GizSQ66mdNJ8KmKXpGK0iHXpVNn/0nwS7J+Dufb6l3yFT6fUrEUC45Mw7y
2x024x0JoAJBk7dSf0db5sNkTy6QFKgDD9doRyE5mWU5oTMq0wHrkoVRghR5qMWL+bKTdWssyfFE
v+Tx0mIRlVQ+1CuqJ1fOe5oDCawaUxFkOSd6HspakLT6nOEEBhe3QPjvv7OTYvOhTxEZHTduC+AB
KJF0C3B/MmJdygnIVB9pWdHM2c08EaizvEn5wIurZJ3r4xSgEZvhfsBCmsrHrflBSLsS9/0nUDW8
W7Y/KW4H4JkgH6c+tpGmr4gkv+iJuTnD+8PX78XPvExWRR0W5u6ooW74Si137XIyGU+CmQeemIJl
+oxWlsRoYDtNhH7Ve0592IC/Y8lOZoW8Na387HOT0i9FdKGa/2t5Cb22INamxAtq7zSbY9eD9QNV
2AEcbywfuMFV9RJYc0daT75GVftQ+gGMmkXs6yk3D1zhxIIdUcWcnrKIt7wgVh96IC49PPJlCy+U
0j5Y64/CZtJjq2DboFepAxdb4Zg1Hx/y8N/HeucFyb5EyFMCilcpcS2E6E7qSjaizOMcdJx0pi/m
UQ36hg0MqalqGiTGrJOovvRa4Cfw2IhqVmijQh1qP+Jg2E+4YvRZVCo3d7+P13djmw95MpeOWyp2
ldtvLIWYp72wCgn8SXIFs28Gmofv6xk3rtj1akOQyO1lhRTNjzJtxvwBnz6CE/BSoT2AyY3AOK4c
2DiWArKbuJZYALycWesicMr0EyJbm9W3I2yhOhUNZeTdLj+2FMXFeeUZ6vLaTmqaXQXakqzQ+cq1
5FmseRwi9HS=