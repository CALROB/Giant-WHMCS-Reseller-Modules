<?php //0032b
// Giant Reseller Phone System addon 3.2.3 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwJY4GZCIkelZLY4Aq3FVIhz1n/XGH9SKfMyANS0sjXU/pEpe6noaiL3Vas41Q+TYXJdWJfh
Ski7yQJ88suI1YwwYrmd730VJinA2qu7Qodp6a2vl1sOXFsOrC2BBybedzIEckf+DLNPTfyOUrZY
miY70/ZCsnz1J+Cc6hVMcOuBWFzkZ7STm7EBkDE9GKbtBBoIGZ+bo60f+PZAjuGgj75rN4ppUmW6
nUsMCxT/+QOG02FSc+5G3p6S6LUbqp4a7AVD6qIz935CiQ6sq1R+XD0qpcjcpit3PhWv33LG1F5K
+ZU5Ya96CKBVo/Ytu3IHY96JE81ar8D171dOTtww/f6z0o+g1d2RpNuAASRb+Y+s0mCftRbT9lCK
oN62ltUpUyxA86Rt9rgHCzQHMHbwYGMJZx1SdEF7m2jNJZV4VuriuYDYQgvvFU7g0+eT1d2+pcs5
KOtTbehowt3EDihr3sjaa6l5OYs4unZG4r9eXanWzhONtkhLbGL7g6Vkm1/KJaSNsPIhdnvKjqqo
huA3FkR7PI875RLHQv+T3/xp7oITMD+czd2qPWQPNGr1zYvIb0gV//XwS2rYuBCJ6w4nA17mC9QO
RTJD9UGu1DIKGjYMFduWqvxkRXwDVs8/AU3jMXZIyEnbNutrSgIa+ff9j1bTN3JjMSC9ehDujs4L
hv1PXBcrhPTcM7s46qUNISMFVWpgFKah4ANGCHKYGkx+RmoBOBjzLAjY6b2RKwVpqNGViopFUh2E
ipSfeBvKgNZxCOvTn0V1jA2qUz2IljzDn3CMKqWtXH13SvQxQuJpJAJ5bGO4PB1pVRDnWdoa525q
DqbwZBtQ1vJR26qhnlsEpOz7nsvav212y/GQH59kVqLDpjpt0RT7ZHakJALopCUcnRsz+ebg9Im8
He7dGJ4P1MUqIkJ/vp+8K7NtO8avZSFgm9SYpK/oBMnfKg3tAM55sAdtL8Nl91tKGk57yARHRSl8
4o0f2JKzf+5hgDgU4uV1vawb6mnlWvoFYV7TnspZaHzNy7iWNrPEma1vP1/6hu9lyjjZlWqiTPpW
Z94QqpH5eNPotYfPRD3kq37JOa3YJHnL6oex9h6tGx5j24eqhfVQvfTZB1p0s5pu1pQ1d7S8JuNE
o0+AJlug5L40SA4vQwpg0mZLZ10e0SY86aKmEW7FCPKB/YVk8BPMbPeJJ04ckC1NsaxoSuTzLt4p
KInhMPr97V2qaSgX1QfJuvIWjmfK06C=