<?php //0032b
// Giant Reseller Phone System addon 3.2.3 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmH3EVjobO7y3/cis1w2EcJiZGKArO1AzDD94diObN2uio0jg8eh1x2ALxNwl1tUEE8ZkYxb
Z0oPlzylb8oa4YNRmWOej4g5N3hbGlzKSuHfIAPwyaFBw0c64YvLQ22/lurvYAPoIV2z93dMy2/X
c1OobzbZGQ1guOMKOzml0fQOfUptRqH33UpusH9yVug7mgwpr5R4kyT7D5uIOki2wOKwdsgPwb2W
INIsv+uEGahApiQnUYLXOl1yJMGwByr0uzqMmBQGgtmnJB6Xjj0M/eJGDCvhPixDsMrc/3+DYG8v
7a4C/OT7BHd/y6VlKQOjt5w7oPzrBn6nKLC8PuyHDjLQR0Ui/9xysJBSFpUgnpSXQcoV97ufwnA1
xHUlUdB922fC5y/Kd9h5lors6wSwf1cVnqxaaIvkTFpCT7hTgjhHSngX4CBS98yIaIQdykJ54hS+
aDqNXi+V5iY4fDEDTgvc80aa05WPuj8ZrrT4PZKYhCwcR3h5V1ZWn3k9HL/gnEwqKvG1I6C2Rqkk
QBWM2V/6WGohtFtjaJEsIA2op646wbxePxdI5BgTLV9duwqBxtnwT2AfHXzEhQVJaV94EErcJK7r
bP5PI1HYnCtoHHg2gcYaoaOjQ/650YcotWx0769AEDPn0LqVCV+5yCqPdyQKu0nMT0QZxIXQqz+L
dJwyGxER4wblBD1bihxf1/DPcoQnroAGxxq24Gl1mc+w/fuJuhbMXOQYAxZ22I8Q7f1KdAs6ohqa
1p4cVrsaLJ5Fp/4G2PH15xnQfIdPubcbZKEA0RdPIdwwQa7Y9RksgMs0TvtWTC7KEg3pzGz+81Ii
darxpIBDGamGqmC6wy5kPl7Am5tLSDRowGlxbgZ4Yx5TZq3TJgWV1RkVRfO2paJVA1WqTGZOt2Hb
zzMG1YHqyT0fBhDr/Jvi+rnouGGxGbuCQB1BD98tVdTkkJAfPipTOsghSsHQtDFPhdWW/kxXkJMd
LAeX7HbcW2OuaGjbtunE1+oXr3b7RVAAAJDp4uN5soaKyu6P/bEhTqq8CP28RGI98PwnTbO8fDDW
1z1oa+kcYMwhBkzj33P47FZgUyBGMXNemF6lffSkfoyXlXNQahBJN3CCz4z9RGtX0vx1Uyr6v0c4
gmXgCweuLs1/r5C5iIKaz9tcaBHUCNR+uEZuRoFu4dwQSWFS2zRet06kw4QTC0==