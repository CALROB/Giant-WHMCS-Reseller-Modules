<?php //0032b
// Giant Reseller Phone System addon 3.2.3 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsQ+lIrRXmO29Wie3WoghFAMIbFg74rdtkceGGM5cHwYrvrtl2+Zx9w7nxfU13ymoBxO7JP6
Qatv2+tpMEP1imkpql5kBzffmZ2aXPwukEpuYraNP80SJHnEfboMNgK5qyYerf/WifRBC6IOCZP0
yWydKf3MJidKO/OmCIXJy/ftMquR8VbfVEb9DPB+GOl+H/heN7OvTFHFn8I3/dMiIhmVCEwMsQZg
hNAJda5JtQMFu+nbswbkCElK8IEwwCu+xkIGfnDljGGnJB6Xjj0M/eJGDCvhPixDZt20Jdw9y3BU
0VDgBGLDBHbyFaBgeHa9mc9ZC9JWh7u7UB3aXKbx6ZBcwMrZW+VPW+J5E1RePaWGLkS5ZFSp0h3x
3quQHeRlkT2Ehqu6bioFCh+mfh6EjGjc5+C/HXMIz4wIrHaeXoLrwSeN8pvqNYI2O9koUqJ388Fm
QCAQNKseet00tg9VYLgugm4SIvb3O8BFlnyWxfBvLUDdnD/tSl7q1KdqEdzFAXgbLF1nxa+JsMUW
su3mk0iYqAMq7UJSLHcvNPa65HYymPS8G63eB9zXLaJh840JZ1rGt895G9RVx6MEyzfVH/ML9tNG
r/xGy3sjSHoPeUo10NQ5unrRw8uIxtTLQUsP7EIlViWjFStaaAtl3VzGXKxbxgDeyezaTt52knmx
31h0j1ur393A1Fbc04VBdOhP9TllcvByYPCiIvQEzcMdnKNIIo+SL8Y5x4n1ZvQ5mye2RDWXJnx9
IMR11T6guyTQYURoi/Ai2YK6DltCFZi1134Z1P7wlmhS81PPxJJEv3iqzsyUj7WF3dhRzjg7yMwv
3O0IX9Jl3PY6DFv9fTQFNqtRMdytrw37of/K8yLRHC4Lot3KDQmOyoHo3dwwyGHVjrw37ShkNxnD
0VaYO8T9SNVgGhZjYJCRPXfTqKih1QYV97BartmQzVOVq7ra8NZxYocWuEAc3MW7M71VHhPtzPl7
qV72kPlukhEHybPy84eDNjH3CB9xBxsYOskNQoAy0vS4dfbbQOMklcJepleNd9Hr8o4G88HUbMu0
fMxaYCRrPmghsbG6YasLCRKCLRtp3gFhuZk2bIqHU6PFx32ubKnuAPc8gigCfuGd9eVmBH9dZC8f
aMnkWFOHaH5Sw3lWJxf724i/B4mYgk+jhW+TiJh+0r8CvqDTckGaIrmPqUd6RsWkoFDTAWRe7zu8
WTja0ivcL2271xXoeWm0TOkduHlKzUwCGHUi/Dhev5qOx3U8Av59647DJy19Lm+RoMKoRPTlL0h1
hDgfQ6/UtdWe6kGV2R7JBdjmYJivGm4Zedes60rgu8PZsoemxg2gX1fLpkA0ytJiio9umO+aLbaX
P1O7n46/lkPUZvxVrvypBG7kG1m5elwdbS+b95sRxOYXHTeiXh8UgllRMsfa6s9sm7jqn4lpKNyX
K3Tg+IyssXZ/6dmbFSoV23rqwXXZkPCWE4DOOPdLY7iEDDlzPhDpv+TSZ9INZo3+J67PRj9TAg8c
WY0I2PGAsC4h54BEDfByE7oybSCeYKjQE3zyeR1iHK+fppQUkKGPoL6/zlfePLzzn1IIlc9rBMdH
mh0UquPNTo4sJWBj9nnDsYWbRgQ/68R9+r9T6EjbhxMQ+UVAzAMLMJS2Bc/BtpDcRWaruAguS+Mk
nQdcyKG84pcqdVk3N4/Isg+BjGi+sHHxyGyg1lzdYnRZK+ccPWzMXC2upXlAZMI5KBPzrT2CPwwa
/SbHIhtFts6xfztm+B4++U7irlgTbVGkrmNyHue8Xxu0smz+epZwK9X55BGcKE9Ri9cIc0lJqmn8
jnidTl9p8qEHjDKqOYqQfizt2kY0IPPr8ytpMLpkRp6Poy3xoVNeB69S3GFbl6R3nnNR1Adha4jH
X9Rd8xxgVBlbIikZ76VO78qF+GBIG3jI5C8QOVTRUocbdRGQtqrlVXjPx3z1w7ZX6z6CkpP/+/R8
PG0qk5apuQIEP4LMMcN5QKS7/q+Gz/nOgCfrGZJ9yEgANYh/COWJ8H87DmgATkOtFO+GUwsgcU1n
4eVxYpvZANPA0G9HJnCi9Apslv58RIzclWCDULQ9gMl+rmZPQvxAdqkDwuXcSxKUCp7UJ3j/KySe
u0NYHv+V2MLuSvDgxhLQf/Jz