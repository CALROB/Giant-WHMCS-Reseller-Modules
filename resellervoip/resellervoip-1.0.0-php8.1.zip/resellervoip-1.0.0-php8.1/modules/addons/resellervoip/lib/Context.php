<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPocIIVibUhByD2ZSs1Tvq3Zl2U4Jj+V91UffVl6su/j/eIu41L4ZRK/+kw8UoLSWlsVIl58/
8hRoPZW0sPQacgxQ0OSZw6EeNNAsQCZ5N5IJKC8QG+dKiYXb/61cKQbkbHZj29Jk6ADNZbyEe+X6
iDit0px2j+sp8HcGtDPCN3h5n5sZer9iysmNccfoJJq38zQ2QZ1Ygf9V2SK9Sa+cT/9C5q7CB52N
58k8yayrM7lkWHsr2ao6Rm+orNmpZuyweFXnTP6ZrPTjGw2+bBnj4hXa9p7RTViYLMb3MR+BdKW9
i0kOINia3G1TZcVBuGYEAZb1gvagfhvPIsbIRN1Q49VK/5dfTHCBsrPAsHTreSU7j4ZgPcQluukj
mg/Icv8Ct9Ja/DSpHI6kTxicBSnl3sqxIuhDLAiWgdj6z9hO/8v7W6XPfgTkWDfgeNKUeXnPerTS
9GiSMB3XUYzmLjAEhk2TF/7z9QGMr2FD20LdMIrb4W02N+T/j5siGaoFZ/G/xRVcGxmhAZXMjFGg
RFafFpc9n3za564eRCeMp+lGbsOQQWxAT8rIlGei9ezYKTkdbn6fiRZsJXEi0XbVGcmTYpqKtfPm
VwxiLHFYNWgn9NFJkGQ/GJ5RL93dUBnkas9Qxf5ONqQWdDCbvS2LR/+GOpv3JJxcAtWDfzQvN61h
IW9iNLUwqQQUsY+upvJAIc7XLWFb+p5ksA7GDXULfqUHGYGDAvzT1G3uutR7XNvlaV6+2Z9BymGp
td1Sm6NBqd8FYso63umLqNn7MDoTO9qJSab5mXn9Qw0R5jnQmtWBPqZQwyHEqCUmlcXqTW2ovh4A
MLXjpTYJbLsXxt7ruauUoPRxS+zBfUPv/32aVTQ+NFDVuFHG3etAKnAtz1+Vw4u31zlZMtctBWgN
TPQxOuKLH9w6KfjHl3IvSxwzMdY21L1YIJAHFQzYUJLhQhQBb3IwiXGFHt1sVYG/bq3edIqBEalw
np2qZxLLOtM0lb9SV7DmvWTIW6g+KCxCjbi/dGQGSZi5cttf0hXdFahhyitlwgMUotqZCb5U/ED5
eqQiM1xpCt0agHwOhRUs8XMdt9gLGBY5Pi8zRNk4dinSbdOl65w3Hu9//ISmDWy/aTPSmuyivn3h
PoZX34Rk4ATIhWI/cIPbHCRohZDhtaArWZRk1W==