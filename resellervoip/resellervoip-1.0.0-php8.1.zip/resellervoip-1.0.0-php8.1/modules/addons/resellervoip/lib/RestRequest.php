<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp8nnNfD1pvz38jGMNznrYDX0sBbCbFMySaLrA3JiOl2TaIqXzUWbWvAZc8TD1hdbgOjJ8w6
/EpTD+KEiUpPIU/7ABFtH5FnmHb9T+/EV6u58WHX55U6XOaZPfDG7JPLfjpOvD1dOmob6TrD0EGi
Vug7+UB+uPP280BbwPYrp8i8ul+Wl3wVz6UAEs76v1cD3loIaTwERctM0zRUGpxCyjnYtR2SWKYD
oqAj1dfnlQXxudkHW/s8yFK5qKgqnWqx9dGjyk8h1ALjGw2+bBnj4hXa9p7RTViY/rXkgy3sAKK0
PWubINii3Ih/OgstTtxvPQRgYnNmCFyuVH4TqbGKVVFYmPRSFpufOqSk44zAnytS08Eif1/3tP99
mkNBa8Jifzh22p4Elz5foXvblMwlwgaFEH7z+cBNPJwPPZioOo2EtgI/3SiqWUBhRE2TYE/FzFin
iyYvAmTAJFt/ncdgx/NPS7ymAFx86i7masL+mDdl5e5v3q8+XOjyR/n5B6wGFeEl9dHlLvRBCEOF
bqFja1IxusQZirxQsu1kqForWmCleBkMw+/MpTio2fW1FduxFnImyHppndZyExmuM8gokYqZb/bo
nRewQLy2lIKun8BIb1e5Jd/AECSI8ZeWehyNKuMvzsT6gkCe0KVIwBD5aLmZm7swzflMXXb//ZLR
w+FIk/wk/IJxGLTXqwBBrc922Du/2W81ABNQGTq9g2nmViJ5rqrOYWUdIIIGdF1ZZjmmBO430hVc
OARslwnFDymO1LO1FGgUqMax05qGDMm+TrONhNDyaqKNoPW8fdS7al1Mrn2H2GKnBoESQNe+6DGZ
ACixtMiKoCzwE9GTXw1WLw5+XavfkkN518B1O80ofOVTHwZu3D9qNmk8tmeB60GMIOf/3ZXtbvPS
zN/zAMcq08QsFN4vUQsnrztT7rsDQPb18nLqq2sMaivq6rbzxhf9xP2WoMlkbD1H0HkO/OUOVVKU
j2rTjB/2E/ULcP4UcSXUKdyFy6eWVycFooPzdUMj8OzgW50d0pyBXFh47t/rXymCydBa4Dll/GY6
rhm4o6kV7PtuZgnWQvk6P2MfHoz3RUdskswm/gFr9Xx3E++SdrnLM/AHkU1SQnsAz656liiiEJJ4
IfSJT48W2KtijSV9Y0F6O5Mbw+PPvVqi1R+Ma56jj3vVV57FI1Kqfc0jtVls3Yk8DLGNOA4tJnSh
