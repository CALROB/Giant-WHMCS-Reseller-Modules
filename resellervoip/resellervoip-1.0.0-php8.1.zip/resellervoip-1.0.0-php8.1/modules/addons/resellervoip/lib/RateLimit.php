<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmeZu53M2TbdgvLrSthRSK9jr0fP+ca1XAAybEYdnS8IaIvEtD29Y6S4Md/Xeq9AxKr1Nxqk
d9frR/6kQa4nrmTunbBPed/p2gp91wmVPE5fg6sDmwm1jI86pcj0R14BtkCZdY/E7R5sbsb2STaD
GeL1KY67Cts4YFSdLW4jZm/72vfFqu4jUOeb1oebqFRqvnVx1jWa3eJdvX5izkq6PSDMQ06d4cdd
m0APwRg+eGD2QDOKlq0KWLRh7d/JKX7jyADtiDrL4Mr3eBwKl6qIk6GdCTjr+oBdPQ4NJ/caiUpO
gBg1/oaDVgIiP6rYEtHKAUBGa9XPEotbnPZMhSTP6Q9vT14QR5TzC++VjzN5ggGgMYjaPg4hcU1B
egZxxwdvzbRSfBAbJ7aSL2L4ei/R+rGOr8x7lCmJOFhK4pBZ9veI5Tr1YWyTesKlEcxDvsE1K0N4
U6tLX6Faam2zzYVMRbn7RBPGURISpIuE0WJC96WWUtCEakkbnAKm7RNjbUpsYwi8LVPN1d5BTFfP
FPwkJbeEa6cqeHIExBkODmhUMggfbr8RKbGua87LJlrvpRbn6rVSVjO7Tdh8c31A5RBKkHXbbm25
fzDunN0Qtd2krGXMig9gLeAY6g0ewNu51DZYJWKJ7Srxlcf7Esyk6CeSjVjbbSn2kv1wUCCE0409
cZPfLmUJIOv3EBGxG3usGOC85XcH1+rWsKFE5psc2emsAOUsAoRQqBbKYQDC2PNNGc0I30I4/B05
mQGSDEUV4C/covoFw44qHEWkAQwP816Ufbl2KF9qOuT5+GLISm6yd41guMe1NKazVwWc5rbP/3P1
WDqwSjAkBBt3r0s2qc/KzcorOLyq/EjDPddCejX0nb13Ik67h3RmUAdGU7Ja6FfRZ+xasld+X6wb
sn384e4jf7BG4VO2jfnmdz/JTl+OGJeaDDKeGLvGwJLXFXlorDj/2/rVo4413dW21u2jR+6ZroZQ
dmKMcXap3EpB1oQ8NJLoTINmsMKxvkn1psYeUWLYlRjHkDAJLJkQbUJEfg/mKWpeHBNU/sMREZ55
rh9DpE6HItpyt2HFBy0CsbzxI4Z2HPg5kXh3TUpfliinH+h0mi1xXY+yhgxOpqFmGpulWiTIhPL6
xwviEMV38kEHI6AcLPAEYB1iO+l5UHVOtqlY2+xu5YLFOI4Pa6g/sbsguvH0KodqRV8ThHCSvrE6
oasFXOs8/yTfYaiXcS5Tv3qmBQmaPvTaNIUf1CvMEVRCddIMed2v9W8g2JUl8FJTNnTH9xsADBfB
BNkY8PXdt1wD/Mlye4XXajQ/Tn2VsCJ1Bz2h1y5zEXVObmFx08mn1zzZOeHui3FrQ4OfIFJECjcB
52cGhIb3PYnXcYTVlFzvI7E7J4tdOmY3pHtqmMmfsFzEfS9T35//x48cZ0vVN7QilEnAtOxcxOMa
HzXmqrkL4sR+Qc1J3UjJFzmT93iEqXlIRoi5uJ4HdzutG2rWeUoTamtqepNAi3tviFVDxduUeh44
pH4z/HxQujt82sX8Ot0squB1aPM9Px+RhrgSUm2L3CJ7ggod4lA4oxwn8A0htuJgRmpml7MWXL78
UGlLwY7M+6bogZU2Pt7X+zNutEkoHSMC5N7B1xbvSyjBz760GibEiabEtW8UrQ1n2TgbOj4ZVgvg
8Sgj/8Frctz9IURjY2z02f8hU8ztymz0OrDYiW1PTID6NLIefxJlU+w9Qj7RppieT1EzvpyEWB8x
SFKRwcMTiTPRbYd8rdap05aCdcL56W0hwgamY7k9N+icbhHCj3X5H6TQxhdcg6qppYAaklp8LPPg
bx63CFLBX2b4PW+ZH45ZWNpq9cB+kjoJHXUrqzE658FQKS2XasK9ptyZWGUnTc6uAcxOd/79FZdc
O4dy15AH+j2T9in8wZVdrfePFwjQTngL2RRHoZxuTvNXil62vLP5YFYt5UJfmFPZ3CrA5Mjr+JVA
GaCNurzWkt8x9Y/tsnE58OTNirPw+Sf1f6r41B4uXsCp2Dx8vbbr7j0w7Uo1rB3/AUV1bYvf1bGO
ndrBWZS1nvVt8+LGwodlC7TqNU4s2WfQTIm6R+1PIVij+3/8TwuiW8dNoxh/CwgOJOpED+AQjxAK
b5mtDKVcR36mLfRERK3Ea0o/xAFbid2MzqsGLISInDZlhti69qYv4Z8iiBl0QiYscBA391rJD0p5
LeIEKjXy+ONNjQUa5eJB3M69UUVHyBLpbgsho9wrHPcDTEt+fD4VgkeOJ8orXHgVDnibCIqNaINE
h2TMUzX2jVws9g6SfVaNm5KPTjhig1ctWVtgnJGFb33kAd0i7jJZMzkCN8QgpeEs/EpRLKAjAjMc
UzYbrHuJw2dAUTMsWnPB5x49JhiDJUXuy1d/Jix8s9cxTE5upBuVKXgzDBcBUPCTVjE761mjB8sZ
cyOm+/ni4CTMSxqb8kR3