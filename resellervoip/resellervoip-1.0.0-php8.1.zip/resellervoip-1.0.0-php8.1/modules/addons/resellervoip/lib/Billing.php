<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt+JEszMU810AoQkJ3zB79RiNHIAzULIlTCW3QKf4PeY6bg3p7xdy60+ZJiceAd9o7V2cK24
zr5FAj+Bc/FWTiUyVW1kQwIGL61R5Z4IJVepEhyKkinVNVfXbHel9SiUeVZQ125OTqwnMIN3iKwl
R0aA91frEPiVmgIE8P0xi9ymzsmppevlSaPmuod9BkW6QL8ncW+MTWPrm+2w6pDFjkIWddv6EEzt
tqV/2fre2td37ehe2ovVtnvdDKS6uvS2zVHAOo1qO2HjGw2+bBnj4hXa9p7RTViY2c8JVaJhzCP5
mxEyWVyi3KN/C9x2bEfVmMv/2fhKQubaPH0WOxpqLAxvl6l0HdU7TXanaKzQasXgqXn+Btex2V6G
e+k9WnOG3PTJgGRzAtxB8KxtWo466rTQ8LSqCFCaTwDT6bF0JjAdWA9yL6WgEC9r4a60BXh8zEvb
h3BoFb05GNBmwndrcDA/G2fq4qWHAXJhyzgcRcJNqaOYKoz7ZXWjcqDUS6deif84OpFg44U+fNDB
jlS5NsMttsl//VxxS/wg7H6WtchaESUrIGCqmB+KssElDX3dd9i/o59fS6bFTDUMomGM5YfOuinx
7fU6EW2b9Qt+wpgKXc5k2fzWRr5tGfp7nrRV9kMjRiRcbCrnTly1Vca8uDecAFIHGaUSzyl8LXDJ
RY5O71GCupATmxCaosofGnDkOl5hdYbHlnS/A0cErVqKGJGkciYqJIfqO24vJskmLpKPN3kcUebq
r1ScLwntzIBm3Q3aMXTenu3HjBETHBuKsDoqyBD7gUlZIbicygI/olzgrNZVxyIbJTv2tqfoh0rG
CPs2NrTFkUL0iDPKodnMAHCdPsKIayCDgiyQJO+66bbkc05YMlA37mOeTsifMbc5s7lxc/tL2XKm
V70cFLx10KqkgzKC9lxocOg1hMZGGWWYKU53SehNbHN2HVdegn+ZuY9nUEpEFxEM/cF4SCiqWe1O
WumOdRl2vp8v3Eqps3x+fL9dvGEsbvbcSBPeFJdqSqd6T40AUb3KNe/WVXu9/cMcK19aRPMoA2Z1
eQq5YGRoFLNwFz8rk3Ku4cHCbEHmf0RPuSQApl0Jr0WdPWziwTB6LA9pSs3A+0FcmMb2Ug2X90ur
vKB+nICnSw7OBhrWY0EraLjUAbyUdcKKgTiKUKGJ/b2rLSXRLwE4IHoOpoUk6U9hXoGFEdFMmdj6
r0hjSLXHJohjfsVIiggkMgfQ0DwvwMSsd9adJ7EdS6qSqcI22v1YI3idjn5YHpAEZZ9CQV62OUth
zxwuKEQSlgn9NwVdeUer0xAQDPUcOjl1K53NuksfJt+hzmUMRmbXkeTFJ1F/rpc4pqODY3w+uqlp
XABjQozuRWlUuxjisEGhqXNhaljA6oWOlcpJnxWUnNB9L9qgtUSsbnC9Qg/u2CwziHt1XMzCmZvh
sG0xXF1OluRx8sIMJdGZUiCK4kzrz6k8rIc+gWD1gUVYPyMxJsepd5W+poK3n4Krfb1GCkcjnDoJ
4I4N5BVLc0jQRpqvsv8xzbW+Dhizh2xJvguSehKqxxrpMSlh7rC4+b/8s2XPzDIOTozXiUzsnL7p
CoGPtTESyFHVoVBdBSaFOIRW4082jDewbbai6CTcIn7hLusARyHRktmtmLxktNyFMSD7ogFJ4XxS
ilpgaXkPc/rYIQQhXT+ALxJKJJ9O0xSeR1BUaZYIXPcZwL0VfCXzW5GvZJwdKCJp0JU8oOv59KR0
x/xbd8uY00hV/zE04PpKDjuotjVGJ3M4BsiWtlyNuCYJfr3t6oU054RqWdQzPidIy/08W4d9NpMI
aHaQxGrAUzVx+5hwu93eREOPMhi+1YuEXJAuD49/+IhCjdN9Wf/idLGenR6UUadbVdxUNxV/qkso
SlCng7l7Xo8KUSmr+2L/WODj8xVzhknP91sNnofACgL/okiT8Wc9J2WOoK5CucB+SvjazBANfkhv
e6fFeoWdShKG7x7ZWsNQnpXsNIL0I7nf7ddaGTetJBJBj2HzU9knyKd13iJJi2W1Eco3xfVuMYu3
xl8HevQFsHKEn65+4NH5WADg+FX+uN3J3blERC4gRVmCXAoJe9FADpkyiMj+GZc9OPouovsQkG==