<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoTbJVuGpxNnwTFOtKUm6kAvaUUhgUXMefIykI9hWYZPeTQ63BfvKrZxuzzQ4YAnlnGXuzRW
bHDvAjxadVkFo6fE3Z+4aqxWp/NxfBVzdZ8IN0cnIrElYxWrNC5UjI598kjWCd1OQbK1TnxG8dTv
rdR4CzjposW4puMlrjrUv8lPHsVFoiuambwLp7Ple3F5dbuu2/Py7K6+fzyQG3O1P7o2w7VqOs5i
+XJg5586KMpf09epGpVa2Lh8CKxlsQpeX+rujrEsAcr3eBwKl6qIk6GdCTjr+o84RvfQ+CO7PvAn
FaP9UoGDTJUMw9cJ66GXw3CRYicDH2pVdiUdcqeU8KRmqys6hOPDY8N3TLlHjwdeIWpVOkhIUO1p
e6ksNPLwbHK84Zbty9Y0u3/sBdSatuq0ZsPhjuZAAA1gohrJiwbq5qdKH4FvW/X2ZqaaSk58foIu
mIVoriY/dBxKZpWVRG0Cz17DUk6ob3vM2NbOx2JHh363kPeKmxq06EqpAmF4Ct7iAsBXUfq4Eo4Y
hyXhkec6YkChLLMFGw2hxhp3ifyaeSfw33NutM2xVYflY/Gnblu3CNp9vwG34uNn8MQViWN/woGu
Gs+/Mqaa+zrC1dqUOCylVxA54h/DY7Ki4uGAAQUB9LG16msdlUVWdh+sQCDs/myiAfyRgKlWbHY4
Iz1pfOc0u1JA+Emno/SzOPxuENUkKDzfiLWx0TRoKVrtBWPpm9M3mlfhQUewJfFPBoEt6VY3k3S1
EnVCvKT66bQ8z5GZajCnurYwDOQ7sKcozf/eYYjImn5kFhguuJNPyWmjC8Jh/t13kmMbn/WHJIgd
g0lrhjUEwz4nYIVDAm4MkKtG345KkfaZepBUH61n6D5zSkfRfKJcBP5jm3ac0foo57wmEOy8fFls
N4STMsM/Wp5EIy1qPlMtt0HQfQYkJ8ykPLRqzz7GGmWBHaYYpROHrWWderBnvB/pcsOSq36zpuHK
ntBxqDCm0WhEva+6lBTr3JGTvs3XzpPK9l26gFLtvYTBi9oUwj7A/T6XMKa17rMKEXJXjPwF1ht7
453OtRYYMRESGqYrNMj3NdindvjLbsFEoHkCVnRFryxa5DJ3G/l8/8c2+oqkEYSQLqPsGeVq36aB
WZvu5S8lj7PZmkIHxqX1pTz6RPqUjsPw8xyfz+VprxbRrB+VDIrPUwuXgSgIjtrqFJ8NgfKVybKE
leSuLowZuZJD929AtCXx9dab+aw2b9QhwawvQoivXSrXo+C8pcz8HFXf4bZnoAV9nUmR7zzAE36w
ZtT1/o/vpNDgtNz2NQxHoUdZbLZtE4GWBtI7IeyPKrstLvpG4PCKACyf84NUr7mlR/y1z1QvAkHz
TzjWNy8laKFv4Ign0qJ1jgf4NZdJ1LMD11wbo5b3VlVa5yE7Q0gBXiTiiNqRGiYxcpXsbY0qCYRt
WpedUUYp7/6iq+7BcpCe6Uzw4Q8JQz8c2t86iStGBmkKLY80qkDyxNHzR6ynKQdw6UkGvY5IpEbE
9BtATiE5CHdcviY1VeWWyQAE/lMiv12nWDht3O/EkIewrchJIq86xxP7o1Ecfaw5R+pr5PSIZUYo
slYM9+4lh2dr8RbgRtAqS+Q74KHfAF+j/8R6WIaZCmEdfhSrnr9Lee7H3gzaAC1NUQXhkmWLYTwu
EzzeanR49Nxwh9jf16Kc5cDvhv0coePW9YMCKkFOch14owlBw9m7wd7YacdjQLOSd6DM/jnxuRXo
TDZdJP50a7l3hG6/syRTynG7vR+6TOVssV78mFdp6hQP4AWD6d1/IEynSc1CDO3h20ZtMiMgpGVv
Ds9ZIThuepGJVeMsdsTLXzI4+lIp4icanlkS6nYDZGlB7rV9EOhLFO48ihyliV00XmaJwCTyP1Dp
MW4Agyml7TexH1/Y13s6bFLgea/IfSF3PMZRWvG5NNzOs9W36QJz1tLCVGG9HDlHIyUwVG661mSq
yejkJpAKSeysshhTyVppYkiDOByshLVjnKnRKXyNdIU9dshceVHsSNpe1fy9nLTrD+6/gWY8GyX0
lM/+E5Qdjt9pXJk6niwwVjDf5vdkO+TDbX4KdTEvEgzG34Z6GD+kC7q/+jVjCJ2EKN2JJxouKoNL
EGB6b9T8hWEsaX33zJlZ5BIZcs7qYXybb+K7jwoWeQOCocHX82NzpxGrj1yomr+FWjZ7zW49kiXT
bge/44Ueo5bFdjZbC3UcKKaYQOYnYB5WBRaICAck+/l/RUb+fqEzjBwSPuMgzW+OWADrOnBp7mLS
s2A7m6Hd4NxP8RuB4AO7wr9E