<?php //0032b
// Giant Reseller Phone System addon 1.0.0 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+g9L7ddKwr++Z/1MZrf7AYVIz0RsL3I59kybdPpJPNK8k7SVPuwt4eqyh/bWiFc0mcQh/UP
WaFhKcqRxAR3N5buouCWk3bNYviPUtjE1Nzqgxu1QQjd8bON8ltn8qC3p9f/7txODRcTJvUaaJO5
ggdxWPTDCQtqE392LfnyFjbijSpes4edSufjhKZBY/5omyXBMw2NdzSGA5wxOAiVlJvibyRsbCtf
kQIjCpEZX6++J1ltHggRrWKXsyemvhkU1I2xs6V8fMr3eBwKl6qIk6GdCTjr+oBDRHaJ2FtSpISr
5rT9UomD9Bv+ZAaVqRTE+Wro2S+IVV5qPgrtQfNAVEOfVXeK0qkkrxJDp+smK7Jjx9u00Qwq2mLr
fnZJ8yMevw0tSFy/WHKfMgKv7vm+qnuxz+XGptyI1RnwV0nPS3Y4mvfsuCFCjD7Ev1t3Rp5jLid6
V+0rmT8HXwHj+D/tjvlabmadvXfhGcM83aDIk3Aprd9sHercqZvUj4Tvq7svWoMQLyaJYyN0Z90F
bIY9/0yG7ZkalGFmAcJDsWwAsqtU80mAtZitXEykGCBz5vkfkRsAlHX5jDDX5u5cVvUyGezQqa37
5IzP3FFxwX71wSuNTTx3O33mD/GCW26b1ji51pqAMPSisBefksncQHJ+wtimlTlKv5JXsDP5gUGH
FK1vcxcEDsWsgZbCjY1TtubIwt/AxGkq4/PTC7qNzsvCkwHOVAbY0k+xX+lzlSiaH6lOUwrz/NPK
lOILfP4DYYU6gy3QZr4HTHYUHzS3KbYVPBTewuCc88OpJvNIELVnJgtVKPBjQiu6EbVcaH7Zdh0G
M2ObndwmH3sLq5859q842LPw+zIJ2uDghgjcHgYvQRPYabF2GWU+oVOENE+A6V00S9fOFKAhLtZU
rNRhHU5Dvd4QtrrTAUHUMF7MyQzPawjtRLD8vgO+eAo37jxrl1g7lnmKVbAzio35OuDGHRY0Dcjk
fGjosnJpdUh1q0l2c5gF/NOJdPa6iNMOaLOAuwrV0wErpK46E8E5Qm1L6KDcjCrVUVDO73G8c5WZ
geXrOA6fkUDKVOl2YUzZ0LhAD4gQwX/y4hPZy03GhvIcY3TNI0iY04a2YAy3QmYUy3cyRk2RG25N
8KTFL5Jn/Glq/ctJvwXF5qdkZ0/U+zfWUgAdLmyBLdALndUWqZlF2ff8PZIQ/Jybi6R7VacVxBaw
5bhbxR6/ITEk0Q8FBc8B+/O35MfVN9V9htGwK9z0DacO4N5Kul4BC2cg3RUKedS5QjZKQSvOVrQz
IQOmnrVcYRocilNDhjHKhDPfP1tZrYPJH910fV191luTvkCmIW8+swbeDIitSyKjFVypQXtFVGe5
IFmEzGqNxTGg/Je0T12QoFKrG04+Wzc7PuP+AJkx+gQx148J1shwXp/SqOxKSMUnt9KMusFN5s3l
Oh7CtbRHgZEUrEhfEL7/JyeZUSikW4EIqyGva1htXD+1Uq8tVgsivSkdQXJPGARqJpf0v1ii/Xs9
3XCY3u0IMmRVdQ8eRRQrz2i21jgadSd63mjRKpRntnrOiXm/MQXk722pKZgCCu4I70EnFNXMN0X6
4/lt65R3GFvIx56vAHbrtvr7oQ0Ikq3MimmDjf/LCkglKq8UuPnr4dRyOlbcqpNefmpwPoNKTtCS
dvesKzCCuYr0+9aq+1z6KAkbbXHjhXQpiY7wtwBYYmBfSa3MjqLTSCQklgOuNs+r5DIk9+PSC2cB
Mcre3hzJEXlusOMROmMdvGmr/6THifUeAQNMsn4iStaOgG+7MoGhB4cwsRfofDyxhIZh9IyJVXpo
CRH7pOucdknsjTMByTsrDNp08McBlaMY2T3Qwd5UBRCkVk/tXDttf+TTntoOYxINpUdA8dsuGjk2
UIoXl68BseSn+AzlaTTwbAqPcaaGojWiP8tU0L0MZ07IpvwpY+h6pXJ8tG6sPyzdih5oaQ3R6jZ8
LieKLYmz6Ugwj3fcXOYBVFZAKiiWy0j/kCUSlUu9I0pZaJP9Fho1YQ6Ith/8VjQ0pB+U67zq/OsK
INulI2+QJQXzByaN5tqxp2kUS8pv0UhQj6gGGFpVSrzijlWxOaxf028Pd5ymeysM1kSSZvEJhE8n
8sLZvfFo2iBGML6vZEVuGN7ePEuUmBIfaGimc2LfWj0TgyZKAkZyz7ynhcyPhDwnttJ9TYiie+AV
J7+A5CAp1lfXfrOfcDqJCn3ebQSBFhxefSrw16sYQ4jlsth19MQ3NjdM0Em6/4NjgnqZmtW7nTfL
daf/+Lt3XKEDvZU1ui6MpsOOSlZjuKK7do40pTn3vQH3+pypRRfeqbPjKixDBU66PbEHqcEjBkSz
u+FwSGmIKdMcIB/MZAT+4Ej5rjyecwIl7LnOTdM0O3+Z7IKx5+lA02TeNyQl+okh7fW6uDDc9daw
WKAnq8q5WvOtfL3Uj2y56qwHQwJvbydeh+h3irGsFocGhBi+SEH9PRYVda8Xf+UHDKriUSrDqzqN
KJTzkhJnKiICe8BAevybm9CaCnH0TSsUh22AQdSjrmQYo4Djc0==