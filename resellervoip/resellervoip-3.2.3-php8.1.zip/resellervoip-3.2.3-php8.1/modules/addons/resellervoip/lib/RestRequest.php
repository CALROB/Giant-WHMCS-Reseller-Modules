<?php //0032b
// Giant Reseller Phone System addon 3.2.3 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/by/BS/sCIumiPfbA6FnNfVtqOP8xVDtQcyECrWn5NPQ69Nd7Xm+DpY0WYjLL3GaSLpVGEy
v2P3XdDgLBlPQhAVYw/cJOAWv/oU9kpk9hGO7qjJ5YqWKyjqC5h8uprMNTNVFff/wygd3FFwbswo
6WftBP39bOr3Ff9GbGx8ibwRQdwJ8739f1Z0v7L91vgLZkrpVmcEUSBz0ilAzyl5odtDqJv0gwie
FljsAkaVhmS7U+51q6r+cOy8hSLvqyYTGI+0J2XURyCONXJ7go7EZv20uTsTOPMZS5z/Z7PBcezy
LcMhy+3CDVzlPF5OCFSJRYmTK+a55h9lilEn/WsnczBq2r+EmDbz66g0le2TfyQPM6J1E2SE+JDr
w9AkcOw4ibPveJHV++3jQ+wKj3SQYkQrXSACZqyN/5gmUs2g76mhZRbLy4i8CtikHGV0DVsbpMZ7
Y/T5XcAv+kwNlNdPipubdIcIqnx4FL55OW8jyns96ATF9l8Qo90PVQ/K3XZL9YITgpQU0eMnn5qP
4tggrPz9IBUcWy0A8H6yqe8796tTyIWLMK8Sv8prJt4lA+ME5nH01ZBK8VSH4uHjXESc7+lEPciL
2X6Gk/0IgdObVRybbPLQJ+xLjtySlvaKXmthu9pOW5BG8UvMY5NYqYYaT/qMPVdO/Wo3rfL32lAD
s1LLrf/MXHbckcqtxjgZl2yLZzTC/NstQEFe3ddU7+Ux2PoTDkIiQHEl5VLBS4HYfe91SC9UgdXd
mo7IYWYUQcyj6iby7CVJBtd9+Lz7O9eQvN4+tVPLS/548+7oWTT93l2mFrykLELmFeAKHdvgNcUm
IfAMV0XsHBgV89X0zUwMyjZhzNQOY4SCHjaJgohg7F8M1gwxN0TYZydq9RzDKhGeb+42fMy4t5Qk
8VqTptq4XhRH4gbVMd1h/0AgQIAIPDA479y4TblI00VIiT5RD1jvVBSr2l5acdrwcvP0suNkh2IC
netCHux2o0y3ht44skIX096sSXYxPwjpND2r0Tl0jbWrSw9U45a/6mA4KwgIoWTxT2g5HDklGVP5
LGCcsT11msX0ojI4z9d89TEQbX9/ItQqFNKWrShRzzTeSRDupXeEwg+j/OLYs5AqeA3uUeyBIt17
AgDvOPVQZWxkcWIAKwrea16DB0yx4wLTo7os57CMf9VxeJrICOWLtY1R3OS/6KEspG3Fkl+aehfN
fc5DjOi=