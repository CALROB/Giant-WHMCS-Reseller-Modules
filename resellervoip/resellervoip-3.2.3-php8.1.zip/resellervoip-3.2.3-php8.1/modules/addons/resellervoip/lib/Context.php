<?php //0032b
// Giant Reseller Phone System addon 3.2.3 for PHP 8.1. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzJvg1inNn5So4CzEBJ/QBLyV+e15rZZjRkyK5rh8zvPu79jkwXnkWPwn7huIZyKPzrkOUOM
liu0t8jyl0KYX0+o/7Cf/18IyJMdqgfSJP0A3iLt9IXTyQTmf4dqHLC2Gie+HXKG1o6E2eMc2usm
7O+HySRx38VAYsUn22Z6a6Vu9L5E1mh6j0FKWX3rvHn/OaRdYKMhOJlFLRO+NX5U4vXKdp3Y2b0p
cH573ecKk3Us13kRBU6ncahq3Xmws2hN4nLniP2XPSCONXJ7go7EZv20uTsTOPLXOdR+5fucNhLH
rzbRzU3CGiTFq6D7IORP5EoYOhBlaGoq9QllKPm4cv/T1iGRGxHTCma/+bvQIryAgu8wnPKVXVBi
Z+X9M6u+oAkFQjRW+ZLoCD9ZncIz5mI87hPjMcAnEZBTeMMs8JJrMX9mBezrST7+dsX2IRc/aZVK
b32jBlouB4R4Z/QWUzyQ/QQCM2BJlazmiuyJyyQIbbP5jymNeIML1Iv0Om0QegJ7DQk0ij5zYTd+
s61RCgSqOrlyk6K7OeiCG2IcbCiOMJKBVpJonmZNBewIvJyuWZz1DozcC6tdLi+kkxUBD0LwOuI2
T5Ndx7SFUJfR53HCQLNhdrbeOQgiAoMVqBRCQtwf3mn/5J1zQee5/qVqpgG5mpFnBO1Pt+U3ymwf
WXTMdGj6h5vhOQMbiUr5Ua4P1tdXufYkYRZgvanz+AxXwngZ8unGD53iJRi1vwqYssED1wZdaRcs
8okzMLKBn1Gz/guozV/woheKnDGP/osTaiX4iZHfCcB6zVG3OSx8kmy/lp/L9mHHZ8Vl4vZylkjl
hkx4Uh3Z5mIIXjvQw36z/S2PWhGaMgbCJkzaynvaUHCLvUvloBEdhC8PJyXqsgRW/1FeCHBM+z02
7hF1RmdqAJEKOOu+pCnhP8qpmz1QXCg9j19nINWan4MFB/NV5qWz2IXBgJJM9ogNlNC40RlyhBae
jFaxc8qZFLK8yp1yPKaidYH81nI4Bz46s2pHf997ke8aon7wnawtNbE+bjbYXxadfLZb1L/vzouS
Nxq7Dn+6FgMGwKWkSpym81WNZBH9+g28WxBnzam6XlYJNu0Tz6nKsWSeuHKMOT9N/qCv/CM+9Tpp
vQPVyFfmcrp8MtEtlcvgVev8HzilTxg8FlNa