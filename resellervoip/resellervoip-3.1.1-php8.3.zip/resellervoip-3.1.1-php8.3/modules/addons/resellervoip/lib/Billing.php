<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnhp+yMAMy3gLqPkvg6Oe3F4UgrvbFGciR2yFNBDxA8j40Sgmhsppl9f856AQYQgAVOnqyCn
UAhvFtN1shEjw1MtQd9WWdtpLRHGG3lHlEBRvGRta+bCUfgVdd4TTzbtX+/c/UxXmIA+nQtChKl2
x03hT78xEXRNBiQss238ixz0nYBh0lYQT1jm7Gvcze1HAV2r/vn5qnlJ3wUgVvAgkddwFnKKBdFg
AMkmNdSayZlmU11aIitxlHCXEP2Ongv7D54hPJ8KumWhlLV0yVB+iflVPyifSI7QSk/80oyoh6Ad
Qw19Rdvj1PXR2bsJwhdMBZztuc46gEvNjCZx8fyPDmFKB3zaq/nvlwHJ7XfJatz2MmJNiyVm8Ytg
ZhaWl1YgmOVRSs9FnK+nH3yBvLpPB9/iXQF/xJeoPF+Em0vhLD1dE1WQs1kUNikainOrtyzgBsES
GiLafcu8HWbc+nEf3CiHV50PhmYco8KRLxvK6s3dmcrQj2RLWYTgkGxwET1Y88NREMO9xXol7vcF
mz2nR8xAT5/kz/bx17+NiIm/7FaLAm66OGI1pOb26DNbxutfVsgtEjo2aXpuJWf0QuNlwEcAxxgK
5zEXqz0cLESK3k5gYSbJoJT+SutK72M9pvCTBZY71msXw0Tdmz0i/wEnmUr+N0LtApNO5XrXo70e
SEFKRYRUty+tnl1TWAG5V/cq663LpCW6mlskKaPDdMCwy3G4vb/SmhbXDSNceBgik18ue2H9ElWj
MbXjtXC7Lj3GYUKKnht7pAWT/d9vNKEaORUjwm1bFy5XG6NLAA/d/EtktMFwwXrxfqydzaMff0qP
iKz97S/OV6n5rz64T9CjxIm8jWu7ZniBK1v1DZd0T6UiBgbMiQg47jpyuP5zovbHpMQmaQ3aJw8R
TGRb46XxaTdeeVntmmCDZpfrqaxh4LNgnQHXj0TxNLWRwz0abAdXxEAVNcdG0iDNQUDqNOvLQYsi
jhBKy4MSKVR/JXI9B4JnS12dfjEkiLm2q7zciPVo5cavLeRtj459naaZhzOcI45CtrHqJGHK1iSl
5CoVZafMH1h88Oo26p0xdBV0oczyRC1dXKQ+MsJ7wiyB/K3AjT69mRMkyOevc/3eEcWvzkbGmuR6
Ku3pvZMVlITvBa4nz7HuMNpd+xWOA68eWBiQAlpRtTM6EdUKdoSa9O9lji5sUXjgdrnL7McIeXMw
5RkcyWnq3yR/6iL6vnBAWEaqXpvSK0JCr5fsUDlH+bunLw/Nb0lu/GyS7CVHdNg898ALHxb3OI3R
kgckBCxb3lwdCJQRUSyMOOhjJ5aAX7XqV+uS9AZoDtPDwxoJROs7enjxz2xzP6g/bczwyMzdGKzp
xli2WPUZSTDvTmSTQzl3wzC9dQROPWb4Op1RXIV2n+vTc6qi8r2oxHtvs8N1iQUnXqK+sF9FMy2O
/oBhmFO+kKlRWkNiRa/xEfiQwA3r45RloDuYCWkon00VJ+9mVQQZX1XXb7s54/RFABVYP0Iz9BxP
/lDXcZbQ5HWJpf5icrYlBK9W9iOOCqRobCOJAILrwdZszgT/pTvxGSZ3025uigaFd1kw8TwxFYxp
Z3NJXhk0KGxkmfpbklclD0QRcyUMmnfz/E8dLXKPeu02YCE0/I/tqtQ0FcJAn/V/DNdFwiNlwshw
IspPwOaRYXJv/mlHN0z1RJh7sLzN/wRJj8sK8q/R6BMWV7c/0tDgcnTovQhsRJ5DqeC8cuNplKid
rN2jfVoDGxSea+RgJl6QqBZJ5FCxz08xsNg8PlW6uO4qOdFjU8ykQty2aBuWnlLqoU7HDKvG4j0F
crSWljrx2FkGDCAj29E2IMLBfd0WRZHTrr8A+j7/lZ0EEzT3bU03SQCsAPbvlUdxp5GFDQ7AFKTe
MygeS3UOJPxFXRk4z57xnqlnZ8qxKw1KbGOFbDnd4/JHiQx+siz7b/b2eGwrxp3PDdSn+xL5g0Ft
/fVwte0hcMmk3eKinZ+1Jsqb4sD90Z3cx8wvTptcME6xMZNWtXfp94tNG21R1yd5nov1Hn/2Fduf
2J0q55pQZM7g25hpNfGFIfM2QScVxSiDwDiVKjJUitbY1iK0ohkxd2DBQBOgXph6JVBNG8+K2jwC
Jek/RxLVCG==