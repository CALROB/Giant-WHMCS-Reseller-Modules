<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzM2jweJQWoDxZWYYIehRJF+ITGVc0M/R9Myg0S0shlVGDv3eroEJ2B5tKqpm1aLPNZtCDjk
m93um61JwecCaW0gcr+tDK/NUFCGmtm9xmcKKWmQmeWAfq7NKXclTLre3bs85KQeYgth/dfhO+mD
JcucVGY6MRY1UxcWPaYTxO+wrE/iGA8ayZ4TWw20aQNfP98jXIZW3MljDFuYNRckRmmM273iOIfH
sRVKsgnHFZjSJCwy6HK3QC1AQrcly+ijva456wJ1RWWhlLV0yVB+iflVPyifSI66PpFXZE7FuAPt
nCg9S85jKo5hwF3fCc3Yw4oyICAVJwBZuGlPzROrx5+SNQ6PbX0GqUkJcpKGZ8H0YTFuCmZr6kXn
cAEZavLrSym7n5HWwRqtBKkzK9Egfodznlns3/4sqB7owbb3hLDD85DTAOL3tNmVZ5diZcDlZOLs
hWWjqBMPKMAWyo2NkY10KaPCWcP6FYxg0sba5/6zgybgvg8SaDUuSTTiBTjnJOka17aiQophEqkc
TyOIdukb0tBxJcl/uwgr4sapRH3/Gficx+S+cjTUTh2qkzwONQsP8KePKFV2ndGamCiFw55H/Rvl
np8zPSLQqzKcr2dNYSWYuRqtu4OkoUYhP/7XK8iGznajknyvYhiHMuXAN/JunRiUQMCwG3TxiIA/
WbaTlZa6jxhWKCx/Pue2eS5ajCgHtuk7+kRlVqpd27CcAAZ2EcTJh+dDN5QvLxIvPOBxE7TCK9HS
31x6Ain6Wp4z0gkhyJDLkJgOO6L08V4OYe5Xde4bJ7Ub2VCtCMSzXfuMzbWiokyZ5qJ2bYPgmbhg
Fb3BlO32ORJfRnDMq9Tz7sRHL0mGBnp7z7a9gMOw9ov5XFV1vzMPY9MSRtjwRmdgDFw8xUxfhciM
bbfRtcbymsX5uFVWCdsa6IfCdxLdNA8fS9DFjyOd+vcIOQF8Qi2AMstpZac2XZ0fgniLdtk5x8G8
ZYGg3srorXk0dIULfpB6WISJcAu8smRV5TIaA5NBprBikUDceEogTBhJIBgT3eWMZNVN6QNjqBQf
5uH1fxQWwbdDud8kO3hZtilHcn6kGiB4Ck5SY954yQpT5mgDYkI0FLAVsaKGrhcgrgMejehzvrE/
//PgrcXeaQtkAAh3dpABdUFSifQbMC1OVTrsRetxP//hR2o+ZK+kHul0p/SRPEno8DhHBKxxta5W
fE5UAtC=