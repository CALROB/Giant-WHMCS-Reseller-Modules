<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 8.3. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuxGBW/T99CWd6gxB2jiZGc22tBnjz5t0SWS8gwVB3tBORF/PAav+y7zB2VoNRbOh5ViMO1a
hgAVu6WHVSk+JkXw9zbfIUABSLbjUUpbazXjbERHgETJtA260l3qGrw4UfoVIwAbWhGAVtB7OIlc
13au4WswHbpjqgAdSk6tBjSX+tLYzHXRAL9D7rcrY03E4WicUpyOWGZjqTHMe6skjm4lvjCerAjF
z0goXq1G2B6akWv9bwyOocLIRy7KSYmBj9fyjVPhnUa8AxrNmF7o/hARtsVBAN4X5srorZ041BFb
LkVQYN1tRKlvO8VffJgRen4TCA4m6wUM5ltj4TOkzubmyFqh+VqTipA/bVwrVlakt79UK+vaQpft
v5ICkpxPUxxC7Al09dzIXnSnTyKxE4U0PHOuyvD5e4Gvt44PZgeveXUh5adSsECmjjkDQTc8Lgjs
z3Ysi8YhWdbw426czZ6Ha3bUqg4CiKSx5b10hwod2zQYH3XIUKbKZNByLS7j9j2yHO4sjyzsKbea
RE5Nv+JR/YRzS9AZvcfCTW8UQ+USkjA/XO6+JJV9mSUz3CcE5Tb+UU4J32Gj8HufLcb0oMmwJjNW
n3PIvrLZ5NckQ4ok9a/WYdiTpa20y6KwwjbLATxcYvD51PiTZRNU1VyJTnAgTajOvf+AdLEIihoc
eaaT1q8O9w+7/r4boObQ+9kc4Rp/7t/6n/mEH0Vqv3QKjgZ7VzM8cwjHr7O/CJH+8I1TmjI6QJux
4kiwG0gKcFR9VgaVTknOGXrfwjrj54bUe1LcW69EbiuzW1GbtECILtJgbXs2uAA25ByOJviMOwPz
gm3fkXw7Esx57Y9ax55cor3ihobmGKvO2y5lpNYsBhPr3z9qHWR7ZZ4KHmMkRgV6jDPz4wksou/0
L0qJPVY3tPfWtN3OorE+Y0OHgGGMvwDtZpdeKFWYr5fQH3ssTcScCsO2h38DVDWxrKfpHEcVnVgG
Qu0rpDlzKe9FlAeQ8AhTpFo5uHx0iwq8j3XB4KWWaJFfOSaXZ5Oz0x9/Oizlcc9T7W07XeiEcSs1
ZPoZC3RDhAt9/P/toOZ0pNwjJ2R8UvqWCpkBXYOadbpBdm2WMu+J6DdLZOcDGr8+idSdtcdr6GfC
EisuWrWE1OElkPaiQjjU7urtystYNWaTnMYc/001YxtE/zg23m==