<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrI1TPoILaxKRplWlt7ncshiE1X1IEeHYlWS3Hx1XVQZI6W5eFYT7edaubOHW7iMCnxCCNw2
HjDxYHMyY/26pi/DYQvbl2PUGctLNWrBUjctvvfmZYYaIO492LHVubRPbK/YhGNV0hMCmrhJGzbS
19a2gnnOukMFiaQrcvPV2Q6g7sPMbTtfSuWNE0/OMsjpaVFp68aZQXSU9ET6MAmJWXJvWqNkHAaN
s8NPNF0zD+T4mvkFeoEMa67/xuEcS7cJcV20OgUZVEgHpeq47GAjn6LGVrebnt10pEjg+mYQ0HPh
KksYN7Q38mrZ4uZB/qcQ9032H38D1p2gTOVCOno3B4dLqg8lw368I1iHiH2P0LEcd4n+fM9HmwPc
0eaioH0MICjrxOxcrxw176uKQZrnA4qmYK9GXumhe89ihr/soc3yXqHQWOcSJ2CRWWGgm7zvjFTl
dRlFWxElZxWZksUboVomziqPFUg+G8r8H2RpmhykXqo0cnd2msVkl11be5th7Faz+Mi+zD9MHz06
KuMcfsnAYTnqIpVngcQdzvp5QVrn0RKv+1Txzee9p2aR5mmWd4KB51QiD3yOl+uXUzlXAdTbQLxZ
EemVqpJSsE6vkmk7ExAJw2AQYNDj5U4xi+woP+d0BX/uwHXNNCUPYzt0ZapfbjjX15OinoYn2pKz
Jm2iI+VdHYfD6Q1makK2+2xoP5YQQGqGbJzLcBZ7uC8n2l/UYzRg/RDzrKVCjy1UJROJglx/5S4c
IyI0Fe5ZQGWuSVV747a079u8E9op0Ud0pdrAXMlC+90F9CGOJ+XcGipq5KAgbrdzsuFnJnMLxdp5
M80f+py58ZXlRiV0XMG6Ph28C9w7A1QKezwnOKmrcdkQ3ITCvda4xAapcVzr7819uRS7oO+t3IHp
Oiands1eunfnzBP+qW1veL2zBEwbqT9iDKhzO7v9L9TbdYkbow69HZT0cID0+evPPswCicyLLrl6
HUvIN6aKj+8vuB9qwZz1f87y2sUFzK+URoCtfHpM/HO/4C3nWcykGB7AtvPZG42Qdh+aUrXBK/IH
32OS6K/8VNCnqM7F1wu/SJsaHhpYa9WAjeAUTZ+TdfMmtpBL8cIFZEwQ4kFujveM8FjcyCquyq68
R4N2iS+X8ANUYrq740z77lS4GwKly7LIp3BhThQ7f68OcXPdCWlBW6X4hrbP0EPWyIrYoTFp4k+l
j31AOMe=