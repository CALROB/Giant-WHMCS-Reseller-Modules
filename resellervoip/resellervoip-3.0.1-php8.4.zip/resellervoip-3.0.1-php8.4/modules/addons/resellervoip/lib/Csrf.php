<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzDMqI0BiYaNrk140v+3bJb08uelLinMkPyx/VgvjPtGjWBdZMjC3AKsBbOZcgxbbCTllBQb
OIRY1mSKLlj+cTrCddCoQ/vv+0YgV6EMMmgb4ofw/Fdy0NJXNHPLSB5pKijMoyodG8XSCvms0ug2
rvGoQnm967x58AzXIDXypR7c/eaOgQU7tNDxWDFP/JYi3pCQzOr8paDzOpSi5s3RTKxrNiZe520b
1uFTjmGhWEKtm5qES5nOZwSX3aLX1MS5gr3oTJwM1k0zg5FEZGGT0gt4PL1/MYN7S43C66Pix1aH
hCwXP7J+beGR3KGURbXBBca7reJ1sU+stiSpNjc1+YK5zqbyC+IJexPwX28H5BtZHfMuALZRv7sz
0zWCl24tiUjXaIjTB5t8MW2zpb5RX8U3/zI1FaoCDJZ4DxHOBDcrDoJoNW69HLhVAbZwDmXhLiba
dRycdcokZB2cQoYGmJf1eUkcRh+zwv88QyCXKnQDMAX5pBiYNgEYI5vwHs7g43rU+cWrDPWffs5L
epcWkM2zHTeWJCac74D9fbRgjYN7492p8gUn8jHzauaa0uq1tRGPO1U7VMOz7G4Cds6QKtmT20I6
B47tyFoxTR3OEUspHtLJNIgvAx5qqiAGY2+yELzfLm8c1CWanZq9zxerGEQc99ZsCTJGoEacKumn
Z/QkS7rQweqQEhX+o17KXpwZdq5/KLYruzwk/cHVrjCAAgmM/vSBkJK+S8EmdyAla55MBzDNlW8j
u2ReycQqU3JS9eY19qYFU1VRf/BJ0OA946k2QP41ocNAvIX+uJ026OGsVtmGn9nR4tF0qaF5Ylb+
ulrPb1fpCDwjmtIuiY7gU82Q/lmqXTOdjXahnbbgMQHr8b6W6y4V0Xn6LZlXbygYP8Z6fTiN36MQ
S2Y5abaeNapn9iw3lcdj7CVseahM9OYGTgw6pichbgmZNf55LXDN/Sm7ENs9JBV5RnPKHLZTnK55
bczd5fHgZS8bugS29bswGvMzcC275TxelWW4/wqktPe6Bs0nbtA0IeT/2NZwL1T3guxiYbRQWe9N
i8oopEzrVWsm8R9YxyUDUB6jgpzpfRMpjo48OZ+rcrYZN/VYbqGxMsDf+SOw+rqsXa1KM2gOkZvU
kCrn5wv2490/mF77L7E2agA0dS4NkhSl0yBQQfSvNFC3UYG1W+DoBwall56g5eYradJwmOENtX7C
XVieYZBKytvv+y7BMOmTt4iWdzIkEp5aZHE7UvN8hJK+moIDKUTz9LY86TzSUyECZ1d5lleVZzwK
HEx4zSv9vgFY5MQ2QfreKN9R3qjLf/RJwielbKUcj8iQC6/kQGOfJZhTHDGD2ZzjOrUMCzYITHh/
QQk3EYiSMFPEg4aTUIfhZa93v/HkQaaq9qJ0GvRLsa0ibvdHpanaVyjSeReVIy/Efdx+oirR3y3S
9XT6okhddTOxUgXzHyUhCuqUpVE0sbBhIYU/63OVJF8uXKU/n8fqxxKruKqiVetg50QYY9b2RAvj
k1JCOlbLt1TfKXUzCnfSNcys5Ql7xT/04B9q7AV+PWyoROeY0wbt7yyj9wGQ0FwcdoWz/woQDrP9
qvfXJCwDh0e1OkCiAxs2eAYXMCSTH/csLhT3rJT/pFLYYABvNDTcBNdDfDJR3eFUHc8iZpamOTvN
BkcU0kjFmXr0ToAs2/jMEp3Tcd/TsxDeoOAER/+4UZevZ3QmEqVmcxLL1b5WU5TzQpLgBZLitblB
61Pli7RxYgrPSF5cg/kLljIBDdsY0K6iw55o54DuzY+DMsaG4wadjensz0y2rt8baY8fltRh1yMB
xwcbIkzZVJ79EHz37gRxRbSjT+sr6halyZet14OKWImZUB3lqzMRsSWgD9W3meNouU2s8UYsi1kq
NwtR6Nn3gQAFuBlb8o/TRNeM2jA1C/GFdQFxvhzcvfdLGEMJk/v4EVk0Cf90lyKg3T64ZBjAEhxH
HVCZZ7KL07NWRRWVuUBSuZl55YHZsU2/MKmHrn82KtaMyTnadua3i0wrtRq2qzjZPn8W7MRuds8h
qtlmcfWNeLeCjlnD4Q1fSQdHK9GCx7EOo0kue0rL6rsAmIPDxe4Y6Rug3MEOt4e/c7Qr3RSnu1sr
Tl0W9AQeI29NhFHZw4/6iYO09ClDeq3VY2ym6GFd+93bXrd4/zFAxaS7AhghbCBHgTF+TIQ5XHK2
CLVvWg02YpB4Hl32aRn7sprxc7DlmhdGIc1/7uoQv596v5XWpxfLx9wnT4v95f8EUhoItm7Vmtp3
2El+N3I/C4pcOxCDkS4742FaNucjnP9wn+0IMWPgFpLnOXJSHgL6Hp2BVtehVAwpMrJh4neJiGQ8
hKecn8+hBZ76T2qkHz1GbJLiUltuY3bKGSt4B/X3ot1zI9sFToRtpsRdf6qDIpZfuYdFbyw2sPSb
OJZAiFsEy5kY5D+vug62wVpAfOHuSn309HfnNnIAWrFleD6y+oAsXAqW88Z/HJvMvxGKqE5wIcdF
5B+54Q8jhC/tQYHH27/8nRmnlhUqaNP2a2r66HY475IMPxnrGQykdLyJx5sjsV/x+9O=