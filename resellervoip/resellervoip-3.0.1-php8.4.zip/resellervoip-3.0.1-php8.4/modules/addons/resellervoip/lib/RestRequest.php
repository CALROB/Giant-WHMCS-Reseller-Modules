<?php //0032b
// Giant Reseller Phone System addon 3.0.1 for PHP 8.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy3uOhBkN5U6yqBtaO1ufMau86PT8KJ3rkKUd6pC7TWhmM+m8wpjfk1qis4uNAcw0CzexkYD
2DEJ/LK4a9hrVQSepRdzD99VW5HXwSWRn9sKulcsx3r9UoxMn8GM+oCLHkH0lkpcwvi/Vm0/iKOY
JJ1rjDqOziUbHQwptBgkqn+00f08plIYVMnmvdQWjtZQcKVZYuDaog/NKLco4u1ujjWwfEiZN2vX
cLDjXYjRt7GqO7HsZYTdn8N5PkxpfwlJ0JcJPVnRMOSFpeq47GAjn6LGVrebnt10pBHnn9ilyyO4
VycIJbO2roa/OBQtxJPfnS4CAaBcCtYWK8gaNyExO1y+uYuKORK7ZosB6qz/Ew/wchIGMLbWUdQu
0jhluFj1C8L8qyFeIFgk9UXabpsBV9TmZ8NnQIjVZTFMVRXPqevGkysXs7J7fxxyt9zI49WVrFLu
yerfxMseXHTWNoG9mVK9PlechX6Sw0ZB7tczEjOGZuShWmH1LRk/CSGQVBYfTaZ7TOyJFWuGjE7y
5FDkf+rdIsH3PmeIS/QB2wI24xnzr8n2SeRiZMDd0QrLTbWz9t0eJEgUXI8IN3+CnkELDbmIsBP3
00YlsnCRVewrLZHOeQ3HMuKD+mnEE4E7a3tf06mwokwXQv0mRmN5o2RrGdZ/G6oGLaSiPSKezX1P
q4Fr1/oWZM98q/u3g1LN+kuonqX4xpiL23ARl5De9oGaoyY3SHENm+A9bsB7rZSI+s7zDWqjDvGk
NF2+sXe/ikpcY2fVvF3kQSfaxR5JvtVMZQkOaJVWjlyXgoHvddtCx/bceOdPYmar9jHZ0vW7OIHX
dSU/TtNTrVGfqkrhIDZ6WyNbXMfkwm+i1NvBAuZfFzdsV+4WB63A8zE2HnM9NIzvWxoTByZGpXa4
NNAHDDcQFZS0d6eB9sbdlfO5fc5Da46juFwvY7x9N5u/9bcf8KP0avIU2x0ZuNIzZ1IPJX29S8QL
UQ5A3VVIjYO823yTYMvlEA8r4YLc521SojCiDKE9p5LaH7ufeRUaQ+nPNgjvp2kKufJgPBMBnUgQ
bTLWHmwQJi98SlRLBXPF6Ue30hKdaJ61aQ7f8+vyDavEDhqnKJ+VK380Pbe9ENZzqPW42XMIMV+N
7jlLb8U/dCLHsjH+k20K8vTlMFEY14gm7QoF/NonGVnpcyctl+NrGi4/aSQBIG+MWuAFzfVPyubc
gkr494sqoSEyC4zQem==