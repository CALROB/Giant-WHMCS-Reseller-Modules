<?php //0032b
// Giant Reseller Phone System addon 3.1.2 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmkG0eG/P/UhmYkNfuiiou9DoDXidu7FwgYyjfdlCVDwmfR28XArpVxFw1JJCpZnb5AGMATF
RxKe5/NQCKuXH6uX9p9aeyPl6nNNvgBCVnE4k6J2o+pkaKDQqXqFA1VTuBNEfDPVbsP7WfuU8KS4
i2hPzMccRhWmSjwKmysk3olwZMNt1i3O9rZAGOY5fE5QRPLAWuaChVzwp6rcKmGu/Td1PFevu+ZM
JOh/SfzTd6rgtzkx23kNYrFUf4LPJJlAKakm82KVRPGFB8XyuM1cSxLM7YurP5VMR2SIMGKSoNf0
aAKq5EaN6Dl+VC1et9MPS2gTLQ6mvTwIpjpaWIV+/t9mRsANCIFgD61348geVEZRqZtnkxouP5VG
m6kDsWAiRmQ/JT6Ha57yFYn3DCyq1R5UERVTOG0QHA0ipVk0db8jgvpC9XIDeESTWuBtyoFgX7Y7
rXks8ddbA/0IFPbQjqrWApU4JoHKdXL/dVW2SSPN7rgtq0xTPuQYoAaQbJBY1bJbFfJ3VXnuHU1U
vT/Ujbf8h9T2EcwYITq4g+2mTG0trupe2n8NcwViMia/tGLFuSVDma4Ye1Zr8dlvYuIsjtX7C6EO
CqiZ/WgQ3A8jwqn5EFhIrB9C3T5unXfT2j608+U8TD71JCCO6j0N/yAwKUbPz97WnFMSbPI3bC3E
jQyUWIf7JS2bK2M8utIZHXyDgCxJr4a6mB7MJdNqlfJ1YTg7vrGeU9L+gTb5pJRzUHTHZUCw9GdU
wJNHxLq9TN6IFPbw2Wyn+KWZPRcVMxOiu5esRpSOQBFKp2EH1knsQa2oieykoE4GD9UwexzXThqP
p2Zw02yJr742Glc8XFjHZg4VPzbYVF+A0KEm7wC4oj25sLoQTAcCXa/DHVK3xYDRECdevU03utCK
/emWac2A7+3bZH3rnwsIqGyE1jDt4smUx4XRpTxqaLVzib4/8l5Bym4+g5NlTaFp1oi5uJWVrFr+
hYKOeO/ez9dNJmCsDoouQhuKYMaO+KksSmQVO776m/Gj54I9bOqILOQow+65JM3xpTfNBa9OfEMt
L3b4fMAvkedFW+Pga7uWTtbwqVpt2enrMmJ1yI9OAvEtDd78ecrum9q4o6oEb5G+fbizsie7Uy0F
Rhaq+E2/o0+hwgFY7m4e3iUprAlSS4SnDpF00vww8Ti3YqlIdq9puhjIeLa3w5q47JjgpM/+747S
x2RAvGlrnjpEvVWlpxPg+iTiaFkvnanJdZGBGrQywawXKoWhCm516dPFfeeJ50E+AtAqMsvKoW==