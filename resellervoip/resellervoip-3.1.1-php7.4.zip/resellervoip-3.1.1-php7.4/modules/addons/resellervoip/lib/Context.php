<?php //0032b
// Giant Reseller Phone System addon 3.1.1 for PHP 7.4. Encoded release; see the setup guide.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyXuPuv3trkY7iFohN2bQLSI2Nt8yZluAfEyTw6lhp+xYbZTc5VWM8zpUo0leRqmY7Ij0NDY
MJDESlUZs+94QS3tefgZ550XAnkh0tbdY6CXzzuvBJe0ekJCX4HRdme9RD2px5bIp/GBe7/G37kP
LxroOduO85WHk8cdyNoA5cfdLCgqR3kJRu8oDcIgfLDhzgfN5aVIRowPdYCedsYnKmFLTpzaIVx2
H5UN2LlNWJ93s4k9gPuFB+GXE0/ZMeupeukbbMRQDKmxUcLSKtPpqDx+dficp37WPLET9bCN7GRe
BVcEQIVFGl+8MoCVvOMoRdcMqcaHneF8vy0LyN9deshmA9JesayPLKhGuXu/HrdIPeWShn4xGs0t
RNLcquS3/LZLLYbLT2cvhs8aKEkurT7KVP8OGTUclUdjramdxr2MBslrObs1sC52RwhX2D23ll6d
aQva9SAMy6JBIUXKTbg/pnVCkvLENzJDzgTyE389JZXIS/5kR/TIR768Xb3zsjeNwTJ2sG5Oh73t
/IswZcDPSFfuU20AmjNCqlhfALbFkMgtD2TfRKbCOPgK8OJdkaZTcRv7gUY7549KzOdhTKVQCYl+
qgzWplECfS/N4nsshsMYcw5A++e5P1/R1sIpNJDq2P0sBgGFJen2DFkzTugtmp+i3Vy9dn8anE6h
exkWBdRTU6sSQQ+X3CsaE3Jw0k8GSDjWLV50Yhtr398Wu5EiZC0YVvqPezFR7nx88IgVsqnSBJI7
9uyANx2/DH7lYo3zP7fzHGnV+5PT9RSq424VQFm/VOY/j9VsMwYxYHb04pLCAwOJmJLsoNMYdxbe
TMwWiU5PdA5DFLG1FXLW2lhlbITSUuTE/Y9suACJL4Z5uFvpioQjq4o4dP96lzOky945g9uzuWBa
UuHpMNWqum95VreqwH6jAiqb/+FIWtJ39jwcNcxTNTgscu5tpwRLYUm1sOaK0Hx7xwgiU4kLoFbu
kY2bb/XlU5lLIX32qhgPRerTzhY2q121HyjK98Jv0tsosRonCEXn/erMeKnU44q9wo0FBsGq0OXy
gQnBRYOXkEWLnCCUxdTCIaKYKUkxVOaaoBszGd2FYUuCt4GpyC/rS5xsoJt/dTl0DU5ROhqlDkx7
lAEPQw3IeJ8FGu3eTsLjEIrviU1HG3ubGg1EYca77JUpHZP8pEN1ESLxIXnrd6d/zZlk43a62A0o
r1ShrV+8MzHnkeyMLxQ1efRa8lb+vBLQSyPIoO4Ru0iaTT2rDMaLkG==